# FlowPoint Backend — Render-Ready

## Stack
- **Node.js** + **Express** (pas de TypeScript)
- **MongoDB** + Mongoose
- **JWT** (httpOnly cookie `fp_token`)
- **Stripe** (checkout, portal, add-ons, webhooks)
- **OpenAI** GPT-4o-mini
- **Resend** emails
- **SSE** realtime
- **node-cron** (monitors 5min, audits planifiés 1h)

## Déploiement Render

### 1. Créer le service Web
- **Build Command** : `npm install`
- **Start Command** : `npm start`
- **Health Check** : `/api/health`

### 2. Variables d'environnement (dans Render Dashboard)
```
MONGO_URI            → ton URI MongoDB Atlas
JWT_SECRET           → chaîne aléatoire 64 chars
OPENAI_API_KEY       → sk-...
STRIPE_SECRET_KEY    → sk_live_...
STRIPE_PUBLISHABLE_KEY → pk_live_...
STRIPE_WEBHOOK_SECRET → whsec_...
STRIPE_PRICE_STANDARD → price_...
STRIPE_PRICE_PRO      → price_...
STRIPE_PRICE_ULTRA    → price_...
RESEND_API_KEY        → re_...
FROM_EMAIL            → no-reply@tondomaine.com
FRONTEND_URL          → https://ton-app.onrender.com
NODE_ENV              → production
```

### 3. Webhook Stripe
Dans Stripe Dashboard → Webhooks → Ajouter :
- URL : `https://ton-app.onrender.com/api/billing/webhook`
- Événements : `customer.subscription.*`, `invoice.payment_*`

## Structure locale
```
render-app/
├── server.js          ← serveur Express complet (~1400 lignes)
├── package.json
├── .env.example
├── render.yaml
└── frontend/          ← fichiers HTML/CSS/JS statiques
    ├── index.html
    ├── login.html
    ├── dashboard.html
    ├── dashboard.js
    ├── dashboard.css
    ├── pricing.html
    ├── billing.html
    ├── checkout.html
    ├── checkout-embedded.html
    ├── checkout-return.html
    ├── invite-accept.html
    ├── success.html
    ├── cancel.html
    └── style.css
```

## Routes API principales

| Méthode | Route | Description |
|---------|-------|-------------|
| POST | /api/auth/register | Inscription |
| POST | /api/auth/login | Connexion |
| POST | /api/auth/logout | Déconnexion |
| GET | /api/me | Profil utilisateur |
| GET | /api/overview | Dashboard stats |
| GET/POST | /api/audits | Audits SEO |
| GET/POST | /api/monitors | Uptime monitors |
| GET/POST | /api/missions | Missions SEO |
| GET/POST | /api/reports | Rapports |
| GET/POST | /api/keywords | Mots-clés |
| GET/POST | /api/competitors | Concurrents |
| GET/POST | /api/team | Équipe |
| GET/POST | /api/workspace/messages | Messages équipe |
| GET/POST | /api/workspace/notes | Notes |
| GET/POST | /api/connectors | Connecteurs |
| GET/PATCH | /api/local-seo | Fiche Local SEO |
| GET/POST | /api/alert-rules | Règles d'alerte |
| GET | /api/notifications | Notifications |
| POST | /api/ai/chat | Chat IA |
| POST | /api/billing/checkout | Checkout Stripe |
| POST | /api/billing/portal | Portail billing |
| GET | /api/events | SSE realtime |
| GET | /api/export/:type | Export CSV/JSON |
| GET | /api/health | Health check |

## Développement local
```bash
cp .env.example .env
# remplir .env avec tes clés
npm install
npm run dev   # nodemon
```
