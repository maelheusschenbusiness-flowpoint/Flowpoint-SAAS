// supabase.js — FlowPoint Supabase Sync Layer v2
// Strategy:
//   - organizations table: keyed by stripe_customer_id (existing column)
//   - org_addons: select-then-update (no UNIQUE constraint available)
//   - ai_usage_logs: insert only
//   - ai_monthly_usage: select-then-update by (org_id, month)
//   - All syncs are fire-and-forget — never blocks MongoDB path
//   - UUID FK constraint handled by upserting organizations first

const { createClient } = require("@supabase/supabase-js");

let _sb = null;

function getSupabase() {
  if (_sb) return _sb;
  const rawUrl = process.env.SUPABASE_URL || "";
  const url = rawUrl.replace(/\/rest\/v1\/?$/, "").replace(/\/$/, "");
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
  if (!url || !key) {
    console.warn("[Supabase] SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY manquant — sync désactivé");
    return null;
  }
  _sb = createClient(url, key, { auth: { persistSession: false } });
  return _sb;
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function toIso(d) {
  if (!d) return null;
  if (d instanceof Date) return d.toISOString();
  return new Date(d).toISOString();
}

function monthKey(date) {
  const d = date ? new Date(date) : new Date();
  return d.toISOString().substring(0, 7) + "-01";
}

function planBaseCredits(plan) {
  if (plan === "ultra") return 15000000;
  if (plan === "pro")   return 500000;
  return 100000;
}

// ─────────────────────────────────────────────
// organizations — upsert by stripe_customer_id
// Returns the Supabase UUID for this org, or null
// ─────────────────────────────────────────────

async function upsertOrganization({ stripeCustomerId, stripeSubscriptionId, orgName, plan }) {
  const sb = getSupabase();
  if (!sb || !stripeCustomerId) return null;

  try {
    // Try to find existing row by stripe_customer_id
    const { data: existing } = await sb
      .from("organizations")
      .select("id")
      .eq("stripe_customer_id", stripeCustomerId)
      .maybeSingle();

    if (existing) {
      // Update
      await sb.from("organizations").update({
        plan:                   plan || "standard",
        stripe_subscription_id: stripeSubscriptionId || null,
        name:                   orgName || existing.name,
      }).eq("id", existing.id);
      return existing.id;
    } else {
      // Insert
      const slug = stripeCustomerId.toLowerCase().replace(/[^a-z0-9]/g, "-");
      const { data: inserted } = await sb.from("organizations").insert({
        name:                   orgName || "Org",
        slug:                   slug,
        plan:                   plan || "standard",
        stripe_customer_id:     stripeCustomerId,
        stripe_subscription_id: stripeSubscriptionId || null,
      }).select("id").single();
      return inserted?.id || null;
    }
  } catch (e) {
    console.error("[Supabase] upsertOrganization exception:", e.message);
    return null;
  }
}

// ─────────────────────────────────────────────
// subscriptions — upsert by stripe_subscription_id
// ─────────────────────────────────────────────

async function upsertSubscription({ sbOrgId, stripeCustomerId, stripeSubscriptionId, plan, status, trialEnd }) {
  const sb = getSupabase();
  if (!sb) return;

  try {
    // Find user by stripe_customer_id in subscriptions table
    const { data: existing } = await sb
      .from("subscriptions")
      .select("id")
      .eq("stripe_customer_id", stripeCustomerId)
      .maybeSingle();

    const payload = {
      stripe_customer_id:     stripeCustomerId,
      stripe_subscription_id: stripeSubscriptionId || null,
      plan:                   plan || "standard",
      status:                 status || "active",
      trial_end:              trialEnd ? toIso(trialEnd) : null,
    };

    if (existing) {
      await sb.from("subscriptions").update(payload).eq("id", existing.id);
    } else {
      // user_id FK — insert without user_id since we don't have Supabase UUID for user
      await sb.from("subscriptions").insert(payload);
    }
  } catch (e) {
    console.error("[Supabase] upsertSubscription exception:", e.message);
  }
}

// ─────────────────────────────────────────────
// org_addons — select-then-upsert per addon key
// (no UNIQUE constraint, so we do select first)
// ─────────────────────────────────────────────

async function syncOrgAddons({ sbOrgId, billingAddons, stripeSubscriptionId }) {
  const sb = getSupabase();
  if (!sb || !sbOrgId) return;

  const addonMap = {};

  // Boolean addons
  for (const key of ["retention90d", "retention365d", "prioritySupport", "customDomain", "whiteLabel"]) {
    addonMap[key] = !!billingAddons[key];
  }
  // Numeric addons
  for (const key of ["monitorsPack50", "extraSeats", "auditsPack200", "auditsPack1000", "pdfPack200", "exportsPack1000"]) {
    addonMap[key] = Number(billingAddons[key] || 0) > 0;
  }

  try {
    // Fetch all existing addon rows for this org
    const { data: existing } = await sb
      .from("org_addons")
      .select("id, addon_key")
      .eq("org_id", sbOrgId);

    const existingMap = {};
    for (const row of (existing || [])) {
      existingMap[row.addon_key] = row.id;
    }

    const toInsert = [];
    const toUpdate = [];

    for (const [addonKey, active] of Object.entries(addonMap)) {
      if (existingMap[addonKey]) {
        toUpdate.push({ id: existingMap[addonKey], active, stripe_subscription_id: stripeSubscriptionId || null });
      } else {
        toInsert.push({ org_id: sbOrgId, addon_key: addonKey, active, stripe_subscription_id: stripeSubscriptionId || null });
      }
    }

    // Batch insert
    if (toInsert.length > 0) {
      const { error } = await sb.from("org_addons").insert(toInsert);
      if (error) console.error("[Supabase] syncOrgAddons insert error:", error.message);
    }

    // Update one by one (no batch update by multiple IDs in PostgREST)
    for (const row of toUpdate) {
      await sb.from("org_addons").update({
        active: row.active,
        stripe_subscription_id: row.stripe_subscription_id,
      }).eq("id", row.id);
    }
  } catch (e) {
    console.error("[Supabase] syncOrgAddons exception:", e.message);
  }
}

// Reset all addons to inactive
async function resetOrgAddons({ sbOrgId }) {
  const sb = getSupabase();
  if (!sb || !sbOrgId) return;
  try {
    const { error } = await sb
      .from("org_addons")
      .update({ active: false, stripe_subscription_id: null })
      .eq("org_id", sbOrgId);
    if (error) console.error("[Supabase] resetOrgAddons error:", error.message);
  } catch (e) {
    console.error("[Supabase] resetOrgAddons exception:", e.message);
  }
}

// ─────────────────────────────────────────────
// Dynamic quotas — stored as special addon_key rows
// Keys: plan_X, quota_ai_credits, quota_monitors, quota_seats, quota_audits,
//       quota_pdf, quota_exports, quota_retention_days
// ─────────────────────────────────────────────

function baseMonitors(plan) {
  if (plan === "ultra") return 300;
  if (plan === "pro")   return 50;
  return 3;
}
function baseSeats(plan) {
  if (plan === "ultra") return 10;
  return 1;
}
function baseAudits(plan) {
  if (plan === "ultra") return 2000;
  if (plan === "pro")   return 300;
  return 30;
}

async function syncDynamicQuotas({ sbOrgId, plan, stripeSubscriptionId, billingAddons }) {
  const sb = getSupabase();
  if (!sb || !sbOrgId) return;

  const p = plan || "standard";

  // Effective values (mirrors server.js effectiveQuotas)
  const monitorsLimit = baseMonitors(p) + Number(billingAddons?.monitorsPack50 || 0) * 50;
  const seatsLimit    = baseSeats(p)    + Number(billingAddons?.extraSeats     || 0);
  const auditsLimit   = baseAudits(p)   + Number(billingAddons?.auditsPack200  || 0) * 200
                                         + Number(billingAddons?.auditsPack1000 || 0) * 1000;
  const retentionDays = billingAddons?.retention365d ? 365
                      : billingAddons?.retention90d  ? 90
                      : 30;

  // Deactivate old plan_* markers before setting the new one
  const oldPlanKeys = ["plan_standard", "plan_pro", "plan_ultra"].filter(k => k !== "plan_" + p);

  const specialAddons = [
    { key: "plan_" + p,            active: true },
    { key: "quota_ai_credits",     active: true },
    { key: `quota_monitors_${monitorsLimit}`, active: true },
    { key: `quota_seats_${seatsLimit}`,       active: true },
    { key: `quota_audits_${auditsLimit}`,     active: true },
    { key: `quota_retention_${retentionDays}`,active: true },
    { key: "wl_" + (billingAddons?.whiteLabel     ? "on" : "off"), active: !!billingAddons?.whiteLabel },
    { key: "cd_" + (billingAddons?.customDomain   ? "on" : "off"), active: !!billingAddons?.customDomain },
    { key: "ps_" + (billingAddons?.prioritySupport? "on" : "off"), active: !!billingAddons?.prioritySupport },
  ];

  try {
    // Deactivate stale plan_ markers
    if (oldPlanKeys.length > 0) {
      const { data: stale } = await sb.from("org_addons").select("id").eq("org_id", sbOrgId).in("addon_key", oldPlanKeys);
      for (const row of (stale || [])) {
        await sb.from("org_addons").update({ active: false }).eq("id", row.id);
      }
    }

    const { data: existing } = await sb
      .from("org_addons")
      .select("id, addon_key")
      .eq("org_id", sbOrgId)
      .in("addon_key", specialAddons.map(a => a.key));

    const existingMap = {};
    for (const row of (existing || [])) existingMap[row.addon_key] = row.id;

    for (const addon of specialAddons) {
      if (existingMap[addon.key]) {
        await sb.from("org_addons").update({
          active: addon.active,
          stripe_subscription_id: stripeSubscriptionId || null,
        }).eq("id", existingMap[addon.key]);
      } else {
        await sb.from("org_addons").insert({
          org_id:                 sbOrgId,
          addon_key:              addon.key,
          active:                 addon.active,
          stripe_subscription_id: stripeSubscriptionId || null,
        });
      }
    }
  } catch (e) {
    console.error("[Supabase] syncDynamicQuotas exception:", e.message);
  }
}

// ─────────────────────────────────────────────
// syncWhiteLabelBranding — update organizations table with branding data
// Called from applySubscriptionToUserAndOrg when branding fields change
// ─────────────────────────────────────────────

async function syncWhiteLabelBranding({ sbOrgId, branding, billingAddons }) {
  const sb = getSupabase();
  if (!sb || !sbOrgId) return;

  try {
    const payload = {
      white_label:      !!billingAddons?.whiteLabel,
      custom_domain:    !!billingAddons?.customDomain,
      priority_support: !!billingAddons?.prioritySupport,
    };

    // Only include branding fields if they have non-empty values
    // (organizations table may or may not have these columns — graceful ignore on error)
    if (branding?.appName)       payload.branding_app_name      = branding.appName;
    if (branding?.logoUrl)       payload.branding_logo_url      = branding.logoUrl;
    if (branding?.primaryColor)  payload.branding_primary_color = branding.primaryColor;
    if (branding?.supportEmail)  payload.branding_support_email = branding.supportEmail;

    await sb.from("organizations").update(payload).eq("id", sbOrgId);
  } catch (e) {
    // Non-blocking — columns may not exist yet
    console.warn("[Supabase] syncWhiteLabelBranding (non-bloquant):", e.message);
  }
}

// ─────────────────────────────────────────────
// ai_usage_logs — insert one row
// ─────────────────────────────────────────────

async function insertAIUsageLog({ sbOrgId, model, feature, creditsUsed, estimatedCost }) {
  const sb = getSupabase();
  if (!sb) return;
  try {
    const row = {
      model:          model   || "performante",
      feature:        feature || "chat",
      credits_used:   Math.round(Number(creditsUsed)   || 0),
      estimated_cost: Number(estimatedCost || 0),
    };
    if (sbOrgId) row.org_id = sbOrgId;

    const { error } = await sb.from("ai_usage_logs").insert(row);
    if (error) console.error("[Supabase] insertAIUsageLog error:", error.message);
  } catch (e) {
    console.error("[Supabase] insertAIUsageLog exception:", e.message);
  }
}

// ─────────────────────────────────────────────
// ai_monthly_usage — select-then-update by (org_id, month)
// ─────────────────────────────────────────────

async function upsertAIMonthlyUsage({ sbOrgId, creditsUsed, estimatedCost, date }) {
  const sb = getSupabase();
  if (!sb) return;
  const month = monthKey(date);

  try {
    let query = sb.from("ai_monthly_usage").select("id, credits_used, estimated_cost").eq("month", month);
    if (sbOrgId) query = query.eq("org_id", sbOrgId);
    else         query = query.is("org_id", null);

    const { data: existing } = await query.maybeSingle();

    if (existing) {
      await sb.from("ai_monthly_usage").update({
        credits_used:   (existing.credits_used   || 0) + Math.round(Number(creditsUsed)   || 0),
        estimated_cost: (existing.estimated_cost || 0) + Number(estimatedCost || 0),
      }).eq("id", existing.id);
    } else {
      const row = {
        month,
        credits_used:   Math.round(Number(creditsUsed)   || 0),
        estimated_cost: Number(estimatedCost || 0),
      };
      if (sbOrgId) row.org_id = sbOrgId;
      await sb.from("ai_monthly_usage").insert(row);
    }
  } catch (e) {
    console.error("[Supabase] upsertAIMonthlyUsage exception:", e.message);
  }
}

// ─────────────────────────────────────────────
// trackAIUsage — called from consumeAICredits
// Resolves org Supabase UUID from stripeCustomerId cache or skips if unavailable
// ─────────────────────────────────────────────

// Simple in-memory cache: stripeCustomerId → sbOrgId (UUID)
const _orgIdCache = new Map();

async function resolveOrgId(stripeCustomerId) {
  if (!stripeCustomerId) return null;
  if (_orgIdCache.has(stripeCustomerId)) return _orgIdCache.get(stripeCustomerId);
  const sb = getSupabase();
  if (!sb) return null;
  try {
    const { data } = await sb.from("organizations").select("id").eq("stripe_customer_id", stripeCustomerId).maybeSingle();
    const id = data?.id || null;
    if (id) _orgIdCache.set(stripeCustomerId, id);
    return id;
  } catch { return null; }
}

async function trackAIUsage({ stripeCustomerId, model, feature, creditsUsed, estimatedCost }) {
  const sbOrgId = await resolveOrgId(stripeCustomerId);
  await Promise.all([
    insertAIUsageLog({ sbOrgId, model, feature, creditsUsed, estimatedCost }),
    upsertAIMonthlyUsage({ sbOrgId, creditsUsed, estimatedCost, date: new Date() }),
  ]);
}

// ─────────────────────────────────────────────
// syncSubscriptionToSupabase — main entry point from webhook
// ─────────────────────────────────────────────

async function syncSubscriptionToSupabase({
  user, org, plan, billingAddons, stripeSubscriptionId, status,
}) {
  if (!user) return;

  const stripeCustomerId = user.stripeCustomerId;
  if (!stripeCustomerId) return;

  const orgName = org?.name || user.companyName || user.email;

  // 1. Upsert organization row — get Supabase UUID
  const sbOrgId = await upsertOrganization({
    stripeCustomerId,
    stripeSubscriptionId,
    orgName,
    plan,
  });

  // 2. Upsert subscription
  await upsertSubscription({
    sbOrgId,
    stripeCustomerId,
    stripeSubscriptionId,
    plan,
    status,
    trialEnd: user.trialEndsAt,
  });

  if (!sbOrgId) return;

  // 3. Sync org_addons (activation / désactivation automatique)
  await syncOrgAddons({ sbOrgId, billingAddons, stripeSubscriptionId });

  // 4. Sync dynamic quotas (plan + AI credits + monitors + seats + retention)
  await syncDynamicQuotas({ sbOrgId, plan, stripeSubscriptionId, billingAddons });

  // 5. Sync white-label branding fields to organizations table
  await syncWhiteLabelBranding({ sbOrgId, branding: org?.branding || {}, billingAddons: billingAddons || {} });

  // Update cache
  _orgIdCache.set(stripeCustomerId, sbOrgId);
}

// ─────────────────────────────────────────────
// resetSupabaseAfterDelete — called on subscription.deleted
// ─────────────────────────────────────────────

async function resetSupabaseAfterDelete({ user }) {
  if (!user?.stripeCustomerId) return;
  const sb = getSupabase();
  if (!sb) return;

  try {
    const { data: org } = await sb
      .from("organizations")
      .select("id")
      .eq("stripe_customer_id", user.stripeCustomerId)
      .maybeSingle();

    if (!org) return;

    // Reset plan
    await sb.from("organizations").update({ plan: "standard", stripe_subscription_id: null }).eq("id", org.id);

    // Deactivate all addons
    await sb.from("org_addons").update({ active: false, stripe_subscription_id: null }).eq("org_id", org.id);

    // Update subscription status
    await sb.from("subscriptions").update({ status: "canceled", stripe_subscription_id: null })
      .eq("stripe_customer_id", user.stripeCustomerId);

    _orgIdCache.delete(user.stripeCustomerId);
  } catch (e) {
    console.error("[Supabase] resetSupabaseAfterDelete exception:", e.message);
  }
}

module.exports = {
  getSupabase,
  syncSubscriptionToSupabase,
  resetSupabaseAfterDelete,
  trackAIUsage,
  syncOrgAddons,
  resetOrgAddons,
  upsertOrganization,
  upsertSubscription,
  insertAIUsageLog,
  upsertAIMonthlyUsage,
  syncDynamicQuotas,
  syncWhiteLabelBranding,
  resolveOrgId,
};
