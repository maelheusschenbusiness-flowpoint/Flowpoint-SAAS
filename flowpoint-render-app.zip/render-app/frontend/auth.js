(() => {
  "use strict";

  function getAuthToken() {
    return localStorage.getItem("token") || localStorage.getItem("fp_token") || "";
  }

  function setAuthToken(token) {
    if (!token) return;
    localStorage.setItem("token", token);
    localStorage.setItem("fp_token", token);
  }

  function clearAuth() {
    ["token", "fp_token", "fp-token", "fp-auth", "fp-session", "fp-user"].forEach(
      (k) => localStorage.removeItem(k)
    );
    sessionStorage.clear();
  }

  async function authFetch(path, opts = {}) {
    const token = getAuthToken();
    const headers = new Headers(opts.headers || {});

    if (token) headers.set("Authorization", "Bearer " + token);
    if (opts.body && !headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json");
    }

    const doFetch = () =>
      fetch(path, { ...opts, headers, credentials: "include" });

    let res = await doFetch();

    if (res.status === 401) {
      clearAuth();
      window.location.href = "/login.html";
      return null;
    }

    return res;
  }

  window.fpAuth = { getAuthToken, setAuthToken, clearAuth, authFetch };
})();
