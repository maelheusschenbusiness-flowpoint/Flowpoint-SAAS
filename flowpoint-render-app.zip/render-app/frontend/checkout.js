(() => {
  const TOKEN_KEYS = ["token", "fp_token"];
  const CHECKOUT_PAYLOAD_KEY = "fp_checkout_payload";

  const $ = (q) => document.querySelector(q);

  const authPill = $("#authPill");
  const msg = $("#checkoutMsg");
  const retryBtn = $("#retryBtn");
  const goEmbeddedBtn = $("#goEmbeddedBtn");
  const sumPlan = $("#sumPlan");
  const sumAddOns = $("#sumAddOns");

  function getToken() {
    for (const k of TOKEN_KEYS) {
      const v = localStorage.getItem(k);
      if (v) return v;
    }
    return null;
  }

  function setMsg(t) { if (msg) msg.textContent = t || ""; }

  function readPayload() {
    try { return JSON.parse(localStorage.getItem(CHECKOUT_PAYLOAD_KEY) || "null"); }
    catch { return null; }
  }

  function labelize(value) {
    const map = { standard:"Standard", pro:"Pro", ultra:"Ultra", whiteLabel:"White Label", customDomain:"Custom Domain", prioritySupport:"Priority Support", retention90d:"Retention 90j", retention365d:"Retention 365j", auditsPack200:"Audits +200", auditsPack1000:"Audits +1000", pdfPack200:"PDF +200", exportsPack1000:"Exports +1000", monitorsPack50:"Monitors +50", extraSeats:"Extra Seats" };
    const raw = String(value || "").trim();
    if (map[raw]) return map[raw];
    return raw.replace(/([a-z])([A-Z])/g,"$1 $2").replace(/[-_]+/g," ").replace(/\b\w/g,m=>m.toUpperCase());
  }

  function summarize(payload) {
    if (!payload) return;
    if (sumPlan) sumPlan.textContent = payload.plan ? labelize(payload.plan) : "—";
    const addons = payload.addons || {};
    const lines = [];
    for (const [k, v] of Object.entries(addons)) {
      if (k === "whiteLabel") continue;
      if (typeof v === "boolean") { if (v) lines.push(labelize(k)); }
      else if (Number(v) > 0) lines.push(`${labelize(k)} ×${Number(v)}`);
    }
    if (sumAddOns) sumAddOns.textContent = lines.length ? lines.join(" • ") : "—";
  }

  async function doCheckout(payload) {
    const tok = getToken();
    const headers = { "Content-Type": "application/json" };
    if (tok) headers["Authorization"] = `Bearer ${tok}`;

    setMsg("Création de la session Stripe…");
    const r = await fetch("/api/billing/checkout", {
      method: "POST",
      headers,
      credentials: "include",
      body: JSON.stringify({ plan: payload.plan, addons: payload.addons })
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Erreur API checkout");
    if (j.url) {
      setMsg("Redirection vers Stripe…");
      window.location.href = j.url;
    } else {
      setMsg("Abonnement mis à jour. Redirection…");
      setTimeout(() => window.location.href = "/api/dashboard/dashboard.html", 1000);
    }
  }

  function start() {
    if (authPill) authPill.textContent = getToken() ? "Statut : Connecté" : "Statut : Non connecté";

    const payload = readPayload();
    if (!payload) {
      setMsg("Aucune sélection trouvée. Retourne sur pricing.");
      if (retryBtn) { retryBtn.style.display = "inline-block"; retryBtn.onclick = () => window.location.href = "/pricing.html"; }
      return;
    }

    summarize(payload);
    setMsg("Sélection prête. Clique sur Continuer vers le paiement.");

    if (goEmbeddedBtn) {
      goEmbeddedBtn.addEventListener("click", async () => {
        goEmbeddedBtn.disabled = true;
        setMsg("Connexion à Stripe…");
        try {
          await doCheckout(payload);
        } catch (e) {
          setMsg("❌ " + (e.message || "Erreur"));
          goEmbeddedBtn.disabled = false;
          if (retryBtn) { retryBtn.style.display = "inline-block"; retryBtn.onclick = () => window.location.reload(); }
        }
      });
    }
  }

  start();
})();
