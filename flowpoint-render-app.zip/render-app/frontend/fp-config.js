/**
 * FLOWPOINT — Configuration Backend (SSE edition)
 * ══════════════════════════════════════════════════
 * Ce fichier centralise toute la configuration de connexion backend.
 * Il utilise les Server-Sent Events (SSE) pour le realtime.
 * Pas de Socket.IO — pas de dépendance externe.
 *
 * USAGE :
 *   <script src="/fp-config.js"></script>  ← avant dashboard.js
 *
 * Pour dev local avec serveur séparé :
 *   window.__FP_BACKEND_URL = 'http://localhost:3001';
 */

(function () {
  'use strict';

  // ─── BACKEND URL ─────────────────────────────────────────────────────────────

  const FP_BACKEND_URL = (function () {
    if (typeof window.__FP_BACKEND_URL === 'string' && window.__FP_BACKEND_URL) {
      return window.__FP_BACKEND_URL.replace(/\/$/, '');
    }
    // Même origine → frontend servi par le même serveur Express
    if (window.location.protocol !== 'file:') return '';
    return 'http://localhost:3001';
  })();

  window.FP_CONFIG = {
    backendUrl: FP_BACKEND_URL,
    apiBase:    FP_BACKEND_URL + '/api',
    version:    '2.0',
  };

  // ─── FETCH INTERCEPTOR ───────────────────────────────────────────────────────
  // Préfixe tous les fetch('/api/...') avec le backendUrl si différent

  if (FP_BACKEND_URL) {
    const _orig = window.fetch.bind(window);
    window.fetch = function (input, init) {
      init = Object.assign({}, init);
      let url = typeof input === 'string' ? input
        : (input instanceof Request ? input.url : String(input));
      if (url.startsWith('/api/') || url.startsWith('/share/')) {
        url = FP_BACKEND_URL + url;
        init.credentials = init.credentials || 'include';
        return _orig(url, init);
      }
      return _orig(input, init);
    };
  }

  // ─── SSE REALTIME ─────────────────────────────────────────────────────────────
  // Connexion à /api/events (Server-Sent Events)

  window.FP_SSE = null;
  let _sseRetries = 0;

  function connectSSE() {
    if (typeof EventSource === 'undefined') return;
    if (window.location.protocol === 'file:' && !FP_BACKEND_URL) return;

    const url = FP_BACKEND_URL + '/api/events';
    const es = new EventSource(url, { withCredentials: true });
    window.FP_SSE = es;

    es.onopen = function () {
      _sseRetries = 0;
      console.log('[FP] SSE connecté');
      document.dispatchEvent(new CustomEvent('fp:sse:ready'));
    };

    es.onmessage = function (e) {
      let payload;
      try { payload = JSON.parse(e.data); } catch (_) { return; }
      const type = payload.type;
      const data = payload.data || payload;

      // Dispatch événements spécifiques
      if (type === 'connected')           document.dispatchEvent(new CustomEvent('fp:sse:ready', { detail: data }));
      if (type === 'audit')               document.dispatchEvent(new CustomEvent('fp:audit:complete', { detail: data }));
      if (type === 'monitor')             document.dispatchEvent(new CustomEvent('fp:monitor:update', { detail: data }));
      if (type === 'monitor_down')        document.dispatchEvent(new CustomEvent('fp:monitor:alert', { detail: data }));
      if (type === 'billing')             document.dispatchEvent(new CustomEvent('fp:billing:updated', { detail: data }));
      if (type === 'notification')        document.dispatchEvent(new CustomEvent('fp:notification', { detail: data }));
      if (type === 'workspace_message')   document.dispatchEvent(new CustomEvent('fp:team:message', { detail: data }));

      // Événement générique
      document.dispatchEvent(new CustomEvent('fp:realtime', { detail: payload }));
    };

    es.onerror = function () {
      es.close();
      window.FP_SSE = null;
      _sseRetries++;
      const delay = Math.min(30000, 3000 * _sseRetries);
      console.warn(`[FP] SSE déconnecté, reconnexion dans ${delay/1000}s…`);
      setTimeout(connectSSE, delay);
    };
  }

  // Lance SSE après le chargement du DOM (nécessite auth cookie)
  function maybeConnectSSE() {
    const hasToken = localStorage.getItem('token') || localStorage.getItem('fp_token') || '';
    const hasCookie = document.cookie.includes('fp_token');
    if (hasToken || hasCookie || localStorage.getItem('fp_connected') === '1') {
      connectSSE();
    }
    // Écoute l'événement login pour démarrer SSE
    document.addEventListener('fp:login', function () {
      if (!window.FP_SSE) connectSSE();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', maybeConnectSSE);
  } else {
    maybeConnectSSE();
  }

  console.log('[FP] Config chargée — backend:', FP_BACKEND_URL || '(même origine)');
})();
