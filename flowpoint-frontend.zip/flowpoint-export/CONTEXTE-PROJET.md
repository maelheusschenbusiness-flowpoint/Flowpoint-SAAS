# Flowpoint Dashboard — Contexte Complet du Projet

## 🔗 URL du Dashboard
```
https://637b3722-0749-4a98-8b79-abfeb0a1d3ce-00-2vuijftxq94iq.picard.replit.dev/api/dashboard/dashboard.html
```

## 📁 Fichiers principaux
| Fichier | Rôle |
|---|---|
| `dashboard.html` | Page principale — contient inline `<style>` critique (ligne ~36) |
| `dashboard.css` | Tous les styles — correctifs toujours APPENDÉS à la fin |
| `dashboard.js` | Logique complète ~29 173 lignes — jamais `cat`, toujours `sed -n` |
| `fp-config.js` | Configuration Flowpoint |
| `fp-backend.js` | Backend mock |

## 🔢 Version actuelle
```
?v=20260614x
```
Référencée aux lignes 79 (CSS link) et 505 (script JS) dans `dashboard.html`.

**Pattern de bump :**
```bash
sed -i 's/v=ANCIENNE/v=NOUVELLE/g' artifacts/flowpoint-export/dashboard.html
```

---

## ⚠️ RÈGLE CRITIQUE — Spécificité CSS

L'inline `<style>` dans `dashboard.html` (ligne ~36) utilise le préfixe `html[data-theme="light"]` qui donne une **spécificité (0,2,1)** — SUPÉRIEURE au CSS externe (0,1,1).

**Conséquence :** Pour écraser une règle de cet inline style, le CSS externe doit utiliser le même préfixe `html[data-theme="light"]`.

### Règles inline avec haute spécificité (à ne jamais modifier sans comprendre) :
```css
html[data-theme="light"] .fp-layout { background:#f8faff!important; }
html[data-theme="light"] .fp-page   { background:transparent!important; }
html[data-theme="light"] .fp-card   { background:#ffffff!important; box-shadow:0 1px 3px rgba(0,0,0,0.06)!important; }
```

---

## 🎨 Variables CSS clés

```css
/* Fond des sous-cartes */
:root { --fp-inner-card: rgba(255,255,255,0.02); }         /* Dark mode */
html[data-theme="light"] { --fp-inner-card: #ffffff; }     /* Light mode */

/* Bordures des sous-cartes */
:root { --fp-inner-border: rgba(255,255,255,0.06); }
html[data-theme="light"] { --fp-inner-border: rgba(0,0,0,0.08); }
```

**Ces variables remplacent** tous les anciens `rgba(255,255,255,0.02/0.03/0.04)` dans le JS (136 instances remplacées).

---

## 🎨 Light Mode — Fond de page

```css
html[data-theme="light"] body,
html[data-theme="light"] .fp-main-wrap,
html[data-theme="light"] .fp-layout,
html[data-theme="light"] .fp-page {
  background: #f0f2f5 !important; /* Gris neutre, pas bleu */
}
```

---

## 🎴 Cartes (fp-card) en Light Mode

```css
html[data-theme="light"] .fp-card {
  background: #ffffff !important;
  border: 1px solid rgba(0,0,0,0.11) !important;
  border-radius: 20px !important;
  box-shadow: 0 3px 20px rgba(0,0,0,0.13), 0 0 0 1px rgba(0,0,0,0.05) !important;
  overflow: hidden !important;
}
```

**Pourquoi `overflow: hidden` ?** Pour que le `border-radius` clip les enfants qui débordent (tableaux, images).

**Attention :** `fp-table-wrap` doit avoir `overflow-x: auto !important; overflow-y: hidden !important` (pas `overflow: hidden` tout seul, sinon le scroll horizontal de table est bloqué).

---

## 📱 Mobile — Règles importantes

### Bibliothèque de prompts (masquer cartes 3 & 4 par défaut)
```css
@media (max-width: 768px) {
  #fp-prompt-lib-body.fp-collapsible-m > *:nth-child(n+3) { display: none !important; }
  #fp-prompt-lib-body.fp-collapsible-m.fp-expanded-m > *:nth-child(n+3) { display: block !important; }
}
```

### Quick prompts — pleine largeur
```css
@media (max-width: 768px) {
  .fp-ai-quick-prompts { display: flex; flex-direction: column; gap: 7px; }
  .fp-ai-quick-prompts .fp-ai-quick { width: 100%; text-align: left; padding: 10px 14px; }
}
```

### Contexte workspace collapsible
```css
@media (max-width: 768px) {
  #fp-ctx-body.fp-collapsible-m { max-height: 102px !important; } /* 2 rangées exactes */
  #fp-ctx-body.fp-collapsible-m.fp-expanded-m { max-height: 600px !important; }
}
```

---

## 🔧 FAB (Floating Action Button) — Animation fermeture

Le JS utilise `item.style.setProperty('--fab-close-delay', ...)` (variable CSS custom property) pour contourner le conflit de `!important` dans la cascade.

Le CSS utilise :
```css
#fp-fab-wrap .fp-fab-item {
  animation: fab-item-out 0.25s cubic-bezier(0.4,0,0.6,1) var(--fab-close-delay,0s) both !important;
}
```

---

## 🗂️ Sections du JS (lecture avec sed)

```bash
# TOUJOURS utiliser sed -n pour lire des extraits, JAMAIS cat/head/tail
sed -n '8135,8170p' artifacts/flowpoint-export/dashboard.js

# Vérifier l'intégrité du fichier
wc -l artifacts/flowpoint-export/dashboard.js   # ~29 173 lignes
wc -c artifacts/flowpoint-export/dashboard.js   # ~1 995 kB
```

### Points d'intérêt JS :
| Ligne | Contenu |
|---|---|
| ~78 | STATE init (searchHistory, etc.) |
| ~1330 | CMD_ITEMS — palette de recherche |
| ~1386 | openCmdPalette() |
| ~1470 | _cmdRenderResults() — suggestions vides |
| ~2605 | renderOverview() |
| ~2768 | healthMetrics gauge cards |
| ~2851 | wsModules cards (classe fp-ws-module-card) |
| ~8135 | intensityLevels (Conservateur/Équilibré/Agressif) |
| ~8155 | Rendu cartes intensité IA (classe fp-ai-int-opt) |
| ~8448 | systems[] — intelligence section |
| ~8956 | promptCats[] — bibliothèque prompts |
| ~9009 | Quick prompts suggestions rapides |
| ~9049 | Contexte workspace actif (fp-ctx-body) |

---

## 🔍 Barre de recherche — CMD_ITEMS

Catégories existantes :
- **Navigation** (8 items)
- **Audits & Technique** (6 items)
- **Analyse & Performance** (6 items)
- **Marketing & Contenu** (5 items)
- **Monitoring & Alertes** (3 items)
- **Équipe & Admin** (6 items)
- **Actions** (13 items — dont alertes, GBP, concurrents, etc.)
- **Assistant IA** (9 items — chaque clic envoie la question dans l'IA)

### Suggestions affichées à vide :
8 suggestions rapides + 6 navigations rapides affichées dès l'ouverture.

---

## 🚫 Plan switcher supprimé

```css
#fp-plan-switcher { display: none !important; }
```

---

## 📋 Correctifs CSS appendés (ordre chronologique)

Tous les correctifs sont **appendés à la fin** de `dashboard.css`. Ne jamais modifier les règles en milieu de fichier.

1. Fond page light mode (#dce3ef → #f0f2f5)
2. Cartes light mode (border-radius 20px, shadow visible)
3. Spécificité haute (html[data-theme="light"] .fp-card shadow)
4. fp-layout fond gris
5. Cartes intensité IA (fp-ai-int-opt, min-height égal)
6. Quick prompts mobile (colonne pleine largeur)
7. Prompt library mobile (masquer cartes 3&4)
8. Variable --fp-inner-card
9. fp-ws-module-card (blanc en light mode)
10. fp-gauge-card bordures light mode

---

## 🏗️ Architecture du projet (post-merges sécurité)

```
artifacts/
├── api-server/          # Express API (TypeScript)
│   └── src/
│       ├── routes/      # auth, ai, monitors, google (split public/protected), etc.
│       ├── middlewares/ # requireAuth, requireAdmin, orgContext (session-based)
│       └── services/    # sessions.ts (crypto session store), monitor-cron.ts
├── flowpoint-export/    # Dashboard statique (HTML/CSS/JS)
└── mockup-sandbox/      # Preview Vite (sync auto depuis flowpoint-export)

lib/
└── db/                  # Drizzle ORM
    ├── package.json     # "push" et "push-force" (non-interactif)
    └── drizzle.config.ts
```

## 🔐 Sécurité (tasks #94-#100 mergées)

- **Auth** : Sessions crypto `randomBytes(32)` côté serveur, plus de JWT unsigned
- **Tenant isolation** : orgId/userId depuis session serveur, plus depuis body/query
- **Google OAuth** : State CSRF validé, routes protégées derrière requireAuth
- **SSRF** : Monitors re-valident DNS avant fetch + redirect:manual avec max 5 hops
- **Deps** : 0 vulnérabilités connues (`pnpm audit` clean)

---

## ⚙️ Post-merge script

```bash
# scripts/post-merge.sh
#!/bin/bash
set -e
pnpm install --frozen-lockfile
pnpm --filter @workspace/db run push-force   # --force = non-interactif (pas de prompt Drizzle)
bash scripts/sync-dashboard.sh
```

**Timeout** : 60 000 ms (le script prend ~26-28s)

---

*Généré le 16 juin 2026 — version dashboard v20260614x*
