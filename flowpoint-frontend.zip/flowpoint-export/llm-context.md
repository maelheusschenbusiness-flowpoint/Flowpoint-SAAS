# FlowPoint — Contexte projet complet pour IA

> Fichier généré automatiquement. Dernière mise à jour : 2 juin 2026.

---

## 🎯 Qu'est-ce que FlowPoint ?

**FlowPoint** est un dashboard SaaS SEO local tout-en-un pour agences web françaises.
Il permet à une agence de gérer ses clients, leur visibilité locale (Google Maps, GBP), leurs audits SEO, leurs rapports, leur monitoring de disponibilité, et bien plus — le tout dans une interface dark-mode ultra-complète.

**URL live (dev)** : `https://637b3722-0749-4a98-8b79-abfeb0a1d3ce-00-2vuijftxq94iq.picard.replit.dev/`

---

## 🗂️ Architecture technique

```
monorepo pnpm
├── artifacts/
│   ├── api-server/          ← Backend Express (TypeScript)
│   │   └── src/
│   │       ├── app.ts       ← Config Express, sert flowpoint-export en static
│   │       ├── routes/      ← Toutes les routes /api/*
│   │       ├── services/    ← Logique métier (Stripe, auth, SEO, monitoring…)
│   │       └── middlewares/ ← JWT, rate-limit, orgContext
│   │
│   └── flowpoint-export/    ← Frontend statique (HTML/CSS/JS vanilla)
│       ├── dashboard.html   ← SPA principale (charge dashboard.js + dashboard.css)
│       ├── dashboard.js     ← ~28 800 lignes : tout le rendu UI, logique, composants
│       ├── dashboard.css    ← ~7 800 lignes : design system complet dark-mode
│       ├── fp-backend.js    ← Client API : appels fetch vers /api/*, gestion auth
│       ├── fp-config.js     ← Config organisation (plan, addons, limites)
│       ├── login.html       ← Page de connexion
│       ├── pricing.html     ← Page de tarifs publique
│       └── report-view.html ← Rapport client partageable
```

---

## 🏗️ Stack technique

| Couche | Techno |
|--------|--------|
| Frontend | HTML5 + CSS3 + JS vanilla (pas de framework) |
| Backend | Node.js + Express + TypeScript |
| Base de données | Supabase (PostgreSQL) + MongoDB |
| Auth | JWT + cookies httpOnly |
| Paiements | Stripe (abonnements + portail client) |
| Emails | Resend API |
| Monitoring | BetterStack |
| IA | OpenAI API (GPT-4o) |
| SEO data | DataForSEO API |

---

## 📐 Design system (dashboard.css)

Variables CSS principales :
- `--fp-bg` / `--fp-card` / `--fp-border` — fond dark
- `--fp-accent` (#2563EB bleu) — couleur principale
- `--fp-success` (#22c55e) / `--fp-danger` (#ef4444) / `--fp-warning` (#f59e0b)
- `--fp-text` / `--fp-text-muted` / `--fp-text-faint`
- `--fp-font-mono` — police monospace pour codes/chiffres

Classes utilitaires clés :
- `.fp-card` — carte avec fond semi-transparent et bordure
- `.fp-btn fp-btn-primary/ghost/danger fp-btn-sm` — boutons
- `.fp-data-table` — tableau de données stylisé
- `.fp-stat-row` — ligne de stat-cards
- `.fp-badge` — badge coloré inline
- `.fp-input` — champ de formulaire
- `.fp-toggle` — toggle switch
- `.fp-grid-2` / `.fp-grid-3` — grilles CSS
- `.fp-mb-20` / `.fp-mb-16` — marges bottom

---

## 📋 Sections du dashboard (navigation)

### Menu principal (sidebar)
| Section | Route | Description |
|---------|-------|-------------|
| Vue d'ensemble | `overview` | KPIs globaux + activité récente |
| Audits SEO | `audits` | Audit en cours, historique, lancer audit |
| Monitoring | `monitoring` | Uptime, alertes, SLA, incidents |
| Local SEO | `local-seo` | GBP, fiches, avis, positions Maps |
| Missions | `missions` | Tâches SEO clients, suivi, templates |
| Analytics | `analytics` | GA4, conversions, Search Console |
| Rapports | `reports` | Génération, planification, partage |
| Concurrents | `competitors` | Veille, backlinks, mouvements |
| Facturation | `billing` | Abonnement, add-ons, factures |
| Paramètres | `settings` | Équipe, intégrations, API, sécurité |

### Sous-sections Paramètres
- `workspace` — Infos agence, branding, domaine
- `team` — Membres, rôles, invitations
- `notifications` — Email, SMS, Slack
- `automations` — Workflows, triggers, templates
- `integrations` — Hub 15 plateformes + Webhooks + Templates (12) + Logs
- `api` — Clés API, rate limits
- `security` — SSO, 2FA, audit log
- `billing/addons` — 29 add-ons marketplace (grille 4 colonnes)
- `billing/invoices` — Historique factures
- `client-mode` — Vue portail client

---

## 🔌 Intégrations (15 plateformes)

Avec logos SVG intégrés dans le code :

| Plateforme | Couleur | Usage |
|-----------|---------|-------|
| Zapier | #FF4A00 | +6000 apps, Zaps sur événements SEO |
| Make (Integromat) | #6D00CC | Scénarios visuels automatisation |
| Slack | #4A154B | Alertes temps réel + résumés IA |
| Discord | #5865F2 | Notifications canaux |
| Notion | #fff | Pages auto par mission/rapport |
| HubSpot | #FF7A59 | CRM, contacts, deals |
| Airtable | #18BFFF | Bases de données backlinks/keywords |
| Pipedrive | #0B0B1F | Pipeline SEO → leads |
| Google Ads | #4285F4 | Corrélation SEO/SEA |
| Semrush | #FF642B | Import ranking + backlinks |
| Mailchimp | #FFE01B | Rapports hebdo clients |
| n8n | #EA5E00 | Workflows open-source |
| LinkedIn Ads | #0A66C2 | Reporting 360° SEO + social |
| Shopify | #96BF48 | Corrélation SEO ↔ ventes |
| Monday.com | #F62B54 | Missions → tâches projet |

---

## 📦 Templates d'intégration (12 par défaut)

| Nom | Plateforme | Trigger |
|-----|-----------|---------|
| Alerte Monitor Down → Slack | slack | monitor.down |
| Monitor récupéré → Slack | slack | monitor.recovered |
| Audit terminé → Zapier | zapier | audit.completed |
| Keyword chuté → Email | email | keyword.ranking_changed |
| Mission créée → Notion | notion | mission.created |
| Rapport généré → Make | make | report.generated |
| Avis Google → HubSpot | hubspot | review.received |
| Backlink détecté → Airtable | airtable | backlink.detected |
| Paiement échoué → HubSpot | hubspot | payment.failed |
| Concurrent détecté → Make | make | competitor.detected |
| Mission complétée → Monday | monday | mission.completed |
| Insight IA → Slack | slack | ai.insight.generated |

---

## 💳 Plans tarifaires

| Plan | Prix | Limites |
|------|------|---------|
| Standard | 49€/mois | 5 monitors, 50 audits/mois, 3 clients |
| Pro | 79€/mois | 20 monitors, 200 audits, 10 clients, IA |
| Ultra | 149€/mois | Illimité, white-label, SSO, API complète |

---

## 🛒 Add-ons (29 disponibles, grille 4 colonnes)

Catégories : Monitoring, SEO, Local SEO, Conversion, Reporting, IA, Équipe, Storage, API, Enterprise

Exemples actifs dans la démo :
- +50 Monitors (29€/mois) — Best value
- White-Label Exports (inclus Pro)
- Priority Support (actif)

---

## 🎨 Composants UI clés dans dashboard.js

### Fonctions globales
```javascript
render(section, sub)          // Rendu principal, dispatch vers sous-fonctions
navigate(section)             // Navigation entre sections
navigateSub(sub)              // Navigation sous-section
showToast(type, msg)          // Notifications toast (success/error/info/warning)
openFloatPanel(title, html)   // Panel flottant latéral
badge(text, color)            // Badge coloré inline
statCard(title, val, sub, trend) // Carte statistique
svgIcon(name)                 // Icônes SVG (feather-icons style)
escHtml(str)                  // Échappement XSS
btn(label, cls, icon, attrs)  // Bouton HTML
aiBlock(text, actions)        // Bloc IA avec suggestions
```

### Fonctions de rendu par section
```javascript
renderOverview()              // Vue d'ensemble
renderAudits()                // Audits SEO
renderMonitoring()            // Monitoring uptime
renderLocalSeo()              // Local SEO / GBP
renderMissions()              // Missions / tâches
renderAnalytics()             // GA4 + Search Console
renderReports() / renderReportsHistory()  // Rapports
renderBilling()               // Facturation (addons/invoices/usage)
renderSettings()              // Paramètres (toutes sous-sections)
renderClientMode()            // Portail client
```

---

## 🗄️ Structure données principales (STATE)

```javascript
STATE = {
  currentSection: 'overview',
  me: { plan:'pro', orgId:'...', name:'Maël D.', role:'admin',
        addons: { whiteLabel:true, prioritySupport:true, ... } },
  team: [...],
  sites: [...],           // Sites clients monitorés
  gbp: { connected:true, ... },
  gsc: { connected:true, ... },
  github: { connected:false, ... },
  teamChatHistory: [...], // Messages chat équipe
  notifications: [...],
}
```

---

## 📡 API Routes principales (/api/*)

| Route | Méthode | Description |
|-------|---------|-------------|
| /api/auth/login | POST | Connexion JWT |
| /api/auth/me | GET | Profil utilisateur courant |
| /api/monitoring/sites | GET/POST | Sites surveillés |
| /api/audits | GET/POST | Audits SEO |
| /api/reports | GET/POST | Rapports |
| /api/billing/portal | POST | Portail Stripe |
| /api/billing/checkout | POST | Checkout Stripe |
| /api/integrations | GET | Liste webhooks |
| /api/integrations/templates | GET | Templates |
| /api/automation/workflows | GET/POST | Workflows |
| /api/white-label/templates | GET | Templates white-label |

---

## 🔧 Ce qui est fait (état actuel)

- ✅ Dashboard complet ~37 000 lignes (JS+CSS+HTML)
- ✅ 10+ sections principales entièrement rendues
- ✅ Design system dark-mode cohérent
- ✅ Authentification JWT + SSO (SAML/OIDC)
- ✅ Stripe intégré (abonnements, portail, webhooks)
- ✅ 15 intégrations avec logos SVG
- ✅ 12 templates d'intégration avec catégories
- ✅ 29 add-ons marketplace (grille 4 col)
- ✅ Webhooks sortants/entrants configurables
- ✅ Tableau de bord client (portail)
- ✅ Chat équipe temps réel avec pièces jointes
- ✅ Picker emoji sur les messages
- ✅ Tables avec colonnes centrées partout
- ✅ AI blocks avec suggestions contextuelles
- ✅ Mode mobile (responsive)
- ✅ Rapports PDF white-label

---

## 💡 Pistes d'amélioration potentielles

1. **Tests E2E** — Playwright pour valider les flows critiques
2. **Onboarding** — Wizard de démarrage (modal step-by-step)
3. **Notifications push** — Web Push API pour alertes hors-dashboard
4. **Dark/Light mode toggle** — Actuellement 100% dark
5. **Export Excel** — En plus du CSV déjà disponible
6. **Graphiques temps réel** — WebSocket pour les métriques live
7. **Multi-langue** — i18n (actuellement 100% français)
8. **PWA** — Service worker + manifest pour installation mobile
9. **Raccourcis clavier** — Navigation rapide (Cmd+K command palette)
10. **Drag & drop** — Réordonner les missions et widgets dashboard

---

## 📝 Convention de versioning

Les fichiers CSS/JS utilisent un paramètre de version pour cache-busting :
`dashboard.css?v=20260602r` — format `YYYYMMDD` + lettre

Toujours bumper les deux dans `dashboard.html` après modification.

Valider le JS avant commit : `node --check dashboard.js`

---

*Ce fichier est accessible publiquement à :*
`https://637b3722-0749-4a98-8b79-abfeb0a1d3ce-00-2vuijftxq94iq.picard.replit.dev/llm-context.md`
