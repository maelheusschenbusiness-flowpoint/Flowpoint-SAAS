import OpenAI from "openai";
import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";

const openai = process.env["OPENAI_API_KEY"]
  ? new OpenAI({ apiKey: process.env["OPENAI_API_KEY"] })
  : null;

export interface LLMVisibilityResult {
  domain: string;
  score: number;
  mentioned: boolean;
  probeCount: number;
  mentionCount: number;
  status: "ok" | "no_openai" | "error";
  checkedAt?: string;
}

const EMPTY: Omit<LLMVisibilityResult, "domain"> = {
  score: 0, mentioned: false, probeCount: 0, mentionCount: 0, status: "no_openai",
};

const PROBES = [
  (sector: string) => `Quels outils ou logiciels recommandes-tu pour ${sector} en France ? Donne une liste courte.`,
  (sector: string) => `Quelles plateformes utiliser pour gérer ${sector} ? Liste les principales.`,
  (sector: string) => `Nomme les meilleurs services en ligne pour ${sector}. Sois bref.`,
  (sector: string) => `Quels sont les leaders du marché en ${sector} en France ? Cite les plus connus.`,
];

async function ensureTable(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS seo_llm_visibility (
      id          TEXT PRIMARY KEY,
      org_id      TEXT NOT NULL,
      domain      TEXT NOT NULL,
      score       INTEGER NOT NULL,
      mentioned   BOOLEAN NOT NULL,
      probe_count INTEGER NOT NULL,
      mention_count INTEGER NOT NULL,
      status      TEXT NOT NULL,
      checked_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

async function saveLLMVisibility(result: LLMVisibilityResult, orgId: string): Promise<void> {
  try {
    await ensureTable();
    const id = `llmv_${orgId}_${result.domain.replace(/[^a-z0-9]/gi, "_")}`;
    await pool.query(
      `INSERT INTO seo_llm_visibility
         (id, org_id, domain, score, mentioned, probe_count, mention_count, status, checked_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW())
       ON CONFLICT (id) DO UPDATE SET
         score = EXCLUDED.score, mentioned = EXCLUDED.mentioned,
         probe_count = EXCLUDED.probe_count, mention_count = EXCLUDED.mention_count,
         status = EXCLUDED.status, checked_at = NOW()`,
      [id, orgId, result.domain, result.score, result.mentioned,
       result.probeCount, result.mentionCount, result.status],
    );
  } catch (err) {
    logger.warn({ err }, "[LLMVisibility] persist failed");
  }
}

export async function checkLLMVisibility(
  domain: string,
  sector = "SEO local",
  orgId = "default",
): Promise<LLMVisibilityResult> {
  if (!openai) {
    return { domain, ...EMPTY };
  }

  const brand = domain
    .replace(/^https?:\/\//, "")
    .replace(/\.(fr|com|net|org|io)$/, "")
    .replace(/-/g, " ")
    .toLowerCase();

  let mentionCount = 0;
  let successfulProbes = 0;
  const probeCount = PROBES.length;

  for (const probe of PROBES) {
    try {
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        temperature: 0,
        max_tokens: 200,
        messages: [{ role: "user", content: probe(sector) }],
      });
      const text = (completion.choices[0]?.message?.content ?? "").toLowerCase();
      successfulProbes++;
      if (brand.length >= 3 && text.includes(brand)) mentionCount++;
    } catch (err) {
      logger.warn({ err }, "[LLMVisibility] probe failed");
    }
  }

  if (successfulProbes === 0) {
    return { domain, score: 0, mentioned: false, probeCount, mentionCount: 0, status: "error" };
  }

  const SCORE_BUCKETS = [0, 25, 50, 75, 100];
  const bucketIdx = Math.round((mentionCount / successfulProbes) * (SCORE_BUCKETS.length - 1));
  const score = SCORE_BUCKETS[bucketIdx] ?? 0;
  const result: LLMVisibilityResult = {
    domain,
    score,
    mentioned: mentionCount > 0,
    probeCount,
    mentionCount,
    status: "ok",
    checkedAt: new Date().toISOString(),
  };
  await saveLLMVisibility(result, orgId);
  return result;
}
