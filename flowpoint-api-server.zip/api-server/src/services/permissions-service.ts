import { pool } from "@workspace/db";

export const ALL_RESOURCES = [
  'audits','monitors','reports','missions','ai','billing','integrations',
  'exports','alerts','competitors','local-seo','team','api','automation','data',
  'crm','market-intelligence','permissions','white-label',
] as const;

export const ALL_ACTIONS = ['read','create','update','delete','export','manage'] as const;

export interface OrgRole {
  id: string;
  org_id: string;
  name: string;
  slug: string;
  description: string | null;
  color: string;
  is_system: boolean;
  is_custom: boolean;
  permissions: string[];
  member_count: number;
}

export async function getRoles(orgId: string): Promise<OrgRole[]> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM org_roles WHERE org_id=$1 ORDER BY is_system DESC, name ASC`, [orgId]);
    return r.rows as OrgRole[];
  } finally {
    client.release();
  }
}

export async function createRole(orgId: string, plan: string, data: {
  name: string; description?: string; color?: string; permissions?: string[]; parentRoleId?: string;
}): Promise<OrgRole> {
  if (plan === 'Standard') throw new Error("Rôles personnalisés — Pro ou Ultra requis");
  const id = `role_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const slug = data.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  const client = await pool.connect();
  try {
    const r = await client.query(`INSERT INTO org_roles (id,org_id,name,slug,description,color,is_custom,permissions,parent_role_id) VALUES ($1,$2,$3,$4,$5,$6,true,$7,$8) RETURNING *`,
      [id, orgId, data.name, slug, data.description || null, data.color || '#6b7280', JSON.stringify(data.permissions || []), data.parentRoleId || null]);
    return r.rows[0] as OrgRole;
  } finally {
    client.release();
  }
}

export async function updateRole(orgId: string, roleId: string, data: Partial<{ name: string; description: string; color: string; permissions: string[] }>): Promise<void> {
  const updates: string[] = ['updated_at=now()'];
  const params: unknown[] = [];
  if (data.name)        { params.push(data.name);                    updates.push(`name=$${params.length}`); }
  if (data.description !== undefined) { params.push(data.description); updates.push(`description=$${params.length}`); }
  if (data.color)       { params.push(data.color);                   updates.push(`color=$${params.length}`); }
  if (data.permissions) { params.push(JSON.stringify(data.permissions)); updates.push(`permissions=$${params.length}`); }
  params.push(roleId, orgId);
  const client = await pool.connect();
  try {
    await client.query(`UPDATE org_roles SET ${updates.join(',')} WHERE id=$${params.length-1} AND org_id=$${params.length} AND is_system=false`, params);
  } finally {
    client.release();
  }
}

export async function deleteRole(orgId: string, roleId: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`DELETE FROM org_roles WHERE id=$1 AND org_id=$2 AND is_system=false`, [roleId, orgId]);
  } finally {
    client.release();
  }
}

export async function assignRole(orgId: string, userId: string, roleId: string, grantedBy: string): Promise<void> {
  const id = `tmr_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
  const client = await pool.connect();
  try {
    await client.query(`UPDATE team_member_roles SET active=false WHERE org_id=$1 AND user_id=$2`, [orgId, userId]);
    await client.query(`INSERT INTO team_member_roles (id,org_id,user_id,role_id,granted_by,active) VALUES ($1,$2,$3,$4,$5,true)`,
      [id, orgId, userId, roleId, grantedBy]);
  } finally {
    client.release();
  }
}

export async function getPermissionLogs(orgId: string, limit = 50): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM permission_logs WHERE org_id=$1 ORDER BY created_at DESC LIMIT $2`, [orgId, limit]);
    return r.rows;
  } finally {
    client.release();
  }
}

export async function getAccessAudits(orgId: string, limit = 50): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM access_audits WHERE org_id=$1 ORDER BY created_at DESC LIMIT $2`, [orgId, limit]);
    return r.rows;
  } finally {
    client.release();
  }
}

export async function logAccess(orgId: string, userId: string, eventType: string, resource: string, details?: Record<string, unknown>, severity = 'info'): Promise<void> {
  const id = `aa_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
  const client = await pool.connect();
  try {
    await client.query(`INSERT INTO access_audits (id,org_id,user_id,event_type,resource,details,severity) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [id, orgId, userId, eventType, resource, JSON.stringify(details || {}), severity]);
  } catch { /* non-blocking */ } finally {
    client.release();
  }
}

export async function getPermissionsStats(orgId: string): Promise<Record<string, unknown>> {
  const client = await pool.connect();
  try {
    const [rolesRes, logsRes, auditsRes] = await Promise.all([
      client.query(`SELECT COUNT(*) total, COUNT(*) FILTER(WHERE is_custom=true) custom FROM org_roles WHERE org_id=$1`, [orgId]),
      client.query(`SELECT COUNT(*) FROM permission_logs WHERE org_id=$1 AND created_at > now()-interval'7d'`, [orgId]),
      client.query(`SELECT COUNT(*) FROM access_audits WHERE org_id=$1 AND severity='warning' AND created_at > now()-interval'24h'`, [orgId]),
    ]);
    return {
      totalRoles: parseInt(rolesRes.rows[0].total, 10),
      customRoles: parseInt(rolesRes.rows[0].custom, 10),
      recentChanges: parseInt(logsRes.rows[0].count, 10),
      securityAlerts: parseInt(auditsRes.rows[0].count, 10),
    };
  } finally {
    client.release();
  }
}
