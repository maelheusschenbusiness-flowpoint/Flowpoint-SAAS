/**
 * FlowPoint — Org Settings persistence
 *
 * Stores per-org configuration (plan, addons, usage, billing) in PostgreSQL.
 * Replaces the in-memory store.me singleton with DB-backed data that survives
 * server restarts and is correctly scoped per orgId.
 */

import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";

export interface OrgSettingsRow {
  firstName: string;
  orgName: string;
  plan: string;
  subscriptionStatus: string;
  trialEndsAt: string | null;
  stripeCustomerId: string;
  addons: {
    whiteLabel: boolean;
    prioritySupport: boolean;
    customDomain: boolean;
    extraSeats: number;
    monitorsPack50: number;
  };
  usage: {
    audit: { used: number; limit: number };
    pdf:   { used: number; limit: number };
    exports: { used: number; limit: number };
    monitor: { used: number; limit: number };
  };
}

const DEFAULT_ADDONS = {
  whiteLabel: false,
  prioritySupport: false,
  customDomain: false,
  extraSeats: 0,
  monitorsPack50: 0,
};

const DEFAULT_USAGE = {
  audit:   { used: 0, limit: 30 },
  pdf:     { used: 0, limit: 30 },
  exports: { used: 0, limit: 30 },
  monitor: { used: 0, limit: 3  },
};

export async function ensureOrgSettingsTable(): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS org_settings (
        org_id             TEXT PRIMARY KEY DEFAULT 'default',
        first_name         TEXT NOT NULL DEFAULT '',
        org_name           TEXT NOT NULL DEFAULT 'Mon Agence',
        plan               TEXT NOT NULL DEFAULT 'standard',
        subscription_status TEXT NOT NULL DEFAULT 'trialing',
        trial_ends_at      TEXT,
        stripe_customer_id TEXT NOT NULL DEFAULT '',
        addons             JSONB NOT NULL DEFAULT '{"whiteLabel":false,"prioritySupport":false,"customDomain":false,"extraSeats":0,"monitorsPack50":0}',
        usage              JSONB NOT NULL DEFAULT '{"audit":{"used":0,"limit":30},"pdf":{"used":0,"limit":30},"exports":{"used":0,"limit":30},"monitor":{"used":0,"limit":3}}',
        updated_at         TIMESTAMPTZ DEFAULT now() NOT NULL
      );
    `);
    logger.info("[OrgSettings] Table ready");
  } finally {
    client.release();
  }
}

export async function loadOrgSettings(orgId = "default"): Promise<OrgSettingsRow | null> {
  const client = await pool.connect();
  try {
    const r = await client.query(
      "SELECT * FROM org_settings WHERE org_id = $1 LIMIT 1",
      [orgId]
    );
    if (r.rows.length === 0) return null;
    const row = r.rows[0];
    return {
      firstName:          row.first_name         ?? "",
      orgName:            row.org_name            ?? "Mon Agence",
      plan:               row.plan               ?? "standard",
      subscriptionStatus: row.subscription_status ?? "trialing",
      trialEndsAt:        row.trial_ends_at       ?? null,
      stripeCustomerId:   row.stripe_customer_id  ?? "",
      addons:             { ...DEFAULT_ADDONS, ...(row.addons ?? {}) },
      usage:              { ...DEFAULT_USAGE,  ...(row.usage  ?? {}) },
    };
  } finally {
    client.release();
  }
}

export async function upsertOrgSettings(orgId = "default", data: Partial<OrgSettingsRow>): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`
      INSERT INTO org_settings
        (org_id, first_name, org_name, plan, subscription_status, trial_ends_at, stripe_customer_id, addons, usage, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9::jsonb,now())
      ON CONFLICT (org_id) DO UPDATE SET
        first_name         = EXCLUDED.first_name,
        org_name           = EXCLUDED.org_name,
        plan               = EXCLUDED.plan,
        subscription_status = EXCLUDED.subscription_status,
        trial_ends_at      = EXCLUDED.trial_ends_at,
        stripe_customer_id = EXCLUDED.stripe_customer_id,
        addons             = EXCLUDED.addons,
        usage              = EXCLUDED.usage,
        updated_at         = now()
    `, [
      orgId,
      data.firstName         ?? "",
      data.orgName           ?? "Mon Agence",
      data.plan              ?? "standard",
      data.subscriptionStatus ?? "trialing",
      data.trialEndsAt       ?? null,
      data.stripeCustomerId  ?? "",
      JSON.stringify(data.addons ?? DEFAULT_ADDONS),
      JSON.stringify(data.usage  ?? DEFAULT_USAGE),
    ]);
  } finally {
    client.release();
  }
}

export async function patchOrgUsage(
  orgId = "default",
  field: "audit" | "pdf" | "exports" | "monitor",
  delta: number
): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`
      UPDATE org_settings
      SET usage = jsonb_set(
        usage,
        ARRAY[$2, 'used'],
        to_jsonb(GREATEST(0, COALESCE((usage->$2->>'used')::int, 0) + $3))
      ),
      updated_at = now()
      WHERE org_id = $1
    `, [orgId, field, delta]);
  } finally {
    client.release();
  }
}
