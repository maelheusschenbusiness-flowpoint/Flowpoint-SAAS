import { pool } from "@workspace/db";
import OpenAI from "openai";
import { isDemoMode } from "./mock-data.js";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function getMarketDashboard(orgId: string): Promise<Record<string, unknown>> {
  const client = await pool.connect();
  try {
    const [trendsRes, oppsRes, movementsRes, signalsRes, reportsRes] = await Promise.all([
      client.query(`SELECT * FROM market_trends WHERE org_id=$1 ORDER BY opportunity_score DESC LIMIT 20`, [orgId]),
      client.query(`SELECT * FROM market_opportunities WHERE org_id=$1 ORDER BY score DESC LIMIT 15`, [orgId]),
      client.query(`SELECT * FROM competitor_movements WHERE org_id=$1 ORDER BY detected_at DESC LIMIT 10`, [orgId]),
      client.query(`SELECT * FROM industry_signals WHERE org_id=$1 AND (expires_at IS NULL OR expires_at > now()) ORDER BY created_at DESC LIMIT 10`, [orgId]),
      client.query(`SELECT * FROM ai_market_reports WHERE org_id=$1 ORDER BY generated_at DESC LIMIT 3`, [orgId]),
    ]);
    const trends = trendsRes.rows;
    const opportunities = oppsRes.rows;
    return {
      trends, opportunities,
      competitor_movements: movementsRes.rows,
      signals: signalsRes.rows,
      reports: reportsRes.rows,
      stats: {
        totalTrends: trends.length,
        emergingTrends: trends.filter((t: { is_emerging: boolean }) => t.is_emerging).length,
        avgOpportunityScore: trends.length > 0 ? Math.round(trends.reduce((s: number, t: { opportunity_score: number }) => s + t.opportunity_score, 0) / trends.length) : 0,
        totalOpportunities: opportunities.length,
        criticalSignals: signalsRes.rows.filter((s: { severity: string }) => s.severity === 'critical').length,
      },
    };
  } finally {
    client.release();
  }
}

export async function seedMarketData(orgId: string): Promise<void> {
  if (!isDemoMode()) return; // production: market trends come from real DataForSEO analysis
  const client = await pool.connect();
  try {
    const existing = await client.query(`SELECT COUNT(*) FROM market_trends WHERE org_id=$1`, [orgId]);
    if (parseInt(existing.rows[0].count, 10) > 0) return;

    const trends = [
      { keyword:'plombier urgence', direction:'up', growth:34.2, volume:8900, competition:'medium', score:82, emerging:true, geo:'Paris' },
      { keyword:'rénovation salle de bain', direction:'up', growth:28.7, volume:12400, competition:'high', score:71, emerging:false, geo:'Île-de-France' },
      { keyword:'chauffagiste pompe à chaleur', direction:'up', growth:67.1, volume:5600, competition:'low', score:91, emerging:true, geo:'France' },
      { keyword:'devis gratuit plomberie', direction:'stable', growth:5.2, volume:22000, competition:'high', score:64, emerging:false, geo:'France' },
      { keyword:'electricien certifié rge', direction:'up', growth:41.8, volume:7300, competition:'medium', score:85, emerging:true, geo:'France' },
      { keyword:'artisan local rapide', direction:'up', growth:18.3, volume:15600, competition:'low', score:78, emerging:false, geo:'Local' },
    ];
    for (const t of trends) {
      const id = `mt_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
      await client.query(`INSERT INTO market_trends (id,org_id,keyword,trend_direction,growth_rate,search_volume,competition_level,opportunity_score,is_emerging,geo) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT DO NOTHING`,
        [id,orgId,t.keyword,t.direction,t.growth,t.volume,t.competition,t.score,t.emerging,t.geo]);
    }
    const opps = [
      { title:'Mots-clés émergents PAC', desc:'7 mots-clés pompe à chaleur en forte croissance avec peu de concurrence', type:'keyword', score:91, traffic:3200, difficulty:'low', timeframe:'1-2 mois' },
      { title:'Zones géographiques non couvertes', desc:'3 arrondissements parisiens sans présence GBP optimisée', type:'geo', score:84, traffic:5100, difficulty:'medium', timeframe:'2-4 semaines' },
      { title:'Contenu FAQ local', desc:'Opportunité de featured snippets sur 12 questions locales', type:'content', score:76, traffic:2800, difficulty:'low', timeframe:'1 mois' },
    ];
    for (const o of opps) {
      const id = `mo_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
      await client.query(`INSERT INTO market_opportunities (id,org_id,title,description,type,score,estimated_traffic,difficulty,timeframe) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT DO NOTHING`,
        [id,orgId,o.title,o.desc,o.type,o.score,o.traffic,o.difficulty,o.timeframe]);
    }
    const signals = [
      { type:'ranking_volatility', title:'Volatilité élevée détectée', desc:'Fluctuations inhabituelles dans les SERP locaux cette semaine', severity:'warning', category:'seo' },
      { type:'competitor_surge', title:'Nouveau concurrent actif', desc:'rapidplomberie.fr +35 mots-clés top 10 ce mois', severity:'info', category:'competitor' },
      { type:'market_opportunity', title:'Marché PAC sous-exploité', desc:'Forte demande, offre locale insuffisante dans votre secteur', severity:'info', category:'opportunity' },
    ];
    for (const s of signals) {
      const id = `is_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
      await client.query(`INSERT INTO industry_signals (id,org_id,signal_type,title,description,severity,category) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`,
        [id,orgId,s.type,s.title,s.desc,s.severity,s.category]);
    }
  } finally {
    client.release();
  }
}

export async function generateMarketReport(orgId: string): Promise<unknown> {
  const client = await pool.connect();
  try {
    const [trendsRes, oppsRes] = await Promise.all([
      client.query(`SELECT * FROM market_trends WHERE org_id=$1 ORDER BY opportunity_score DESC LIMIT 5`, [orgId]),
      client.query(`SELECT * FROM market_opportunities WHERE org_id=$1 ORDER BY score DESC LIMIT 3`, [orgId]),
    ]);
    const trends = trendsRes.rows;
    const opportunities = oppsRes.rows;

    let summary = 'Rapport d\'intelligence marché généré automatiquement.';
    if (process.env.OPENAI_API_KEY) {
      try {
        const completion = await openai.chat.completions.create({
          model: 'gpt-4o-mini',
          max_tokens: 400,
          messages: [
            { role: 'system', content: 'Tu es un expert SEO local. Génère un résumé stratégique concis en français.' },
            { role: 'user', content: `Tendances détectées : ${trends.slice(0,3).map((t: { keyword: string; growth_rate: number }) => `${t.keyword} (+${t.growth_rate}%)`).join(', ')}. Meilleures opportunités : ${opportunities.slice(0,2).map((o: { title: string; score: number }) => `${o.title} (score ${o.score})`).join(', ')}. Résume en 3 points d'action stratégique.` },
          ],
        });
        summary = completion.choices[0]?.message?.content || summary;
      } catch { /* non-blocking */ }
    }

    const id = `amr_${Date.now()}_${Math.random().toString(36).slice(2,5)}`;
    const now = new Date();
    await client.query(`INSERT INTO ai_market_reports (id,org_id,title,report_type,summary,opportunities,period_start,period_end) VALUES ($1,$2,$3,'weekly',$4,$5,now()-interval'7d',now())`,
      [id, orgId, `Rapport Intelligence Marché — ${now.toLocaleDateString('fr-FR')}`, summary, JSON.stringify(opportunities.map((o: { title: string; score: number }) => ({ title: o.title, score: o.score })))]);
    const r = await client.query(`SELECT * FROM ai_market_reports WHERE id=$1`, [id]);
    return r.rows[0];
  } finally {
    client.release();
  }
}

export async function detectCompetitorMovements(orgId: string, competitorDomain: string): Promise<unknown> {
  const id = `cm_${Date.now()}_${Math.random().toString(36).slice(2,5)}`;
  const client = await pool.connect();
  try {
    const gained = ['seo local', 'plombier rapide', 'devis gratuit'];
    await client.query(`INSERT INTO competitor_movements (id,org_id,competitor_domain,movement_type,description,impact_level,keywords_gained,estimated_traffic_change) VALUES ($1,$2,$3,'keyword_gain','Gain de positions détecté','medium',$4,$5)`,
      [id, orgId, competitorDomain, gained, 0]);
    const r = await client.query(`SELECT * FROM competitor_movements WHERE id=$1`, [id]);
    return r.rows[0];
  } finally {
    client.release();
  }
}
