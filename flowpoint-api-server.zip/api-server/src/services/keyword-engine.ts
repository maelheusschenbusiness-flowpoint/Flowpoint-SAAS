import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { store } from "./store.js";
import { isDemoMode } from "./mock-data.js";
import { evaluateAlertRulesForKeyword } from "./monitor-cron.js";
import {
  isDataForSEOConfigured,
  getSERP,
  getKeywordSuggestions,
  type SERPResult,
} from "./dataforseo-service.js";
import OpenAI from "openai";

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

// ── Plan limits ───────────────────────────────────────────────────────────────
const PLAN_KW_LIMITS: Record<string, number> = {
  Standard: 25,
  Pro: 250,
  Ultra: 2500,
  Agency: 2500,
};

export function getKeywordLimit(plan: string): number {
  return PLAN_KW_LIMITS[plan] ?? 25;
}

// ── Core types ────────────────────────────────────────────────────────────────
export interface TrackedKeyword {
  id: string;
  org_id: string;
  keyword: string;
  url: string | null;
  device: string;
  location: string;
  language: string;
  tag: string | null;
  cluster_id: string | null;
  intent: string | null;
  search_volume: number;
  difficulty: number;
  cpc: number;
  current_position: number | null;
  prev_position: number | null;
  best_position: number | null;
  worst_position: number | null;
  position_change: number;
  trend: string;
  volatility: number;
  serp_features: Record<string, unknown> | null;
  last_synced_at: string | null;
  active: boolean;
  created_at: string;
}

export interface KeywordRanking {
  id: string;
  keyword_id: string;
  keyword: string;
  position: number | null;
  url: string | null;
  serp_features: Record<string, unknown> | null;
  volatility: number;
  checked_at: string;
}

export interface KeywordCluster {
  id: string;
  org_id: string;
  name: string;
  description: string | null;
  intent: string | null;
  keywords: string[];
  keyword_count: number;
  avg_position: number | null;
  avg_volume: number;
  total_volume: number;
  ai_summary: string | null;
  color: string;
}

export interface KeywordOpportunity {
  id: string;
  org_id: string;
  keyword: string;
  search_volume: number;
  difficulty: number;
  cpc: number;
  intent: string | null;
  opportunity_score: number;
  type: string;
  current_position: number | null;
  potential_position: number | null;
  estimated_traffic: number;
  ai_explanation: string | null;
  status: string;
}

// ── Track keyword ─────────────────────────────────────────────────────────────
export async function trackKeyword(
  orgId: string,
  plan: string,
  keyword: string,
  opts: {
    url?: string;
    device?: string;
    location?: string;
    language?: string;
    tag?: string;
  } = {}
): Promise<TrackedKeyword> {
  const client = await pool.connect();
  try {
    const limit = getKeywordLimit(plan);
    const countRes = await client.query(
      `SELECT COUNT(*) FROM tracked_keywords WHERE org_id = $1 AND active = true`,
      [orgId]
    );
    if (parseInt(countRes.rows[0].count, 10) >= limit) {
      throw new Error(`Plan limit reached: ${limit} keywords max on ${plan} plan. Upgrade to track more.`);
    }

    const id = `kw_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const device = opts.device || "desktop";
    const location = opts.location || "France";
    const language = opts.language || "fr";

    const res = await client.query(`
      INSERT INTO tracked_keywords (id, org_id, keyword, url, device, location, language, tag, active)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,true)
      ON CONFLICT (org_id, keyword, device, location) DO UPDATE
        SET active = true, tag = EXCLUDED.tag, updated_at = now()
      RETURNING *
    `, [id, orgId, keyword.trim().toLowerCase(), opts.url || null, device, location, language, opts.tag || null]);

    store.logActivity({
      type: "audit",
      label: `Keyword ajouté au suivi : "${keyword}"`,
      targetId: res.rows[0].id,
      targetType: "keyword",
      metadata: { keyword, device, location },
    }).catch(() => {});

    return res.rows[0] as TrackedKeyword;
  } finally {
    client.release();
  }
}

// ── Sync rankings for a single keyword ───────────────────────────────────────
async function syncSingleKeyword(
  kw: TrackedKeyword,
  orgId: string
): Promise<void> {
  const client = await pool.connect();
  try {
    let position: number | null = null;
    let serpUrl: string | null = null;
    let serpFeatures: Record<string, unknown> = {};

    if (isDataForSEOConfigured()) {
      try {
        const serpResults: SERPResult[] = await getSERP(kw.keyword, kw.location, kw.language);
        const myResult = kw.url
          ? serpResults.find(r => r.url.includes(kw.url!.replace(/^https?:\/\//, "").split("/")[0]))
          : null;

        if (myResult) {
          position = myResult.position;
          serpUrl = myResult.url;
          serpFeatures = {
            hasAIOverview: myResult.hasAIOverview,
            hasFeaturedSnippet: myResult.hasFeaturedSnippet,
            peopleAlsoAsk: myResult.peopleAlsoAsk?.length || 0,
            volatility: myResult.volatility,
          };
        } else {
          position = null; // Not found in top 100
        }
      } catch (err) {
        logger.warn({ err, kw: kw.keyword }, "[KWEngine] SERP fetch failed");
      }
    } else {
      // No DataForSEO credentials: keep last known position in production, simulate in demo only
      if (isDemoMode()) {
        const prevPos = kw.current_position;
        if (prevPos) {
          const delta = Math.floor(Math.random() * 5) - 2;
          position = Math.max(1, Math.min(100, prevPos + delta));
        } else {
          position = Math.floor(Math.random() * 30) + 1;
        }
      } else {
        position = kw.current_position ?? null;
      }
    }

    const prevPosition = kw.current_position;
    const posChange = prevPosition !== null && position !== null ? prevPosition - position : null;
    const trend = posChange !== null && posChange > 0 ? "up" : posChange !== null && posChange < 0 ? "down" : "stable";

    // Compute volatility (std dev of last 7 positions)
    const histRes = await client.query(
      `SELECT position FROM keyword_rankings WHERE keyword_id = $1 ORDER BY checked_at DESC LIMIT 7`,
      [kw.id]
    );
    const history = histRes.rows.map((r: { position: number }) => r.position).filter((p: number) => p !== null);
    let volatility = 0;
    if (history.length > 1) {
      const avg = history.reduce((a: number, b: number) => a + b, 0) / history.length;
      volatility = Math.sqrt(history.reduce((s: number, p: number) => s + Math.pow(p - avg, 2), 0) / history.length);
    }

    // Insert ranking snapshot
    const rankId = `rank_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await client.query(`
      INSERT INTO keyword_rankings (id, org_id, keyword_id, keyword, position, url, serp_features, volatility)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `, [rankId, orgId, kw.id, kw.keyword, position, serpUrl, JSON.stringify(serpFeatures), volatility]);

    // Update tracked keyword
    const bestPos = kw.best_position === null ? position : (position !== null ? Math.min(kw.best_position, position) : kw.best_position);
    const worstPos = kw.worst_position === null ? position : (position !== null ? Math.max(kw.worst_position, position) : kw.worst_position);

    await client.query(`
      UPDATE tracked_keywords
      SET current_position = $1, prev_position = $2, position_change = $3,
          trend = $4, volatility = $5, best_position = $6, worst_position = $7,
          serp_features = $8, last_synced_at = now(), updated_at = now()
      WHERE id = $9
    `, [position, prevPosition, posChange, trend, volatility, bestPos, worstPos, JSON.stringify(serpFeatures), kw.id]);

    // Check alerts
    await checkAndCreateAlert(client, orgId, kw, prevPosition, position, posChange ?? 0);

    // Evaluate keyword_ranking_drop alert rules when position dropped
    if (posChange !== null && posChange < 0 && serpUrl) {
      await evaluateAlertRulesForKeyword(serpUrl, -posChange).catch(() => {});
    }

  } finally {
    client.release();
  }
}

// ── Alert detection ───────────────────────────────────────────────────────────
async function checkAndCreateAlert(
  client: Awaited<ReturnType<typeof pool.connect>>,
  orgId: string,
  kw: TrackedKeyword,
  prevPos: number | null,
  newPos: number | null,
  change: number
): Promise<void> {
  if (prevPos === null || newPos === null) return;

  let alertType: string | null = null;
  let severity = "info";
  let message = "";

  if (change <= -5) {
    alertType = "ranking_drop";
    severity = "critical";
    message = `"${kw.keyword}" a chuté de ${Math.abs(change)} positions (${prevPos} → ${newPos})`;
  } else if (change <= -3) {
    alertType = "ranking_drop";
    severity = "warning";
    message = `"${kw.keyword}" a reculé de ${Math.abs(change)} positions (${prevPos} → ${newPos})`;
  } else if (change >= 5) {
    alertType = "ranking_gain";
    severity = "success";
    message = `"${kw.keyword}" a gagné ${change} positions ! (${prevPos} → ${newPos})`;
  } else if (newPos <= 3 && prevPos > 3) {
    alertType = "top3_entry";
    severity = "success";
    message = `"${kw.keyword}" entre dans le Top 3 ! Position ${newPos}`;
  } else if (newPos <= 10 && prevPos > 10) {
    alertType = "top10_entry";
    severity = "info";
    message = `"${kw.keyword}" entre dans le Top 10. Position ${newPos}`;
  } else if (newPos > 10 && prevPos <= 10) {
    alertType = "top10_exit";
    severity = "warning";
    message = `"${kw.keyword}" est sorti du Top 10. Position ${newPos}`;
  }

  if (alertType) {
    const alertId = `alert_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await client.query(`
      INSERT INTO ranking_alerts (id, org_id, keyword_id, keyword, alert_type, severity, old_position, new_position, change, message)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    `, [alertId, orgId, kw.id, kw.keyword, alertType, severity, prevPos, newPos, change, message]).catch(() => {});
  }
}

// ── Sync all tracked keywords for an org ─────────────────────────────────────
export async function syncOrgRankings(orgId: string): Promise<{
  synced: number;
  errors: number;
  durationMs: number;
}> {
  const startMs = Date.now();
  const client = await pool.connect();
  let keywords: TrackedKeyword[] = [];
  try {
    const res = await client.query(
      `SELECT * FROM tracked_keywords WHERE org_id = $1 AND active = true ORDER BY created_at`,
      [orgId]
    );
    keywords = res.rows as TrackedKeyword[];
  } finally {
    client.release();
  }

  let synced = 0;
  let errors = 0;

  // Process in batches of 5 (rate limit consideration)
  for (let i = 0; i < keywords.length; i += 5) {
    const batch = keywords.slice(i, i + 5);
    const results = await Promise.allSettled(
      batch.map(kw => syncSingleKeyword(kw, orgId))
    );
    for (const r of results) {
      if (r.status === "fulfilled") synced++;
      else { errors++; logger.warn({ err: r.reason }, "[KWEngine] sync error"); }
    }
    if (i + 5 < keywords.length) await new Promise(r => setTimeout(r, 1000));
  }

  const durationMs = Date.now() - startMs;
  logger.info({ orgId, synced, errors, durationMs }, "[KWEngine] Rankings synced");
  return { synced, errors, durationMs };
}

// ── Get ranking history ───────────────────────────────────────────────────────
export async function getRankingHistory(
  keywordId: string,
  orgId: string,
  days = 30
): Promise<KeywordRanking[]> {
  const client = await pool.connect();
  try {
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const res = await client.query(
      `SELECT * FROM keyword_rankings
       WHERE keyword_id = $1 AND org_id = $2 AND checked_at >= $3
       ORDER BY checked_at ASC`,
      [keywordId, orgId, since]
    );
    return res.rows as KeywordRanking[];
  } finally {
    client.release();
  }
}

// ── Get keyword stats for org ─────────────────────────────────────────────────
export async function getKeywordStats(orgId: string): Promise<{
  total: number;
  tracked: number;
  top3: number;
  top10: number;
  top100: number;
  notRanking: number;
  gainingPositions: number;
  losingPositions: number;
  avgPosition: number;
  totalVolume: number;
  unreadAlerts: number;
}> {
  const client = await pool.connect();
  try {
    const [kwRes, alertRes] = await Promise.all([
      client.query(`SELECT * FROM tracked_keywords WHERE org_id = $1 AND active = true`, [orgId]),
      client.query(`SELECT COUNT(*) FROM ranking_alerts WHERE org_id = $1 AND read = false`, [orgId]),
    ]);
    const kws = kwRes.rows as TrackedKeyword[];
    const positions = kws.map(k => k.current_position).filter(p => p !== null) as number[];
    return {
      total: kws.length,
      tracked: kws.length,
      top3: kws.filter(k => k.current_position !== null && k.current_position <= 3).length,
      top10: kws.filter(k => k.current_position !== null && k.current_position <= 10).length,
      top100: positions.length,
      notRanking: kws.filter(k => k.current_position === null).length,
      gainingPositions: kws.filter(k => k.trend === "up").length,
      losingPositions: kws.filter(k => k.trend === "down").length,
      avgPosition: positions.length ? Math.round(positions.reduce((a, b) => a + b, 0) / positions.length) : 0,
      totalVolume: kws.reduce((s, k) => s + (k.search_volume || 0), 0),
      unreadAlerts: parseInt(alertRes.rows[0].count, 10),
    };
  } finally {
    client.release();
  }
}

// ── AI Keyword Clustering ─────────────────────────────────────────────────────
export async function generateClusters(orgId: string): Promise<KeywordCluster[]> {
  const client = await pool.connect();
  let keywords: TrackedKeyword[] = [];
  try {
    const res = await client.query(
      `SELECT * FROM tracked_keywords WHERE org_id = $1 AND active = true`,
      [orgId]
    );
    keywords = res.rows as TrackedKeyword[];
  } finally {
    client.release();
  }

  if (keywords.length === 0) return [];

  let clusters: Array<{ name: string; description: string; intent: string; keywords: string[]; color: string }> = [];

  if (openai && keywords.length > 0) {
    try {
      const kwList = keywords.map(k => k.keyword).join(", ");
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        temperature: 0.3,
        max_tokens: 1500,
        messages: [{
          role: "system",
          content: "You are an expert SEO analyst. Group the provided keywords into semantic clusters. Return valid JSON only.",
        }, {
          role: "user",
          content: `Group these keywords into 3-8 semantic clusters by topic and intent. Return JSON array:
[{"name":"Cluster Name","description":"Short description","intent":"informational|commercial|transactional|navigational","keywords":["kw1","kw2"],"color":"#hex"}]

Keywords: ${kwList}`,
        }],
      });
      const text = completion.choices[0]?.message?.content || "[]";
      clusters = JSON.parse(text.replace(/```json|```/g, "").trim());
    } catch (err) {
      logger.warn({ err }, "[KWEngine] OpenAI clustering failed, using heuristic");
    }
  }

  if (clusters.length === 0) {
    clusters = heuristicCluster(keywords);
  }

  // Save to DB
  const saved: KeywordCluster[] = [];
  const client2 = await pool.connect();
  try {
    for (const c of clusters) {
      const id = `cluster_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const clusterKws = keywords.filter(k => c.keywords.includes(k.keyword));
      const avgPos = clusterKws.filter(k => k.current_position).length
        ? clusterKws.filter(k => k.current_position).reduce((s, k) => s + (k.current_position || 0), 0) / clusterKws.filter(k => k.current_position).length
        : null;
      const totalVol = clusterKws.reduce((s, k) => s + (k.search_volume || 0), 0);

      await client2.query(`
        INSERT INTO keyword_clusters (id, org_id, name, description, intent, keywords, keyword_count, avg_position, total_volume, color)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        ON CONFLICT DO NOTHING
        RETURNING *
      `, [id, orgId, c.name, c.description, c.intent, JSON.stringify(c.keywords), c.keywords.length, avgPos, totalVol, c.color || "#2563EB"]);

      // Update keywords with cluster_id
      for (const kw of c.keywords) {
        await client2.query(
          `UPDATE tracked_keywords SET cluster_id = $1, intent = $2, updated_at = now() WHERE org_id = $3 AND keyword = $4`,
          [id, c.intent, orgId, kw]
        ).catch(() => {});
      }

      saved.push({ id, org_id: orgId, name: c.name, description: c.description, intent: c.intent, keywords: c.keywords, keyword_count: c.keywords.length, avg_position: avgPos, avg_volume: 0, total_volume: totalVol, ai_summary: c.description, color: c.color || "#2563EB" });
    }
  } finally {
    client2.release();
  }

  logger.info({ orgId, clusters: saved.length }, "[KWEngine] Clusters generated");
  return saved;
}

function heuristicCluster(keywords: TrackedKeyword[]): Array<{ name: string; description: string; intent: string; keywords: string[]; color: string }> {
  const groups: Map<string, string[]> = new Map();
  const colors = ["#2563EB", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

  for (const kw of keywords) {
    const words = kw.keyword.split(" ");
    const root = words.slice(0, Math.min(2, words.length)).join(" ");
    if (!groups.has(root)) groups.set(root, []);
    groups.get(root)!.push(kw.keyword);
  }

  return Array.from(groups.entries()).slice(0, 8).map(([root, kws], i) => ({
    name: root.charAt(0).toUpperCase() + root.slice(1),
    description: `Groupe sémantique autour de "${root}"`,
    intent: "informational",
    keywords: kws,
    color: colors[i % colors.length],
  }));
}

// ── Generate keyword opportunities ───────────────────────────────────────────
export async function generateOpportunities(orgId: string, domain: string): Promise<KeywordOpportunity[]> {
  const client = await pool.connect();
  let existing: string[] = [];
  try {
    const res = await client.query(
      `SELECT keyword FROM tracked_keywords WHERE org_id = $1`,
      [orgId]
    );
    existing = res.rows.map((r: { keyword: string }) => r.keyword);
  } finally {
    client.release();
  }

  const seeds = existing.length > 0
    ? existing.slice(0, 3)
    : [domain.replace(/\.(fr|com|net)$/, "").replace(/-/g, " ")];

  const opportunities: KeywordOpportunity[] = [];

  for (const seed of seeds.slice(0, 2)) {
    try {
      const suggestions = await getKeywordSuggestions(seed, "France", "fr");
      for (const s of suggestions.slice(0, 10)) {
        if (existing.includes(s.keyword)) continue;

        const type = s.difficulty < 30 ? "quick_win"
          : s.searchVolume > 1000 && s.difficulty < 60 ? "high_traffic"
          : s.cpc > 1 ? "high_value"
          : "local_seo";

        const estimated_traffic = s.searchVolume > 0
          ? Math.round(s.searchVolume * 0.28) // ~28% CTR for pos 1
          : 0;

        opportunities.push({
          id: `opp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          org_id: orgId,
          keyword: s.keyword,
          search_volume: s.searchVolume,
          difficulty: s.difficulty,
          cpc: s.cpc,
          intent: s.intent,
          opportunity_score: s.opportunityScore,
          type,
          current_position: null,
          potential_position: type === "quick_win" ? 3 : 7,
          estimated_traffic,
          ai_explanation: null,
          status: "new",
        });
      }
    } catch (err) {
      logger.warn({ err }, "[KWEngine] opportunity generation error");
    }
    await new Promise(r => setTimeout(r, 500));
  }

  // Sort by score
  opportunities.sort((a, b) => b.opportunity_score - a.opportunity_score);

  // Enrich top 5 with AI explanations
  if (openai && opportunities.length > 0) {
    try {
      const top5 = opportunities.slice(0, 5).map(o => `${o.keyword} (vol:${o.search_volume}, diff:${o.difficulty})`).join(", ");
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        temperature: 0.4,
        max_tokens: 600,
        messages: [{
          role: "system",
          content: "You are an expert French SEO analyst. Give brief strategic recommendations in French.",
        }, {
          role: "user",
          content: `Give a 1-sentence SEO opportunity explanation in French for each keyword: ${top5}. Return JSON array: [{"keyword":"...","explanation":"..."}]`,
        }],
      });
      const text = completion.choices[0]?.message?.content || "[]";
      const explanations: Array<{ keyword: string; explanation: string }> = JSON.parse(text.replace(/```json|```/g, "").trim());
      for (const e of explanations) {
        const opp = opportunities.find(o => o.keyword === e.keyword);
        if (opp) opp.ai_explanation = e.explanation;
      }
    } catch (err) {
      logger.warn({ err }, "[KWEngine] AI explanation failed");
    }
  }

  // Save to DB
  const client2 = await pool.connect();
  try {
    for (const o of opportunities.slice(0, 50)) {
      await client2.query(`
        INSERT INTO keyword_opportunities (id, org_id, keyword, search_volume, difficulty, cpc, intent, opportunity_score, type, current_position, potential_position, estimated_traffic, ai_explanation, status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
        ON CONFLICT DO NOTHING
      `, [o.id, orgId, o.keyword, o.search_volume, o.difficulty, o.cpc, o.intent, o.opportunity_score, o.type, o.current_position, o.potential_position, o.estimated_traffic, o.ai_explanation, o.status]);
    }
  } finally {
    client2.release();
  }

  logger.info({ orgId, count: opportunities.length }, "[KWEngine] Opportunities generated");
  return opportunities.slice(0, 50);
}

// ── AI keyword recommendations ────────────────────────────────────────────────
export async function getAIRecommendations(orgId: string, domain: string): Promise<{
  recommendations: string[];
  quickWins: string[];
  contentIdeas: string[];
  riskKeywords: string[];
}> {
  const client = await pool.connect();
  let keywords: TrackedKeyword[] = [];
  try {
    const res = await client.query(
      `SELECT * FROM tracked_keywords WHERE org_id = $1 AND active = true ORDER BY current_position ASC LIMIT 20`,
      [orgId]
    );
    keywords = res.rows as TrackedKeyword[];
  } finally {
    client.release();
  }

  if (!openai || keywords.length === 0) {
    return {
      recommendations: [
        `Créer du contenu longue traîne autour de "${domain}"`,
        "Optimiser les pages positionnées 4-10 pour viser le top 3",
        "Cibler les mots-clés locaux avec faible concurrence",
        "Construire des backlinks depuis des sites sectoriels",
      ],
      quickWins: keywords.filter(k => k.current_position && k.current_position >= 4 && k.current_position <= 15).slice(0, 3).map(k => `Optimiser "${k.keyword}" (pos. ${k.current_position}) pour viser top 3`),
      contentIdeas: ["Guide complet du secteur", "FAQ optimisée schema markup", "Comparatif produits/services"],
      riskKeywords: keywords.filter(k => k.trend === "down").slice(0, 3).map(k => `"${k.keyword}" en baisse (${k.current_position})`),
    };
  }

  try {
    const kwSummary = keywords.slice(0, 15).map(k => `${k.keyword} (pos:${k.current_position ?? "NR"}, trend:${k.trend})`).join(", ");
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.5,
      max_tokens: 800,
      messages: [{
        role: "system",
        content: "You are an expert French SEO consultant. Provide actionable recommendations in French.",
      }, {
        role: "user",
        content: `Domain: ${domain}. Tracked keywords: ${kwSummary}.
Return JSON: {"recommendations":["..."],"quickWins":["..."],"contentIdeas":["..."],"riskKeywords":["..."]} (3-4 items each, in French)`,
      }],
    });
    const text = completion.choices[0]?.message?.content || "{}";
    return JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch (err) {
    logger.warn({ err }, "[KWEngine] AI recommendations failed");
    return { recommendations: [], quickWins: [], contentIdeas: [], riskKeywords: [] };
  }
}

// ── Daily sync for all orgs ───────────────────────────────────────────────────
export async function runDailyRankingSync(): Promise<void> {
  logger.info("[KWEngine] Starting daily ranking sync");
  const client = await pool.connect();
  let orgIds: string[] = [];
  try {
    const res = await client.query(
      `SELECT DISTINCT org_id FROM tracked_keywords WHERE active = true`
    );
    orgIds = res.rows.map((r: { org_id: string }) => r.org_id);
  } finally {
    client.release();
  }

  let totalSynced = 0;
  for (const orgId of orgIds) {
    try {
      const result = await syncOrgRankings(orgId);
      totalSynced += result.synced;
      await new Promise(r => setTimeout(r, 2000)); // Rate limit between orgs
    } catch (err) {
      logger.error({ err, orgId }, "[KWEngine] Daily sync failed for org");
    }
  }

  logger.info({ orgs: orgIds.length, totalSynced }, "[KWEngine] Daily ranking sync complete");
}
