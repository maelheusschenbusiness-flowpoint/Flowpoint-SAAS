import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";

export interface OverviewMetrics {
  avgScore: number;
  seoScore: number;
  seoTrendDelta: number;
  monitorsUp: number;
  monitorsDown: number;
  monitorsTotal: number;
  monitoringScore: number;
  avgLatency: number;
  gscClicks30d: number | null;
  gscImpressions30d: number | null;
  gscAvgPosition: number | null;
  organicGrowthPct: number | null;
  gbpAvgRating: number | null;
  gbpReviewCount: number | null;
  gbpUnansweredReviews: number | null;
  missionsOpen: number;
  missionsDone: number;
  missionsQuickWins: number;
  ga4Sessions: number | null;
  ga4Conversions: number | null;
  localScore: number;
  conversionScore: number;
  competitorPressure: number;
  growthMomentum: number;
  revenueOpportunity: number | null;
  auditsTotal: number;
  reportsTotal: number;
  teamTotal: number;
  competitorsTotal: number;
  keywordsTotal: number;
  recentAudits: Array<{ score: number; url: string }>;
  auditHistory: Array<{ month: string; avg: number }>;
  computedAt: string;
  healthScore: number;
  healthSubScores: {
    seo: number;
    monitoring: number;
    local: number;
    conversion: number;
    growth: number;
  };
  aiCreditsUsed: number | null;
  aiCreditsLimit: number | null;
}

const _cache = new Map<string, { data: OverviewMetrics; expiresAt: number }>();
const CACHE_TTL_MS = 60 * 60 * 1000;

export async function getOverviewMetrics(orgId = "default"): Promise<OverviewMetrics> {
  const key = `overview:${orgId}`;
  const hit = _cache.get(key);
  if (hit && hit.expiresAt > Date.now()) return hit.data;

  const data = await _compute(orgId);
  _cache.set(key, { data, expiresAt: Date.now() + CACHE_TTL_MS });
  _saveDailySnapshot(orgId, data).catch(() => {});
  return data;
}

export function invalidateOverviewCache(orgId = "default"): void {
  _cache.delete(`overview:${orgId}`);
}

async function _saveDailySnapshot(orgId: string, m: OverviewMetrics): Promise<void> {
  const client = await pool.connect().catch(() => null);
  if (!client) return;
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS overview_snapshots (
        id            SERIAL PRIMARY KEY,
        org_id        TEXT        NOT NULL DEFAULT 'default',
        avg_score     INT,
        monitoring_score INT,
        local_score   INT,
        conversion_score INT,
        growth_momentum INT,
        revenue_opportunity DOUBLE PRECISION,
        gsc_clicks    INT,
        gsc_impressions INT,
        gsc_avg_position DOUBLE PRECISION,
        missions_open INT,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
    const { rowCount } = await client.query(
      `SELECT id FROM overview_snapshots WHERE org_id=$1 AND created_at > NOW() - INTERVAL '23 hours' LIMIT 1`,
      [orgId]
    );
    if (!rowCount) {
      await client.query(`
        INSERT INTO overview_snapshots
          (org_id, avg_score, monitoring_score, local_score, conversion_score,
           growth_momentum, revenue_opportunity, gsc_clicks, gsc_impressions,
           gsc_avg_position, missions_open)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      `, [
        orgId,
        m.avgScore, m.monitoringScore, m.localScore, m.conversionScore,
        m.growthMomentum, m.revenueOpportunity,
        m.gscClicks30d, m.gscImpressions30d, m.gscAvgPosition, m.missionsOpen,
      ]);
    }
  } catch (err) {
    logger.warn({ err }, "[OverviewService] daily snapshot failed");
  } finally {
    client.release();
  }
}

async function _compute(orgId: string): Promise<OverviewMetrics> {
  const client = await pool.connect();
  const since7d  = new Date(Date.now() - 7  * 24 * 3600_000).toISOString();
  const since30d = new Date(Date.now() - 30 * 24 * 3600_000).toISOString();

  try {
    const [
      monitorsRow, auditsRow, recentAuditRow, prevWeekRow,
      auditTrend, lastAudits,
      reportsRow, teamRow, competitorsRow, keywordsRow,
      croRow, localRow,
      gscRow, gbpRow, ga4Row, missionsRow,
    ] = await Promise.all([

      client.query<{ total: number; down: number; avg_latency: number }>(`
        SELECT count(*)::int total,
               count(*) filter (where status='down')::int down,
               round(avg(latency))::int avg_latency
        FROM monitors
      `).then(r => r.rows[0]).catch(() => null),

      client.query<{ avg_score: number; total: number }>(`
        SELECT round(avg(score))::int avg_score, count(*)::int total FROM audits
      `).then(r => r.rows[0]).catch(() => null),

      client.query<{ avg_score: number }>(`
        SELECT round(avg(score))::int avg_score FROM audits WHERE created_at >= $1
      `, [since7d]).then(r => r.rows[0]).catch(() => null),

      client.query<{ avg_score: number }>(`
        SELECT round(avg(score))::int avg_score FROM audits
        WHERE created_at >= NOW() - INTERVAL '14 days'
          AND created_at < NOW() - INTERVAL '7 days'
      `).then(r => r.rows[0]).catch(() => null),

      client.query<{ month: string; avg: number }>(`
        SELECT to_char(created_at,'YYYY-MM') month, round(avg(score))::int avg
        FROM audits WHERE created_at >= $1
        GROUP BY 1 ORDER BY 1
      `, [since30d]).then(r => r.rows).catch(() => [] as Array<{ month: string; avg: number }>),

      client.query<{ score: number; url: string }>(`
        SELECT score, url FROM audits ORDER BY created_at DESC LIMIT 3
      `).then(r => r.rows).catch(() => [] as Array<{ score: number; url: string }>),

      client.query<{ total: number }>(`SELECT count(*)::int total FROM reports`)
        .then(r => r.rows[0]).catch(() => null),

      client.query<{ total: number }>(`SELECT count(*)::int total FROM team_members`)
        .then(r => r.rows[0]).catch(() => null),

      client.query<{ total: number; avg_dr: number }>(`
        SELECT count(*)::int total, round(avg(domain_rating))::int avg_dr FROM competitors
      `).then(r => r.rows[0]).catch(() => null),

      client.query<{ total: number }>(`SELECT count(*)::int total FROM keywords`)
        .then(r => r.rows[0]).catch(() => null),

      client.query<{ avg_cro: number | null }>(`
        SELECT round(avg(overall_score))::int avg_cro FROM cro_scores
      `).then(r => r.rows[0]).catch(() => null),

      client.query<{ avg_dom: number | null }>(`
        SELECT round(avg(dominance_score))::int avg_dom
        FROM local_heatmaps WHERE status='completed'
      `).then(r => r.rows[0]).catch(() => null),

      client.query<{ clicks: number; impressions: number; avg_pos: number }>(`
        SELECT sum(clicks)::int clicks,
               sum(impressions)::int impressions,
               round(avg(position)::numeric,1) avg_pos
        FROM gsc_search_analytics
        WHERE org_id=$1 AND date >= $2
      `, [orgId, since30d]).then(r => r.rows[0]).catch(() => null),

      client.query<{ avg_rating: number; total: number; unanswered: number }>(`
        SELECT round(avg(rating)::numeric,1) avg_rating,
               count(*)::int total,
               count(*) filter (where reply_text IS NULL)::int unanswered
        FROM gbp_reviews WHERE org_id=$1
      `, [orgId]).then(r => r.rows[0]).catch(() => null),

      client.query<{ data: unknown }>(`
        SELECT data FROM ga4_report_cache
        WHERE org_id=$1 ORDER BY cached_at DESC LIMIT 1
      `, [orgId]).then(r => r.rows[0]).catch(() => null),

      client.query<{ open: number; quick_wins: number; done: number }>(`
        SELECT count(*) filter (where status NOT IN ('done','dismissed','stale'))::int open,
               count(*) filter (where ai_quick_win=true AND status NOT IN ('done','dismissed','stale'))::int quick_wins,
               count(*) filter (where status = 'done')::int done
        FROM missions WHERE org_id=$1
      `, [orgId]).then(r => r.rows[0]).catch(() => null),
    ]);

    const avgScore         = Number(auditsRow?.avg_score ?? 0);
    const currentWeekScore = Number(recentAuditRow?.avg_score ?? avgScore);
    const prevWeekScore    = Number(prevWeekRow?.avg_score ?? currentWeekScore);
    const seoTrendDelta    = currentWeekScore - prevWeekScore;

    const monitorsTotal  = Number(monitorsRow?.total ?? 0);
    const monitorsDown   = Number(monitorsRow?.down  ?? 0);
    const monitoringScore = monitorsTotal > 0
      ? Math.round((monitorsTotal - monitorsDown) / monitorsTotal * 100)
      : 100;

    const conversionScore = Number(croRow?.avg_cro ?? 0);
    const localScore      = Number(localRow?.avg_dom ?? 0);

    const competitorsCount = Number(competitorsRow?.total ?? 0);
    const avgCompDR        = Number(competitorsRow?.avg_dr ?? 0);
    const competitorPressure = Math.min(100, competitorsCount > 0
      ? Math.round(avgCompDR * competitorsCount / Math.max(1, competitorsCount))
      : 0
    );

    const trendVals = auditTrend.map(r => Number(r.avg));
    const growthMomentum = trendVals.length >= 2
      ? Math.min(100, Math.max(0, Math.round(50 + (trendVals[trendVals.length - 1]! - trendVals[0]!) * 2)))
      : Math.min(100, Math.max(0, avgScore));

    const gscClicks30d      = gscRow?.clicks      ? Number(gscRow.clicks)      : null;
    const gscImpressions30d = gscRow?.impressions ? Number(gscRow.impressions) : null;
    const gscAvgPosition    = gscRow?.avg_pos     ? Number(gscRow.avg_pos)     : null;

    const organicGrowthPct = (trendVals.length >= 2 && gscClicks30d !== null)
      ? Math.round(((trendVals[trendVals.length - 1]! - trendVals[0]!) / Math.max(1, trendVals[0]!)) * 100)
      : null;

    let revenueOpportunity: number | null = null;
    let ga4Sessions: number | null = null;
    let ga4Conversions: number | null = null;
    if (ga4Row?.data) {
      try {
        const d = (typeof ga4Row.data === "string" ? JSON.parse(ga4Row.data) : ga4Row.data) as Record<string, unknown>;
        const totalSessions    = Number(d?.sessions ?? 0);
        const organicSessions  = Number(d?.organic_sessions ?? totalSessions);
        const conversionEvents = Number(d?.conversions ?? 0);
        // Expose GA4 as first-class fields
        if (totalSessions > 0)    ga4Sessions    = totalSessions;
        if (conversionEvents > 0) ga4Conversions = conversionEvents;
        // Revenue opportunity: organic sessions × real conversion rate (or 2% baseline)
        const actualConvRate = (conversionEvents > 0 && totalSessions > 0)
          ? conversionEvents / totalSessions
          : 0.02;
        if (organicSessions > 0) {
          revenueOpportunity = Math.round(organicSessions * actualConvRate * 50);
        }
      } catch { /* no GA4 data */ }
    }

    // ── HEALTH SCORE (weighted composite) ────────────────────────────────────
    const healthSubScores = {
      seo:        Math.max(0, Math.min(100, currentWeekScore || avgScore)),
      monitoring: Math.max(0, Math.min(100, monitoringScore)),
      local:      Math.max(0, Math.min(100, localScore)),
      conversion: Math.max(0, Math.min(100, conversionScore)),
      growth:     Math.max(0, Math.min(100, growthMomentum)),
    };
    const healthScore = Math.round(
      healthSubScores.seo        * 0.30 +
      healthSubScores.monitoring * 0.20 +
      healthSubScores.local      * 0.20 +
      healthSubScores.conversion * 0.15 +
      healthSubScores.growth     * 0.15
    );

    // ── AI CREDITS from ai_monthly_usage ──────────────────────────────────────
    const aiUsageRow = await client.query<{ credits_used: number; credits_limit: number }>(`
      SELECT
        COALESCE(SUM(credits_used), 0)::int AS credits_used,
        MAX(credits_limit)::int             AS credits_limit
      FROM ai_monthly_usage
      WHERE org_id = $1 AND month = to_char(NOW(), 'YYYY-MM')
    `, [orgId]).then(r => r.rows[0]).catch(() => null);

    return {
      avgScore,
      seoScore:          currentWeekScore,
      seoTrendDelta,
      monitorsUp:        monitorsTotal - monitorsDown,
      monitorsDown,
      monitorsTotal,
      monitoringScore,
      avgLatency:        Number(monitorsRow?.avg_latency ?? 0),
      gscClicks30d,
      gscImpressions30d,
      gscAvgPosition,
      organicGrowthPct,
      gbpAvgRating:         gbpRow?.avg_rating ? Number(gbpRow.avg_rating) : null,
      gbpReviewCount:       gbpRow?.total      ? Number(gbpRow.total)      : null,
      gbpUnansweredReviews: gbpRow?.unanswered ? Number(gbpRow.unanswered): null,
      missionsOpen:       Number(missionsRow?.open       ?? 0),
      missionsDone:       Number(missionsRow?.done       ?? 0),
      missionsQuickWins:  Number(missionsRow?.quick_wins ?? 0),
      ga4Sessions,
      ga4Conversions,
      localScore,
      conversionScore,
      competitorPressure,
      growthMomentum,
      revenueOpportunity,
      auditsTotal:      Number(auditsRow?.total      ?? 0),
      reportsTotal:     Number(reportsRow?.total     ?? 0),
      teamTotal:        Number(teamRow?.total        ?? 0),
      competitorsTotal: competitorsCount,
      keywordsTotal:    Number(keywordsRow?.total    ?? 0),
      recentAudits: lastAudits,
      auditHistory: auditTrend,
      computedAt: new Date().toISOString(),
      healthScore,
      healthSubScores,
      aiCreditsUsed:  aiUsageRow?.credits_used  != null ? Number(aiUsageRow.credits_used)  : null,
      aiCreditsLimit: aiUsageRow?.credits_limit != null ? Number(aiUsageRow.credits_limit) : null,
    };
  } finally {
    client.release();
  }
}
