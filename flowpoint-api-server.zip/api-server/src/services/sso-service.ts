import { pool } from "@workspace/db";

export const SSO_PROVIDER_TYPES = [
  { id: 'google_workspace', name: 'Google Workspace', icon: '🔵', color: '#4285F4', plan: 'Pro',   protocol: 'oauth2' },
  { id: 'microsoft_azure',  name: 'Microsoft Azure AD', icon: '🟦', color: '#0078D4', plan: 'Ultra', protocol: 'oauth2' },
  { id: 'okta',             name: 'Okta',              icon: '🔷', color: '#007DC1', plan: 'Ultra', protocol: 'saml2'  },
  { id: 'auth0',            name: 'Auth0',             icon: '⚫', color: '#EB5424', plan: 'Ultra', protocol: 'oauth2' },
  { id: 'onelogin',         name: 'OneLogin',          icon: '🟠', color: '#E4271B', plan: 'Ultra', protocol: 'saml2'  },
  { id: 'saml_generic',     name: 'SAML générique',    icon: '🔐', color: '#6b7280', plan: 'Ultra', protocol: 'saml2'  },
] as const;

export async function getSSODashboard(orgId: string): Promise<Record<string, unknown>> {
  const client = await pool.connect();
  try {
    const [provRes, authRes, auditRes, sessRes] = await Promise.all([
      client.query(`SELECT * FROM sso_providers WHERE org_id=$1 ORDER BY created_at DESC`, [orgId]),
      client.query(`SELECT * FROM organization_auth WHERE org_id=$1 LIMIT 1`, [orgId]),
      client.query(`SELECT * FROM login_audits WHERE org_id=$1 ORDER BY created_at DESC LIMIT 50`, [orgId]),
      client.query(`SELECT * FROM enterprise_sessions WHERE org_id=$1 AND is_active=true ORDER BY last_active_at DESC LIMIT 20`, [orgId]),
    ]);
    const audits = auditRes.rows;
    return {
      providers: provRes.rows,
      auth_config: authRes.rows[0] || null,
      login_audits: audits,
      active_sessions: sessRes.rows,
      stats: {
        totalProviders: provRes.rows.length,
        activeProviders: provRes.rows.filter((p: { enabled: boolean }) => p.enabled).length,
        totalLogins: audits.length,
        failedLogins: audits.filter((a: { success: boolean }) => !a.success).length,
        activeSessions: sessRes.rows.length,
        suspiciousLogins: audits.filter((a: { risk_score: number }) => (a.risk_score || 0) >= 70).length,
      },
    };
  } finally {
    client.release();
  }
}

export async function createSSOProvider(orgId: string, plan: string, data: {
  providerType: string; name: string; domain?: string; clientId?: string;
  clientSecret?: string; metadataUrl?: string; ssoUrl?: string; scopes?: string[];
  autoProvision?: boolean; defaultRoleId?: string;
}): Promise<unknown> {
  const provInfo = SSO_PROVIDER_TYPES.find(p => p.id === data.providerType);
  if (!provInfo) throw new Error("Provider SSO invalide");
  if (provInfo.plan === 'Ultra' && plan !== 'Agency' && plan !== 'Ultra') {
    throw new Error(`${provInfo.name} — Ultra requis`);
  }
  if (provInfo.plan === 'Pro' && plan === 'Standard') {
    throw new Error(`${provInfo.name} — Pro requis`);
  }
  const id = `sso_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO sso_providers (id,org_id,provider_type,name,domain,client_id,client_secret,metadata_url,sso_url,scopes,auto_provision,default_role_id,enabled) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,true)`,
      [id, orgId, data.providerType, data.name, data.domain || null, data.clientId || null, data.clientSecret || null, data.metadataUrl || null, data.ssoUrl || null, data.scopes || [], data.autoProvision !== false, data.defaultRoleId || null]
    );
    const r = await client.query(`SELECT * FROM sso_providers WHERE id=$1`, [id]);
    return r.rows[0];
  } finally {
    client.release();
  }
}

export async function updateSSOProvider(orgId: string, id: string, data: Partial<{
  enabled: boolean; enforce_sso: boolean; domain: string; auto_provision: boolean;
}>): Promise<void> {
  const updates: string[] = ['updated_at=now()'];
  const params: unknown[] = [];
  if (data.enabled !== undefined)       { params.push(data.enabled);       updates.push(`enabled=$${params.length}`); }
  if (data.enforce_sso !== undefined)   { params.push(data.enforce_sso);   updates.push(`enforce_sso=$${params.length}`); }
  if (data.domain !== undefined)        { params.push(data.domain);        updates.push(`domain=$${params.length}`); }
  if (data.auto_provision !== undefined){ params.push(data.auto_provision); updates.push(`auto_provision=$${params.length}`); }
  params.push(id, orgId);
  const client = await pool.connect();
  try {
    await client.query(`UPDATE sso_providers SET ${updates.join(',')} WHERE id=$${params.length - 1} AND org_id=$${params.length}`, params);
  } finally {
    client.release();
  }
}

export async function deleteSSOProvider(orgId: string, id: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`DELETE FROM sso_providers WHERE id=$1 AND org_id=$2`, [id, orgId]);
  } finally {
    client.release();
  }
}

export async function getOrgAuthConfig(orgId: string): Promise<unknown> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM organization_auth WHERE org_id=$1 LIMIT 1`, [orgId]);
    return r.rows[0] || null;
  } finally {
    client.release();
  }
}

export async function upsertOrgAuthConfig(orgId: string, data: {
  allowedDomains?: string[]; enforceSso?: boolean; enforceMfa?: boolean;
  sessionTimeout?: number; ipWhitelist?: string[]; loginMessage?: string;
}): Promise<void> {
  const id = `oa_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
  const client = await pool.connect();
  try {
    await client.query(`
      INSERT INTO organization_auth (id,org_id,allowed_domains,enforce_sso,enforce_mfa,session_timeout_minutes,ip_whitelist,login_message)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      ON CONFLICT (org_id) DO UPDATE SET
        allowed_domains=EXCLUDED.allowed_domains, enforce_sso=EXCLUDED.enforce_sso,
        enforce_mfa=EXCLUDED.enforce_mfa, session_timeout_minutes=EXCLUDED.session_timeout_minutes,
        ip_whitelist=EXCLUDED.ip_whitelist, login_message=EXCLUDED.login_message, updated_at=now()
    `, [id, orgId, data.allowedDomains || [], data.enforceSso || false, data.enforceMfa || false, data.sessionTimeout || 480, data.ipWhitelist || [], data.loginMessage || null]);
  } catch {
    // org_id may not have unique constraint — upsert via update
    await client.query(`UPDATE organization_auth SET allowed_domains=$1,enforce_sso=$2,enforce_mfa=$3,session_timeout_minutes=$4,ip_whitelist=$5,login_message=$6,updated_at=now() WHERE org_id=$7`,
      [data.allowedDomains || [], data.enforceSso || false, data.enforceMfa || false, data.sessionTimeout || 480, data.ipWhitelist || [], data.loginMessage || null, orgId]);
  } finally {
    client.release();
  }
}

export async function logLoginAttempt(orgId: string, data: {
  userId?: string; email: string; provider: string; success: boolean;
  ipAddress?: string; userAgent?: string; failureReason?: string;
}): Promise<void> {
  const id = `la_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
  // Deterministic risk score based on failure reason (no random)
  const riskScore = data.success ? 0
    : (data.failureReason?.includes("block") || data.failureReason?.includes("too_many")) ? 80
    : data.failureReason?.includes("invalid") ? 55
    : data.failureReason?.includes("expired") ? 30
    : 40;
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO login_audits (id,org_id,user_id,email,provider,success,ip_address,user_agent,risk_score,failure_reason) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [id, orgId, data.userId || null, data.email, data.provider, data.success, data.ipAddress || null, data.userAgent || null, riskScore, data.failureReason || null]
    );
  } catch { /* non-blocking */ } finally {
    client.release();
  }
}

export async function invalidateSession(orgId: string, sessionId: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`UPDATE enterprise_sessions SET is_active=false WHERE id=$1 AND org_id=$2`, [sessionId, orgId]);
  } finally {
    client.release();
  }
}

export async function getLoginAudits(orgId: string, limit = 50): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM login_audits WHERE org_id=$1 ORDER BY created_at DESC LIMIT $2`, [orgId, limit]);
    return r.rows;
  } finally {
    client.release();
  }
}
