import { google } from "googleapis";
import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { store } from "./store.js";
import crypto from "crypto";

const CLIENT_ID     = process.env["GOOGLE_CLIENT_ID"]     || "";
const CLIENT_SECRET = process.env["GOOGLE_CLIENT_SECRET"] || "";
const REDIRECT_URI  = process.env["GOOGLE_REDIRECT_URI"]  || "http://localhost:8080/api/google/callback";

const GBP_SCOPES = [
  "openid",
  "email",
  "profile",
  "https://www.googleapis.com/auth/business.manage",
  "https://www.googleapis.com/auth/analytics.readonly",
  "https://www.googleapis.com/auth/analytics.edit",
  "https://www.googleapis.com/auth/webmasters.readonly",
  "https://www.googleapis.com/auth/webmasters",
];

// ── Token encryption (AES-256-GCM) ───────────────────────────────────────────
// Key derived from ENCRYPTION_KEY env (32 bytes) or first 32 chars of JWT_SECRET.
// Format: enc_v1:<iv_hex>:<authTag_hex>:<ciphertext_hex>
// Falls back gracefully if env key missing (stores/returns plain text).

function getEncKey(): Buffer | null {
  const raw = process.env["ENCRYPTION_KEY"] || process.env["JWT_SECRET"] || "";
  if (raw.length < 16) return null;
  return crypto.createHash("sha256").update(raw).digest();
}

export function encryptToken(plain: string): string {
  if (!plain) return plain;
  const key = getEncKey();
  if (!key) return plain;
  try {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
    const ct = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
    const tag = cipher.getAuthTag();
    return `enc_v1:${iv.toString("hex")}:${tag.toString("hex")}:${ct.toString("hex")}`;
  } catch (e) {
    logger.warn({ e }, "[Crypto] encryptToken failed — storing plain");
    return plain;
  }
}

export function decryptToken(stored: string): string {
  if (!stored || !stored.startsWith("enc_v1:")) return stored;
  const key = getEncKey();
  if (!key) return stored;
  try {
    const parts = stored.split(":");
    if (parts.length !== 4) return stored;
    const iv  = Buffer.from(parts[1]!, "hex");
    const tag = Buffer.from(parts[2]!, "hex");
    const ct  = Buffer.from(parts[3]!, "hex");
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    return decipher.update(ct).toString("utf8") + decipher.final("utf8");
  } catch (e) {
    logger.warn({ e }, "[Crypto] decryptToken failed — returning raw");
    return stored;
  }
}

// ── Retry helper ──────────────────────────────────────────────────────────────

async function withRetry<T>(fn: () => Promise<T>, retries = 3, delayMs = 800): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      if (i < retries - 1) await new Promise(r => setTimeout(r, delayMs * (i + 1)));
    }
  }
  throw lastErr;
}

export function isGoogleConfigured(): boolean {
  return Boolean(CLIENT_ID && CLIENT_SECRET);
}

export function createOAuthClient() {
  return new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
}

export function generateAuthUrl(state: string): string {
  const client = createOAuthClient();
  return client.generateAuthUrl({
    access_type: "offline",
    scope: GBP_SCOPES,
    state,
    prompt: "consent",
  });
}

export async function getTokensFromCode(code: string) {
  const client = createOAuthClient();
  const { tokens } = await client.getToken(code);
  return tokens;
}

export async function refreshAccessToken(refreshToken: string): Promise<string> {
  const client = createOAuthClient();
  client.setCredentials({ refresh_token: refreshToken });
  const { credentials } = await client.refreshAccessToken();
  return credentials.access_token ?? "";
}

async function gbpFetch(accessToken: string, path: string): Promise<unknown> {
  const base = "https://mybusinessaccountmanagement.googleapis.com/v1";
  const resp = await fetch(`${base}${path}`, {
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
  });
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`GBP API ${resp.status}: ${text.slice(0, 200)}`);
  }
  return resp.json();
}

async function reviewsFetch(accessToken: string, locationName: string): Promise<unknown> {
  const url = `https://mybusiness.googleapis.com/v4/${locationName}/reviews`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!resp.ok) throw new Error(`Reviews API ${resp.status}`);
  return resp.json();
}

async function locationsFetch(accessToken: string, accountName: string): Promise<unknown> {
  const url = `https://mybusinessbusinessinformation.googleapis.com/v1/${accountName}/locations?readMask=name,title,phoneNumbers,categories,websiteUri,regularHours,latlng,metadata,profile,relationshipData,serviceArea`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!resp.ok) throw new Error(`Locations API ${resp.status}`);
  return resp.json();
}

export async function getAccounts(accessToken: string) {
  try {
    const data = (await gbpFetch(accessToken, "/accounts")) as { accounts?: unknown[] };
    return data.accounts || [];
  } catch (e) {
    logger.warn({ e }, "[GBP] getAccounts failed");
    return [];
  }
}

export async function getLocations(accessToken: string, accountName: string) {
  try {
    const data = (await locationsFetch(accessToken, accountName)) as { locations?: unknown[] };
    return data.locations || [];
  } catch (e) {
    logger.warn({ e }, "[GBP] getLocations failed");
    return [];
  }
}

export async function getLocationReviews(accessToken: string, locationName: string) {
  try {
    const data = (await reviewsFetch(accessToken, locationName)) as { reviews?: unknown[] };
    return data.reviews || [];
  } catch (e) {
    logger.warn({ e }, "[GBP] getLocationReviews failed");
    return [];
  }
}

async function getValidAccessToken(orgId: string): Promise<string | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT access_token, refresh_token, token_expiry FROM google_accounts WHERE org_id=$1 LIMIT 1`,
      [orgId]
    );
    if (res.rows.length === 0) return null;
    const row = res.rows[0] as { access_token: string; refresh_token: string; token_expiry: string | null };
    const expiry = row.token_expiry ? new Date(row.token_expiry).getTime() : 0;
    const accessToken = decryptToken(row.access_token);
    const refreshToken = decryptToken(row.refresh_token);

    if (Date.now() < expiry - 60_000) return accessToken;
    if (!refreshToken) return null;

    const newToken = await withRetry(() => refreshAccessToken(refreshToken));
    const encNew = encryptToken(newToken);
    await client.query(
      `UPDATE google_accounts SET access_token=$1, token_expiry=$2, updated_at=now() WHERE org_id=$3`,
      [encNew, new Date(Date.now() + 3600_000).toISOString(), orgId]
    );
    return newToken;
  } finally {
    client.release();
  }
}

export async function syncAll(orgId = "default"): Promise<{ locationsCount: number; reviewsCount: number }> {
  const accessToken = await getValidAccessToken(orgId);
  if (!accessToken) {
    logger.info("[GBP] No Google account connected, skipping sync");
    return { locationsCount: 0, reviewsCount: 0 };
  }

  const accounts = (await getAccounts(accessToken)) as Array<{ name: string; accountName?: string }>;
  let locationsCount = 0;
  let reviewsCount = 0;

  const client = await pool.connect();
  try {
    for (const account of accounts) {
      const accountName = account.name;
      const locs = (await getLocations(accessToken, accountName)) as Array<{
        name: string; title?: string; phoneNumbers?: { primaryPhone?: string };
        categories?: { primaryCategory?: { displayName?: string } };
        websiteUri?: string; latlng?: { latitude?: number; longitude?: number };
        metadata?: { mapsUri?: string };
      }>;

      for (const loc of locs) {
        const locationId = loc.name.split("/").pop() || loc.name;
        await client.query(
          `INSERT INTO google_locations (id, org_id, google_account_name, location_id, account_name, name, primary_category, phone, website, lat, lng, raw_data, last_sync_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,now())
           ON CONFLICT (id) DO UPDATE SET name=$6, primary_category=$7, phone=$8, website=$9, lat=$10, lng=$11, raw_data=$12, last_sync_at=now()`,
          [
            `gl_${orgId}_${locationId}`,
            orgId,
            accountName,
            locationId,
            accountName,
            loc.title || locationId,
            loc.categories?.primaryCategory?.displayName || null,
            loc.phoneNumbers?.primaryPhone || null,
            loc.websiteUri || null,
            loc.latlng?.latitude || null,
            loc.latlng?.longitude || null,
            JSON.stringify(loc),
          ]
        );
        locationsCount++;

        const reviews = (await getLocationReviews(accessToken, loc.name)) as Array<{
          name: string; reviewer?: { displayName?: string; profilePhotoUrl?: string };
          starRating?: string; comment?: string; createTime?: string; updateTime?: string;
          reviewReply?: { comment?: string; updateTime?: string };
        }>;

        for (const rev of reviews) {
          const reviewId = rev.name.split("/").pop() || rev.name;
          const stars: Record<string, number> = { ONE: 1, TWO: 2, THREE: 3, FOUR: 4, FIVE: 5 };
          await client.query(
            `INSERT INTO google_reviews (id, org_id, location_id, review_id, reviewer_name, reviewer_photo, rating, comment, create_time, update_time, reply_comment, reply_updated_at, raw_data)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
             ON CONFLICT (id) DO UPDATE SET rating=$7, comment=$8, reply_comment=$11, reply_updated_at=$12, raw_data=$13`,
            [
              `gr_${orgId}_${reviewId}`,
              orgId,
              locationId,
              reviewId,
              rev.reviewer?.displayName || "Anonyme",
              rev.reviewer?.profilePhotoUrl || null,
              stars[rev.starRating || "ONE"] || 1,
              rev.comment || null,
              rev.createTime || null,
              rev.updateTime || null,
              rev.reviewReply?.comment || null,
              rev.reviewReply?.updateTime || null,
              JSON.stringify(rev),
            ]
          );
          reviewsCount++;
        }
      }
    }
  } finally {
    client.release();
  }

  await client.query(`UPDATE google_accounts SET last_sync_at=now() WHERE org_id=$1`, [orgId]).catch(() => {});

  store.logActivity({
    type: "ai",
    label: `GBP synchronisé — ${locationsCount} établissement(s), ${reviewsCount} avis`,
    targetType: "google_business",
  });

  logger.info({ locationsCount, reviewsCount }, "[GBP] Sync complete");
  return { locationsCount, reviewsCount };
}

// ── Performance API ───────────────────────────────────────────────────────────

export async function getPerformance(accessToken: string, locationName: string) {
  try {
    const endDate   = new Date();
    const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const fmt = (d: Date) => ({ year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() });

    const url = `https://businessprofileperformance.googleapis.com/v1/${locationName}:fetchMultiDailyMetricsTimeSeries`;
    const resp = await fetch(url, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        dailyMetrics: [
          "BUSINESS_IMPRESSIONS_DESKTOP_MAPS",
          "BUSINESS_IMPRESSIONS_DESKTOP_SEARCH",
          "BUSINESS_IMPRESSIONS_MOBILE_MAPS",
          "BUSINESS_IMPRESSIONS_MOBILE_SEARCH",
          "CALL_CLICKS",
          "WEBSITE_CLICKS",
          "BUSINESS_DIRECTION_REQUESTS",
          "BUSINESS_BOOKINGS",
          "BUSINESS_CONVERSATIONS",
        ],
        dailyRange: { startDate: fmt(startDate), endDate: fmt(endDate) },
      }),
    });
    if (!resp.ok) throw new Error(`Performance API ${resp.status}`);
    const data = await resp.json() as { multiDailyMetricTimeSeries?: unknown[] };
    return data.multiDailyMetricTimeSeries ?? [];
  } catch (e) {
    logger.warn({ e }, "[GBP] getPerformance failed — returning empty");
    return [];
  }
}

// ── Publish GBP Post ──────────────────────────────────────────────────────────

export async function publishGBPPost(
  accessToken: string,
  locationName: string,
  text: string,
  callToActionType?: string,
  callToActionUrl?: string,
): Promise<{ ok: boolean; name?: string; error?: string }> {
  try {
    const url = `https://mybusiness.googleapis.com/v4/${locationName}/localPosts`;
    const body: Record<string, unknown> = {
      languageCode: "fr",
      summary: text,
      topicType: "STANDARD",
    };
    if (callToActionType && callToActionUrl) {
      body["callToAction"] = { actionType: callToActionType, url: callToActionUrl };
    }
    const resp = await fetch(url, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(`GBP Post API ${resp.status}: ${txt.slice(0, 200)}`);
    }
    const result = await resp.json() as { name?: string };
    return { ok: true, name: result.name };
  } catch (e) {
    logger.warn({ e }, "[GBP] publishPost failed");
    return { ok: false, error: String(e) };
  }
}

// ── Reply to Review ───────────────────────────────────────────────────────────

export async function replyToReview(
  accessToken: string,
  locationName: string,
  reviewId: string,
  comment: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const url = `https://mybusiness.googleapis.com/v4/${locationName}/reviews/${reviewId}/reply`;
    const resp = await fetch(url, {
      method: "PUT",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ comment }),
    });
    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(`Reply API ${resp.status}: ${txt.slice(0, 200)}`);
    }
    return { ok: true };
  } catch (e) {
    logger.warn({ e }, "[GBP] replyToReview failed");
    return { ok: false, error: String(e) };
  }
}

// ── AI Review Reply Generator ─────────────────────────────────────────────────

export async function generateAIReply(
  reviewerName: string,
  rating: number,
  comment: string,
  businessName = "notre établissement",
): Promise<string> {
  const OPENAI_KEY = process.env["OPENAI_API_KEY"];
  if (!OPENAI_KEY) {
    const templates: Record<number, string> = {
      5: `Merci infiniment ${reviewerName} pour votre avis 5 étoiles ! Votre satisfaction est notre plus belle récompense. Nous serons ravis de vous accueillir à nouveau très prochainement.`,
      4: `Merci beaucoup ${reviewerName} pour votre avis positif ! Nous sommes ravis que votre expérience ait été satisfaisante et nous espérons vous revoir bientôt.`,
      3: `Merci ${reviewerName} pour votre retour. Nous prenons note de vos remarques et travaillons continuellement à améliorer nos services. N'hésitez pas à nous contacter directement pour toute question.`,
      2: `Merci ${reviewerName} de nous avoir partagé votre expérience. Nous sommes désolés que votre visite n'ait pas répondu à vos attentes et prenons vos remarques très au sérieux.`,
      1: `Merci ${reviewerName} pour votre retour. Nous sommes sincèrement désolés pour cette expérience et souhaitons rectifier la situation. Pourriez-vous nous contacter directement à votre convenance ?`,
    };
    return templates[Math.max(1, Math.min(5, rating))] ?? templates[3]!;
  }

  try {
    const prompt = rating >= 4
      ? `Tu es le gérant de ${businessName}. Écris une réponse chaleureuse et professionnelle en français (2-3 phrases max) pour remercier ${reviewerName} de son avis ${rating}/5 étoiles : "${comment}". Reste naturel, pas de formules génériques.`
      : `Tu es le gérant de ${businessName}. Écris une réponse professionnelle et empathique en français (2-4 phrases max) pour répondre à l'avis ${rating}/5 de ${reviewerName} : "${comment}". Prends les remarques au sérieux et propose de rectifier si besoin.`;

    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 200,
        temperature: 0.7,
      }),
    });
    const data = await resp.json() as { choices?: Array<{ message?: { content?: string } }> };
    return data.choices?.[0]?.message?.content?.trim() ?? "Merci pour votre avis.";
  } catch (e) {
    logger.warn({ e }, "[GBP] AI reply generation failed");
    return `Merci ${reviewerName} pour votre avis. Votre retour est très précieux pour nous !`;
  }
}

// ── Get valid token (exported for routes) ─────────────────────────────────────

export async function getValidToken(orgId: string): Promise<string | null> {
  return getValidAccessToken(orgId);
}

export async function getGBPStatus(orgId = "default") {
  const client = await pool.connect();
  try {
    const acc = await client.query(
      `SELECT id, email, connected_at, last_sync_at FROM google_accounts WHERE org_id=$1 LIMIT 1`,
      [orgId]
    );
    if (acc.rows.length === 0) return { connected: false };

    const locs = await client.query(
      `SELECT id, name, primary_category, rating, reviews_count, phone, website, last_sync_at FROM google_locations WHERE org_id=$1 ORDER BY name`,
      [orgId]
    );
    const revs = await client.query(
      `SELECT id, location_id, reviewer_name, rating, comment, create_time, reply_comment FROM google_reviews WHERE org_id=$1 ORDER BY create_time DESC LIMIT 50`,
      [orgId]
    );

    return {
      connected: true,
      email: acc.rows[0].email,
      connectedAt: acc.rows[0].connected_at,
      lastSync: acc.rows[0].last_sync_at,
      locations: locs.rows,
      reviews: revs.rows,
    };
  } finally {
    client.release();
  }
}
