import cron from "node-cron";
import { logger } from "../lib/logger.js";
import { syncAll } from "./google-service.js";
import { syncGSCData } from "./gsc-service.js";
import { startMissionCron } from "./mission-cron.js";
import { startKeywordCron } from "./keyword-cron.js";

export function startGBPCron(): void {
  cron.schedule("0 */6 * * *", async () => {
    logger.info("[GBP Cron] Starting scheduled GBP + GSC sync…");
    try {
      const gbpResult = await syncAll("default");
      logger.info({ ...gbpResult }, "[GBP Cron] GBP sync complete");
    } catch (e) {
      logger.warn({ e }, "[GBP Cron] GBP sync failed");
    }
    try {
      const gscResult = await syncGSCData("default");
      logger.info({ ...gscResult }, "[GSC Cron] GSC sync complete");
    } catch (e) {
      logger.warn({ e }, "[GSC Cron] GSC sync failed (no site selected or quota exceeded)");
    }
  });

  logger.info("[GBP Cron] Google Business Profile sync scheduled (every 6h)");

  // Start Mission Engine cron
  startMissionCron();

  // Start Keyword Domination Engine daily sync
  startKeywordCron();
}
