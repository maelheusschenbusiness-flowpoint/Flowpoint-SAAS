import cron from "node-cron";
import { logger } from "../lib/logger.js";
import { runMissionEngine } from "./mission-engine.js";

export function startMissionCron(): void {
  // Daily mission scan at 06:00
  cron.schedule("0 6 * * *", async () => {
    logger.info("[MissionCron] Starting daily mission engine run…");
    try {
      const result = await runMissionEngine("default", "cron_daily");
      logger.info({ ...result }, "[MissionCron] Daily run complete");
    } catch (e) {
      logger.warn({ e }, "[MissionCron] Daily run failed");
    }
  });

  // Weekly cleanup at Sunday 03:00
  cron.schedule("0 3 * * 0", async () => {
    logger.info("[MissionCron] Starting weekly mission refresh…");
    try {
      const result = await runMissionEngine("default", "cron_weekly");
      logger.info({ ...result }, "[MissionCron] Weekly refresh complete");
    } catch (e) {
      logger.warn({ e }, "[MissionCron] Weekly refresh failed");
    }
  });

  logger.info("[MissionCron] Mission Engine cron scheduled (daily 06:00, weekly cleanup Sun 03:00)");
}
