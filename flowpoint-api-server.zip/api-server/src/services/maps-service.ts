const MAPS_KEY = process.env["GOOGLE_MAPS_API_KEY"] ?? "";
const MAPS_BASE = "https://maps.googleapis.com/maps/api";

export function isMapsConfigured(): boolean {
  return MAPS_KEY.length > 0;
}

async function mapsGet(path: string): Promise<unknown> {
  if (!isMapsConfigured()) throw new Error("GOOGLE_MAPS_API_KEY not configured");
  const url = `${MAPS_BASE}${path}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`Maps API HTTP ${res.status}`);
  return res.json();
}

export interface LatLng { lat: number; lng: number; }

export interface GeocodedPlace {
  formatted_address: string;
  lat: number;
  lng: number;
  placeId: string;
}

export async function geocodeAddress(address: string): Promise<GeocodedPlace | null> {
  const encoded = encodeURIComponent(address);
  const data = await mapsGet(`/geocode/json?address=${encoded}&key=${MAPS_KEY}`) as { status: string; results: Array<{ formatted_address: string; place_id: string; geometry: { location: { lat: number; lng: number } } }> };
  if (data.status !== "OK" || !data.results.length) return null;
  const r = data.results[0];
  return {
    formatted_address: r.formatted_address,
    lat: r.geometry.location.lat,
    lng: r.geometry.location.lng,
    placeId: r.place_id,
  };
}

export interface NearbyPlace {
  placeId: string;
  name: string;
  vicinity: string;
  rating: number;
  userRatingsTotal: number;
  lat: number;
  lng: number;
  types: string[];
  businessStatus: string;
}

export async function getNearbyPlaces(lat: number, lng: number, keyword: string, radiusM = 3000): Promise<NearbyPlace[]> {
  const params = new URLSearchParams({
    location: `${lat},${lng}`,
    radius: String(radiusM),
    keyword,
    key: MAPS_KEY,
  });
  const data = await mapsGet(`/place/nearbysearch/json?${params}`) as {
    status: string;
    results: Array<{
      place_id: string; name: string; vicinity: string; rating?: number;
      user_ratings_total?: number; geometry: { location: { lat: number; lng: number } };
      types: string[]; business_status?: string;
    }>;
  };
  if (data.status !== "OK" && data.status !== "ZERO_RESULTS") return [];
  return (data.results ?? []).map(r => ({
    placeId: r.place_id,
    name: r.name,
    vicinity: r.vicinity,
    rating: r.rating ?? 0,
    userRatingsTotal: r.user_ratings_total ?? 0,
    lat: r.geometry.location.lat,
    lng: r.geometry.location.lng,
    types: r.types ?? [],
    businessStatus: r.business_status ?? "OPERATIONAL",
  }));
}

export interface DistanceResult {
  origin: string;
  destination: string;
  distanceText: string;
  distanceValue: number;
  durationText: string;
  durationValue: number;
}

export async function getDistanceMatrix(origins: string[], destinations: string[]): Promise<DistanceResult[]> {
  const params = new URLSearchParams({
    origins: origins.join("|"),
    destinations: destinations.join("|"),
    key: MAPS_KEY,
  });
  const data = await mapsGet(`/distancematrix/json?${params}`) as {
    status: string;
    origin_addresses: string[];
    destination_addresses: string[];
    rows: Array<{ elements: Array<{ status: string; distance: { text: string; value: number }; duration: { text: string; value: number } }> }>;
  };
  if (data.status !== "OK") return [];
  const results: DistanceResult[] = [];
  data.rows.forEach((row, i) => {
    row.elements.forEach((el, j) => {
      if (el.status === "OK") {
        results.push({
          origin: data.origin_addresses[i] ?? origins[i],
          destination: data.destination_addresses[j] ?? destinations[j],
          distanceText: el.distance.text,
          distanceValue: el.distance.value,
          durationText: el.duration.text,
          durationValue: el.duration.value,
        });
      }
    });
  });
  return results;
}

export interface HeatmapZone {
  lat: number;
  lng: number;
  weight: number;
  label: string;
}

export async function getHeatmapData(lat: number, lng: number, radiusM = 5000, keyword: string): Promise<HeatmapZone[]> {
  const offsets = [
    { dlat: 0, dlng: 0, w: 1.0, label: "Centre" },
    { dlat: 0.012, dlng: 0, w: 0.7, label: "Nord" },
    { dlat: -0.012, dlng: 0, w: 0.55, label: "Sud" },
    { dlat: 0, dlng: 0.018, w: 0.65, label: "Est" },
    { dlat: 0, dlng: -0.018, w: 0.6, label: "Ouest" },
    { dlat: 0.008, dlng: 0.012, w: 0.5, label: "Nord-Est" },
    { dlat: 0.008, dlng: -0.012, w: 0.45, label: "Nord-Ouest" },
    { dlat: -0.008, dlng: 0.012, w: 0.4, label: "Sud-Est" },
    { dlat: -0.008, dlng: -0.012, w: 0.35, label: "Sud-Ouest" },
  ];
  const nearby = await getNearbyPlaces(lat, lng, keyword, radiusM).catch(() => []);
  const zones: HeatmapZone[] = offsets.map(o => {
    const zoneLat = lat + o.dlat;
    const zoneLng = lng + o.dlng;
    const nearbyCount = nearby.filter(p => Math.abs(p.lat - zoneLat) < 0.015 && Math.abs(p.lng - zoneLng) < 0.02).length;
    const competitionPenalty = Math.min(0.4, nearbyCount * 0.06);
    return { lat: zoneLat, lng: zoneLng, weight: Math.max(0.1, o.w - competitionPenalty), label: o.label };
  });
  return zones;
}

export interface CompetitorAnalysis {
  placeId: string;
  name: string;
  vicinity: string;
  rating: number;
  reviewCount: number;
  lat: number;
  lng: number;
  distanceM: number;
  threatLevel: "critical" | "high" | "medium" | "low";
  seoScore: number;
}

export async function analyzeCompetitors(lat: number, lng: number, keyword: string, radiusM = 5000): Promise<CompetitorAnalysis[]> {
  const places = await getNearbyPlaces(lat, lng, keyword, radiusM);
  return places.slice(0, 20).map(p => {
    const dLat = p.lat - lat;
    const dLng = p.lng - lng;
    const distanceM = Math.round(Math.sqrt((dLat * 111000) ** 2 + (dLng * 111000 * Math.cos(lat * Math.PI / 180)) ** 2));
    const ratingScore = (p.rating / 5) * 40;
    const reviewScore = Math.min(40, (p.userRatingsTotal / 100) * 10);
    const proximityScore = Math.max(0, 20 - (distanceM / radiusM) * 20);
    const seoScore = Math.round(ratingScore + reviewScore + proximityScore);
    const threatLevel: "critical" | "high" | "medium" | "low" =
      seoScore >= 75 ? "critical" :
      seoScore >= 55 ? "high" :
      seoScore >= 35 ? "medium" : "low";
    return { placeId: p.placeId, name: p.name, vicinity: p.vicinity, rating: p.rating, reviewCount: p.userRatingsTotal, lat: p.lat, lng: p.lng, distanceM, threatLevel, seoScore };
  }).sort((a, b) => b.seoScore - a.seoScore);
}
