import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { getValidToken } from "./google-service.js";

const GSC_BASE = "https://www.googleapis.com/webmasters/v3";

async function gscFetch(accessToken: string, path: string, body?: unknown): Promise<unknown> {
  const url = path.startsWith("http") ? path : `${GSC_BASE}${path}`;
  const opts: RequestInit = {
    method: body ? "POST" : "GET",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
  };
  if (body) opts.body = JSON.stringify(body);
  const resp = await fetch(url, opts);
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`GSC API ${resp.status}: ${text.slice(0, 300)}`);
  }
  return resp.json();
}

export async function listGSCSites(orgId: string): Promise<Array<{ siteUrl: string; permissionLevel: string }>> {
  const token = await getValidToken(orgId);
  if (!token) return [];
  try {
    const data = await gscFetch(token, "/sites") as { siteEntry?: Array<{ siteUrl: string; permissionLevel: string }> };
    return data.siteEntry ?? [];
  } catch (e) {
    logger.warn({ e }, "[GSC] listSites failed");
    return [];
  }
}

export async function querySearchAnalytics(
  orgId: string,
  siteUrl: string,
  params: {
    startDate: string;
    endDate: string;
    dimensions?: string[];
    rowLimit?: number;
    startRow?: number;
    dimensionFilterGroups?: unknown[];
    aggregationType?: string;
  }
): Promise<Array<Record<string, unknown>>> {
  const token = await getValidToken(orgId);
  if (!token) return [];
  try {
    const body = {
      startDate: params.startDate,
      endDate: params.endDate,
      dimensions: params.dimensions ?? ["query"],
      rowLimit: params.rowLimit ?? 1000,
      startRow: params.startRow ?? 0,
      aggregationType: params.aggregationType ?? "auto",
      ...(params.dimensionFilterGroups && { dimensionFilterGroups: params.dimensionFilterGroups }),
    };
    const encodedSite = encodeURIComponent(siteUrl);
    const data = await gscFetch(token, `/sites/${encodedSite}/searchAnalytics/query`, body) as {
      rows?: Array<Record<string, unknown>>;
    };
    return data.rows ?? [];
  } catch (e) {
    logger.warn({ e, siteUrl }, "[GSC] querySearchAnalytics failed");
    return [];
  }
}

export async function getIndexingStatus(orgId: string, siteUrl: string, inspectionUrl: string): Promise<unknown> {
  const token = await getValidToken(orgId);
  if (!token) return null;
  try {
    const data = await gscFetch(
      token,
      "https://searchconsole.googleapis.com/v1/urlInspection/index:inspect",
      { inspectionUrl, siteUrl }
    );
    return data;
  } catch (e) {
    logger.warn({ e }, "[GSC] getIndexingStatus failed");
    return null;
  }
}

export async function getSitemaps(orgId: string, siteUrl: string): Promise<unknown[]> {
  const token = await getValidToken(orgId);
  if (!token) return [];
  try {
    const encodedSite = encodeURIComponent(siteUrl);
    const data = await gscFetch(token, `/sites/${encodedSite}/sitemaps`) as { sitemap?: unknown[] };
    return data.sitemap ?? [];
  } catch (e) {
    logger.warn({ e }, "[GSC] getSitemaps failed");
    return [];
  }
}

export async function getGSCStatus(orgId = "default"): Promise<{
  connected: boolean;
  siteUrl?: string | null;
  siteDisplayName?: string;
  lastSync?: string | null;
  clicksTotal?: number;
  impressionsTotal?: number;
  avgCTR?: number;
  avgPosition?: number;
}> {
  const client = await pool.connect();
  try {
    const siteRes = await client.query(
      `SELECT site_url, display_name, last_sync_at FROM gsc_sites WHERE org_id=$1 AND is_active=true LIMIT 1`,
      [orgId]
    );
    if (siteRes.rows.length === 0) {
      const token = await getValidToken(orgId);
      return { connected: !!token };
    }
    const site = siteRes.rows[0] as { site_url: string; display_name: string; last_sync_at: string | null };

    const statsRes = await client.query(
      `SELECT
        COALESCE(SUM(clicks),0) AS clicks_total,
        COALESCE(SUM(impressions),0) AS impressions_total,
        CASE WHEN SUM(impressions) > 0 THEN ROUND(SUM(clicks)::numeric / SUM(impressions) * 100, 2) ELSE 0 END AS avg_ctr,
        COALESCE(ROUND(AVG(position)::numeric, 1), 0) AS avg_position
       FROM gsc_search_analytics
       WHERE org_id=$1 AND site_url=$2 AND date >= CURRENT_DATE - INTERVAL '30 days'`,
      [orgId, site.site_url]
    );
    const stats = statsRes.rows[0] as { clicks_total: string; impressions_total: string; avg_ctr: string; avg_position: string };

    return {
      connected: true,
      siteUrl: site.site_url,
      siteDisplayName: site.display_name || site.site_url,
      lastSync: site.last_sync_at,
      clicksTotal: parseInt(stats.clicks_total) || 0,
      impressionsTotal: parseInt(stats.impressions_total) || 0,
      avgCTR: parseFloat(stats.avg_ctr) || 0,
      avgPosition: parseFloat(stats.avg_position) || 0,
    };
  } finally {
    client.release();
  }
}

export async function getActiveSite(orgId = "default"): Promise<string | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT site_url FROM gsc_sites WHERE org_id=$1 AND is_active=true LIMIT 1`,
      [orgId]
    );
    return res.rows.length ? (res.rows[0] as { site_url: string }).site_url : null;
  } finally {
    client.release();
  }
}

export async function setActiveSite(orgId: string, siteUrl: string, displayName?: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`UPDATE gsc_sites SET is_active=false WHERE org_id=$1`, [orgId]);
    await client.query(
      `INSERT INTO gsc_sites (id, org_id, site_url, display_name, is_active, created_at)
       VALUES ($1,$2,$3,$4,true,now())
       ON CONFLICT (org_id, site_url) DO UPDATE SET is_active=true, display_name=COALESCE($4, gsc_sites.display_name), updated_at=now()`,
      [`gsc_${orgId}_${Buffer.from(siteUrl).toString("base64").slice(0, 20)}`, orgId, siteUrl, displayName || siteUrl]
    );
  } finally {
    client.release();
  }
}

export async function syncGSCData(orgId = "default"): Promise<{ keywordsCount: number; pagesCount: number }> {
  const siteUrl = await getActiveSite(orgId);
  if (!siteUrl) {
    logger.info("[GSC] No site selected, skipping sync");
    return { keywordsCount: 0, pagesCount: 0 };
  }

  const endDate = new Date().toISOString().split("T")[0]!;
  const startDate = new Date(Date.now() - 90 * 24 * 3600_000).toISOString().split("T")[0]!;

  const [keywordRows, pageRows] = await Promise.all([
    querySearchAnalytics(orgId, siteUrl, {
      startDate, endDate,
      dimensions: ["query", "date"],
      rowLimit: 5000,
    }),
    querySearchAnalytics(orgId, siteUrl, {
      startDate, endDate,
      dimensions: ["page", "date"],
      rowLimit: 2000,
    }),
  ]);

  const client = await pool.connect();
  let keywordsCount = 0;
  let pagesCount = 0;

  try {
    for (const row of keywordRows) {
      const keys = row.keys as string[] | undefined;
      if (!keys || keys.length < 2) continue;
      const [keyword, date] = keys;
      const id = `gsc_k_${orgId}_${Buffer.from(`${siteUrl}${keyword}${date}`).toString("base64").slice(0, 40)}`;
      await client.query(
        `INSERT INTO gsc_search_analytics (id, org_id, site_url, keyword, page, date, clicks, impressions, ctr, position, cached_at)
         VALUES ($1,$2,$3,$4,NULL,$5,$6,$7,$8,$9,now())
         ON CONFLICT (org_id, site_url, keyword, page, date) DO UPDATE SET
           clicks=$6, impressions=$7, ctr=$8, position=$9, cached_at=now()`,
        [id, orgId, siteUrl, keyword, date,
          Math.round((row.clicks as number) || 0),
          Math.round((row.impressions as number) || 0),
          parseFloat(String(row.ctr || 0)),
          parseFloat(String(row.position || 0))]
      );
      keywordsCount++;
    }

    for (const row of pageRows) {
      const keys = row.keys as string[] | undefined;
      if (!keys || keys.length < 2) continue;
      const [page, date] = keys;
      const id = `gsc_p_${orgId}_${Buffer.from(`${siteUrl}${page}${date}`).toString("base64").slice(0, 40)}`;
      await client.query(
        `INSERT INTO gsc_search_analytics (id, org_id, site_url, keyword, page, date, clicks, impressions, ctr, position, cached_at)
         VALUES ($1,$2,$3,NULL,$4,$5,$6,$7,$8,$9,now())
         ON CONFLICT (org_id, site_url, keyword, page, date) DO UPDATE SET
           clicks=$6, impressions=$7, ctr=$8, position=$9, cached_at=now()`,
        [id, orgId, siteUrl, page, date,
          Math.round((row.clicks as number) || 0),
          Math.round((row.impressions as number) || 0),
          parseFloat(String(row.ctr || 0)),
          parseFloat(String(row.position || 0))]
      );
      pagesCount++;
    }

    await client.query(`UPDATE gsc_sites SET last_sync_at=now() WHERE org_id=$1 AND site_url=$2`, [orgId, siteUrl]);
    await logSync(client, orgId, "gsc", "success", `Synced ${keywordsCount} keywords, ${pagesCount} pages`, keywordsCount + pagesCount);
  } catch (e) {
    await logSync(client, orgId, "gsc", "failed", String(e), 0);
    throw e;
  } finally {
    client.release();
  }

  logger.info({ keywordsCount, pagesCount, siteUrl }, "[GSC] Sync complete");
  return { keywordsCount, pagesCount };
}

async function logSync(
  client: { query: (sql: string, params?: unknown[]) => Promise<unknown> },
  orgId: string,
  integration: string,
  status: string,
  message: string,
  recordsSynced: number,
): Promise<void> {
  try {
    const id = `sync_${orgId}_${integration}_${Date.now()}`;
    await client.query(
      `INSERT INTO google_sync_logs (id, org_id, integration, status, message, records_synced, started_at, ended_at)
       VALUES ($1,$2,$3,$4,$5,$6,now(),now())`,
      [id, orgId, integration, status, message, recordsSynced]
    );
  } catch (_) { /* non-critical */ }
}

export async function getTopKeywords(orgId: string, siteUrl: string, days = 30, limit = 100): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT keyword,
        SUM(clicks) AS clicks,
        SUM(impressions) AS impressions,
        CASE WHEN SUM(impressions) > 0 THEN ROUND(SUM(clicks)::numeric / SUM(impressions) * 100, 2) ELSE 0 END AS ctr,
        ROUND(AVG(position)::numeric, 1) AS position
       FROM gsc_search_analytics
       WHERE org_id=$1 AND site_url=$2 AND keyword IS NOT NULL
         AND date >= CURRENT_DATE - INTERVAL '${days} days'
       GROUP BY keyword
       ORDER BY impressions DESC
       LIMIT $3`,
      [orgId, siteUrl, limit]
    );
    return res.rows;
  } finally {
    client.release();
  }
}

export async function getTopPages(orgId: string, siteUrl: string, days = 30, limit = 100): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT page,
        SUM(clicks) AS clicks,
        SUM(impressions) AS impressions,
        CASE WHEN SUM(impressions) > 0 THEN ROUND(SUM(clicks)::numeric / SUM(impressions) * 100, 2) ELSE 0 END AS ctr,
        ROUND(AVG(position)::numeric, 1) AS position
       FROM gsc_search_analytics
       WHERE org_id=$1 AND site_url=$2 AND page IS NOT NULL
         AND date >= CURRENT_DATE - INTERVAL '${days} days'
       GROUP BY page
       ORDER BY clicks DESC
       LIMIT $3`,
      [orgId, siteUrl, limit]
    );
    return res.rows;
  } finally {
    client.release();
  }
}

export async function getImpressionsOverTime(orgId: string, siteUrl: string, days = 90): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT date::text,
        SUM(clicks) AS clicks,
        SUM(impressions) AS impressions,
        CASE WHEN SUM(impressions) > 0 THEN ROUND(SUM(clicks)::numeric / SUM(impressions) * 100, 2) ELSE 0 END AS ctr,
        ROUND(AVG(position)::numeric, 1) AS avg_position
       FROM gsc_search_analytics
       WHERE org_id=$1 AND site_url=$2 AND keyword IS NOT NULL
         AND date >= CURRENT_DATE - INTERVAL '${days} days'
       GROUP BY date
       ORDER BY date`,
      [orgId, siteUrl]
    );
    return res.rows;
  } finally {
    client.release();
  }
}

export async function getSyncLogs(orgId: string, limit = 20): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT integration, status, message, records_synced, started_at, ended_at
       FROM google_sync_logs WHERE org_id=$1
       ORDER BY started_at DESC LIMIT $2`,
      [orgId, limit]
    );
    return res.rows;
  } finally {
    client.release();
  }
}
