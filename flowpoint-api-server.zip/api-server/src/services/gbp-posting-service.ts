import { pool } from "@workspace/db";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export type PostType = 'standard' | 'offer' | 'event' | 'update' | 'product';
export type CtaType = 'BOOK' | 'ORDER' | 'SHOP' | 'LEARN_MORE' | 'SIGN_UP' | 'CALL' | 'GET_OFFER';

export interface GbpPostInput {
  locationId: string;
  locationName?: string;
  postType?: PostType;
  title?: string;
  content: string;
  ctaType?: CtaType;
  ctaUrl?: string;
  mediaUrls?: string[];
  scheduledAt?: string;
  seoKeywords?: string[];
  eventTitle?: string;
  eventStart?: string;
  eventEnd?: string;
  offerCode?: string;
  aiGenerated?: boolean;
}

export async function createPost(orgId: string, data: GbpPostInput): Promise<unknown> {
  const id = `gp_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
  const status = data.scheduledAt ? 'scheduled' : 'draft';
  const client = await pool.connect();
  try {
    await client.query(`INSERT INTO gbp_posts (id,org_id,location_id,location_name,post_type,title,content,cta_type,cta_url,media_urls,scheduled_at,event_title,event_start,event_end,offer_code,status,seo_keywords,ai_generated) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)`,
      [id, orgId, data.locationId, data.locationName||null, data.postType||'standard', data.title||null, data.content, data.ctaType||null, data.ctaUrl||null, data.mediaUrls||[], data.scheduledAt||null, data.eventTitle||null, data.eventStart||null, data.eventEnd||null, data.offerCode||null, status, data.seoKeywords||[], data.aiGenerated||false]);
    if (data.scheduledAt) {
      const queueId = `gpq_${Date.now()}_${Math.random().toString(36).slice(2,5)}`;
      await client.query(`INSERT INTO gbp_post_queue (id,post_id,org_id,location_id,status,scheduled_for) VALUES ($1,$2,$3,$4,'queued',$5)`,
        [queueId, id, orgId, data.locationId, data.scheduledAt]);
    }
    const r = await client.query(`SELECT * FROM gbp_posts WHERE id=$1`, [id]);
    return r.rows[0];
  } finally {
    client.release();
  }
}

export async function generateAiPost(orgId: string, params: {
  locationId: string; locationName?: string; postType?: PostType;
  industry?: string; keywords?: string[]; tone?: string; objective?: string;
}): Promise<{ content: string; title?: string; ctaType?: CtaType; seoKeywords: string[] }> {
  const defaultContent = `Découvrez nos services de qualité ! ${params.keywords?.join(', ') || 'Contactez-nous'} dès aujourd'hui. Devis gratuit et intervention rapide.`;

  if (!process.env.OPENAI_API_KEY) {
    return { content: defaultContent, title: 'Nos services', seoKeywords: params.keywords || [] };
  }

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 500,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: 'Tu es un expert en contenu Google Business Profile local. Génère un post optimisé SEO local en JSON: { content: string, title: string, cta_type: string, keywords: string[] }' },
        { role: 'user', content: `Type: ${params.postType||'standard'}, Établissement: "${params.locationName||'Mon établissement'}", Secteur: ${params.industry||'services locaux'}, Mots-clés cibles: ${params.keywords?.join(', ')||''}, Ton: ${params.tone||'professionnel'}, Objectif: ${params.objective||'notoriété'}. Maximum 300 caractères pour le contenu.` },
      ],
    });
    const parsed = JSON.parse(completion.choices[0]?.message?.content || '{}');
    return {
      content: parsed.content || defaultContent,
      title: parsed.title,
      ctaType: (parsed.cta_type as CtaType) || 'LEARN_MORE',
      seoKeywords: parsed.keywords || params.keywords || [],
    };
  } catch {
    return { content: defaultContent, title: 'Nos services', seoKeywords: params.keywords || [] };
  }
}

export async function publishPost(orgId: string, postId: string): Promise<unknown> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM gbp_posts WHERE id=$1 AND org_id=$2`, [postId, orgId]);
    const post = r.rows[0];
    if (!post) throw new Error("Post introuvable");
    // In production: call Google Business Profile API to publish
    const googlePostId = `gpost_${Date.now()}`;
    await client.query(`UPDATE gbp_posts SET status='published', published_at=now(), google_post_id=$1, updated_at=now() WHERE id=$2`, [googlePostId, postId]);
    const updated = await client.query(`SELECT * FROM gbp_posts WHERE id=$1`, [postId]);
    return updated.rows[0];
  } finally {
    client.release();
  }
}

export async function getPostsDashboard(orgId: string): Promise<Record<string, unknown>> {
  const client = await pool.connect();
  try {
    const [postsRes, queueRes] = await Promise.all([
      client.query(`SELECT * FROM gbp_posts WHERE org_id=$1 ORDER BY created_at DESC LIMIT 50`, [orgId]),
      client.query(`SELECT * FROM gbp_post_queue WHERE org_id=$1 AND status='queued' ORDER BY scheduled_for ASC LIMIT 10`, [orgId]),
    ]);
    const posts = postsRes.rows;
    return {
      posts,
      queue: queueRes.rows,
      stats: {
        total: posts.length,
        published: posts.filter((p: { status: string }) => p.status === 'published').length,
        scheduled: posts.filter((p: { status: string }) => p.status === 'scheduled').length,
        drafts: posts.filter((p: { status: string }) => p.status === 'draft').length,
        totalViews: posts.reduce((s: number, p: { views: number }) => s + (p.views || 0), 0),
        totalClicks: posts.reduce((s: number, p: { clicks: number }) => s + (p.clicks || 0), 0),
        aiGenerated: posts.filter((p: { ai_generated: boolean }) => p.ai_generated).length,
      },
    };
  } finally {
    client.release();
  }
}

export async function deletePost(orgId: string, postId: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`DELETE FROM gbp_posts WHERE id=$1 AND org_id=$2 AND status!='published'`, [postId, orgId]);
  } finally {
    client.release();
  }
}

export async function getScheduledPosts(orgId: string): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT p.*, q.scheduled_for, q.status as queue_status FROM gbp_posts p LEFT JOIN gbp_post_queue q ON q.post_id=p.id WHERE p.org_id=$1 AND p.status='scheduled' ORDER BY p.scheduled_at ASC`, [orgId]);
    return r.rows;
  } finally {
    client.release();
  }
}
