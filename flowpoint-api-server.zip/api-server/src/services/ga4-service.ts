import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { refreshAccessToken, decryptToken, encryptToken } from "./google-service.js";

// ── In-memory cache (15 min TTL) ──────────────────────────────────────────────

const _cache = new Map<string, { data: unknown; ts: number }>();
const CACHE_TTL = 15 * 60 * 1000;

function getCached(key: string): unknown | null {
  const entry = _cache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.ts > CACHE_TTL) { _cache.delete(key); return null; }
  return entry.data;
}

function setCache(key: string, data: unknown): void {
  _cache.set(key, { data, ts: Date.now() });
}

// ── Token management ──────────────────────────────────────────────────────────

async function getValidAccessToken(orgId: string): Promise<string | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT access_token, refresh_token, token_expiry FROM google_accounts WHERE org_id=$1 LIMIT 1`,
      [orgId]
    );
    if (!res.rows.length) return null;
    const row = res.rows[0] as { access_token: string; refresh_token: string; token_expiry: string | null };
    const expiry = row.token_expiry ? new Date(row.token_expiry).getTime() : 0;
    const accessToken = decryptToken(row.access_token);
    const refreshTok  = decryptToken(row.refresh_token);
    if (Date.now() < expiry - 60_000) return accessToken;
    if (!refreshTok) return null;
    const newToken = await refreshAccessToken(refreshTok);
    await client.query(
      `UPDATE google_accounts SET access_token=$1, token_expiry=$2, updated_at=now() WHERE org_id=$3`,
      [encryptToken(newToken), new Date(Date.now() + 3600_000).toISOString(), orgId]
    );
    return newToken;
  } finally {
    client.release();
  }
}

// ── Generic GA4 fetch ─────────────────────────────────────────────────────────

async function ga4Fetch(accessToken: string, url: string, body?: unknown): Promise<unknown> {
  const opts: RequestInit = {
    method: body ? "POST" : "GET",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
  };
  if (body) opts.body = JSON.stringify(body);
  const resp = await fetch(url, opts);
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`GA4 API ${resp.status}: ${text.slice(0, 300)}`);
  }
  return resp.json();
}

// ── Report runner with caching ────────────────────────────────────────────────

async function runReport(orgId: string, propertyId: string, body: unknown): Promise<unknown> {
  const cacheKey = `report:${orgId}:${propertyId}:${JSON.stringify(body)}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const token = await getValidAccessToken(orgId);
  if (!token) throw new Error("Google account not connected. Link your GA4 account first.");

  const data = await ga4Fetch(
    token,
    `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`,
    body
  );
  setCache(cacheKey, data);
  return data;
}

async function runRealtimeReport(orgId: string, propertyId: string, body: unknown): Promise<unknown> {
  const token = await getValidAccessToken(orgId);
  if (!token) throw new Error("Google account not connected.");
  return ga4Fetch(
    token,
    `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runRealtimeReport`,
    body
  );
}

// ── Admin API (accounts / properties) ────────────────────────────────────────

export async function listGA4Accounts(orgId: string): Promise<unknown[]> {
  const token = await getValidAccessToken(orgId);
  if (!token) return [];
  try {
    const data = await ga4Fetch(
      token,
      "https://analyticsadmin.googleapis.com/v1beta/accounts"
    ) as { accounts?: unknown[] };
    return data.accounts ?? [];
  } catch (e) {
    logger.warn({ e }, "[GA4] listAccounts failed");
    return [];
  }
}

export async function listGA4Properties(orgId: string, accountId?: string): Promise<unknown[]> {
  const token = await getValidAccessToken(orgId);
  if (!token) return [];
  try {
    const filter = accountId ? `?filter=ancestor:accounts/${accountId}` : "";
    const data = await ga4Fetch(
      token,
      `https://analyticsadmin.googleapis.com/v1beta/properties${filter}`
    ) as { properties?: unknown[] };
    return data.properties ?? [];
  } catch (e) {
    logger.warn({ e }, "[GA4] listProperties failed");
    return [];
  }
}

// ── Stored property ───────────────────────────────────────────────────────────

export async function getStoredProperty(orgId: string): Promise<string | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT property_id FROM ga4_properties WHERE org_id=$1 AND is_active=true LIMIT 1`,
      [orgId]
    );
    return res.rows.length ? (res.rows[0] as { property_id: string }).property_id : null;
  } finally {
    client.release();
  }
}

export async function setStoredProperty(
  orgId: string,
  propertyId: string,
  propertyName: string,
): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO ga4_properties (id, org_id, property_id, property_name, is_active, created_at)
       VALUES ($1,$2,$3,$4,true,now())
       ON CONFLICT (org_id) DO UPDATE SET property_id=$3, property_name=$4, is_active=true, updated_at=now()`,
      [`ga4_${orgId}`, orgId, propertyId, propertyName]
    );
  } finally {
    client.release();
  }
}

// ── Analytics reports ─────────────────────────────────────────────────────────

export async function getGA4Overview(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  const prev = days * 2;
  return runReport(orgId, propertyId, {
    dateRanges: [
      { startDate: `${days}daysAgo`, endDate: "yesterday" },
      { startDate: `${prev}daysAgo`, endDate: `${days}daysAgo` },
    ],
    metrics: [
      { name: "sessions" },
      { name: "totalUsers" },
      { name: "newUsers" },
      { name: "bounceRate" },
      { name: "engagementRate" },
      { name: "averageSessionDuration" },
      { name: "screenPageViews" },
      { name: "conversions" },
    ],
    dimensions: [{ name: "date" }],
    orderBys: [{ dimension: { dimensionName: "date" } }],
  });
}

export async function getGA4Realtime(orgId: string, propertyId: string): Promise<unknown> {
  return runRealtimeReport(orgId, propertyId, {
    metrics: [
      { name: "activeUsers" },
      { name: "screenPageViews" },
    ],
    dimensions: [
      { name: "country" },
      { name: "city" },
      { name: "unifiedScreenName" },
      { name: "deviceCategory" },
    ],
    limit: 50,
  });
}

export async function getGA4Sources(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  const prev = days * 2;
  return runReport(orgId, propertyId, {
    dateRanges: [
      { startDate: `${days}daysAgo`, endDate: "yesterday" },
      { startDate: `${prev}daysAgo`, endDate: `${days}daysAgo` },
    ],
    metrics: [
      { name: "sessions" },
      { name: "totalUsers" },
      { name: "bounceRate" },
      { name: "conversions" },
      { name: "engagementRate" },
    ],
    dimensions: [
      { name: "sessionDefaultChannelGrouping" },
      { name: "sessionSourceMedium" },
    ],
    orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
    limit: 25,
  });
}

export async function getGA4Pages(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  return runReport(orgId, propertyId, {
    dateRanges: [{ startDate: `${days}daysAgo`, endDate: "yesterday" }],
    metrics: [
      { name: "screenPageViews" },
      { name: "totalUsers" },
      { name: "averageSessionDuration" },
      { name: "bounceRate" },
      { name: "entrances" },
      { name: "exits" },
    ],
    dimensions: [{ name: "pagePath" }, { name: "pageTitle" }],
    orderBys: [{ metric: { metricName: "screenPageViews" }, desc: true }],
    limit: 50,
  });
}

export async function getGA4Funnels(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  const [landingPages, conversionPaths] = await Promise.all([
    runReport(orgId, propertyId, {
      dateRanges: [{ startDate: `${days}daysAgo`, endDate: "yesterday" }],
      metrics: [
        { name: "sessions" },
        { name: "totalUsers" },
        { name: "bounceRate" },
        { name: "conversions" },
      ],
      dimensions: [
        { name: "landingPage" },
        { name: "sessionDefaultChannelGrouping" },
      ],
      orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
      limit: 20,
    }),
    runReport(orgId, propertyId, {
      dateRanges: [{ startDate: `${days}daysAgo`, endDate: "yesterday" }],
      metrics: [
        { name: "conversions" },
        { name: "totalUsers" },
        { name: "sessions" },
      ],
      dimensions: [
        { name: "eventName" },
        { name: "sessionDefaultChannelGrouping" },
      ],
      orderBys: [{ metric: { metricName: "conversions" }, desc: true }],
      limit: 20,
    }),
  ]);
  return { landingPages, conversionPaths };
}

export async function getGA4Conversions(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  const prev = days * 2;
  return runReport(orgId, propertyId, {
    dateRanges: [
      { startDate: `${days}daysAgo`, endDate: "yesterday" },
      { startDate: `${prev}daysAgo`, endDate: `${days}daysAgo` },
    ],
    metrics: [
      { name: "conversions" },
      { name: "totalUsers" },
      { name: "sessions" },
      { name: "conversionRate" },
    ],
    dimensions: [
      { name: "eventName" },
      { name: "sessionDefaultChannelGrouping" },
    ],
    orderBys: [{ metric: { metricName: "conversions" }, desc: true }],
    limit: 30,
  });
}

export async function getGA4Audience(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  const [devices, geo, newVsReturn] = await Promise.all([
    runReport(orgId, propertyId, {
      dateRanges: [{ startDate: `${days}daysAgo`, endDate: "yesterday" }],
      metrics: [{ name: "sessions" }, { name: "totalUsers" }, { name: "bounceRate" }, { name: "engagementRate" }],
      dimensions: [{ name: "deviceCategory" }, { name: "operatingSystem" }, { name: "browser" }],
      orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
      limit: 30,
    }),
    runReport(orgId, propertyId, {
      dateRanges: [{ startDate: `${days}daysAgo`, endDate: "yesterday" }],
      metrics: [{ name: "sessions" }, { name: "totalUsers" }, { name: "conversions" }],
      dimensions: [{ name: "country" }, { name: "city" }],
      orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
      limit: 30,
    }),
    runReport(orgId, propertyId, {
      dateRanges: [{ startDate: `${days}daysAgo`, endDate: "yesterday" }],
      metrics: [{ name: "totalUsers" }, { name: "newUsers" }, { name: "sessions" }, { name: "engagementRate" }],
      dimensions: [{ name: "newVsReturning" }],
    }),
  ]);
  return { devices, geo, newVsReturn };
}

export async function getGA4Campaigns(orgId: string, propertyId: string, days = 30): Promise<unknown> {
  const prev = days * 2;
  return runReport(orgId, propertyId, {
    dateRanges: [
      { startDate: `${days}daysAgo`, endDate: "yesterday" },
      { startDate: `${prev}daysAgo`, endDate: `${days}daysAgo` },
    ],
    metrics: [
      { name: "sessions" },
      { name: "totalUsers" },
      { name: "conversions" },
      { name: "bounceRate" },
      { name: "averageSessionDuration" },
      { name: "conversionRate" },
    ],
    dimensions: [
      { name: "sessionCampaignName" },
      { name: "sessionDefaultChannelGrouping" },
      { name: "sessionSourceMedium" },
    ],
    orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
    limit: 30,
  });
}

export async function isGA4Connected(orgId: string): Promise<boolean> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT 1 FROM google_accounts WHERE org_id=$1 LIMIT 1`,
      [orgId]
    );
    return res.rows.length > 0;
  } finally {
    client.release();
  }
}

export { getValidAccessToken as getGA4ValidToken };
