import { db, forecastModelsTable, forecastSnapshotsTable, forecastPredictionsTable, auditsTable } from "@workspace/db";
import { eq, desc, sql, inArray } from "drizzle-orm";
import { logger } from "../lib/logger.js";
import { consumeAICredits } from "./ai-engine.js";
import { isDemoMode } from "./mock-data.js";

type ScenarioKey = "base" | "optimistic" | "pessimistic";

function linearTrend(history: number[], horizon: number, growth: number): number[] {
  const lastVal = history[history.length - 1] ?? (history.reduce((s, v) => s + v, 0) / history.length);
  return Array.from({ length: horizon }, (_, i) => {
    return Math.round(lastVal * Math.pow(1 + growth, i + 1));
  });
}

function confidenceBand(values: number[], spread: number): Array<[number, number]> {
  return values.map(v => [Math.round(v * (1 - spread)), Math.round(v * (1 + spread))]);
}

async function buildAuditScoreHistory(): Promise<number[]> {
  try {
    const rows = await db.select({
      month: sql<string>`to_char(created_at, 'YYYY-MM')`,
      avg: sql<number>`round(avg(score))::int`,
    }).from(auditsTable)
      .groupBy(sql`to_char(created_at, 'YYYY-MM')`)
      .orderBy(sql`to_char(created_at, 'YYYY-MM')`)
      .limit(12);

    if (rows.length >= 3) {
      return rows.map(r => Number(r.avg));
    }
  } catch (err) {
    logger.warn({ err }, "[Forecasting] Could not build audit history from DB");
  }
  return [];
}

export async function generateForecasts(siteUrl: string): Promise<void> {
  try {
    await consumeAICredits({ feature: "forecast", metadata: { siteUrl } });

    const existing = await db.select().from(forecastModelsTable)
      .where(eq(forecastModelsTable.siteUrl, siteUrl)).limit(1);
    if (existing.length > 0) {
      await refreshPredictions(siteUrl);
      return;
    }

    const auditHistory = await buildAuditScoreHistory();
    const hasRealAuditHistory = auditHistory.length >= 3;

    // In production, only build models from real data.
    // Traffic / conversion / revenue require GA4/CRM integration data — use fake baselines only in demo mode.
    const defaultSeoHistory = hasRealAuditHistory
      ? auditHistory
      : (isDemoMode() ? [55, 58, 60, 62, 63, 65, 66, 67, 68, 70, 71, 72] : []);

    const modelTypes: Array<{ type: string; baseGrowth: number; history: number[] }> = [
      ...(isDemoMode() ? [
        { type: "traffic",    baseGrowth: 0.04, history: [2800, 3100, 2950, 3300, 3600, 3450, 3800, 4100, 3900, 4200, 4500, 4300] },
      ] : []),
      ...(defaultSeoHistory.length >= 3 ? [
        { type: "seo_score",  baseGrowth: 0.02, history: defaultSeoHistory },
      ] : []),
      ...(isDemoMode() ? [
        { type: "conversion", baseGrowth: 0.03, history: [2.1, 2.3, 2.2, 2.4, 2.5, 2.4, 2.6, 2.7, 2.6, 2.8, 2.9, 3.0] },
        { type: "revenue",    baseGrowth: 0.05, history: [1800, 2100, 1950, 2300, 2600, 2400, 2800, 3100, 2900, 3200, 3500, 3400] },
      ] : []),
    ];

    if (modelTypes.length === 0) {
      logger.info({ siteUrl }, "[Forecasting] Insufficient real data — need 3+ audits before forecasting is available");
      return;
    }

    const scenarios: ScenarioKey[] = ["base", "optimistic", "pessimistic"];
    const growthMultipliers: Record<ScenarioKey, number> = { base: 1, optimistic: 1.5, pessimistic: 0.4 };

    for (const mt of modelTypes) {
      const modelId = `fm_${siteUrl}_${mt.type}`.replace(/[^a-z0-9_]/gi, "_").slice(0, 60);
      const accuracy = mt.type === "seo_score" && hasRealAuditHistory ? 0.91 : 0.82;

      await db.insert(forecastModelsTable).values({
        id: modelId,
        siteUrl,
        modelType: mt.type,
        params: { history: mt.history, baseGrowth: mt.baseGrowth, sourceRealData: mt.type === "seo_score" && hasRealAuditHistory },
        lastTrainedAt: new Date(),
        accuracy,
      }).onConflictDoNothing();

      const now = new Date();
      for (let i = 0; i < mt.history.length; i++) {
        const snapDate = new Date(now.getFullYear(), now.getMonth() - mt.history.length + i, 1);
        await db.insert(forecastSnapshotsTable).values({
          id: `fs_${modelId}_${i}`,
          modelId,
          date: snapDate.toISOString().slice(0, 7),
          value: mt.history[i],
          metricType: mt.type,
        }).onConflictDoNothing();
      }

      for (const scenario of scenarios) {
        const growth = mt.baseGrowth * growthMultipliers[scenario];
        const spread = scenario === "base" ? 0.08 : scenario === "optimistic" ? 0.12 : 0.15;
        const predictions = linearTrend(mt.history, 6, growth);
        const bands = confidenceBand(predictions, spread);

        for (let i = 0; i < predictions.length; i++) {
          const predDate = new Date(now.getFullYear(), now.getMonth() + i + 1, 1);
          await db.insert(forecastPredictionsTable).values({
            id: `fp_${modelId}_${scenario}_${i}`,
            modelId,
            date: predDate.toISOString().slice(0, 7),
            predictedValue: predictions[i],
            confidenceLow: bands[i][0],
            confidenceHigh: bands[i][1],
            scenario,
          }).onConflictDoNothing();
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "[Forecasting] Failed to generate forecasts");
  }
}

async function refreshPredictions(siteUrl: string): Promise<void> {
  try {
    const models = await db.select().from(forecastModelsTable).where(eq(forecastModelsTable.siteUrl, siteUrl));

    const auditHistory = await buildAuditScoreHistory();
    const hasRealAuditHistory = auditHistory.length >= 3;
    const thisMonth = new Date().toISOString().slice(0, 7); // "YYYY-MM"

    for (const m of models) {
      if (m.modelType === "seo_score" && hasRealAuditHistory) {
        const currentScore = auditHistory[auditHistory.length - 1]!;

        // ── Append this month's real audit score as a new snapshot (idempotent) ──
        // Each weekly run adds one row per month; once we reach 12 distinct
        // months the snapshot count gate in getForecastData() unlocks real forecasts.
        await db.insert(forecastSnapshotsTable).values({
          id: `fs_${m.id}_real_${thisMonth}`,
          modelId: m.id,
          date: thisMonth,
          value: currentScore,
          metricType: "seo_score",
        }).onConflictDoNothing();

        // ── Refresh forward predictions from latest audit history ──
        const growth = 0.02;
        const predictions = linearTrend(auditHistory, 6, growth);
        const bands = confidenceBand(predictions, 0.08);
        const now = new Date();

        for (let i = 0; i < predictions.length; i++) {
          const predDate = new Date(now.getFullYear(), now.getMonth() + i + 1, 1);
          const id = `fp_${m.id}_base_${i}`;
          await db.execute(
            sql`UPDATE forecast_predictions SET predicted_value = ${predictions[i]}, confidence_low = ${bands[i][0]}, confidence_high = ${bands[i][1]} WHERE id = ${id}`
          );
        }

        await db.execute(
          sql`UPDATE forecast_models SET last_trained_at = NOW(), accuracy = 0.91 WHERE id = ${m.id}`
        );
      } else {
        await db.execute(
          sql`UPDATE forecast_models SET last_trained_at = NOW() WHERE id = ${m.id}`
        );
      }
    }
  } catch (err) {
    logger.warn({ err }, "[Forecasting] Could not refresh predictions");
  }
}

export type ForecastResult =
  | {
      status: "collecting";
      pointsCollected: number;
      pointsNeeded: number;
      estimatedAvailableAt: string;
      models: [];
      predictions: [];
      snapshots: [];
      anomalies: [];
    }
  | {
      status?: never;
      models: Array<typeof forecastModelsTable.$inferSelect>;
      predictions: Array<typeof forecastPredictionsTable.$inferSelect>;
      snapshots: Array<typeof forecastSnapshotsTable.$inferSelect>;
      anomalies: Array<{ metric: string; description: string; severity: string; detectedAt: Date }>;
    };

export async function getForecastData(siteUrl?: string): Promise<ForecastResult> {
  const models = siteUrl
    ? await db.select().from(forecastModelsTable).where(eq(forecastModelsTable.siteUrl, siteUrl))
    : await db.select().from(forecastModelsTable).limit(20);

  const modelIds = models.map(m => m.id);

  // Count real snapshot points — even if models exist they may have been seeded
  // from too few data points.  We enforce the 12-point minimum here so no
  // invented forecast curves ever reach the client.
  let snapshotCount = 0;
  if (modelIds.length > 0) {
    const snapRows = await db.select({ cnt: sql<number>`count(*)::int` })
      .from(forecastSnapshotsTable)
      .where(inArray(forecastSnapshotsTable.modelId, modelIds))
      .then(r => r)
      .catch(() => [{ cnt: 0 }] as Array<{ cnt: number }>);
    snapshotCount = Number(snapRows[0]?.cnt ?? 0);
  }

  if (modelIds.length === 0 || snapshotCount < 12) {
    const auditHistory = await buildAuditScoreHistory();
    const pointsCollected = Math.max(snapshotCount, auditHistory.length);
    const weeksToGo = Math.max(0, 12 - pointsCollected);
    const estimatedAvailableAt = new Date(
      Date.now() + weeksToGo * 7 * 24 * 3600_000
    ).toISOString();
    return {
      status: "collecting",
      pointsCollected,
      pointsNeeded: 12,
      estimatedAvailableAt,
      models: [],
      predictions: [],
      snapshots: [],
      anomalies: [],
    };
  }

  // Return all scenarios (base / optimistic / pessimistic) filtered to this site's models
  const [predictions, snapshots] = await Promise.all([
    db.select().from(forecastPredictionsTable)
      .where(inArray(forecastPredictionsTable.modelId, modelIds))
      .orderBy(desc(forecastPredictionsTable.date))
      .limit(300),
    db.select().from(forecastSnapshotsTable)
      .where(inArray(forecastSnapshotsTable.modelId, modelIds))
      .orderBy(desc(forecastSnapshotsTable.date))
      .limit(100),
  ]);

  return { models, predictions, snapshots, anomalies: await buildRealAnomalies() };
}

async function buildRealAnomalies(): Promise<Array<{ metric: string; description: string; severity: string; detectedAt: Date }>> {
  const anomalies: Array<{ metric: string; description: string; severity: string; detectedAt: Date }> = [];

  try {
    const recentAudits = await db.select({
      week: sql<string>`to_char(created_at, 'IYYY-IW')`,
      avg: sql<number>`round(avg(score))::int`,
      cnt: sql<number>`count(*)::int`,
    }).from(auditsTable)
      .groupBy(sql`to_char(created_at, 'IYYY-IW')`)
      .orderBy(desc(sql`to_char(created_at, 'IYYY-IW')`))
      .limit(4);

    if (recentAudits.length >= 2) {
      const latest = Number(recentAudits[0]?.avg ?? 0);
      const prev = Number(recentAudits[1]?.avg ?? 0);
      const delta = latest - prev;

      if (delta <= -10) {
        anomalies.push({
          metric: "seo_score",
          description: `Score SEO en chute de ${Math.abs(delta)} pts cette semaine — vérifier les changements récents`,
          severity: "high",
          detectedAt: new Date(),
        });
      } else if (delta >= 8) {
        anomalies.push({
          metric: "seo_score",
          description: `Score SEO en progression de +${delta} pts cette semaine — tendance positive`,
          severity: "low",
          detectedAt: new Date(),
        });
      } else if (delta === 0 && latest < 60) {
        anomalies.push({
          metric: "seo_score",
          description: `Score SEO stable à ${latest}/100 sur 2 semaines — progression attendue non réalisée`,
          severity: "low",
          detectedAt: new Date(Date.now() - 86400000),
        });
      }
    }
  } catch { /* no anomalies if DB fails */ }

  return anomalies;
}
