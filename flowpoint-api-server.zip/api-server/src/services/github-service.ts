import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";

const ORG_ID = "default";
const GITHUB_API = "https://api.github.com";

export function isGitHubConfigured(): boolean {
  return !!(process.env["GITHUB_CLIENT_ID"] && process.env["GITHUB_CLIENT_SECRET"]);
}

export function getGitHubAuthUrl(state: string, scope = "repo,read:user,read:org"): string {
  const clientId = process.env["GITHUB_CLIENT_ID"] || "";
  const redirectUri = process.env["GITHUB_REDIRECT_URI"] || `${process.env["PUBLIC_URL"] || ""}/api/github/callback`;
  return `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(scope)}&state=${state}`;
}

export async function exchangeCodeForToken(code: string): Promise<{ access_token: string; token_type: string; scope: string }> {
  const res = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { "Accept": "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: process.env["GITHUB_CLIENT_ID"],
      client_secret: process.env["GITHUB_CLIENT_SECRET"],
      code,
      redirect_uri: process.env["GITHUB_REDIRECT_URI"] || `${process.env["PUBLIC_URL"] || ""}/api/github/callback`,
    }),
  });

  if (!res.ok) throw new Error(`GitHub token exchange failed: ${res.status}`);
  return res.json() as Promise<{ access_token: string; token_type: string; scope: string }>;
}

async function githubFetch<T>(path: string, token: string): Promise<T> {
  const res = await fetch(`${GITHUB_API}${path}`, {
    headers: {
      "Authorization": `Bearer ${token}`,
      "Accept": "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
    },
  });
  if (!res.ok) throw new Error(`GitHub API error: ${res.status} ${path}`);
  return res.json() as Promise<T>;
}

export async function getGitHubUser(token: string): Promise<{ login: string; name: string; email: string; avatar_url: string; id: number }> {
  return githubFetch("/user", token);
}

export async function getUserRepos(token: string, page = 1, perPage = 30): Promise<GHRepo[]> {
  return githubFetch(`/user/repos?sort=updated&per_page=${perPage}&page=${page}&type=all`, token);
}

export async function getOrgRepos(token: string, org: string): Promise<GHRepo[]> {
  return githubFetch(`/orgs/${org}/repos?sort=updated&per_page=50`, token);
}

export async function getRepoCommits(token: string, owner: string, repo: string, days = 30): Promise<GHCommit[]> {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  return githubFetch(`/repos/${owner}/${repo}/commits?since=${since}&per_page=100`, token);
}

export async function getRepoDeployments(token: string, owner: string, repo: string): Promise<GHDeployment[]> {
  return githubFetch(`/repos/${owner}/${repo}/deployments?per_page=30`, token);
}

export async function getRepoReleases(token: string, owner: string, repo: string): Promise<GHRelease[]> {
  return githubFetch(`/repos/${owner}/${repo}/releases?per_page=20`, token);
}

export async function getRepoBranches(token: string, owner: string, repo: string): Promise<{ name: string }[]> {
  return githubFetch(`/repos/${owner}/${repo}/branches?per_page=50`, token);
}

export async function getRepoContributors(token: string, owner: string, repo: string): Promise<GHContributor[]> {
  return githubFetch(`/repos/${owner}/${repo}/contributors?per_page=30`, token);
}

export async function getRepoContent(token: string, owner: string, repo: string, path = ""): Promise<GHContent[]> {
  try {
    return githubFetch(`/repos/${owner}/${repo}/contents/${path}`, token);
  } catch {
    return [];
  }
}

export async function getVulnerabilityAlerts(token: string, owner: string, repo: string): Promise<GHVulnAlert[]> {
  try {
    return githubFetch(`/repos/${owner}/${repo}/vulnerability-alerts`, token);
  } catch {
    return [];
  }
}

export async function getWorkflowRuns(token: string, owner: string, repo: string): Promise<{ workflow_runs: GHWorkflowRun[] }> {
  try {
    return githubFetch(`/repos/${owner}/${repo}/actions/runs?per_page=20`, token);
  } catch {
    return { workflow_runs: [] };
  }
}

// ── Code Analysis ─────────────────────────────────────────────────────────────
export async function analyzeRepo(token: string, owner: string, repo: string): Promise<RepoAnalysis> {
  const [repoData, commits, deployments, branches, contributors] = await Promise.allSettled([
    githubFetch<GHRepo>(`/repos/${owner}/${repo}`, token),
    getRepoCommits(token, owner, repo, 30).catch(() => [] as GHCommit[]),
    getRepoDeployments(token, owner, repo).catch(() => [] as GHDeployment[]),
    getRepoBranches(token, owner, repo).catch(() => [] as { name: string }[]),
    getRepoContributors(token, owner, repo).catch(() => [] as GHContributor[]),
  ]);

  const rd = repoData.status === "fulfilled" ? repoData.value as GHRepo : null;
  const cms = commits.status === "fulfilled" ? commits.value as GHCommit[] : [];
  const deps = deployments.status === "fulfilled" ? deployments.value as GHDeployment[] : [];
  const brs = branches.status === "fulfilled" ? branches.value as { name: string }[] : [];
  const ctrs = contributors.status === "fulfilled" ? contributors.value as GHContributor[] : [];

  // Detect tech stack from repo topics + language
  const language = rd?.language || "Unknown";
  const topics = rd?.topics || [];

  // SEO/Performance checks based on repo structure
  const seoIssues: CodeIssue[] = [];
  const perfIssues: CodeIssue[] = [];
  const securityIssues: CodeIssue[] = [];

  // Check for common SEO issues
  if (!topics.includes("seo")) {
    seoIssues.push({ severity: "info", title: "Topics SEO manquants", desc: "Ajoutez des topics comme 'seo' sur votre dépôt GitHub pour améliorer la découvrabilité.", fix: "Ajoutez des topics sur GitHub > Settings > Topics" });
  }
  if (rd && !rd.description) {
    seoIssues.push({ severity: "warning", title: "Description absente", desc: "Le dépôt n'a pas de description. Les moteurs de recherche et utilisateurs ne sauront pas à quoi sert ce projet.", fix: "Ajoutez une description dans les settings du dépôt" });
  }
  if (rd && !rd.homepage) {
    seoIssues.push({ severity: "info", title: "Pas d'URL de site web", desc: "Ajoutez l'URL du site dans les paramètres du dépôt pour améliorer la visibilité.", fix: "Renseignez l'URL dans GitHub > Settings > Website" });
  }

  // Performance checks
  if (rd && rd.size > 100000) {
    perfIssues.push({ severity: "warning", title: "Dépôt très volumineux", desc: `La taille du dépôt est de ${Math.round(rd.size / 1024)} MB. Les grands dépôts ralentissent les clones et les CI/CD.`, fix: "Utilisez Git LFS pour les fichiers binaires volumineux" });
  }
  const daysInactive = rd ? Math.floor((Date.now() - new Date(rd.pushed_at || rd.updated_at).getTime()) / 86400000) : 0;
  if (daysInactive > 90) {
    perfIssues.push({ severity: "warning", title: `Inactif depuis ${daysInactive} jours`, desc: "Aucun commit récent — vérifiez si le dépôt est maintenu activement.", fix: "Mettez à jour les dépendances et poushez régulièrement" });
  }
  if (brs.length > 30) {
    perfIssues.push({ severity: "info", title: `${brs.length} branches ouvertes`, desc: "Trop de branches peuvent indiquer un manque de nettoyage. Les branches abandonnées compliquent la collaboration.", fix: "Supprimez les branches mergées avec 'git branch --merged | xargs git branch -d'" });
  }

  // Security checks
  if (!rd?.private && rd?.visibility === "public") {
    securityIssues.push({ severity: "info", title: "Dépôt public", desc: "Vérifiez qu'aucune clé API ou secret ne se trouve dans l'historique des commits.", fix: "Utilisez git-secrets ou truffleHog pour scanner l'historique" });
  }
  if (brs.findIndex(b => b.name === "main" || b.name === "master") === -1 && brs.length > 0) {
    securityIssues.push({ severity: "info", title: "Branche principale non standard", desc: "La branche principale n'est pas 'main' ou 'master'.", fix: "Normalisez le nom de la branche principale" });
  }

  // Commit analytics
  const commitsByDay = new Map<string, number>();
  cms.forEach(c => {
    const day = (c.commit?.author?.date || "").slice(0, 10);
    if (day) commitsByDay.set(day, (commitsByDay.get(day) || 0) + 1);
  });

  const commitsByAuthor = new Map<string, number>();
  cms.forEach(c => {
    const author = c.commit?.author?.name || "Unknown";
    commitsByAuthor.set(author, (commitsByAuthor.get(author) || 0) + 1);
  });

  // Health score calculation
  const health = calculateHealthScore({
    hasDescription: !!rd?.description,
    hasTopics: (rd?.topics?.length || 0) > 0,
    hasHomepage: !!rd?.homepage,
    hasRecentCommit: daysInactive < 30,
    hasDocs: false,
    issueCount: rd?.open_issues_count || 0,
    commitFrequency: cms.length,
    hasDeployments: deps.length > 0,
    branchCount: brs.length,
    contributorCount: ctrs.length,
    seoIssueCount: seoIssues.filter(i => i.severity === "error" || i.severity === "warning").length,
    secIssueCount: securityIssues.filter(i => i.severity === "error" || i.severity === "warning").length,
  });

  const analysis: RepoAnalysis = {
    owner,
    repo,
    language,
    topics,
    description: rd?.description || "",
    homepage: rd?.homepage || "",
    size: rd?.size || 0,
    stars: rd?.stargazers_count || 0,
    forks: rd?.forks_count || 0,
    openIssues: rd?.open_issues_count || 0,
    private: rd?.private || false,
    defaultBranch: rd?.default_branch || "main",
    lastCommitAt: rd?.pushed_at || rd?.updated_at || new Date().toISOString(),
    daysInactive,
    health,
    seoIssues,
    perfIssues,
    securityIssues,
    commits: {
      total: cms.length,
      last30Days: cms.length,
      byDay: Object.fromEntries(commitsByDay),
      topAuthors: Array.from(commitsByAuthor.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, count]) => ({ name, count })),
    },
    deployments: deps.slice(0, 10).map(d => ({
      id: d.id,
      env: d.environment || "production",
      ref: d.ref,
      createdAt: d.created_at,
      state: "pending",
    })),
    branches: { total: brs.length, names: brs.slice(0, 20).map(b => b.name) },
    contributors: ctrs.slice(0, 10).map(c => ({ login: c.login, avatarUrl: c.avatar_url, contributions: c.contributions })),
    analyzedAt: new Date().toISOString(),
  };

  // Persist to DB
  await saveAnalysis(owner, repo, analysis).catch(() => {});

  return analysis;
}

function calculateHealthScore(factors: {
  hasDescription: boolean; hasTopics: boolean; hasHomepage: boolean;
  hasRecentCommit: boolean; hasDocs: boolean; issueCount: number;
  commitFrequency: number; hasDeployments: boolean; branchCount: number;
  contributorCount: number; seoIssueCount: number; secIssueCount: number;
}): { score: number; label: string; breakdown: Record<string, number> } {
  const breakdown: Record<string, number> = {
    documentation: (factors.hasDescription ? 15 : 0) + (factors.hasTopics ? 10 : 0) + (factors.hasDocs ? 10 : 0),
    activity: Math.min(25, factors.hasRecentCommit ? 15 + Math.min(10, factors.commitFrequency) : 0),
    deployment: factors.hasDeployments ? 15 : 0,
    collaboration: Math.min(10, factors.contributorCount * 2),
    seo: Math.max(0, 15 - factors.seoIssueCount * 5),
    security: Math.max(0, 10 - factors.secIssueCount * 3),
  };

  const score = Math.min(100, Object.values(breakdown).reduce((a, b) => a + b, 0));
  const label = score >= 80 ? "Excellent" : score >= 60 ? "Bon" : score >= 40 ? "À améliorer" : "Critique";

  return { score, label, breakdown };
}

// ── DB persistence ────────────────────────────────────────────────────────────
export async function saveConnection(orgId: string, userId: number, login: string, name: string, email: string, avatarUrl: string, accessToken: string, scope: string) {
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO github_connections (org_id, github_user_id, login, name, email, avatar_url, access_token, scope, connected_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,now())
       ON CONFLICT (org_id) DO UPDATE SET
         github_user_id=$2, login=$3, name=$4, email=$5, avatar_url=$6,
         access_token=$7, scope=$8, updated_at=now()`,
      [orgId, userId, login, name || login, email || "", avatarUrl || "", accessToken, scope]
    );
  } finally {
    client.release();
  }
}

export async function getConnection(orgId: string): Promise<{ login: string; name: string; access_token: string; scope: string; connected_at: string } | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(`SELECT * FROM github_connections WHERE org_id = $1`, [orgId]);
    return res.rows[0] || null;
  } finally {
    client.release();
  }
}

export async function disconnectGitHub(orgId: string) {
  const client = await pool.connect();
  try {
    await client.query(`DELETE FROM github_connections WHERE org_id = $1`, [orgId]);
  } finally {
    client.release();
  }
}

export async function saveAnalysis(owner: string, repo: string, analysis: RepoAnalysis) {
  const client = await pool.connect();
  try {
    const id = `gha_${owner}_${repo}_${Date.now()}`;
    await client.query(
      `INSERT INTO github_analyses (id, org_id, owner, repo, health_score, issues, analysis, analyzed_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,now())
       ON CONFLICT (org_id, owner, repo) DO UPDATE SET
         health_score=$4, issues=$5, analysis=$6, analyzed_at=now()`,
      [id, ORG_ID, owner, repo, analysis.health.score, JSON.stringify([...analysis.seoIssues, ...analysis.perfIssues, ...analysis.securityIssues]), JSON.stringify(analysis)]
    );
  } finally {
    client.release();
  }
}

export async function getAnalysis(owner: string, repo: string): Promise<RepoAnalysis | null> {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT analysis FROM github_analyses WHERE org_id = $1 AND owner = $2 AND repo = $3 ORDER BY analyzed_at DESC LIMIT 1`,
      [ORG_ID, owner, repo]
    );
    if (!res.rows[0]) return null;
    return JSON.parse(String(res.rows[0].analysis)) as RepoAnalysis;
  } catch {
    return null;
  } finally {
    client.release();
  }
}

// ── Types ──────────────────────────────────────────────────────────────────────
export interface GHRepo {
  id: number; name: string; full_name: string; description: string | null;
  language: string | null; topics: string[]; homepage: string | null;
  size: number; stargazers_count: number; forks_count: number;
  open_issues_count: number; private: boolean; visibility: string;
  default_branch: string; pushed_at: string; updated_at: string;
}
export interface GHCommit {
  sha: string;
  commit: { message: string; author: { name: string; email: string; date: string } };
  author: { login: string; avatar_url: string } | null;
}
export interface GHDeployment {
  id: number; ref: string; environment: string; created_at: string; updated_at: string;
}
export interface GHRelease {
  id: number; tag_name: string; name: string; body: string; created_at: string; draft: boolean; prerelease: boolean;
}
export interface GHContributor {
  login: string; avatar_url: string; contributions: number;
}
export interface GHContent {
  name: string; path: string; type: string; size: number;
}
export interface GHVulnAlert {
  id: number; severity: string; description: string; package_name: string;
}
export interface GHWorkflowRun {
  id: number; name: string; status: string; conclusion: string | null; created_at: string; updated_at: string;
}
export interface CodeIssue {
  severity: "error" | "warning" | "info"; title: string; desc: string; fix: string;
}
export interface RepoAnalysis {
  owner: string; repo: string; language: string; topics: string[];
  description: string; homepage: string; size: number; stars: number;
  forks: number; openIssues: number; private: boolean; defaultBranch: string;
  lastCommitAt: string; daysInactive: number;
  health: { score: number; label: string; breakdown: Record<string, number> };
  seoIssues: CodeIssue[]; perfIssues: CodeIssue[]; securityIssues: CodeIssue[];
  commits: { total: number; last30Days: number; byDay: Record<string, number>; topAuthors: { name: string; count: number }[] };
  deployments: { id: number; env: string; ref: string; createdAt: string; state: string }[];
  branches: { total: number; names: string[] };
  contributors: { login: string; avatarUrl: string; contributions: number }[];
  analyzedAt: string;
}
