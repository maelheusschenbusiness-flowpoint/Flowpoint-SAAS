import { db, revenueLeaksTable, conversionFailuresTable, trafficLossesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { consumeAICredits } from "./ai-engine.js";

interface LeakCandidate {
  leakType: string;
  title: string;
  description: string;
  estimatedMonthlyLoss: number;
  impactScore: number;
  fixDifficultyMin: number;
  quickFix: string;
  page: string;
}

// ── detectRevenueLeaks ──────────────────────────────────────────────────────
// Calculates leaks exclusively from real data signals:
//   1. PageSpeed results  (pagespeed_results table)
//   2. Monitor failures   (monitor_checks table)
//   3. GSC traffic decline (gsc_search_analytics table)
//   4. Behavioral rage clicks (behavior_sessions table)
// NEVER inserts hardcoded/template data. If no real signals → inserts nothing.
export async function detectRevenueLeaks(siteUrl: string): Promise<void> {
  try {
    await consumeAICredits({ feature: "revenue_leak", metadata: { siteUrl } });

    // Skip if leaks were already computed for this site (avoid duplicates)
    const existing = await db.select({ id: revenueLeaksTable.id })
      .from(revenueLeaksTable)
      .where(eq(revenueLeaksTable.siteUrl, siteUrl))
      .limit(1);
    if (existing.length > 0) return;

    const candidates: LeakCandidate[] = [];

    // ── Signal 1: Slow pages from PageSpeed ────────────────────────────────
    try {
      const psi = await pool.query<{
        url: string; strategy: string; performance_score: number; lcp: number;
      }>(
        `SELECT url, strategy, performance_score, lcp
         FROM pagespeed_results
         WHERE org_id = 'default'
           AND created_at > NOW() - INTERVAL '30 days'
           AND performance_score < 50
         ORDER BY performance_score ASC
         LIMIT 5`
      );
      for (const r of psi.rows) {
        const pts = 50 - (r.performance_score ?? 0);
        const lossEst = Math.round(pts * 9);
        const lcpS = r.lcp ? (r.lcp / 1000).toFixed(1) + 's' : 'N/A';
        let pagePath = '/';
        try { pagePath = new URL(r.url.startsWith('http') ? r.url : `https://${r.url}`).pathname; } catch {}
        candidates.push({
          leakType: 'slow_page',
          title: `Page lente — Score ${r.performance_score}/100 (${r.strategy})`,
          description: `${r.url} — Performance ${r.performance_score}/100 (LCP: ${lcpS}). Pages < 50/100 génèrent un taux d'abandon mobile élevé selon Google.`,
          estimatedMonthlyLoss: lossEst,
          impactScore: Math.min(98, 100 - (r.performance_score ?? 0)),
          fixDifficultyMin: 120,
          quickFix: 'Compresser les images (WebP), activer le cache navigateur, différer le JS non critique, activer HTTP/2',
          page: pagePath,
        });
      }
    } catch (err) { logger.debug({ err }, '[RevenueLeak] PSI signal skipped'); }

    // ── Signal 2: Monitor failures ──────────────────────────────────────────
    try {
      const failures = await pool.query<{
        monitor_url: string; fail_count: string; total_count: string;
      }>(
        `SELECT m.url AS monitor_url,
                COUNT(*) FILTER (WHERE mc.ok = false) AS fail_count,
                COUNT(*) AS total_count
         FROM monitor_checks mc
         JOIN monitors m ON m.id = mc.monitor_id
         WHERE mc.checked_at > (EXTRACT(EPOCH FROM (NOW() - INTERVAL '30 days')) * 1000)::bigint
         GROUP BY m.url
         HAVING COUNT(*) FILTER (WHERE mc.ok = false) > 5
            AND COUNT(*) > 10
         ORDER BY COUNT(*) FILTER (WHERE mc.ok = false) DESC
         LIMIT 3`
      );
      for (const f of failures.rows) {
        const failCount = Number(f.fail_count);
        const total = Number(f.total_count);
        const uptimePct = Math.round((1 - failCount / total) * 1000) / 10;
        const downtimeMin = Math.round((failCount / total) * 43200);
        const lossEst = Math.round(downtimeMin * 0.8);
        if (lossEst > 0) {
          candidates.push({
            leakType: 'downtime',
            title: `Disponibilité ${uptimePct}% — ${failCount} interruptions ce mois`,
            description: `${f.monitor_url} — Uptime ${uptimePct}% sur 30 jours (~${downtimeMin} min d'indisponibilité). Chaque minute hors ligne impacte directement les conversions.`,
            estimatedMonthlyLoss: lossEst,
            impactScore: Math.min(95, Math.round(100 - uptimePct + 10)),
            fixDifficultyMin: 60,
            quickFix: 'Configurer un CDN (Cloudflare), mettre en place un healthcheck applicatif, auto-restart service',
            page: '/',
          });
        }
      }
    } catch (err) { logger.debug({ err }, '[RevenueLeak] Monitor signal skipped'); }

    // ── Signal 3: GSC traffic decline ───────────────────────────────────────
    try {
      const gsc = await pool.query<{
        page: string; clicks_recent: string; clicks_prev: string;
      }>(
        `SELECT page,
                SUM(CASE WHEN date >= CURRENT_DATE - 30 THEN clicks ELSE 0 END)::text AS clicks_recent,
                SUM(CASE WHEN date >= CURRENT_DATE - 60 AND date < CURRENT_DATE - 30 THEN clicks ELSE 0 END)::text AS clicks_prev
         FROM gsc_search_analytics
         WHERE org_id = 'default'
           AND date >= CURRENT_DATE - 60
           AND page IS NOT NULL
         GROUP BY page
         HAVING SUM(CASE WHEN date >= CURRENT_DATE - 60 AND date < CURRENT_DATE - 30 THEN clicks ELSE 0 END) > 20
            AND SUM(CASE WHEN date >= CURRENT_DATE - 30 THEN clicks ELSE 0 END) <
                SUM(CASE WHEN date >= CURRENT_DATE - 60 AND date < CURRENT_DATE - 30 THEN clicks ELSE 0 END) * 0.7
         ORDER BY (SUM(CASE WHEN date >= CURRENT_DATE - 60 AND date < CURRENT_DATE - 30 THEN clicks ELSE 0 END) -
                   SUM(CASE WHEN date >= CURRENT_DATE - 30 THEN clicks ELSE 0 END)) DESC
         LIMIT 3`
      );
      for (const g of gsc.rows) {
        const recent = Number(g.clicks_recent);
        const prev = Number(g.clicks_prev);
        const lostClicks = prev - recent;
        const dropPct = Math.round((1 - recent / prev) * 100);
        const lossEst = Math.round(lostClicks * 1.5);
        if (lossEst > 15) {
          candidates.push({
            leakType: 'traffic_loss',
            title: `Baisse SEO −${dropPct}% — ${lostClicks} clics perdus`,
            description: `${g.page} — Perte de ${lostClicks} clics organiques vs mois précédent (−${dropPct}%). Revenus organiques directement impactés.`,
            estimatedMonthlyLoss: lossEst,
            impactScore: Math.min(90, 40 + Math.round(dropPct / 2)),
            fixDifficultyMin: 90,
            quickFix: 'Rafraîchir le contenu, vérifier les backlinks perdus, analyser les Core Web Vitals, soumettre en ré-indexation',
            page: g.page,
          });
        }
      }
    } catch (err) { logger.debug({ err }, '[RevenueLeak] GSC signal skipped'); }

    // ── Signal 4: Rage clicks (behavioral_sessions) ─────────────────────────
    try {
      const rage = await pool.query<{ exit_page: string; total_rage: string }>(
        `SELECT exit_page, SUM(rage_clicks)::text AS total_rage
         FROM behavior_sessions
         WHERE site_url = $1
           AND started_at > NOW() - INTERVAL '30 days'
           AND rage_clicks > 0
           AND exit_page IS NOT NULL
         GROUP BY exit_page
         HAVING SUM(rage_clicks) > 3
         ORDER BY SUM(rage_clicks) DESC
         LIMIT 3`,
        [siteUrl]
      );
      for (const r of rage.rows) {
        const total = Number(r.total_rage);
        candidates.push({
          leakType: 'dead_cta',
          title: `${total} rage clicks — friction utilisateur détectée`,
          description: `${r.exit_page} — ${total} rage clicks ce mois. Fort indicateur de CTA non fonctionnel, réponse lente, ou bug interface frustrant les visiteurs.`,
          estimatedMonthlyLoss: Math.round(total * 4),
          impactScore: Math.min(88, 55 + Math.round(total / 2)),
          fixDifficultyMin: 30,
          quickFix: 'Vérifier le CTA ciblé, tester la réactivité sur mobile, analyser les heatmaps sur cette page',
          page: r.exit_page,
        });
      }
    } catch (err) { logger.debug({ err }, '[RevenueLeak] Behavioral signal skipped'); }

    // ── Insert only real candidates ────────────────────────────────────────
    if (candidates.length === 0) {
      logger.info({ siteUrl }, '[RevenueLeak] No real signals found — nothing inserted');
      return;
    }

    for (const c of candidates) {
      const safeId = siteUrl.replace(/[^a-z0-9]/gi, '_').slice(0, 30);
      const id = `rl_${safeId}_${c.leakType}_${Date.now()}`.slice(0, 80);
      await db.insert(revenueLeaksTable).values({
        id,
        siteUrl,
        page: c.page,
        leakType: c.leakType,
        title: c.title,
        description: c.description,
        estimatedMonthlyLoss: c.estimatedMonthlyLoss,
        impactScore: c.impactScore,
        fixDifficultyMin: c.fixDifficultyMin,
        quickFix: c.quickFix,
        status: 'open',
        metadata: { source: 'real_signals', confidence: 0.80 },
      }).onConflictDoNothing();
    }

    logger.info({ siteUrl, count: candidates.length }, '[RevenueLeak] Leaks inserted from real signals');
  } catch (err) {
    logger.error({ err }, '[RevenueLeak] Detection failed');
  }
}

// ── getRevenueLeakData ──────────────────────────────────────────────────────
export async function getRevenueLeakData(siteUrl?: string): Promise<{
  leaks: Array<typeof revenueLeaksTable.$inferSelect>;
  failures: Array<typeof conversionFailuresTable.$inferSelect>;
  trafficLosses: Array<typeof trafficLossesTable.$inferSelect>;
  summary: { totalMonthlyLoss: number; criticalLeaks: number; quickWins: number; potentialRecovery: number };
  isEmpty: boolean;
  emptyReason?: string;
}> {
  const [leaks, failures, losses] = await Promise.all([
    siteUrl
      ? db.select().from(revenueLeaksTable).where(eq(revenueLeaksTable.siteUrl, siteUrl)).orderBy(desc(revenueLeaksTable.impactScore)).limit(20)
      : db.select().from(revenueLeaksTable).orderBy(desc(revenueLeaksTable.impactScore)).limit(20),
    siteUrl
      ? db.select().from(conversionFailuresTable).where(eq(conversionFailuresTable.siteUrl, siteUrl)).limit(10)
      : db.select().from(conversionFailuresTable).limit(10),
    siteUrl
      ? db.select().from(trafficLossesTable).where(eq(trafficLossesTable.siteUrl, siteUrl)).limit(10)
      : db.select().from(trafficLossesTable).limit(10),
  ]);

  const totalMonthlyLoss = leaks.reduce((s, l) => s + (l.estimatedMonthlyLoss ?? 0), 0);
  const criticalLeaks    = leaks.filter(l => (l.impactScore ?? 0) >= 85).length;
  const quickWins        = leaks.filter(l => (l.fixDifficultyMin ?? 0) <= 60).length;
  const potentialRecovery = Math.round(totalMonthlyLoss * 0.65);

  const isEmpty = leaks.length === 0 && failures.length === 0 && losses.length === 0;
  const emptyReason = isEmpty
    ? "Aucune fuite de revenus détectée pour le moment — connectez GA4, PageSpeed et Behavioral Analytics pour activer la détection automatique."
    : undefined;

  return { leaks, failures, trafficLosses: losses, summary: { totalMonthlyLoss, criticalLeaks, quickWins, potentialRecovery }, isEmpty, emptyReason };
}
