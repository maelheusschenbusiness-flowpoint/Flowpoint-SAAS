/**
 * PostgreSQL-backed session store with in-memory LRU cache.
 *
 * Tokens are NEVER stored in plain text — only a SHA-256 hash is persisted.
 * Sessions survive server restarts. Expired sessions are cleaned up on a
 * background interval and lazily on every read.
 */

import crypto from "crypto";
import { logger } from "../lib/logger.js";
import { pool } from "@workspace/db";

export const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

export interface Session {
  token:     string;
  userId:    string;
  email:     string;
  orgId:     string;
  role:      string;
  createdAt: number;
  expiresAt: number;
}

// ── In-memory cache (avoids DB round-trip on every request) ──────────────────
const cache = new Map<string, Session>();
const MAX_CACHE = 2000;

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

function evictOldest(): void {
  if (cache.size < MAX_CACHE) return;
  const oldest = [...cache.entries()]
    .sort((a, b) => a[1].createdAt - b[1].createdAt)
    .slice(0, 200);
  for (const [k] of oldest) cache.delete(k);
}

// ── DB helpers ────────────────────────────────────────────────────────────────
async function dbGet(tokenHash: string): Promise<Session | null> {
  try {
    const client = await pool.connect();
    try {
      const { rows } = await client.query<{
        id: string; token_hash: string; user_id: string; email: string;
        org_id: string; role: string; expires_at: string; created_at: string; last_seen_at: string;
      }>(
        `SELECT * FROM sessions WHERE token_hash = $1 AND expires_at > $2 LIMIT 1`,
        [tokenHash, Date.now()]
      );
      if (!rows[0]) return null;
      const r = rows[0];
      return {
        token:     "",
        userId:    r.user_id,
        email:     r.email,
        orgId:     r.org_id,
        role:      r.role,
        createdAt: Number(r.created_at),
        expiresAt: Number(r.expires_at),
      };
    } finally {
      client.release();
    }
  } catch (err) {
    logger.warn({ err }, "[Sessions] DB read failed — falling back to cache only");
    return null;
  }
}

async function dbCreate(id: string, tokenHash: string, s: Session, userAgent?: string, ipHash?: string): Promise<void> {
  try {
    const client = await pool.connect();
    try {
      await client.query(
        `INSERT INTO sessions
           (id, token_hash, user_id, email, org_id, role, expires_at, created_at, last_seen_at, user_agent, ip_hash)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
         ON CONFLICT (token_hash) DO NOTHING`,
        [id, tokenHash, s.userId, s.email, s.orgId, s.role,
         s.expiresAt, s.createdAt, s.createdAt, userAgent ?? null, ipHash ?? null]
      );
    } finally {
      client.release();
    }
  } catch (err) {
    logger.warn({ err }, "[Sessions] DB write failed — session exists only in memory");
  }
}

async function dbDelete(tokenHash: string): Promise<void> {
  try {
    const client = await pool.connect();
    try {
      await client.query(`DELETE FROM sessions WHERE token_hash = $1`, [tokenHash]);
    } finally {
      client.release();
    }
  } catch (err) {
    logger.warn({ err }, "[Sessions] DB delete failed");
  }
}

async function dbTouch(tokenHash: string, now: number): Promise<void> {
  try {
    const client = await pool.connect();
    try {
      await client.query(
        `UPDATE sessions SET last_seen_at = $1 WHERE token_hash = $2`,
        [now, tokenHash]
      );
    } finally {
      client.release();
    }
  } catch {
    // non-fatal
  }
}

// ── Public API ────────────────────────────────────────────────────────────────
export function createSession(
  opts: { email: string; role?: string },
  meta?: { userAgent?: string; ip?: string }
): string {
  const token = crypto.randomBytes(32).toString("hex");
  const tokenHash = hashToken(token);
  const id = `sess_${Date.now()}_${crypto.randomBytes(6).toString("hex")}`;
  const now = Date.now();

  const ipHash = meta?.ip
    ? crypto.createHash("sha256").update(meta.ip).digest("hex").slice(0, 16)
    : undefined;

  const session: Session = {
    token,
    userId:    opts.email,
    email:     opts.email,
    orgId:     "default",
    role:      opts.role ?? "viewer",
    createdAt: now,
    expiresAt: now + SESSION_TTL_MS,
  };

  evictOldest();
  cache.set(token, session);

  // Persist to DB async (non-blocking)
  dbCreate(id, tokenHash, session, meta?.userAgent, ipHash).catch(() => {});

  return token;
}

export async function getSession(token: string): Promise<Session | null>;
export function getSession(token: string, sync: true): Session | null;
export function getSession(token: string, sync?: true): Session | null | Promise<Session | null> {
  if (sync === true) {
    // Sync path — cache only (used by middleware on hot path)
    const s = cache.get(token);
    if (!s) return null;
    if (s.expiresAt < Date.now()) { cache.delete(token); return null; }
    return s;
  }

  // Async path — check cache first, fall back to DB
  const cached = cache.get(token);
  if (cached) {
    if (cached.expiresAt < Date.now()) {
      cache.delete(token);
      const tokenHash = hashToken(token);
      dbDelete(tokenHash).catch(() => {});
      return Promise.resolve(null);
    }
    return Promise.resolve(cached);
  }

  // Not in cache — try DB
  const tokenHash = hashToken(token);
  return dbGet(tokenHash).then(s => {
    if (!s) return null;
    s.token = token; // re-attach raw token for cache
    cache.set(token, s);
    dbTouch(tokenHash, Date.now()).catch(() => {});
    return s;
  });
}

export function deleteSession(token: string): void {
  cache.delete(token);
  const tokenHash = hashToken(token);
  dbDelete(tokenHash).catch(() => {});
}

export function cleanExpiredSessions(): void {
  const now = Date.now();
  for (const [token, s] of cache) {
    if (s.expiresAt < now) cache.delete(token);
  }
  // DB cleanup (async, best-effort)
  pool.query(`DELETE FROM sessions WHERE expires_at < $1`, [now]).catch(() => {});
}

// ── Ensure sessions table exists (called at startup) ─────────────────────────
export async function ensureSessionsTable(): Promise<void> {
  try {
    const client = await pool.connect();
    try {
      await client.query(`
        CREATE TABLE IF NOT EXISTS sessions (
          id           VARCHAR(64) PRIMARY KEY,
          token_hash   VARCHAR(64) NOT NULL UNIQUE,
          user_id      TEXT NOT NULL,
          email        TEXT NOT NULL,
          org_id       TEXT NOT NULL DEFAULT 'default',
          role         TEXT NOT NULL DEFAULT 'viewer',
          expires_at   BIGINT NOT NULL,
          created_at   BIGINT NOT NULL,
          last_seen_at BIGINT NOT NULL,
          user_agent   TEXT,
          ip_hash      VARCHAR(64)
        )
      `);
      await client.query(`CREATE INDEX IF NOT EXISTS sessions_token_hash_idx ON sessions(token_hash)`);
      await client.query(`CREATE INDEX IF NOT EXISTS sessions_user_id_idx ON sessions(user_id)`);
      await client.query(`CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON sessions(expires_at)`);
      logger.info("[Sessions] Sessions table ready");
    } finally {
      client.release();
    }
  } catch (err) {
    logger.warn({ err }, "[Sessions] Could not ensure sessions table — using memory-only fallback");
  }
}

// ── Background cleanup every 10 minutes ──────────────────────────────────────
setInterval(cleanExpiredSessions, 10 * 60 * 1000);
