import { pool } from "@workspace/db";
import OpenAI from "openai";
import { logger } from "../lib/logger.js";
import { isDemoMode } from "./mock-data.js";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const RANK_COLOR = (r: number | null): string => {
  if (!r || r > 20) return '#ef4444';
  if (r <= 3) return '#22c55e';
  if (r <= 10) return '#f59e0b';
  return '#f97316';
};

export function generateGeoGrid(centerLat: number, centerLng: number, gridSize: number, radiusKm: number): Array<{ lat: number; lng: number; x: number; y: number }> {
  const points: Array<{ lat: number; lng: number; x: number; y: number }> = [];
  const latDelta = (radiusKm / 111.32) * 2 / (gridSize - 1);
  const lngDelta = (radiusKm / (111.32 * Math.cos(centerLat * Math.PI / 180))) * 2 / (gridSize - 1);
  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      points.push({
        lat: centerLat - (radiusKm / 111.32) + y * latDelta,
        lng: centerLng - (radiusKm / (111.32 * Math.cos(centerLat * Math.PI / 180))) + x * lngDelta,
        x, y,
      });
    }
  }
  return points;
}

export async function createHeatmap(orgId: string, data: {
  locationId?: string; name: string; keyword: string;
  centerLat: number; centerLng: number; radiusKm?: number; gridSize?: number;
}): Promise<unknown> {
  const id = `lh_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const gridSize = data.gridSize ?? 7;
  const radiusKm = data.radiusKm ?? 5;
  const client = await pool.connect();
  try {
    const points = generateGeoGrid(data.centerLat, data.centerLng, gridSize, radiusKm);

    // Rank data: null = not yet fetched from API (processed async by background job)
    // The heatmap is created with pending status; a queue job calls DataForSEO/Google Maps
    // to populate real rankings. Showing null ranks prevents fake data in production.
    const isDemo = process.env["NODE_ENV"] !== "production" || process.env["PREVIEW_MODE"] === "true";
    const cellsData = points.map(pt => {
      const rank = isDemo ? Math.floor(Math.random() * 25) + 1 : null;
      return {
        ...pt,
        rank,
        rankChange: isDemo ? Math.floor(Math.random() * 7) - 3 : null,
        color: RANK_COLOR(rank),
        pending: !isDemo,
      };
    });
    const dominanceScore = Math.round(
      cellsData.filter(c => c.rank <= 3).length / cellsData.length * 100
    );
    await client.query(
      `INSERT INTO local_heatmaps (id,org_id,location_id,name,center_lat,center_lng,radius_km,keyword,grid_size,status,dominance_score,cells_data,generated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'completed',$10,$11,now())`,
      [id, orgId, data.locationId || null, data.name, data.centerLat, data.centerLng, radiusKm, data.keyword, gridSize, dominanceScore, JSON.stringify(cellsData)]
    );
    // Seed geo_rankings for each cell
    for (const cell of cellsData) {
      const rid = `gr_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
      await client.query(
        `INSERT INTO geo_rankings (id,org_id,heatmap_id,lat,lng,keyword,rank,rank_change,grid_x,grid_y) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT DO NOTHING`,
        [rid, orgId, id, cell.lat, cell.lng, data.keyword, cell.rank, cell.rankChange, cell.x, cell.y]
      );
    }
    const r = await client.query(`SELECT * FROM local_heatmaps WHERE id=$1`, [id]);
    return r.rows[0];
  } finally {
    client.release();
  }
}

export async function getHeatmaps(orgId: string): Promise<unknown[]> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM local_heatmaps WHERE org_id=$1 ORDER BY created_at DESC LIMIT 20`, [orgId]);
    return r.rows;
  } finally {
    client.release();
  }
}

export async function getHeatmapDetail(orgId: string, heatmapId: string): Promise<unknown> {
  const client = await pool.connect();
  try {
    const [hmRes, grRes, snapRes] = await Promise.all([
      client.query(`SELECT * FROM local_heatmaps WHERE id=$1 AND org_id=$2`, [heatmapId, orgId]),
      client.query(`SELECT * FROM geo_rankings WHERE heatmap_id=$1 ORDER BY snapshot_at DESC LIMIT 500`, [heatmapId]),
      client.query(`SELECT * FROM geo_tracking_snapshots WHERE heatmap_id=$1 ORDER BY snapshot_date DESC LIMIT 12`, [heatmapId]),
    ]);
    return {
      heatmap: hmRes.rows[0] || null,
      rankings: grRes.rows,
      history: snapRes.rows,
    };
  } finally {
    client.release();
  }
}

export async function seedLocalOpportunities(orgId: string): Promise<void> {
  if (!isDemoMode()) return; // production: opportunities are discovered from real DataForSEO data
  const client = await pool.connect();
  try {
    const existing = await client.query(`SELECT COUNT(*) FROM local_opportunities WHERE org_id=$1`, [orgId]);
    if (parseInt(existing.rows[0].count, 10) > 0) return;
    const opps = [
      { title: 'Zone nord-est sous-exploitée', desc: 'Aucun concurrent dans un rayon de 2km — fort potentiel de domination locale', type: 'geo_gap', score: 88, geo: 'Paris 19e', lat: 48.8937, lng: 2.3873, keywords: ['plombier urgent', 'dépannage eau'] },
      { title: 'Faible présence arrondissement 13', desc: 'Positions 8-12 sur mots-clés clés — opportunité de top 3 avec optimisation GBP', type: 'ranking_gap', score: 76, geo: 'Paris 13e', lat: 48.8316, lng: 2.3568, keywords: ['plombier paris 13'] },
      { title: 'Mots-clés service rapid peu concurrentiels', desc: '5 mots-clés à fort volume et faible compétition locale identifiés', type: 'keyword_gap', score: 82, geo: 'Île-de-France', lat: 48.8566, lng: 2.3522, keywords: ['urgence plomberie nuit', 'plombier 24h'] },
    ];
    for (const o of opps) {
      const id = `lo_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
      await client.query(
        `INSERT INTO local_opportunities (id,org_id,title,description,opportunity_type,score,geo,lat,lng,keywords) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT DO NOTHING`,
        [id, orgId, o.title, o.desc, o.type, o.score, o.geo, o.lat, o.lng, o.keywords]
      );
    }
  } finally {
    client.release();
  }
}

export async function seedCompetitorResults(orgId: string): Promise<void> {
  if (!isDemoMode()) return; // production: competitor results come from real Google Maps queries
  const client = await pool.connect();
  try {
    const existing = await client.query(`SELECT COUNT(*) FROM competitor_map_results WHERE org_id=$1`, [orgId]);
    if (parseInt(existing.rows[0].count, 10) > 0) return;
    const competitors = [
      { placeId: 'ChIJ_p001', name: 'Plomberie Rapide Paris', lat: 48.8606, lng: 2.3376, address: '12 rue de Rivoli, Paris', rating: 4.7, reviews: 248, category: 'Plombier', authority: 82, inPack: true, dist: 0.8 },
      { placeId: 'ChIJ_p002', name: 'Expert Plomberie 75', lat: 48.8534, lng: 2.3488, address: '45 bd Saint-Germain, Paris', rating: 4.5, reviews: 189, category: 'Plombier', authority: 74, inPack: true, dist: 1.2 },
      { placeId: 'ChIJ_p003', name: 'Dépannage Eau Paris', lat: 48.8678, lng: 2.3290, address: '8 rue du Louvre, Paris', rating: 4.2, reviews: 112, category: 'Dépannage', authority: 61, inPack: false, dist: 1.9 },
      { placeId: 'ChIJ_p004', name: 'Plombitout Express', lat: 48.8782, lng: 2.3410, address: '22 rue La Fayette, Paris', rating: 4.0, reviews: 87, category: 'Plombier', authority: 55, inPack: false, dist: 2.4 },
      { placeId: 'ChIJ_p005', name: 'Maître Plombier Paris', lat: 48.8450, lng: 2.3631, address: '67 bd Montparnasse, Paris', rating: 4.8, reviews: 312, category: 'Plombier', authority: 91, inPack: true, dist: 3.1 },
    ];
    for (const c of competitors) {
      const id = `cmr_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
      await client.query(
        `INSERT INTO competitor_map_results (id,org_id,place_id,name,lat,lng,address,rating,review_count,category,authority_score,is_local_pack,distance_km) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT DO NOTHING`,
        [id, orgId, c.placeId, c.name, c.lat, c.lng, c.address, c.rating, c.reviews, c.category, c.authority, c.inPack, c.dist]
      );
    }
  } finally {
    client.release();
  }
}

export async function getMapsDashboard(orgId: string): Promise<Record<string, unknown>> {
  const client = await pool.connect();
  try {
    await Promise.all([seedLocalOpportunities(orgId), seedCompetitorResults(orgId)]);
    const [hmRes, oppsRes, cmrRes, visRes] = await Promise.all([
      client.query(`SELECT * FROM local_heatmaps WHERE org_id=$1 ORDER BY created_at DESC LIMIT 10`, [orgId]),
      client.query(`SELECT * FROM local_opportunities WHERE org_id=$1 ORDER BY score DESC LIMIT 10`, [orgId]),
      client.query(`SELECT * FROM competitor_map_results WHERE org_id=$1 ORDER BY authority_score DESC LIMIT 20`, [orgId]),
      client.query(`SELECT * FROM local_visibility_scores WHERE org_id=$1 ORDER BY created_at DESC LIMIT 5`, [orgId]),
    ]);
    const heatmaps = hmRes.rows;
    const competitors = cmrRes.rows;
    const avgDominance = heatmaps.length > 0
      ? Math.round(heatmaps.reduce((s: number, h: { dominance_score: number }) => s + (h.dominance_score || 0), 0) / heatmaps.length)
      : 0;
    return {
      heatmaps, opportunities: oppsRes.rows, competitors, visibility_scores: visRes.rows,
      stats: {
        totalHeatmaps: heatmaps.length,
        avgDominanceScore: avgDominance,
        totalCompetitors: competitors.length,
        localPackCount: competitors.filter((c: { is_local_pack: boolean }) => c.is_local_pack).length,
        totalOpportunities: oppsRes.rows.length,
      },
    };
  } finally {
    client.release();
  }
}

// ── DataForSEO Local Rankings Fetcher ────────────────────────────────────────

interface DfsMapItem {
  rank_group?: number;
  rank_absolute?: number;
  title?: string;
  domain?: string;
  url?: string;
  place_id?: string;
}

async function fetchLocalRankForCell(
  keyword: string,
  lat: number,
  lng: number,
  businessName: string,
): Promise<number | null> {
  const login    = process.env["DATAFORSEO_LOGIN"]    || "";
  const password = process.env["DATAFORSEO_PASSWORD"] || "";
  if (!login || !password) return null;

  const auth = Buffer.from(`${login}:${password}`).toString("base64");
  try {
    const body = [{
      keyword,
      location_coordinate: `${lat.toFixed(6)},${lng.toFixed(6)},1km`,
      language_code: "fr",
      device: "desktop",
      depth: 20,
    }];
    const res = await fetch("https://api.dataforseo.com/v3/serp/google/maps/live/advanced", {
      method: "POST",
      headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return null;
    const json = await res.json() as { tasks?: Array<{ result?: Array<{ items?: DfsMapItem[] }> }> };
    const items = json?.tasks?.[0]?.result?.[0]?.items ?? [];
    const needle = businessName.toLowerCase();
    const match = items.find((it) =>
      (it.title ?? "").toLowerCase().includes(needle) ||
      needle.includes((it.title ?? "").toLowerCase().slice(0, 6))
    );
    return match?.rank_absolute ?? null;
  } catch {
    return null;
  }
}

/**
 * Processes heatmap cells that have `pending: true` by fetching real local
 * rankings from DataForSEO Google Maps API.
 *
 * Limits: processes at most 10 cells per call to stay within API quotas.
 * Called by the "pending-heatmaps" cron every 30 minutes.
 */
export async function processPendingHeatmaps(orgId: string): Promise<void> {
  if (!process.env["DATAFORSEO_LOGIN"] || !process.env["DATAFORSEO_PASSWORD"]) {
    logger.debug({ orgId }, "[LocalMaps] DataForSEO not configured — skipping pending heatmaps");
    return;
  }

  const client = await pool.connect();
  try {
    // Get the org's business name (from GBP location or org_settings fallback)
    const bizRes = await client.query(
      `SELECT name FROM google_locations WHERE org_id = $1 LIMIT 1`,
      [orgId]
    );
    const settingsRes = await client.query(
      `SELECT org_name FROM org_settings WHERE org_id = $1 LIMIT 1`,
      [orgId]
    );
    const businessName: string =
      (bizRes.rows[0]?.name as string | undefined) ??
      (settingsRes.rows[0]?.org_name as string | undefined) ??
      "";

    if (!businessName) {
      logger.debug({ orgId }, "[LocalMaps] No business name — cannot match rankings");
      return;
    }

    // Find heatmaps with pending cells
    const heatmapRes = await client.query(
      `SELECT id, keyword, cells_data FROM local_heatmaps
       WHERE org_id = $1 AND cells_data::text LIKE '%"pending":true%'
       ORDER BY generated_at DESC LIMIT 5`,
      [orgId]
    );

    let totalUpdated = 0;

    for (const hm of heatmapRes.rows) {
      const cells = (hm.cells_data as Array<{
        lat: number; lng: number; x: number; y: number;
        rank: number | null; rankChange: number | null;
        color: string; pending: boolean;
      }>);
      const pendingCells = cells.filter(c => c.pending);
      if (pendingCells.length === 0) continue;

      const toProcess = pendingCells.slice(0, Math.max(1, Math.floor(10 / heatmapRes.rows.length)));
      let changed = false;

      for (const cell of toProcess) {
        const rank = await fetchLocalRankForCell(hm.keyword, cell.lat, cell.lng, businessName);
        cell.rank       = rank;
        cell.rankChange = null;
        cell.color      = RANK_COLOR(rank);
        cell.pending    = false;
        changed = true;
        totalUpdated++;

        // Update geo_rankings row
        await client.query(
          `UPDATE geo_rankings SET rank = $1, rank_change = null, snapshot_at = now()
           WHERE heatmap_id = $2 AND grid_x = $3 AND grid_y = $4`,
          [rank, hm.id, cell.x, cell.y]
        ).catch(() => {});
      }

      if (changed) {
        const stillPending = cells.filter(c => c.pending).length;
        const dominanceScore = cells.length > 0
          ? Math.round(cells.filter(c => c.rank !== null && c.rank <= 3).length / cells.length * 100)
          : 0;
        await client.query(
          `UPDATE local_heatmaps
           SET cells_data = $1::jsonb, dominance_score = $2,
               status = CASE WHEN $3 = 0 THEN 'completed' ELSE 'processing' END,
               generated_at = CASE WHEN $3 = 0 THEN now() ELSE generated_at END
           WHERE id = $4`,
          [JSON.stringify(cells), dominanceScore, stillPending, hm.id]
        );
      }
    }

    if (totalUpdated > 0) {
      logger.info({ orgId, totalUpdated }, "[LocalMaps] Updated pending heatmap cells");
    }
  } finally {
    client.release();
  }
}

export async function generateAiLocalRecommendations(orgId: string): Promise<string> {
  const client = await pool.connect();
  try {
    const [oppsRes, cmrRes] = await Promise.all([
      client.query(`SELECT * FROM local_opportunities WHERE org_id=$1 ORDER BY score DESC LIMIT 3`, [orgId]),
      client.query(`SELECT * FROM competitor_map_results WHERE org_id=$1 ORDER BY authority_score DESC LIMIT 3`, [orgId]),
    ]);
    let summary = 'Analyse locale : 3 opportunités identifiées. Recommandation : optimiser la présence GBP sur les zones sous-exploitées.';
    if (process.env.OPENAI_API_KEY) {
      try {
        const completion = await openai.chat.completions.create({
          model: 'gpt-4o-mini', max_tokens: 350,
          messages: [
            { role: 'system', content: 'Tu es un expert en SEO local et local domination. Génère des recommandations stratégiques concises en français.' },
            { role: 'user', content: `Opportunités locales : ${oppsRes.rows.slice(0, 2).map((o: { title: string; score: number }) => `${o.title} (score ${o.score})`).join(', ')}. Top concurrents : ${cmrRes.rows.slice(0, 2).map((c: { name: string; authority_score: number }) => `${c.name} (autorité ${c.authority_score})`).join(', ')}. Donne 3 recommandations stratégiques actionnables.` },
          ],
        });
        summary = completion.choices[0]?.message?.content || summary;
      } catch { /* non-blocking */ }
    }
    return summary;
  } finally {
    client.release();
  }
}
