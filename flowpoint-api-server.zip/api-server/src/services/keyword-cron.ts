import { runDailyRankingSync } from "./keyword-engine.js";
import { logger } from "../lib/logger.js";

function scheduleAt(hour: number, minute: number, task: () => Promise<void>, label: string): void {
  function msUntilNext(): number {
    const now = new Date();
    const next = new Date(now);
    next.setUTCHours(hour, minute, 0, 0);
    if (next <= now) next.setUTCDate(next.getUTCDate() + 1);
    return next.getTime() - now.getTime();
  }

  function schedule(): void {
    const delay = msUntilNext();
    setTimeout(async () => {
      logger.info(`[KWCron] Running ${label}`);
      try { await task(); } catch (err) { logger.error({ err }, `[KWCron] ${label} failed`); }
      schedule();
    }, delay);
    logger.info({ nextInMs: delay, nextAt: new Date(Date.now() + delay).toISOString() }, `[KWCron] ${label} scheduled`);
  }

  schedule();
}

export function startKeywordCron(): void {
  // Daily ranking sync at 04:00 UTC
  scheduleAt(4, 0, runDailyRankingSync, "daily-ranking-sync");
  logger.info("[KWCron] Keyword cron started");
}
