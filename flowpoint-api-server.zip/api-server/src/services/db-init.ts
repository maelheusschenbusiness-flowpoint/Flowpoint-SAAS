import { db, pool, monitorsTable, auditsTable, reportsTable, teamMembersTable, downtimeIncidentsTable, auditSchedulesTable, activityEventsTable, automationWorkflowsTable, orgAddonsTable } from "@workspace/db";

import { eq } from "drizzle-orm";
import { MOCK_AUDITS, MOCK_MONITORS, MOCK_REPORTS, MOCK_TEAM, isDemoMode } from "./mock-data.js";
import { logger } from "../lib/logger.js";

async function runMigrations(): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`
      ALTER TABLE monitors ADD COLUMN IF NOT EXISTS alert_phone text DEFAULT '';
      ALTER TABLE monitors ADD COLUMN IF NOT EXISTS is_critical boolean DEFAULT false;
      ALTER TABLE audits ADD COLUMN IF NOT EXISTS origin text DEFAULT 'manual';
      ALTER TABLE keywords ADD COLUMN IF NOT EXISTS intent text;
      CREATE TABLE IF NOT EXISTS audit_schedules (
        id text PRIMARY KEY,
        url text NOT NULL,
        frequency text NOT NULL DEFAULT 'weekly',
        next_run bigint NOT NULL,
        last_run bigint,
        created_at bigint NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_audits_url_date ON audits(url, date);
      CREATE TABLE IF NOT EXISTS alert_rules (
        id text PRIMARY KEY,
        name text NOT NULL,
        type text NOT NULL,
        operator text NOT NULL,
        threshold real NOT NULL,
        duration_min integer NOT NULL DEFAULT 0,
        channels text NOT NULL DEFAULT '["email"]',
        site_urls text NOT NULL DEFAULT '[]',
        enabled boolean NOT NULL DEFAULT true,
        created_at timestamptz DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS activity_events (
        id text PRIMARY KEY,
        user_id text NOT NULL DEFAULT 'mael',
        user_name text NOT NULL DEFAULT 'Maël H.',
        type text NOT NULL,
        label text NOT NULL,
        target_id text,
        target_type text,
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_activity_events_created_at ON activity_events(created_at DESC);
      CREATE TABLE IF NOT EXISTS monitor_checks (
        id text PRIMARY KEY,
        monitor_id text NOT NULL,
        checked_at bigint NOT NULL,
        ok boolean NOT NULL,
        latency real NOT NULL DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS idx_monitor_checks_monitor_id ON monitor_checks(monitor_id, checked_at DESC);
      ALTER TABLE reports ADD COLUMN IF NOT EXISTS meeting_notes_json text DEFAULT '[]';
      ALTER TABLE reports ADD COLUMN IF NOT EXISTS date_start text DEFAULT '';
      ALTER TABLE reports ADD COLUMN IF NOT EXISTS date_end text DEFAULT '';
      ALTER TABLE share_tokens ADD COLUMN IF NOT EXISTS meeting_notes_json text DEFAULT '[]';
      CREATE TABLE IF NOT EXISTS activity_events_archive (
        id text PRIMARY KEY,
        user_id text NOT NULL DEFAULT 'mael',
        user_name text NOT NULL DEFAULT 'Maël H.',
        type text NOT NULL,
        label text NOT NULL,
        target_id text,
        target_type text,
        metadata jsonb,
        created_at timestamptz NOT NULL,
        archived_at timestamptz DEFAULT now() NOT NULL
      );

      -- ── Add-ons & AI Credits ─────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS org_addons (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        addon_key text NOT NULL,
        active boolean NOT NULL DEFAULT false,
        activated_at timestamptz,
        expires_at timestamptz,
        stripe_item_id text,
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS idx_org_addons_org_key ON org_addons(org_id, addon_key);

      CREATE TABLE IF NOT EXISTS ai_usage_logs (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        user_id text NOT NULL DEFAULT 'mael',
        model text NOT NULL,
        feature text NOT NULL,
        credits_used integer NOT NULL DEFAULT 0,
        tokens_in integer NOT NULL DEFAULT 0,
        tokens_out integer NOT NULL DEFAULT 0,
        cost_eur real NOT NULL DEFAULT 0,
        latency_ms integer NOT NULL DEFAULT 0,
        success text NOT NULL DEFAULT 'true',
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_org_created ON ai_usage_logs(org_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS ai_monthly_usage (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        month text NOT NULL,
        credits_used integer NOT NULL DEFAULT 0,
        credits_limit integer NOT NULL DEFAULT 100000,
        credits_extra integer NOT NULL DEFAULT 0,
        cost_eur real NOT NULL DEFAULT 0,
        request_count integer NOT NULL DEFAULT 0,
        reset_at timestamptz,
        updated_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS idx_ai_monthly_usage_org_month ON ai_monthly_usage(org_id, month);
      ALTER TABLE ai_monthly_usage ADD COLUMN IF NOT EXISTS tokens_used integer NOT NULL DEFAULT 0;

      CREATE TABLE IF NOT EXISTS ai_alerts (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        alert_type text NOT NULL,
        message text NOT NULL,
        threshold integer,
        current_value integer,
        triggered_at timestamptz DEFAULT now() NOT NULL,
        resolved_at timestamptz,
        metadata jsonb
      );

      -- ── Behavioral Tracking ──────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS behavior_events (
        id text PRIMARY KEY,
        session_id text NOT NULL,
        site_url text NOT NULL,
        page text NOT NULL,
        event_type text NOT NULL,
        element text,
        x_pos integer,
        y_pos integer,
        scroll_depth integer,
        time_on_page integer,
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_behavior_events_session ON behavior_events(session_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_behavior_events_site ON behavior_events(site_url, event_type, created_at DESC);

      CREATE TABLE IF NOT EXISTS behavior_sessions (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        user_agent text,
        device_type text NOT NULL DEFAULT 'desktop',
        country text,
        page_views integer NOT NULL DEFAULT 1,
        bounce boolean NOT NULL DEFAULT false,
        engagement_score integer NOT NULL DEFAULT 0,
        rage_clicks integer NOT NULL DEFAULT 0,
        exit_page text,
        started_at timestamptz DEFAULT now() NOT NULL,
        ended_at timestamptz
      );

      CREATE TABLE IF NOT EXISTS behavior_insights (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        insight_type text NOT NULL,
        severity text NOT NULL DEFAULT 'medium',
        title text NOT NULL,
        description text NOT NULL,
        affected_pages jsonb,
        estimated_impact text,
        ai_suggestion text,
        status text NOT NULL DEFAULT 'open',
        created_at timestamptz DEFAULT now() NOT NULL,
        resolved_at timestamptz
      );

      -- Per-site ingestion tokens — SHA-256 hash only; bound to org for ownership checks
      CREATE TABLE IF NOT EXISTS behavior_site_tokens (
        token_hash text PRIMARY KEY,
        site_url text NOT NULL,
        org_id text NOT NULL DEFAULT 'default',
        created_at timestamptz DEFAULT now() NOT NULL,
        last_used_at timestamptz
      );
      CREATE UNIQUE INDEX IF NOT EXISTS behavior_site_tokens_site_url_idx
        ON behavior_site_tokens (site_url);

      -- ── CRO ──────────────────────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS cro_recommendations (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        page text NOT NULL,
        type text NOT NULL,
        priority text NOT NULL DEFAULT 'medium',
        title text NOT NULL,
        description text NOT NULL,
        implementation text,
        estimated_uplift real NOT NULL DEFAULT 0,
        status text NOT NULL DEFAULT 'pending',
        ai_generated text NOT NULL DEFAULT 'true',
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS cro_experiments (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        page text NOT NULL,
        name text NOT NULL,
        hypothesis text NOT NULL,
        variant_a jsonb,
        variant_b jsonb,
        status text NOT NULL DEFAULT 'draft',
        winner text,
        conversion_a real,
        conversion_b real,
        confidence real,
        started_at timestamptz,
        ended_at timestamptz,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS cro_scores (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        page text NOT NULL,
        overall_score integer NOT NULL DEFAULT 50,
        friction_score integer NOT NULL DEFAULT 50,
        cta_score integer NOT NULL DEFAULT 50,
        form_score integer NOT NULL DEFAULT 50,
        mobile_score integer NOT NULL DEFAULT 50,
        copy_score integer NOT NULL DEFAULT 50,
        issues jsonb,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      -- ── Revenue Leaks ────────────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS revenue_leaks (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        leak_type text NOT NULL,
        page text NOT NULL,
        title text NOT NULL,
        description text NOT NULL,
        estimated_monthly_loss real NOT NULL DEFAULT 0,
        impact_score integer NOT NULL DEFAULT 0,
        fix_difficulty_min integer NOT NULL DEFAULT 30,
        quick_fix text,
        status text NOT NULL DEFAULT 'open',
        metadata jsonb,
        detected_at timestamptz DEFAULT now() NOT NULL,
        resolved_at timestamptz
      );

      CREATE TABLE IF NOT EXISTS traffic_losses (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        reason text NOT NULL,
        pages_affected jsonb,
        estimated_sessions_lost integer NOT NULL DEFAULT 0,
        estimated_revenue_loss real NOT NULL DEFAULT 0,
        severity text NOT NULL DEFAULT 'medium',
        detected_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS conversion_failures (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        funnel_step text NOT NULL,
        failure_rate real NOT NULL DEFAULT 0,
        sessions_impacted integer NOT NULL DEFAULT 0,
        estimated_loss_eur real NOT NULL DEFAULT 0,
        root_cause text,
        recommendation text,
        detected_at timestamptz DEFAULT now() NOT NULL
      );

      -- ── Forecasting ──────────────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS forecast_models (
        id text PRIMARY KEY,
        site_url text NOT NULL,
        model_type text NOT NULL,
        params jsonb,
        last_trained_at timestamptz,
        accuracy real,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS forecast_snapshots (
        id text PRIMARY KEY,
        model_id text NOT NULL,
        date text NOT NULL,
        value real NOT NULL,
        metric_type text NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS forecast_predictions (
        id text PRIMARY KEY,
        model_id text NOT NULL,
        date text NOT NULL,
        predicted_value real NOT NULL,
        confidence_low real NOT NULL,
        confidence_high real NOT NULL,
        scenario text NOT NULL DEFAULT 'base',
        generated_at timestamptz DEFAULT now() NOT NULL
      );

      -- ── Market Intelligence ──────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS market_insights (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        insight_type text NOT NULL,
        category text NOT NULL,
        title text NOT NULL,
        body text NOT NULL,
        impact text NOT NULL DEFAULT 'medium',
        score integer NOT NULL DEFAULT 50,
        sources jsonb,
        ai_generated text NOT NULL DEFAULT 'true',
        status text NOT NULL DEFAULT 'active',
        created_at timestamptz DEFAULT now() NOT NULL,
        expires_at timestamptz
      );

      CREATE TABLE IF NOT EXISTS market_trends (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        keyword text NOT NULL,
        trend_direction text NOT NULL DEFAULT 'stable',
        momentum real NOT NULL DEFAULT 0,
        volume_estimate integer NOT NULL DEFAULT 0,
        competitor_count integer NOT NULL DEFAULT 0,
        opportunity text,
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      -- ── Automation Workflows ─────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS automation_workflows (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        name text NOT NULL,
        icon text NOT NULL DEFAULT '⚡',
        description text,
        trigger_type text NOT NULL,
        trigger_config jsonb,
        actions jsonb NOT NULL,
        enabled boolean NOT NULL DEFAULT true,
        runs_count integer NOT NULL DEFAULT 0,
        last_run_at timestamptz,
        next_run_at timestamptz,
        category text NOT NULL DEFAULT 'general',
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS workflow_runs (
        id text PRIMARY KEY,
        workflow_id text NOT NULL,
        status text NOT NULL DEFAULT 'running',
        started_at timestamptz DEFAULT now() NOT NULL,
        ended_at timestamptz,
        duration_ms integer,
        steps_completed integer NOT NULL DEFAULT 0,
        steps_failed integer NOT NULL DEFAULT 0,
        error text,
        output jsonb,
        metadata jsonb
      );
      CREATE INDEX IF NOT EXISTS idx_workflow_runs_wf_id ON workflow_runs(workflow_id, started_at DESC);

      -- ── White-Label ──────────────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS custom_domains (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        domain text NOT NULL,
        status text NOT NULL DEFAULT 'pending',
        ssl_active boolean NOT NULL DEFAULT false,
        verification_token text,
        verified_at timestamptz,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS report_templates (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        name text NOT NULL,
        logo_url text,
        primary_color text NOT NULL DEFAULT '#2563EB',
        secondary_color text NOT NULL DEFAULT '#22c55e',
        font text NOT NULL DEFAULT 'Inter',
        footer_text text,
        header_text text,
        hide_flowpoint_branding boolean NOT NULL DEFAULT false,
        custom_css text,
        is_default boolean NOT NULL DEFAULT false,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS report_exports (
        id text PRIMARY KEY,
        report_id text NOT NULL,
        template_id text,
        format text NOT NULL DEFAULT 'pdf',
        file_path text,
        size_bytes integer,
        status text NOT NULL DEFAULT 'pending',
        generated_at timestamptz DEFAULT now() NOT NULL,
        downloaded_at timestamptz,
        download_count integer NOT NULL DEFAULT 0,
        metadata jsonb
      );

      -- ── Org Permissions ──────────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS org_permissions (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        role text NOT NULL,
        module text NOT NULL,
        can_read boolean NOT NULL DEFAULT true,
        can_write boolean NOT NULL DEFAULT false,
        can_admin boolean NOT NULL DEFAULT false,
        can_export boolean NOT NULL DEFAULT false,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS idx_org_permissions_role_module ON org_permissions(org_id, role, module);

      -- ── AI Workspace Launch — v3 ──────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS onboarding_sessions (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        user_id text NOT NULL DEFAULT 'demo',
        status text NOT NULL DEFAULT 'in_progress',
        site_url text,
        business_name text,
        niche text,
        location text,
        company_size text,
        activity_type text,
        started_at timestamptz DEFAULT now() NOT NULL,
        completed_at timestamptz,
        metadata jsonb
      );

      CREATE TABLE IF NOT EXISTS onboarding_answers (
        id text PRIMARY KEY,
        session_id text NOT NULL REFERENCES onboarding_sessions(id) ON DELETE CASCADE,
        question_key text NOT NULL,
        answer_value text,
        answer_json jsonb,
        answered_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS ai_workspace_profiles (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        session_id text REFERENCES onboarding_sessions(id),
        business_name text,
        niche text,
        location text,
        goals jsonb,
        competitors jsonb,
        stack jsonb,
        priorities jsonb,
        generated_roadmap jsonb,
        generated_strategy text,
        seo_score integer,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS ai_generated_missions (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        profile_id text REFERENCES ai_workspace_profiles(id),
        title text NOT NULL,
        description text,
        category text NOT NULL DEFAULT 'seo',
        priority integer NOT NULL DEFAULT 5,
        estimated_impact text,
        estimated_effort text,
        status text NOT NULL DEFAULT 'pending',
        created_at timestamptz DEFAULT now() NOT NULL,
        completed_at timestamptz
      );

      CREATE TABLE IF NOT EXISTS ai_setup_logs (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        session_id text REFERENCES onboarding_sessions(id),
        step text NOT NULL,
        message text,
        level text NOT NULL DEFAULT 'info',
        metadata jsonb,
        logged_at timestamptz DEFAULT now() NOT NULL
      );

      -- ── Google Business Profile — v4 ──────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS google_accounts (
        id text PRIMARY KEY,
        org_id text NOT NULL UNIQUE DEFAULT 'default',
        google_id text,
        email text,
        access_token text,
        refresh_token text,
        token_expiry timestamptz,
        scopes jsonb,
        connected_at timestamptz DEFAULT now() NOT NULL,
        last_sync_at timestamptz,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS google_locations (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        google_account_name text,
        location_id text NOT NULL,
        account_name text,
        name text NOT NULL,
        primary_category text,
        address text,
        phone text,
        website text,
        lat numeric,
        lng numeric,
        rating numeric DEFAULT 0,
        reviews_count integer DEFAULT 0,
        raw_data jsonb,
        last_sync_at timestamptz,
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS google_reviews (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        location_id text NOT NULL,
        review_id text NOT NULL,
        reviewer_name text,
        reviewer_photo text,
        rating integer DEFAULT 0,
        comment text,
        create_time timestamptz,
        update_time timestamptz,
        reply_comment text,
        reply_updated_at timestamptz,
        raw_data jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS idx_google_reviews_review_id ON google_reviews(org_id, review_id);

      CREATE TABLE IF NOT EXISTS gbp_performance (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        location_id text NOT NULL,
        metric text NOT NULL,
        date date NOT NULL,
        value integer DEFAULT 0,
        cached_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS idx_gbp_perf_unique ON gbp_performance(org_id, location_id, metric, date);

      -- ── DataForSEO — v5 ───────────────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS seo_keywords (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        keyword text NOT NULL,
        search_volume integer DEFAULT 0,
        cpc numeric DEFAULT 0,
        competition numeric DEFAULT 0,
        difficulty integer DEFAULT 0,
        intent text,
        opportunity_score integer DEFAULT 0,
        raw_data jsonb,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS seo_serp_snapshots (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        keyword text NOT NULL,
        results jsonb,
        positions_count integer DEFAULT 0,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS seo_competitors (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        source_domain text NOT NULL,
        competitor_domain text NOT NULL,
        domain_rating integer DEFAULT 0,
        organic_keywords integer DEFAULT 0,
        estimated_traffic integer DEFAULT 0,
        keyword_gap integer DEFAULT 0,
        raw_data jsonb,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS seo_backlinks (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        domain text NOT NULL,
        total_backlinks integer DEFAULT 0,
        total_domains integer DEFAULT 0,
        domain_rating integer DEFAULT 0,
        spam_score integer DEFAULT 0,
        new_backlinks integer DEFAULT 0,
        lost_backlinks integer DEFAULT 0,
        toxic_backlinks integer DEFAULT 0,
        raw_data jsonb,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS seo_domain_metrics (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        domain text NOT NULL,
        domain_rating integer DEFAULT 0,
        organic_traffic integer DEFAULT 0,
        organic_keywords integer DEFAULT 0,
        paid_traffic integer DEFAULT 0,
        backlinks integer DEFAULT 0,
        raw_data jsonb,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS seo_local_rankings (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        keyword text NOT NULL,
        location text NOT NULL,
        results jsonb,
        count integer DEFAULT 0,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS seo_ai_mentions (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        keyword text NOT NULL,
        chatgpt_mentions integer DEFAULT 0,
        gemini_mentions integer DEFAULT 0,
        ai_overview_present boolean DEFAULT false,
        llm_visibility_score integer DEFAULT 0,
        raw_data jsonb,
        cached_at timestamptz DEFAULT now() NOT NULL,
        created_at timestamptz DEFAULT now() NOT NULL
      );
    `);
    logger.info("[DB] Migrations applied v2 (org_addons, ai_usage, behavioral, cro, revenue_leaks, forecasting, market_intelligence, automation, white_label, org_permissions)");
    logger.info("[DB] Migrations applied v3 (onboarding_sessions, onboarding_answers, ai_workspace_profiles, ai_generated_missions, ai_setup_logs)");
    logger.info("[DB] Migrations applied v4 (google_accounts, google_locations, google_reviews)");
    logger.info("[DB] Migrations applied v5 (seo_keywords, seo_serp_snapshots, seo_competitors, seo_backlinks, seo_domain_metrics, seo_local_rankings, seo_ai_mentions)");

    // ── v6 — GA4 Analytics ────────────────────────────────────────────────────
    await client.query(`
      CREATE TABLE IF NOT EXISTS ga4_properties (
        id                text PRIMARY KEY,
        org_id            text NOT NULL UNIQUE,
        property_id       text NOT NULL,
        property_name     text NOT NULL DEFAULT '',
        is_active         boolean NOT NULL DEFAULT true,
        created_at        timestamptz DEFAULT now() NOT NULL,
        updated_at        timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_ga4_properties_org ON ga4_properties(org_id);

      CREATE TABLE IF NOT EXISTS ga4_report_cache (
        id                text PRIMARY KEY,
        org_id            text NOT NULL,
        property_id       text NOT NULL,
        report_type       text NOT NULL,
        days              integer NOT NULL DEFAULT 30,
        data              jsonb NOT NULL DEFAULT '{}',
        cached_at         timestamptz DEFAULT now() NOT NULL,
        expires_at        timestamptz NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_ga4_cache_lookup ON ga4_report_cache(org_id, property_id, report_type, days);
      CREATE INDEX IF NOT EXISTS idx_ga4_cache_expires ON ga4_report_cache(expires_at);
    `);
    logger.info("[DB] Migrations applied v6 (ga4_properties, ga4_report_cache)");

    // ── v7 — PageSpeed Insights + AI Chat History ─────────────────────────────
    await client.query(`
      CREATE TABLE IF NOT EXISTS pagespeed_results (
        id                  text PRIMARY KEY,
        org_id              text NOT NULL DEFAULT 'default',
        url                 text NOT NULL,
        strategy            text NOT NULL DEFAULT 'mobile',
        performance_score   integer NOT NULL DEFAULT 0,
        accessibility_score integer NOT NULL DEFAULT 0,
        seo_score           integer NOT NULL DEFAULT 0,
        best_practices_score integer NOT NULL DEFAULT 0,
        lcp                 numeric NOT NULL DEFAULT 0,
        cls                 numeric NOT NULL DEFAULT 0,
        inp                 numeric NOT NULL DEFAULT 0,
        ttfb                numeric NOT NULL DEFAULT 0,
        fcp                 numeric NOT NULL DEFAULT 0,
        tbt                 numeric NOT NULL DEFAULT 0,
        speed_index         numeric NOT NULL DEFAULT 0,
        opportunities       jsonb DEFAULT '[]',
        diagnostics         jsonb DEFAULT '{}',
        raw_lighthouse      jsonb DEFAULT '{}',
        ai_recommendations  text,
        created_at          timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_psi_results_org_url ON pagespeed_results(org_id, url, strategy);
      CREATE INDEX IF NOT EXISTS idx_psi_results_created ON pagespeed_results(created_at DESC);

      CREATE TABLE IF NOT EXISTS pagespeed_history (
        id                  text PRIMARY KEY,
        org_id              text NOT NULL DEFAULT 'default',
        url                 text NOT NULL,
        strategy            text NOT NULL DEFAULT 'mobile',
        performance_score   integer NOT NULL DEFAULT 0,
        accessibility_score integer NOT NULL DEFAULT 0,
        seo_score           integer NOT NULL DEFAULT 0,
        best_practices_score integer NOT NULL DEFAULT 0,
        lcp                 numeric NOT NULL DEFAULT 0,
        cls                 numeric NOT NULL DEFAULT 0,
        inp                 numeric NOT NULL DEFAULT 0,
        ttfb                numeric NOT NULL DEFAULT 0,
        created_at          timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_psi_history_org_url ON pagespeed_history(org_id, url, strategy, created_at DESC);

      CREATE TABLE IF NOT EXISTS ai_chat_history (
        id          text PRIMARY KEY,
        org_id      text NOT NULL DEFAULT 'default',
        user_id     text NOT NULL DEFAULT 'mael',
        role        text NOT NULL DEFAULT 'user',
        content     text NOT NULL,
        feature     text NOT NULL DEFAULT 'chat',
        context     jsonb DEFAULT '{}',
        tokens_used integer DEFAULT 0,
        model       text DEFAULT 'gpt-4o-mini',
        created_at  timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_ai_chat_org ON ai_chat_history(org_id, user_id, created_at DESC);
    `);
    logger.info("[DB] Migrations applied v7 (pagespeed_results, pagespeed_history, ai_chat_history)");

    // ── v8 — Billing events, GitHub integration, Auth providers ───────────────
    await client.query(`
      CREATE TABLE IF NOT EXISTS billing_events (
        id          BIGSERIAL PRIMARY KEY,
        org_id      TEXT NOT NULL DEFAULT 'default',
        type        TEXT NOT NULL,
        amount      NUMERIC(10,2) NOT NULL DEFAULT 0,
        currency    TEXT NOT NULL DEFAULT 'eur',
        plan        TEXT,
        stripe_event_id TEXT,
        metadata    JSONB DEFAULT '{}',
        created_at  TIMESTAMPTZ DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_billing_events_org ON billing_events(org_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_billing_events_type ON billing_events(type, created_at DESC);

      CREATE TABLE IF NOT EXISTS subscription_analytics (
        id          BIGSERIAL PRIMARY KEY,
        org_id      TEXT NOT NULL DEFAULT 'default',
        date        DATE NOT NULL DEFAULT CURRENT_DATE,
        plan        TEXT NOT NULL,
        mrr         NUMERIC(10,2) DEFAULT 0,
        arr         NUMERIC(10,2) DEFAULT 0,
        active_subs INT DEFAULT 0,
        churned     INT DEFAULT 0,
        new_subs    INT DEFAULT 0,
        trial_subs  INT DEFAULT 0,
        metadata    JSONB DEFAULT '{}',
        UNIQUE(org_id, date)
      );

      CREATE TABLE IF NOT EXISTS cron_history (
        id          BIGSERIAL PRIMARY KEY,
        job_name    TEXT NOT NULL,
        status      TEXT NOT NULL DEFAULT 'ok',
        duration_ms INT  NOT NULL DEFAULT 0,
        error       TEXT,
        ran_at      TIMESTAMPTZ DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_cron_history_job ON cron_history(job_name, ran_at DESC);
      CREATE INDEX IF NOT EXISTS idx_cron_history_ran ON cron_history(ran_at DESC);

      CREATE TABLE IF NOT EXISTS worker_failures (
        id          BIGSERIAL PRIMARY KEY,
        worker_name TEXT        NOT NULL,
        error       TEXT        NOT NULL,
        stack       TEXT,
        context     JSONB,
        failed_at   TIMESTAMPTZ DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_worker_failures_worker ON worker_failures(worker_name, failed_at DESC);
      CREATE INDEX IF NOT EXISTS idx_worker_failures_at    ON worker_failures(failed_at DESC);

      CREATE TABLE IF NOT EXISTS user_prefs (
        org_id     TEXT PRIMARY KEY,
        streak     INTEGER NOT NULL DEFAULT 0,
        pinned     JSONB NOT NULL DEFAULT '{}',
        checklist  JSONB,
        settings   JSONB,
        updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS github_connections (
        id              BIGSERIAL PRIMARY KEY,
        org_id          TEXT NOT NULL DEFAULT 'default',
        github_user_id  BIGINT NOT NULL,
        login           TEXT NOT NULL,
        name            TEXT,
        email           TEXT,
        avatar_url      TEXT,
        access_token    TEXT NOT NULL,
        scope           TEXT,
        connected_at    TIMESTAMPTZ DEFAULT now() NOT NULL,
        updated_at      TIMESTAMPTZ,
        UNIQUE(org_id)
      );

      CREATE TABLE IF NOT EXISTS github_repos (
        id          BIGSERIAL PRIMARY KEY,
        org_id      TEXT NOT NULL DEFAULT 'default',
        owner       TEXT NOT NULL,
        repo        TEXT NOT NULL,
        full_name   TEXT NOT NULL,
        language    TEXT,
        private     BOOLEAN DEFAULT false,
        health_score INT DEFAULT 0,
        last_synced TIMESTAMPTZ,
        metadata    JSONB DEFAULT '{}',
        created_at  TIMESTAMPTZ DEFAULT now() NOT NULL,
        UNIQUE(org_id, full_name)
      );

      CREATE TABLE IF NOT EXISTS github_analyses (
        id          TEXT PRIMARY KEY,
        org_id      TEXT NOT NULL DEFAULT 'default',
        owner       TEXT NOT NULL,
        repo        TEXT NOT NULL,
        health_score INT DEFAULT 0,
        issues      JSONB DEFAULT '[]',
        analysis    JSONB DEFAULT '{}',
        analyzed_at TIMESTAMPTZ DEFAULT now() NOT NULL,
        UNIQUE(org_id, owner, repo)
      );
      CREATE INDEX IF NOT EXISTS idx_github_analyses_org ON github_analyses(org_id, analyzed_at DESC);

      CREATE TABLE IF NOT EXISTS auth_providers (
        id          BIGSERIAL PRIMARY KEY,
        org_id      TEXT NOT NULL DEFAULT 'default',
        provider    TEXT NOT NULL,
        provider_id TEXT NOT NULL,
        email       TEXT,
        name        TEXT,
        avatar_url  TEXT,
        access_token TEXT,
        refresh_token TEXT,
        token_expiry TIMESTAMPTZ,
        metadata    JSONB DEFAULT '{}',
        created_at  TIMESTAMPTZ DEFAULT now() NOT NULL,
        updated_at  TIMESTAMPTZ,
        UNIQUE(org_id, provider)
      );
    `);
    logger.info("[DB] Migrations applied v8 (billing_events, subscription_analytics, github_connections, github_repos, github_analyses, auth_providers)");

    // ── v9 — Google Search Console + sync logs ────────────────────────────────
    await client.query(`
      CREATE TABLE IF NOT EXISTS gsc_sites (
        id              text PRIMARY KEY,
        org_id          text NOT NULL DEFAULT 'default',
        site_url        text NOT NULL,
        display_name    text,
        permission_level text,
        is_active       boolean NOT NULL DEFAULT false,
        last_sync_at    timestamptz,
        created_at      timestamptz DEFAULT now() NOT NULL,
        updated_at      timestamptz DEFAULT now() NOT NULL,
        UNIQUE(org_id, site_url)
      );
      CREATE INDEX IF NOT EXISTS idx_gsc_sites_org ON gsc_sites(org_id, is_active);

      CREATE TABLE IF NOT EXISTS gsc_search_analytics (
        id          text PRIMARY KEY,
        org_id      text NOT NULL DEFAULT 'default',
        site_url    text NOT NULL,
        keyword     text,
        page        text,
        device      text,
        country     text,
        date        date NOT NULL,
        clicks      integer NOT NULL DEFAULT 0,
        impressions integer NOT NULL DEFAULT 0,
        ctr         numeric(8,4) NOT NULL DEFAULT 0,
        position    numeric(8,2) NOT NULL DEFAULT 0,
        cached_at   timestamptz DEFAULT now() NOT NULL,
        UNIQUE(org_id, site_url, keyword, page, date)
      );
      CREATE INDEX IF NOT EXISTS idx_gsc_analytics_org_site ON gsc_search_analytics(org_id, site_url, date DESC);
      CREATE INDEX IF NOT EXISTS idx_gsc_analytics_keyword ON gsc_search_analytics(org_id, site_url, keyword, date DESC);
      CREATE INDEX IF NOT EXISTS idx_gsc_analytics_page ON gsc_search_analytics(org_id, site_url, page, date DESC);

      CREATE TABLE IF NOT EXISTS google_sync_logs (
        id              text PRIMARY KEY,
        org_id          text NOT NULL DEFAULT 'default',
        integration     text NOT NULL,
        status          text NOT NULL DEFAULT 'success',
        message         text,
        records_synced  integer NOT NULL DEFAULT 0,
        started_at      timestamptz DEFAULT now() NOT NULL,
        ended_at        timestamptz
      );
      CREATE INDEX IF NOT EXISTS idx_google_sync_logs_org ON google_sync_logs(org_id, integration, started_at DESC);

      ALTER TABLE google_accounts ADD COLUMN IF NOT EXISTS access_token_enc text;
      ALTER TABLE google_accounts ADD COLUMN IF NOT EXISTS refresh_token_enc text;
    `);
    logger.info("[DB] Migrations applied v9 (gsc_sites, gsc_search_analytics, google_sync_logs)");

    // ── v10 — AI Mission Engine ────────────────────────────────────────────────
    await client.query(`
      CREATE TABLE IF NOT EXISTS missions (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        title text NOT NULL,
        description text,
        category text NOT NULL DEFAULT 'seo',
        type text NOT NULL DEFAULT 'seo',
        priority text NOT NULL DEFAULT 'medium',
        priority_score integer NOT NULL DEFAULT 50,
        status text NOT NULL DEFAULT 'todo',
        impact text NOT NULL DEFAULT 'Moyen',
        effort text NOT NULL DEFAULT 'Moyen',
        estimated_traffic_impact integer,
        estimated_revenue_impact real,
        estimated_seo_impact integer,
        estimated_conversion_impact real,
        difficulty_score integer,
        business_impact_score integer,
        ai_explanation text,
        ai_action_steps jsonb,
        ai_quick_win boolean DEFAULT false,
        ai_reasoning text,
        ai_summary text,
        source_type text,
        source_data jsonb,
        steps jsonb,
        due_date text,
        completed_at timestamptz,
        dismissed_at timestamptz,
        last_refreshed_at timestamptz DEFAULT now(),
        created_at timestamptz DEFAULT now() NOT NULL,
        updated_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_missions_org ON missions(org_id);
      CREATE INDEX IF NOT EXISTS idx_missions_status ON missions(org_id, status);
      CREATE INDEX IF NOT EXISTS idx_missions_priority ON missions(org_id, priority_score DESC);

      CREATE TABLE IF NOT EXISTS mission_templates (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        title text NOT NULL,
        description text,
        category text NOT NULL,
        type text NOT NULL,
        priority text NOT NULL DEFAULT 'medium',
        impact text NOT NULL DEFAULT 'Moyen',
        effort text NOT NULL DEFAULT 'Moyen',
        steps jsonb,
        conditions jsonb,
        is_active boolean NOT NULL DEFAULT true,
        usage_count integer NOT NULL DEFAULT 0,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS mission_history (
        id text PRIMARY KEY,
        mission_id text NOT NULL,
        org_id text NOT NULL DEFAULT 'default',
        action text NOT NULL,
        from_status text,
        to_status text,
        user_id text,
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_mission_history_mission ON mission_history(mission_id);

      CREATE TABLE IF NOT EXISTS mission_ai_logs (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        trigger_type text NOT NULL,
        model text,
        input_tokens integer,
        output_tokens integer,
        missions_generated integer,
        missions_updated integer,
        execution_ms integer,
        status text NOT NULL DEFAULT 'success',
        error text,
        metadata jsonb,
        created_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS mission_priorities (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        mission_id text NOT NULL,
        priority_score integer NOT NULL,
        traffic_weight real,
        revenue_weight real,
        seo_weight real,
        difficulty_weight real,
        computed_at timestamptz DEFAULT now() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS mission_impact_scores (
        id text PRIMARY KEY,
        org_id text NOT NULL DEFAULT 'default',
        mission_id text NOT NULL,
        traffic_impact integer,
        revenue_impact real,
        seo_impact integer,
        conversion_impact real,
        business_impact integer,
        quick_win_score integer,
        computed_at timestamptz DEFAULT now() NOT NULL
      );
    `);
    logger.info("[DB] Migrations applied v10 (missions, mission_templates, mission_history, mission_ai_logs, mission_priorities, mission_impact_scores)");

    // ── v11 — Better Stack integration ────────────────────────────────────────
    const v11 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='bs_monitors' LIMIT 1`);
    if (v11.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS bs_monitors (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          bs_id text,
          name text NOT NULL,
          url text NOT NULL,
          monitor_type text NOT NULL DEFAULT 'status',
          status text NOT NULL DEFAULT 'up',
          required_keyword text,
          request_timeout integer DEFAULT 30,
          verify_ssl boolean DEFAULT true,
          check_frequency integer DEFAULT 180,
          regions jsonb,
          paused boolean DEFAULT false,
          uptime_percentage real,
          avg_response_time integer,
          ssl_expires_at text,
          ssl_days_remaining integer,
          last_checked_at timestamptz,
          follow_redirects boolean DEFAULT true,
          remember_cookies boolean DEFAULT false,
          team_name text,
          recovery_period integer DEFAULT 180,
          alert_policy jsonb,
          metadata jsonb,
          synced_at timestamptz DEFAULT now(),
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS bs_monitors_org_idx ON bs_monitors(org_id);
        CREATE INDEX IF NOT EXISTS bs_monitors_status_idx ON bs_monitors(status);
        CREATE INDEX IF NOT EXISTS bs_monitors_bs_id_idx ON bs_monitors(bs_id);

        CREATE TABLE IF NOT EXISTS bs_incidents (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          bs_id text,
          monitor_id text,
          name text,
          url text,
          cause text,
          status text NOT NULL DEFAULT 'resolved',
          started_at timestamptz,
          resolved_at timestamptz,
          duration_seconds integer,
          regions jsonb,
          response_content text,
          response_options jsonb,
          acknowledged_at timestamptz,
          acknowledged_by text,
          metadata jsonb,
          synced_at timestamptz DEFAULT now(),
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS bs_incidents_org_idx ON bs_incidents(org_id);
        CREATE INDEX IF NOT EXISTS bs_incidents_status_idx ON bs_incidents(status);
        CREATE INDEX IF NOT EXISTS bs_incidents_started_at_idx ON bs_incidents(started_at DESC);

        CREATE TABLE IF NOT EXISTS bs_heartbeats (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          bs_id text,
          name text NOT NULL,
          period integer DEFAULT 3600,
          grace integer DEFAULT 0,
          status text NOT NULL DEFAULT 'pending',
          last_ping_at timestamptz,
          next_expected_at timestamptz,
          url text,
          email text,
          paused boolean DEFAULT false,
          team_name text,
          synced_at timestamptz DEFAULT now(),
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS bs_heartbeats_org_idx ON bs_heartbeats(org_id);

        CREATE TABLE IF NOT EXISTS bs_status_pages (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          bs_id text,
          name text NOT NULL,
          subdomain text,
          custom_domain text,
          logo_url text,
          favicon_url text,
          min_incident_length integer DEFAULT 0,
          announcement_bar_text text,
          subscriber_notifications boolean DEFAULT false,
          timezone text DEFAULT 'UTC',
          theme text DEFAULT 'dark',
          metadata jsonb,
          synced_at timestamptz DEFAULT now(),
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS bs_status_pages_org_idx ON bs_status_pages(org_id);

        CREATE TABLE IF NOT EXISTS bs_monitor_stats (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          monitor_id text NOT NULL,
          period text NOT NULL,
          uptime_percentage real,
          avg_response_time integer,
          total_downtime integer,
          incidents_count integer,
          response_times_data jsonb,
          uptime_data jsonb,
          computed_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS bs_monitor_stats_monitor_idx ON bs_monitor_stats(monitor_id);
      `);
      logger.info("[DB] Migrations applied v11 (bs_monitors, bs_incidents, bs_heartbeats, bs_status_pages, bs_monitor_stats)");
    }

    // ── v12 — Keyword Domination Engine ───────────────────────────────────────
    const v12 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='tracked_keywords' LIMIT 1`);
    if (v12.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS tracked_keywords (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          keyword text NOT NULL,
          url text,
          device text NOT NULL DEFAULT 'desktop',
          location text NOT NULL DEFAULT 'France',
          language text NOT NULL DEFAULT 'fr',
          tag text,
          cluster_id text,
          intent text,
          search_volume integer DEFAULT 0,
          difficulty integer DEFAULT 0,
          cpc numeric DEFAULT 0,
          current_position integer,
          prev_position integer,
          best_position integer,
          worst_position integer,
          position_change integer DEFAULT 0,
          trend text DEFAULT 'stable',
          volatility real DEFAULT 0,
          serp_features jsonb,
          last_synced_at timestamptz,
          active boolean DEFAULT true,
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS tracked_kw_org_idx ON tracked_keywords(org_id);
        CREATE INDEX IF NOT EXISTS tracked_kw_position_idx ON tracked_keywords(current_position);
        CREATE UNIQUE INDEX IF NOT EXISTS tracked_kw_unique ON tracked_keywords(org_id, keyword, device, location);

        CREATE TABLE IF NOT EXISTS keyword_rankings (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          keyword_id text NOT NULL REFERENCES tracked_keywords(id) ON DELETE CASCADE,
          keyword text NOT NULL,
          position integer,
          url text,
          title text,
          serp_features jsonb,
          volatility real DEFAULT 0,
          checked_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS kw_rankings_keyword_id_idx ON keyword_rankings(keyword_id);
        CREATE INDEX IF NOT EXISTS kw_rankings_checked_at_idx ON keyword_rankings(checked_at DESC);
        CREATE INDEX IF NOT EXISTS kw_rankings_org_idx ON keyword_rankings(org_id);

        CREATE TABLE IF NOT EXISTS keyword_clusters (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          name text NOT NULL,
          description text,
          intent text,
          keywords jsonb,
          keyword_count integer DEFAULT 0,
          avg_position real,
          avg_volume integer DEFAULT 0,
          avg_difficulty integer DEFAULT 0,
          total_volume integer DEFAULT 0,
          ai_summary text,
          color text DEFAULT '#2563EB',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS kw_clusters_org_idx ON keyword_clusters(org_id);

        CREATE TABLE IF NOT EXISTS keyword_opportunities (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          keyword text NOT NULL,
          search_volume integer DEFAULT 0,
          difficulty integer DEFAULT 0,
          cpc numeric DEFAULT 0,
          intent text,
          opportunity_score integer DEFAULT 0,
          type text NOT NULL DEFAULT 'quick_win',
          current_position integer,
          potential_position integer,
          estimated_traffic integer DEFAULT 0,
          ai_explanation text,
          status text DEFAULT 'new',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS kw_opp_org_idx ON keyword_opportunities(org_id);
        CREATE INDEX IF NOT EXISTS kw_opp_score_idx ON keyword_opportunities(opportunity_score DESC);

        CREATE TABLE IF NOT EXISTS competitor_rankings (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          competitor_domain text NOT NULL,
          keyword text NOT NULL,
          position integer,
          url text,
          our_position integer,
          gap integer,
          search_volume integer DEFAULT 0,
          difficulty integer DEFAULT 0,
          checked_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS comp_rankings_org_idx ON competitor_rankings(org_id);
        CREATE INDEX IF NOT EXISTS comp_rankings_checked_at_idx ON competitor_rankings(checked_at DESC);

        CREATE TABLE IF NOT EXISTS ranking_alerts (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          keyword_id text NOT NULL,
          keyword text NOT NULL,
          alert_type text NOT NULL,
          severity text NOT NULL DEFAULT 'info',
          old_position integer,
          new_position integer,
          change integer,
          message text NOT NULL,
          read boolean DEFAULT false,
          triggered_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ranking_alerts_org_idx ON ranking_alerts(org_id);
        CREATE INDEX IF NOT EXISTS ranking_alerts_read_idx ON ranking_alerts(read);
        CREATE INDEX IF NOT EXISTS ranking_alerts_triggered_idx ON ranking_alerts(triggered_at DESC);
      `);
      logger.info("[DB] Migrations applied v12 (tracked_keywords, keyword_rankings, keyword_clusters, keyword_opportunities, competitor_rankings, ranking_alerts)");
    }

    // ── v13 — Zapier/Make Integration Hub ─────────────────────────────────────
    const v13 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='automation_integrations' LIMIT 1`);
    if (v13.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS automation_integrations (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          name text NOT NULL,
          type text NOT NULL,
          platform text NOT NULL,
          endpoint_url text,
          secret_key text,
          headers jsonb DEFAULT '{}',
          events jsonb DEFAULT '[]',
          active boolean DEFAULT true,
          verified boolean DEFAULT false,
          last_triggered_at timestamptz,
          trigger_count integer DEFAULT 0,
          failure_count integer DEFAULT 0,
          retry_enabled boolean DEFAULT true,
          max_retries integer DEFAULT 3,
          timeout_ms integer DEFAULT 10000,
          metadata jsonb DEFAULT '{}',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ai_org_idx ON automation_integrations(org_id);
        CREATE INDEX IF NOT EXISTS ai_platform_idx ON automation_integrations(platform);
        CREATE INDEX IF NOT EXISTS ai_active_idx ON automation_integrations(active);

        CREATE TABLE IF NOT EXISTS automation_templates (
          id text PRIMARY KEY,
          name text NOT NULL,
          description text,
          platform text NOT NULL,
          category text NOT NULL DEFAULT 'general',
          trigger_event text NOT NULL,
          action_type text NOT NULL,
          config_template jsonb DEFAULT '{}',
          icon text DEFAULT '⚡',
          color text DEFAULT '#2563EB',
          popularity integer DEFAULT 0,
          plan_required text DEFAULT 'Standard',
          active boolean DEFAULT true,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS at_platform_idx ON automation_templates(platform);
        CREATE INDEX IF NOT EXISTS at_category_idx ON automation_templates(category);

        CREATE TABLE IF NOT EXISTS automation_runs (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          integration_id text NOT NULL REFERENCES automation_integrations(id) ON DELETE CASCADE,
          event_type text NOT NULL,
          payload jsonb,
          status text NOT NULL DEFAULT 'pending',
          http_status integer,
          response_body text,
          duration_ms integer,
          attempt integer DEFAULT 1,
          next_retry_at timestamptz,
          error text,
          triggered_at timestamptz DEFAULT now() NOT NULL,
          delivered_at timestamptz
        );
        CREATE INDEX IF NOT EXISTS ar_org_idx ON automation_runs(org_id);
        CREATE INDEX IF NOT EXISTS ar_integration_idx ON automation_runs(integration_id);
        CREATE INDEX IF NOT EXISTS ar_status_idx ON automation_runs(status);
        CREATE INDEX IF NOT EXISTS ar_triggered_idx ON automation_runs(triggered_at DESC);

        CREATE TABLE IF NOT EXISTS automation_logs (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          integration_id text,
          run_id text,
          event_type text NOT NULL,
          level text NOT NULL DEFAULT 'info',
          message text NOT NULL,
          metadata jsonb,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS al_org_idx ON automation_logs(org_id);
        CREATE INDEX IF NOT EXISTS al_integration_idx ON automation_logs(integration_id);
        CREATE INDEX IF NOT EXISTS al_created_idx ON automation_logs(created_at DESC);

        CREATE TABLE IF NOT EXISTS incoming_webhooks (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          name text NOT NULL,
          token text UNIQUE NOT NULL,
          source text NOT NULL DEFAULT 'custom',
          action text NOT NULL DEFAULT 'create_mission',
          action_config jsonb DEFAULT '{}',
          active boolean DEFAULT true,
          last_received_at timestamptz,
          receive_count integer DEFAULT 0,
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS iw_org_idx ON incoming_webhooks(org_id);
        CREATE UNIQUE INDEX IF NOT EXISTS iw_token_idx ON incoming_webhooks(token);
      `);

      // Seed default templates
      await client.query(`
        INSERT INTO automation_templates (id,name,description,platform,category,trigger_event,action_type,config_template,icon,color,popularity,plan_required) VALUES
        ('tpl_01','Alerte Monitor Down → Slack','Notifie votre canal Slack immédiatement quand un monitor tombe','slack','monitoring','monitor.down','slack_message','{"channel":"#alerts","message":"🚨 Monitor {{domain}} est DOWN"}','🚨','#ef4444',95,'Standard'),
        ('tpl_02','Audit terminé → Zapier','Déclenche un Zap à chaque audit SEO complété avec le score','zapier','seo','audit.completed','zapier_trigger','{"include_score":true,"include_recommendations":true}','⚡','#ff6640',88,'Pro'),
        ('tpl_03','Mission créée → Notion','Crée automatiquement une tâche Notion par mission FlowPoint','notion','productivity','mission.created','notion_create_page','{"database_id":"","title_property":"Name"}','📋','#ffffff',72,'Pro'),
        ('tpl_04','Rapport généré → Make','Envoie le lien PDF vers votre scénario Make (Integromat)','make','reporting','report.generated','make_webhook','{"include_pdf_url":true}','🔄','#6d00cc',65,'Pro'),
        ('tpl_05','Avis Google → HubSpot','Crée un contact HubSpot pour chaque nouveau 1-2 étoiles','hubspot','reputation','review.received','hubspot_create_contact','{"min_rating":1,"max_rating":2}','🎯','#ff7a59',58,'Pro'),
        ('tpl_06','Keyword chute → Email','Alerte email quand un mot-clé perd 5+ positions','email','seo','keyword.ranking_changed','send_email','{"threshold":-5,"subject":"⚠️ Chute de position détectée"}','📉','#f59e0b',80,'Standard'),
        ('tpl_07','Monitor récupéré → Slack','Notifie Slack quand un site revient en ligne','slack','monitoring','monitor.recovered','slack_message','{"channel":"#monitoring","message":"✅ {{domain}} est de retour en ligne"}','✅','#22c55e',91,'Standard'),
        ('tpl_08','Paiement échoué → HubSpot','Marque le contact HubSpot quand un paiement échoue','hubspot','billing','payment.failed','hubspot_update_contact','{"property":"payment_status","value":"failed"}','💳','#ef4444',45,'Ultra'),
        ('tpl_09','Backlink détecté → Airtable','Log chaque nouveau backlink dans une base Airtable','airtable','seo','backlink.detected','airtable_create_record','{"base_id":"","table_name":"Backlinks"}','🔗','#18bfff',55,'Pro'),
        ('tpl_10','Concurrent détecté → Make','Alerte Make quand un nouveau concurrent est identifié','make','intelligence','competitor.detected','make_webhook','{"include_domain":true,"include_metrics":true}','🕵️','#6d00cc',42,'Ultra')
        ON CONFLICT DO NOTHING;
      `);

      logger.info("[DB] Migrations applied v13 (automation_integrations, automation_templates, automation_runs, automation_logs, incoming_webhooks)");
    }

    // ── v14 — CRM Integrations ────────────────────────────────────────────────
    const v14 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='crm_integrations' LIMIT 1`);
    if (v14.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS crm_integrations (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          provider text NOT NULL,
          name text NOT NULL,
          status text NOT NULL DEFAULT 'disconnected',
          access_token text,
          refresh_token text,
          token_expires_at timestamptz,
          portal_id text,
          portal_url text,
          scope text,
          sync_enabled boolean DEFAULT true,
          sync_direction text DEFAULT 'bidirectional',
          sync_interval_minutes integer DEFAULT 60,
          last_sync_at timestamptz,
          last_sync_status text,
          synced_contacts integer DEFAULT 0,
          synced_leads integer DEFAULT 0,
          synced_deals integer DEFAULT 0,
          metadata jsonb DEFAULT '{}',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS crm_org_idx ON crm_integrations(org_id);
        CREATE INDEX IF NOT EXISTS crm_provider_idx ON crm_integrations(provider);

        CREATE TABLE IF NOT EXISTS crm_tokens (
          id text PRIMARY KEY,
          crm_integration_id text NOT NULL REFERENCES crm_integrations(id) ON DELETE CASCADE,
          access_token text NOT NULL,
          refresh_token text,
          expires_at timestamptz,
          scopes text[],
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );

        CREATE TABLE IF NOT EXISTS crm_sync_logs (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          crm_integration_id text REFERENCES crm_integrations(id) ON DELETE SET NULL,
          provider text NOT NULL,
          direction text NOT NULL,
          entity_type text NOT NULL,
          status text NOT NULL DEFAULT 'pending',
          records_processed integer DEFAULT 0,
          records_created integer DEFAULT 0,
          records_updated integer DEFAULT 0,
          records_failed integer DEFAULT 0,
          duration_ms integer,
          error text,
          started_at timestamptz DEFAULT now() NOT NULL,
          completed_at timestamptz
        );
        CREATE INDEX IF NOT EXISTS csl_org_idx ON crm_sync_logs(org_id);
        CREATE INDEX IF NOT EXISTS csl_crm_idx ON crm_sync_logs(crm_integration_id);
        CREATE INDEX IF NOT EXISTS csl_started_idx ON crm_sync_logs(started_at DESC);

        CREATE TABLE IF NOT EXISTS crm_field_mappings (
          id text PRIMARY KEY,
          crm_integration_id text NOT NULL REFERENCES crm_integrations(id) ON DELETE CASCADE,
          entity_type text NOT NULL,
          flowpoint_field text NOT NULL,
          crm_field text NOT NULL,
          transform text,
          active boolean DEFAULT true,
          created_at timestamptz DEFAULT now() NOT NULL
        );

        CREATE TABLE IF NOT EXISTS crm_sync_jobs (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          crm_integration_id text NOT NULL REFERENCES crm_integrations(id) ON DELETE CASCADE,
          job_type text NOT NULL,
          status text NOT NULL DEFAULT 'pending',
          scheduled_at timestamptz NOT NULL,
          started_at timestamptz,
          completed_at timestamptz,
          result jsonb,
          error text,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS csj_org_idx ON crm_sync_jobs(org_id);
        CREATE INDEX IF NOT EXISTS csj_status_idx ON crm_sync_jobs(status);

        CREATE TABLE IF NOT EXISTS crm_webhooks (
          id text PRIMARY KEY,
          crm_integration_id text NOT NULL REFERENCES crm_integrations(id) ON DELETE CASCADE,
          provider text NOT NULL,
          event_type text NOT NULL,
          payload jsonb,
          processed boolean DEFAULT false,
          received_at timestamptz DEFAULT now() NOT NULL,
          processed_at timestamptz
        );
        CREATE INDEX IF NOT EXISTS cw_integration_idx ON crm_webhooks(crm_integration_id);
      `);
      logger.info("[DB] Migrations applied v14 (crm_integrations, crm_tokens, crm_sync_logs, crm_field_mappings, crm_sync_jobs, crm_webhooks)");
    }

    // ── v15 — Enterprise Permissions / RBAC ──────────────────────────────────
    const v15 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='org_roles' LIMIT 1`);
    if (v15.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS org_roles (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          name text NOT NULL,
          slug text NOT NULL,
          description text,
          color text DEFAULT '#6b7280',
          is_system boolean DEFAULT false,
          is_custom boolean DEFAULT false,
          parent_role_id text,
          permissions jsonb DEFAULT '[]',
          member_count integer DEFAULT 0,
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS or_org_slug_idx ON org_roles(org_id, slug);

        CREATE TABLE IF NOT EXISTS role_permissions (
          id text PRIMARY KEY,
          role_id text NOT NULL REFERENCES org_roles(id) ON DELETE CASCADE,
          resource text NOT NULL,
          actions text[] DEFAULT '{}',
          conditions jsonb DEFAULT '{}',
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS rp_role_idx ON role_permissions(role_id);
        CREATE INDEX IF NOT EXISTS rp_resource_idx ON role_permissions(resource);

        CREATE TABLE IF NOT EXISTS team_member_roles (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          user_id text NOT NULL,
          role_id text NOT NULL REFERENCES org_roles(id) ON DELETE CASCADE,
          granted_by text,
          granted_at timestamptz DEFAULT now() NOT NULL,
          expires_at timestamptz,
          active boolean DEFAULT true
        );
        CREATE INDEX IF NOT EXISTS tmr_org_idx ON team_member_roles(org_id);
        CREATE INDEX IF NOT EXISTS tmr_user_idx ON team_member_roles(user_id);

        CREATE TABLE IF NOT EXISTS permission_logs (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          user_id text,
          action text NOT NULL,
          resource text NOT NULL,
          result text NOT NULL,
          ip_address text,
          user_agent text,
          metadata jsonb DEFAULT '{}',
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS pl_org_idx ON permission_logs(org_id);
        CREATE INDEX IF NOT EXISTS pl_created_idx ON permission_logs(created_at DESC);

        CREATE TABLE IF NOT EXISTS access_audits (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          user_id text NOT NULL,
          event_type text NOT NULL,
          resource text,
          details jsonb DEFAULT '{}',
          severity text DEFAULT 'info',
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS aa_org_idx ON access_audits(org_id);
        CREATE INDEX IF NOT EXISTS aa_user_idx ON access_audits(user_id);
        CREATE INDEX IF NOT EXISTS aa_created_idx ON access_audits(created_at DESC);

        INSERT INTO org_roles (id,org_id,name,slug,description,color,is_system,permissions) VALUES
        ('role_owner','default','Propriétaire','owner','Accès complet à tout','#f59e0b',true,'["*"]'),
        ('role_admin','default','Administrateur','admin','Gestion complète sauf billing','#ef4444',true,'["audits:*","monitors:*","reports:*","missions:*","team:*","settings:*","integrations:*"]'),
        ('role_manager','default','Manager','manager','Gestion des équipes et projets','#2563EB',true,'["audits:read,create","monitors:read,create","reports:read,create","missions:*","team:read"]'),
        ('role_seo_manager','default','SEO Manager','seo-manager','Gestion SEO complète','#22c55e',true,'["audits:*","missions:*","keywords:*","competitors:read"]'),
        ('role_analyst','default','Analyste','analyst','Lecture et analyse uniquement','#8b5cf6',true,'["audits:read","monitors:read","reports:read","missions:read"]'),
        ('role_client','default','Client Viewer','client-viewer','Vue client limitée','#06b6d4',true,'["reports:read","audits:read"]'),
        ('role_readonly','default','Lecture seule','read-only','Accès en lecture uniquement','#6b7280',true,'["*:read"]')
        ON CONFLICT DO NOTHING;
      `);
      logger.info("[DB] Migrations applied v15 (org_roles, role_permissions, team_member_roles, permission_logs, access_audits)");
    }

    // ── v16 — AI Market Intelligence ──────────────────────────────────────────
    const v16 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='market_trends' LIMIT 1`);
    if (v16.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS market_trends (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          keyword text NOT NULL,
          category text,
          trend_direction text NOT NULL DEFAULT 'stable',
          growth_rate numeric(6,2) DEFAULT 0,
          search_volume integer DEFAULT 0,
          competition_level text DEFAULT 'medium',
          opportunity_score integer DEFAULT 50,
          is_emerging boolean DEFAULT false,
          is_declining boolean DEFAULT false,
          geo text,
          industry text,
          data jsonb DEFAULT '{}',
          detected_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS mt_org_idx ON market_trends(org_id);
        CREATE INDEX IF NOT EXISTS mt_score_idx ON market_trends(opportunity_score DESC);
        CREATE INDEX IF NOT EXISTS mt_emerging_idx ON market_trends(is_emerging);

        CREATE TABLE IF NOT EXISTS market_opportunities (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          title text NOT NULL,
          description text,
          type text NOT NULL,
          score integer DEFAULT 50,
          estimated_traffic integer,
          estimated_revenue numeric(12,2),
          difficulty text DEFAULT 'medium',
          timeframe text,
          keywords text[],
          geo text,
          status text DEFAULT 'new',
          ai_summary text,
          actions jsonb DEFAULT '[]',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS mo_org_idx ON market_opportunities(org_id);
        CREATE INDEX IF NOT EXISTS mo_score_idx ON market_opportunities(score DESC);

        CREATE TABLE IF NOT EXISTS competitor_movements (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          competitor_domain text NOT NULL,
          movement_type text NOT NULL,
          description text,
          impact_level text DEFAULT 'medium',
          keywords_gained text[],
          keywords_lost text[],
          estimated_traffic_change integer,
          detected_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS cm_org_idx ON competitor_movements(org_id);
        CREATE INDEX IF NOT EXISTS cm_detected_idx ON competitor_movements(detected_at DESC);

        CREATE TABLE IF NOT EXISTS industry_signals (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          signal_type text NOT NULL,
          title text NOT NULL,
          description text,
          severity text DEFAULT 'info',
          category text,
          source text,
          data jsonb DEFAULT '{}',
          expires_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS is_org_idx ON industry_signals(org_id);
        CREATE INDEX IF NOT EXISTS is_created_idx ON industry_signals(created_at DESC);

        CREATE TABLE IF NOT EXISTS ai_market_reports (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          title text NOT NULL,
          report_type text NOT NULL DEFAULT 'weekly',
          summary text,
          opportunities jsonb DEFAULT '[]',
          threats jsonb DEFAULT '[]',
          recommendations jsonb DEFAULT '[]',
          trends_data jsonb DEFAULT '{}',
          generated_at timestamptz DEFAULT now() NOT NULL,
          period_start timestamptz,
          period_end timestamptz
        );
        CREATE INDEX IF NOT EXISTS amr_org_idx ON ai_market_reports(org_id);
        CREATE INDEX IF NOT EXISTS amr_generated_idx ON ai_market_reports(generated_at DESC);
      `);
      logger.info("[DB] Migrations applied v16 (market_trends, market_opportunities, competitor_movements, industry_signals, ai_market_reports)");
    }

    // ── v16b — Create missing market tables + patch market_trends columns ──────
    // market_trends may exist from v2 with fewer columns; create the rest.
    const v16b = await client.query(`SELECT 1 FROM information_schema.columns WHERE table_name='market_trends' AND column_name='growth_rate' LIMIT 1`);
    if (v16b.rowCount === 0) {
      // Patch market_trends (may already exist from v2)
      await client.query(`
        ALTER TABLE market_trends
          ADD COLUMN IF NOT EXISTS growth_rate numeric(6,2) DEFAULT 0,
          ADD COLUMN IF NOT EXISTS search_volume integer DEFAULT 0,
          ADD COLUMN IF NOT EXISTS competition_level text DEFAULT 'medium',
          ADD COLUMN IF NOT EXISTS opportunity_score integer DEFAULT 50,
          ADD COLUMN IF NOT EXISTS is_emerging boolean DEFAULT false,
          ADD COLUMN IF NOT EXISTS is_declining boolean DEFAULT false,
          ADD COLUMN IF NOT EXISTS geo text,
          ADD COLUMN IF NOT EXISTS industry text,
          ADD COLUMN IF NOT EXISTS detected_at timestamptz DEFAULT now(),
          ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
      `);

      // Create market_opportunities if it doesn't exist yet
      await client.query(`
        CREATE TABLE IF NOT EXISTS market_opportunities (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          title text NOT NULL,
          description text,
          type text NOT NULL,
          score integer DEFAULT 50,
          estimated_traffic integer,
          estimated_revenue numeric(12,2),
          difficulty text DEFAULT 'medium',
          timeframe text,
          keywords text[],
          geo text,
          status text DEFAULT 'new',
          ai_summary text,
          actions jsonb DEFAULT '[]',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS mo_org_idx ON market_opportunities(org_id);
        CREATE INDEX IF NOT EXISTS mo_score_idx ON market_opportunities(score DESC);

        CREATE TABLE IF NOT EXISTS competitor_movements (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          competitor_domain text NOT NULL,
          movement_type text NOT NULL,
          description text,
          impact_level text DEFAULT 'medium',
          keywords_gained text[],
          keywords_lost text[],
          estimated_traffic_change integer,
          detected_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS cm_org_idx ON competitor_movements(org_id);
        CREATE INDEX IF NOT EXISTS cm_detected_idx ON competitor_movements(detected_at DESC);

        CREATE TABLE IF NOT EXISTS industry_signals (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          signal_type text NOT NULL,
          title text NOT NULL,
          description text,
          severity text DEFAULT 'info',
          category text,
          source text,
          data jsonb DEFAULT '{}',
          expires_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS is_org_idx ON industry_signals(org_id);
        CREATE INDEX IF NOT EXISTS is_created_idx ON industry_signals(created_at DESC);

        CREATE TABLE IF NOT EXISTS ai_market_reports (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          title text NOT NULL,
          report_type text NOT NULL DEFAULT 'weekly',
          summary text,
          opportunities jsonb DEFAULT '[]',
          threats jsonb DEFAULT '[]',
          recommendations jsonb DEFAULT '[]',
          trends_data jsonb DEFAULT '{}',
          generated_at timestamptz DEFAULT now() NOT NULL,
          period_start timestamptz,
          period_end timestamptz
        );
        CREATE INDEX IF NOT EXISTS amr_org_idx ON ai_market_reports(org_id);
        CREATE INDEX IF NOT EXISTS amr_generated_idx ON ai_market_reports(generated_at DESC);
      `);
      logger.info("[DB] Migrations applied v16b (market_trends patched + market_opportunities/competitor_movements/industry_signals/ai_market_reports created)");
    }

    // ── v17 — AI Review Intelligence ──────────────────────────────────────────
    const v17 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='review_analysis' LIMIT 1`);
    if (v17.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS review_analysis (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          review_id text,
          source text NOT NULL DEFAULT 'google',
          author_name text,
          rating integer,
          review_text text,
          language text DEFAULT 'fr',
          sentiment text,
          sentiment_score numeric(4,3),
          emotions jsonb DEFAULT '[]',
          topics jsonb DEFAULT '[]',
          issues jsonb DEFAULT '[]',
          strengths jsonb DEFAULT '[]',
          ai_reply text,
          reply_status text DEFAULT 'pending',
          replied_at timestamptz,
          reviewed_at timestamptz DEFAULT now() NOT NULL,
          analyzed_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ra_org_idx ON review_analysis(org_id);
        CREATE INDEX IF NOT EXISTS ra_rating_idx ON review_analysis(rating);
        CREATE INDEX IF NOT EXISTS ra_sentiment_idx ON review_analysis(sentiment);
        CREATE INDEX IF NOT EXISTS ra_location_idx ON review_analysis(location_id);

        CREATE TABLE IF NOT EXISTS reputation_scores (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          score numeric(5,2) DEFAULT 0,
          avg_rating numeric(3,2) DEFAULT 0,
          total_reviews integer DEFAULT 0,
          positive_count integer DEFAULT 0,
          neutral_count integer DEFAULT 0,
          negative_count integer DEFAULT 0,
          response_rate numeric(5,2) DEFAULT 0,
          velocity numeric(5,2) DEFAULT 0,
          trend text DEFAULT 'stable',
          period_start timestamptz,
          period_end timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS rs_org_idx ON reputation_scores(org_id);

        CREATE TABLE IF NOT EXISTS ai_review_replies (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          review_id text NOT NULL,
          location_id text,
          reply_text text NOT NULL,
          tone text DEFAULT 'professional',
          language text DEFAULT 'fr',
          status text DEFAULT 'draft',
          published_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS arr_org_idx ON ai_review_replies(org_id);
        CREATE INDEX IF NOT EXISTS arr_review_idx ON ai_review_replies(review_id);

        CREATE TABLE IF NOT EXISTS review_alerts (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          alert_type text NOT NULL,
          severity text DEFAULT 'medium',
          title text NOT NULL,
          description text,
          review_id text,
          resolved boolean DEFAULT false,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS reval_org_idx ON review_alerts(org_id);
        CREATE INDEX IF NOT EXISTS reval_resolved_idx ON review_alerts(resolved);
      `);
      logger.info("[DB] Migrations applied v17 (review_analysis, reputation_scores, ai_review_replies, review_alerts)");
    }

    // ── v18 — AI GBP Posting ──────────────────────────────────────────────────
    const v18 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='gbp_posts' LIMIT 1`);
    if (v18.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS gbp_posts (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text NOT NULL,
          location_name text,
          post_type text NOT NULL DEFAULT 'standard',
          title text,
          content text NOT NULL,
          cta_type text,
          cta_url text,
          media_urls text[],
          event_title text,
          event_start timestamptz,
          event_end timestamptz,
          offer_code text,
          offer_terms text,
          status text NOT NULL DEFAULT 'draft',
          scheduled_at timestamptz,
          published_at timestamptz,
          google_post_id text,
          views integer DEFAULT 0,
          clicks integer DEFAULT 0,
          calls integer DEFAULT 0,
          ai_generated boolean DEFAULT false,
          seo_keywords text[],
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS gp_org_idx ON gbp_posts(org_id);
        CREATE INDEX IF NOT EXISTS gp_location_idx ON gbp_posts(location_id);
        CREATE INDEX IF NOT EXISTS gp_status_idx ON gbp_posts(status);
        CREATE INDEX IF NOT EXISTS gp_scheduled_idx ON gbp_posts(scheduled_at);

        CREATE TABLE IF NOT EXISTS gbp_post_queue (
          id text PRIMARY KEY,
          post_id text NOT NULL REFERENCES gbp_posts(id) ON DELETE CASCADE,
          org_id text NOT NULL DEFAULT 'default',
          location_id text NOT NULL,
          status text NOT NULL DEFAULT 'queued',
          attempt integer DEFAULT 0,
          max_attempts integer DEFAULT 3,
          scheduled_for timestamptz NOT NULL,
          processed_at timestamptz,
          error text,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS gpq_status_idx ON gbp_post_queue(status);
        CREATE INDEX IF NOT EXISTS gpq_scheduled_idx ON gbp_post_queue(scheduled_for);

        CREATE TABLE IF NOT EXISTS gbp_media_assets (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          filename text NOT NULL,
          url text NOT NULL,
          mime_type text,
          size_bytes integer,
          width integer,
          height integer,
          alt_text text,
          ai_caption text,
          tags text[],
          used_in_posts integer DEFAULT 0,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS gma_org_idx ON gbp_media_assets(org_id);

        CREATE TABLE IF NOT EXISTS gbp_location_groups (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          name text NOT NULL,
          description text,
          location_ids text[] DEFAULT '{}',
          active boolean DEFAULT true,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS glg_org_idx ON gbp_location_groups(org_id);
      `);
      logger.info("[DB] Migrations applied v18 (gbp_posts, gbp_post_queue, gbp_media_assets, gbp_location_groups)");
    }

    // ── v19 — Local Domination Maps ───────────────────────────────────────────
    const v19 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='local_heatmaps' LIMIT 1`);
    if (v19.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS local_heatmaps (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          name text NOT NULL,
          center_lat numeric(10,6) NOT NULL,
          center_lng numeric(10,6) NOT NULL,
          radius_km numeric(6,2) DEFAULT 5,
          keyword text NOT NULL,
          grid_size integer DEFAULT 7,
          status text NOT NULL DEFAULT 'pending',
          dominance_score integer DEFAULT 0,
          cells_data jsonb DEFAULT '[]',
          generated_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS lh_org_idx ON local_heatmaps(org_id);
        CREATE INDEX IF NOT EXISTS lh_location_idx ON local_heatmaps(location_id);

        CREATE TABLE IF NOT EXISTS geo_rankings (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          heatmap_id text REFERENCES local_heatmaps(id) ON DELETE CASCADE,
          lat numeric(10,6) NOT NULL,
          lng numeric(10,6) NOT NULL,
          keyword text NOT NULL,
          rank integer,
          rank_change integer DEFAULT 0,
          url text,
          place_id text,
          grid_x integer,
          grid_y integer,
          snapshot_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS gr_heatmap_idx ON geo_rankings(heatmap_id);
        CREATE INDEX IF NOT EXISTS gr_org_idx ON geo_rankings(org_id);
        CREATE INDEX IF NOT EXISTS gr_snapshot_idx ON geo_rankings(snapshot_at DESC);

        CREATE TABLE IF NOT EXISTS local_visibility_scores (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          keyword text NOT NULL,
          visibility_score integer DEFAULT 0,
          avg_rank numeric(5,2),
          top3_count integer DEFAULT 0,
          top10_count integer DEFAULT 0,
          out_of_pack integer DEFAULT 0,
          geo text,
          period_start timestamptz,
          period_end timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS lvs_org_idx ON local_visibility_scores(org_id);
        CREATE INDEX IF NOT EXISTS lvs_created_idx ON local_visibility_scores(created_at DESC);

        CREATE TABLE IF NOT EXISTS competitor_map_results (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          heatmap_id text REFERENCES local_heatmaps(id) ON DELETE SET NULL,
          place_id text NOT NULL,
          name text NOT NULL,
          lat numeric(10,6),
          lng numeric(10,6),
          address text,
          rating numeric(3,2),
          review_count integer DEFAULT 0,
          category text,
          authority_score integer DEFAULT 0,
          is_local_pack boolean DEFAULT false,
          distance_km numeric(6,2),
          detected_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS cmr_org_idx ON competitor_map_results(org_id);
        CREATE INDEX IF NOT EXISTS cmr_authority_idx ON competitor_map_results(authority_score DESC);

        CREATE TABLE IF NOT EXISTS geo_tracking_snapshots (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          heatmap_id text NOT NULL REFERENCES local_heatmaps(id) ON DELETE CASCADE,
          snapshot_date date NOT NULL,
          avg_rank numeric(5,2),
          dominance_score integer,
          top3_cells integer DEFAULT 0,
          total_cells integer DEFAULT 0,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS gts_heatmap_idx ON geo_tracking_snapshots(heatmap_id);

        CREATE TABLE IF NOT EXISTS local_opportunities (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          location_id text,
          title text NOT NULL,
          description text,
          opportunity_type text NOT NULL,
          score integer DEFAULT 50,
          geo text,
          lat numeric(10,6),
          lng numeric(10,6),
          radius_km numeric(6,2),
          keywords text[],
          status text DEFAULT 'new',
          ai_recommendation text,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS lo_org_idx ON local_opportunities(org_id);
        CREATE INDEX IF NOT EXISTS lo_score_idx ON local_opportunities(score DESC);
      `);
      logger.info("[DB] Migrations applied v19 (local_heatmaps, geo_rankings, local_visibility_scores, competitor_map_results, geo_tracking_snapshots, local_opportunities)");
    }

    // ── v20 — SSO Enterprise ──────────────────────────────────────────────────
    const v20 = await client.query(`SELECT 1 FROM information_schema.tables WHERE table_name='sso_providers' LIMIT 1`);
    if (v20.rowCount === 0) {
      await client.query(`
        CREATE TABLE IF NOT EXISTS sso_providers (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          provider_type text NOT NULL,
          name text NOT NULL,
          domain text,
          enabled boolean DEFAULT false,
          enforce_sso boolean DEFAULT false,
          metadata_url text,
          entity_id text,
          acs_url text,
          sso_url text,
          certificate text,
          client_id text,
          client_secret text,
          scopes text[],
          auto_provision boolean DEFAULT true,
          default_role_id text,
          config jsonb DEFAULT '{}',
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS sp_org_idx ON sso_providers(org_id);

        CREATE TABLE IF NOT EXISTS organization_auth (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          allowed_domains text[],
          enforce_sso boolean DEFAULT false,
          enforce_mfa boolean DEFAULT false,
          session_timeout_minutes integer DEFAULT 480,
          ip_whitelist text[],
          password_policy jsonb DEFAULT '{}',
          login_message text,
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );

        CREATE TABLE IF NOT EXISTS login_audits (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          user_id text,
          email text,
          provider text,
          success boolean NOT NULL,
          ip_address text,
          user_agent text,
          country text,
          city text,
          risk_score integer DEFAULT 0,
          failure_reason text,
          session_id text,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS la_org_idx ON login_audits(org_id);
        CREATE INDEX IF NOT EXISTS la_user_idx ON login_audits(user_id);
        CREATE INDEX IF NOT EXISTS la_created_idx ON login_audits(created_at DESC);
        CREATE INDEX IF NOT EXISTS la_success_idx ON login_audits(success);

        CREATE TABLE IF NOT EXISTS enterprise_sessions (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          user_id text NOT NULL,
          email text,
          provider text,
          ip_address text,
          user_agent text,
          is_active boolean DEFAULT true,
          last_active_at timestamptz DEFAULT now(),
          expires_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS es_org_idx ON enterprise_sessions(org_id);
        CREATE INDEX IF NOT EXISTS es_user_idx ON enterprise_sessions(user_id);
        CREATE INDEX IF NOT EXISTS es_active_idx ON enterprise_sessions(is_active);

        CREATE TABLE IF NOT EXISTS identity_mappings (
          id text PRIMARY KEY,
          org_id text NOT NULL DEFAULT 'default',
          sso_provider_id text REFERENCES sso_providers(id) ON DELETE CASCADE,
          external_id text NOT NULL,
          user_id text,
          email text NOT NULL,
          display_name text,
          role_id text,
          attributes jsonb DEFAULT '{}',
          last_login_at timestamptz,
          created_at timestamptz DEFAULT now() NOT NULL,
          updated_at timestamptz DEFAULT now() NOT NULL
        );
        CREATE INDEX IF NOT EXISTS im_org_idx ON identity_mappings(org_id);
        CREATE INDEX IF NOT EXISTS im_email_idx ON identity_mappings(email);
      `);
      logger.info("[DB] Migrations applied v20 (sso_providers, organization_auth, login_audits, enterprise_sessions, identity_mappings)");
    }

    // ── v21 — Add org_id to core tables (multi-tenant isolation) ─────────────
    // Each ALTER is wrapped in its own DO block so one failure doesn't abort the rest.
    const orgIdMigrations: Array<{ table: string; defaultVal?: string }> = [
      { table: "monitors" },
      { table: "audits" },
      { table: "keywords" },
      { table: "competitors" },
      { table: "reports" },
      { table: "activity_events" },
    ];
    for (const { table, defaultVal = "default" } of orgIdMigrations) {
      await client.query(`
        DO $$ BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_name = '${table}' AND column_name = 'org_id'
          ) THEN
            ALTER TABLE ${table} ADD COLUMN org_id text NOT NULL DEFAULT '${defaultVal}';
          END IF;
        EXCEPTION WHEN OTHERS THEN NULL;
        END $$;
      `);
    }
    logger.info("[DB] Migrations applied v21 (org_id columns on monitors, audits, keywords, competitors, reports, activity_events)");

    // ── v22 — Stripe webhook idempotency key ─────────────────────────────────
    await client.query(`
      DO $$ BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint
          WHERE conname = 'billing_events_stripe_event_id_key'
        ) THEN
          ALTER TABLE billing_events ADD CONSTRAINT billing_events_stripe_event_id_key UNIQUE (stripe_event_id);
        END IF;
      EXCEPTION WHEN OTHERS THEN NULL;
      END $$;
    `);
    logger.info("[DB] Migrations applied v22 (billing_events unique stripe_event_id for webhook idempotency)");

  } finally {
    client.release();
  }
}

export async function initDb(): Promise<void> {
  try {
    await runMigrations();

    // Seed mock/demo data only in development or preview mode.
    // In production, real data is created by users through the UI.
    if (isDemoMode()) {
    const existingMonitors = await db.select().from(monitorsTable).limit(1);
    if (existingMonitors.length === 0) {
      logger.info("[DB] Seeding monitors...");
      await db.insert(monitorsTable).values(
        MOCK_MONITORS.map((m) => ({
          id: m.id,
          name: m.name,
          url: m.url,
          status: m.status,
          uptime: m.uptime,
          latency: m.latency,
          lastCheck: m.lastCheck,
          alertEmail: m.alertEmail || "",
          frequency: "5min",
          lastAlertSent: null,
        }))
      );
    }

    const existingAudits = await db.select().from(auditsTable).limit(1);
    if (existingAudits.length === 0) {
      logger.info("[DB] Seeding audits...");
      await db.insert(auditsTable).values(
        MOCK_AUDITS.map((a) => ({
          id: a.id,
          url: a.url,
          score: a.score,
          status: a.status,
          speed: a.speed,
          date: a.date,
          issues: a.issues,
        }))
      );
    }

    const existingReports = await db.select().from(reportsTable).limit(1);
    if (existingReports.length === 0) {
      logger.info("[DB] Seeding reports...");
      await db.insert(reportsTable).values(
        MOCK_REPORTS.map((r) => ({
          id: r.id,
          name: r.name,
          type: r.type,
          date: r.date,
          pages: r.pages,
          shared: r.shared,
          auditId: r.auditId || "",
          whiteLabel: r.whiteLabel ?? false,
          pdfReady: r.pdfReady ?? false,
        }))
      );
    }

    const existingTeam = await db.select().from(teamMembersTable).limit(1);
    if (existingTeam.length === 0) {
      logger.info("[DB] Seeding team...");
      await db.insert(teamMembersTable).values(
        MOCK_TEAM.map((t) => ({
          id: t.id,
          name: t.name,
          email: t.email,
          role: t.role,
          joined: t.joined,
        }))
      );
    }

    const existingActivity = await db.select().from(activityEventsTable).limit(1);
    if (existingActivity.length === 0) {
      logger.info("[DB] Seeding activity events...");
      const now = Date.now();
      const SEED_ACTIVITIES = [
        { id: "ae1",  userId: "sophie", userName: "Sophie M.", type: "audit",   label: "Audit terminé : boulangerie-martin.fr (82/100)",         targetId: "a1",  targetType: "audit",   metadata: { score: 82, url: "boulangerie-martin.fr" },             createdAt: new Date(now - 12 * 60 * 1000) },
        { id: "ae2",  userId: "mael",   userName: "Maël H.",   type: "monitor", label: "Monitor DOWN : restaurant-lesoleil.com",                 targetId: "m2",  targetType: "monitor", metadata: { status: "down", url: "restaurant-lesoleil.com" },       createdAt: new Date(now - 44 * 60 * 1000) },
        { id: "ae3",  userId: "mael",   userName: "Maël H.",   type: "report",  label: "Rapport généré : Rapport Mai 2026",                     targetId: "r1",  targetType: "report",  metadata: { name: "Rapport Mai 2026" },                             createdAt: new Date(now - 3 * 3600 * 1000) },
        { id: "ae4",  userId: "lucas",  userName: "Lucas D.",  type: "audit",   label: "Audit lancé : plombier-paris.fr",                       targetId: "a3",  targetType: "audit",   metadata: { url: "plombier-paris.fr" },                             createdAt: new Date(now - 5 * 3600 * 1000) },
        { id: "ae5",  userId: "sophie", userName: "Sophie M.", type: "team",    label: "Invitation acceptée par lucas@client.com",               targetId: "t3",  targetType: "member",  metadata: { email: "lucas@client.com" },                            createdAt: new Date(now - 8 * 3600 * 1000) },
        { id: "ae6",  userId: "mael",   userName: "Maël H.",   type: "monitor", label: "Monitor UP : restaurant-lesoleil.com",                  targetId: "m2",  targetType: "monitor", metadata: { status: "up", url: "restaurant-lesoleil.com" },         createdAt: new Date(now - 24 * 3600 * 1000) },
        { id: "ae7",  userId: "sophie", userName: "Sophie M.", type: "report",  label: "Rapport partagé : Audit SEO complet — Le Soleil",       targetId: "r2",  targetType: "report",  metadata: { name: "Audit SEO complet — Restaurant Le Soleil" },    createdAt: new Date(now - 26 * 3600 * 1000) },
        { id: "ae8",  userId: "mael",   userName: "Maël H.",   type: "monitor", label: "Monitor créé : pharmacie-centre.fr",                    targetId: "m5",  targetType: "monitor", metadata: { url: "pharmacie-centre.fr" },                           createdAt: new Date(now - 30 * 3600 * 1000) },
        { id: "ae9",  userId: "lucas",  userName: "Lucas D.",  type: "audit",   label: "Audit terminé : coiffeur-lyon.com (75/100)",            targetId: "a4",  targetType: "audit",   metadata: { score: 75, url: "coiffeur-lyon.com" },                 createdAt: new Date(now - 36 * 3600 * 1000) },
        { id: "ae10", userId: "mael",   userName: "Maël H.",   type: "alert",   label: "Alerte déclenchée : latence coiffeur-lyon.com > 800ms", targetId: "r1",  targetType: "alert",   metadata: { metric: "latency", value: 890, threshold: 800 },       createdAt: new Date(now - 40 * 3600 * 1000) },
        { id: "ae11", userId: "sophie", userName: "Sophie M.", type: "audit",   label: "Audit lancé : restaurant-lesoleil.com",                 targetId: "a2",  targetType: "audit",   metadata: { url: "restaurant-lesoleil.com" },                       createdAt: new Date(now - 48 * 3600 * 1000) },
        { id: "ae12", userId: "mael",   userName: "Maël H.",   type: "report",  label: "Rapport généré : Export moniteurs Avril 2026",          targetId: "r3",  targetType: "report",  metadata: { name: "Export moniteurs Avril 2026" },                 createdAt: new Date(now - 52 * 3600 * 1000) },
        { id: "ae13", userId: "lucas",  userName: "Lucas D.",  type: "monitor", label: "Monitor supprimé : old-site-test.com",                  targetId: "mx1", targetType: "monitor", metadata: { url: "old-site-test.com" },                             createdAt: new Date(now - 60 * 3600 * 1000) },
        { id: "ae14", userId: "sophie", userName: "Sophie M.", type: "audit",   label: "Audit terminé : pharmacie-centre.fr (55/100)",          targetId: "a5",  targetType: "audit",   metadata: { score: 55, url: "pharmacie-centre.fr" },               createdAt: new Date(now - 72 * 3600 * 1000) },
        { id: "ae15", userId: "mael",   userName: "Maël H.",   type: "team",    label: "Rôle modifié : Sophie M. → Manager",                   targetId: "t2",  targetType: "member",  metadata: { name: "Sophie M.", role: "manager" },                   createdAt: new Date(now - 80 * 3600 * 1000) },
        { id: "ae16", userId: "mael",   userName: "Maël H.",   type: "alert",   label: "Règle d'alerte créée : Score SEO < 50",                 targetId: "ar1", targetType: "alert",   metadata: { type: "score", threshold: 50 },                        createdAt: new Date(now - 90 * 3600 * 1000) },
        { id: "ae17", userId: "sophie", userName: "Sophie M.", type: "report",  label: "Rapport partagé : Rapport mensuel global Q1 2026",      targetId: "r4",  targetType: "report",  metadata: { name: "Rapport mensuel global Q1 2026" },              createdAt: new Date(now - 96 * 3600 * 1000) },
        { id: "ae18", userId: "lucas",  userName: "Lucas D.",  type: "audit",   label: "Audit lancé : garage-auto-nice.com",                    targetId: "a6",  targetType: "audit",   metadata: { url: "garage-auto-nice.com" },                         createdAt: new Date(now - 100 * 3600 * 1000) },
        { id: "ae19", userId: "mael",   userName: "Maël H.",   type: "monitor", label: "Alerte email configurée : plombier-paris.fr",           targetId: "m3",  targetType: "monitor", metadata: { url: "plombier-paris.fr", channel: "email" },          createdAt: new Date(now - 110 * 3600 * 1000) },
        { id: "ae20", userId: "sophie", userName: "Sophie M.", type: "audit",   label: "Audit terminé : garage-auto-nice.com (90/100)",         targetId: "a6",  targetType: "audit",   metadata: { score: 90, url: "garage-auto-nice.com" },             createdAt: new Date(now - 120 * 3600 * 1000) },
      ];
      await db.insert(activityEventsTable).values(SEED_ACTIVITIES);
    }
    } // end isDemoMode() — no mock seeding in production

    // Always run: record downtime for monitors that are already marked "down" on startup.
    // This ensures downtime tracking is accurate after a server restart (not just demo).
    const serverStartTs = Date.now();
    const allMonitors = await db.select().from(monitorsTable);
    for (const monitor of allMonitors) {
      if (monitor.status === "down") {
        await db.insert(downtimeIncidentsTable)
          .values({ monitorId: monitor.id, downSince: serverStartTs })
          .onConflictDoNothing();
      }
    }

    logger.info("[DB] Database initialized");
  } catch (err) {
    logger.error({ err }, "[DB] Failed to initialize database");
    throw err;
  }
}

/**
 * Adds FK constraints between child tables and their parent tables.
 * Safe to run multiple times — each constraint is checked for existence first.
 * Orphan rows are cleaned up before adding constraints to avoid FK violations.
 */
export async function ensureFkConstraints(): Promise<void> {
  const client = await pool.connect();
  try {
    // monitor_checks → monitors (ON DELETE CASCADE)
    await client.query(`
      DO $$ BEGIN
        DELETE FROM monitor_checks
          WHERE monitor_id NOT IN (SELECT id FROM monitors);
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint WHERE conname = 'fk_monitor_checks_monitor_id'
        ) THEN
          ALTER TABLE monitor_checks
            ADD CONSTRAINT fk_monitor_checks_monitor_id
            FOREIGN KEY (monitor_id) REFERENCES monitors(id) ON DELETE CASCADE;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        NULL;  -- non-fatal; constraint may not be addable due to driver or version
      END $$;
    `);

    // downtime_incidents → monitors (ON DELETE CASCADE)
    await client.query(`
      DO $$ BEGIN
        DELETE FROM downtime_incidents
          WHERE monitor_id NOT IN (SELECT id FROM monitors);
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint WHERE conname = 'fk_downtime_incidents_monitor_id'
        ) THEN
          ALTER TABLE downtime_incidents
            ADD CONSTRAINT fk_downtime_incidents_monitor_id
            FOREIGN KEY (monitor_id) REFERENCES monitors(id) ON DELETE CASCADE;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END $$;
    `);

    logger.info("[DB] FK constraints verified");
  } finally {
    client.release();
  }
}

/**
 * Ensures all critical DB indexes exist on the live database.
 * Idempotent — safe to run on every server start. Uses IF NOT EXISTS so
 * it never fails on an already-indexed table and never blocks startup.
 */
export async function ensureDbIndexes(): Promise<void> {
  const client = await pool.connect();
  const indexes: Array<{ name: string; ddl: string }> = [
    // monitors
    { name: "monitors_org_id_idx",      ddl: "CREATE INDEX IF NOT EXISTS monitors_org_id_idx ON monitors (org_id)" },
    { name: "monitors_org_status_idx",  ddl: "CREATE INDEX IF NOT EXISTS monitors_org_status_idx ON monitors (org_id, status)" },
    // audits
    { name: "audits_org_id_idx",        ddl: "CREATE INDEX IF NOT EXISTS audits_org_id_idx ON audits (org_id)" },
    { name: "audits_org_created_idx",   ddl: "CREATE INDEX IF NOT EXISTS audits_org_created_idx ON audits (org_id, created_at)" },
    // keywords
    { name: "keywords_org_id_idx",      ddl: "CREATE INDEX IF NOT EXISTS keywords_org_id_idx ON keywords (org_id)" },
    { name: "keywords_org_keyword_idx", ddl: "CREATE INDEX IF NOT EXISTS keywords_org_keyword_idx ON keywords (org_id, keyword)" },
    // competitors
    { name: "competitors_org_id_idx",   ddl: "CREATE INDEX IF NOT EXISTS competitors_org_id_idx ON competitors (org_id)" },
    { name: "competitors_url_idx",      ddl: "CREATE INDEX IF NOT EXISTS competitors_url_idx ON competitors (url)" },
    // reports
    { name: "reports_org_id_idx",       ddl: "CREATE INDEX IF NOT EXISTS reports_org_id_idx ON reports (org_id)" },
    { name: "reports_created_at_idx",   ddl: "CREATE INDEX IF NOT EXISTS reports_created_at_idx ON reports (created_at)" },
    // activity_events
    { name: "activity_events_org_id_idx",    ddl: "CREATE INDEX IF NOT EXISTS activity_events_org_id_idx ON activity_events (org_id)" },
    { name: "activity_events_user_id_idx",   ddl: "CREATE INDEX IF NOT EXISTS activity_events_user_id_idx ON activity_events (user_id)" },
    { name: "activity_events_type_idx",      ddl: "CREATE INDEX IF NOT EXISTS activity_events_type_idx ON activity_events (type)" },
    { name: "activity_events_created_at_idx",ddl: "CREATE INDEX IF NOT EXISTS activity_events_created_at_idx ON activity_events (created_at)" },
    // monitor_checks
    { name: "monitor_checks_monitor_id_idx",      ddl: "CREATE INDEX IF NOT EXISTS monitor_checks_monitor_id_idx ON monitor_checks (monitor_id)" },
    { name: "monitor_checks_checked_at_idx",      ddl: "CREATE INDEX IF NOT EXISTS monitor_checks_checked_at_idx ON monitor_checks (checked_at)" },
    { name: "monitor_checks_monitor_checked_idx", ddl: "CREATE INDEX IF NOT EXISTS monitor_checks_monitor_checked_idx ON monitor_checks (monitor_id, checked_at)" },
    // missions (already has org_id column, add index if missing)
    { name: "missions_org_id_idx",      ddl: "CREATE INDEX IF NOT EXISTS missions_org_id_idx ON missions (org_id)" },
    { name: "missions_status_idx",      ddl: "CREATE INDEX IF NOT EXISTS missions_status_idx ON missions (status)" },
    { name: "missions_priority_idx",    ddl: "CREATE INDEX IF NOT EXISTS missions_priority_idx ON missions (priority_score DESC)" },
    // notifications
    { name: "notifications_org_id_idx", ddl: "CREATE INDEX IF NOT EXISTS notifications_org_id_idx ON notifications (org_id)" },
    // ai_usage_logs
    { name: "ai_monthly_usage_org_idx", ddl: "CREATE INDEX IF NOT EXISTS ai_monthly_usage_org_idx ON ai_monthly_usage (org_id, month)" },
  ];

  let created = 0;
  let skipped = 0;
  try {
    for (const { name, ddl } of indexes) {
      try {
        await client.query(ddl);
        created++;
      } catch {
        // Table may not exist yet (created by drizzle push later) — non-fatal
        skipped++;
        logger.debug({ index: name }, "[DB] Index skipped (table may not exist yet)");
      }
    }
    logger.info({ created, skipped, total: indexes.length }, "[DB] Indexes ensured");
  } finally {
    client.release();
  }
}

/**
 * Creates cron_history and worker_failures tables if they don't exist.
 * These power the /api/diagnostics/workers endpoint with real execution history.
 */
export async function ensureCronTables(): Promise<void> {
  const client = await pool.connect();
  try {
    // Each statement in its own DO block so pre-existing tables/columns don't abort.
    const stmts = [
      // cron_history — may already exist with ran_at column from an earlier migration
      `CREATE TABLE IF NOT EXISTS cron_history (
        id          SERIAL PRIMARY KEY,
        job_name    TEXT        NOT NULL,
        ran_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        finished_at TIMESTAMPTZ,
        status      TEXT        NOT NULL DEFAULT 'running',
        duration_ms INTEGER,
        error       TEXT,
        metadata    JSONB
      )`,
      `DO $$ BEGIN CREATE INDEX IF NOT EXISTS cron_history_job_name_idx ON cron_history (job_name); EXCEPTION WHEN OTHERS THEN NULL; END $$`,
      `DO $$ BEGIN CREATE INDEX IF NOT EXISTS cron_history_ran_at_idx ON cron_history (ran_at DESC); EXCEPTION WHEN OTHERS THEN NULL; END $$`,
      // worker_failures — may already exist without the resolved column
      `CREATE TABLE IF NOT EXISTS worker_failures (
        id          SERIAL PRIMARY KEY,
        worker_name TEXT        NOT NULL,
        failed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        error       TEXT,
        stack       TEXT,
        context     JSONB
      )`,
      // Add resolved columns if missing
      `DO $$ BEGIN ALTER TABLE worker_failures ADD COLUMN IF NOT EXISTS resolved BOOLEAN NOT NULL DEFAULT FALSE; EXCEPTION WHEN OTHERS THEN NULL; END $$`,
      `DO $$ BEGIN ALTER TABLE worker_failures ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMPTZ; EXCEPTION WHEN OTHERS THEN NULL; END $$`,
      `DO $$ BEGIN CREATE INDEX IF NOT EXISTS worker_failures_worker_name_idx ON worker_failures (worker_name); EXCEPTION WHEN OTHERS THEN NULL; END $$`,
      `DO $$ BEGIN CREATE INDEX IF NOT EXISTS worker_failures_failed_at_idx ON worker_failures (failed_at DESC); EXCEPTION WHEN OTHERS THEN NULL; END $$`,
      `DO $$ BEGIN CREATE INDEX IF NOT EXISTS worker_failures_resolved_idx ON worker_failures (resolved); EXCEPTION WHEN OTHERS THEN NULL; END $$`,
    ];
    for (const stmt of stmts) {
      await client.query(stmt);
    }
    logger.info("[DB] Cron tables ensured (cron_history, worker_failures)");
  } catch (err) {
    logger.warn({ err }, "[DB] Cron tables init failed (non-fatal)");
  } finally {
    client.release();
  }
}
