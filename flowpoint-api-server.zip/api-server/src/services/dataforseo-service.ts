import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { store } from "./store.js";
import { isDemoMode } from "./mock-data.js";

const DFS_LOGIN    = process.env["DATAFORSEO_LOGIN"]    || "";
const DFS_PASSWORD = process.env["DATAFORSEO_PASSWORD"] || "";
const DFS_BASE     = "https://api.dataforseo.com";
const REQUEST_TIMEOUT_MS = 20_000;
const CACHE_TTL_MS       = 6 * 60 * 60 * 1000; // 6h

export function isDataForSEOConfigured(): boolean {
  return Boolean(DFS_LOGIN && DFS_PASSWORD);
}

// ── In-memory cache ──────────────────────────────────────────────────────────

interface CacheEntry { data: unknown; expiresAt: number }
const memCache = new Map<string, CacheEntry>();

function cacheGet<T>(key: string): T | null {
  const entry = memCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) { memCache.delete(key); return null; }
  return entry.data as T;
}

function cacheSet(key: string, data: unknown, ttlMs = CACHE_TTL_MS): void {
  memCache.set(key, { data, expiresAt: Date.now() + ttlMs });
}

// ── Daily quota tracking (in-memory, resets at midnight UTC) ─────────────────

const quotaMap = new Map<string, { count: number; date: string }>();

const PLAN_LIMITS: Record<string, number> = {
  Free: 50, Standard: 50, Pro: 500, Agency: 5000,
};

export function checkAndIncrementQuota(orgId: string, plan: string): boolean {
  const today = new Date().toISOString().slice(0, 10);
  const entry  = quotaMap.get(orgId);
  const limit  = PLAN_LIMITS[plan] ?? 50;
  if (!entry || entry.date !== today) {
    quotaMap.set(orgId, { count: 1, date: today });
    return true;
  }
  if (entry.count >= limit) return false;
  entry.count += 1;
  return true;
}

export function getQuotaUsage(orgId: string, plan: string): { used: number; limit: number } {
  const today = new Date().toISOString().slice(0, 10);
  const entry  = quotaMap.get(orgId);
  const limit  = PLAN_LIMITS[plan] ?? 50;
  if (!entry || entry.date !== today) return { used: 0, limit };
  return { used: entry.count, limit };
}

// ── HTTP helper with retry + timeout ─────────────────────────────────────────

async function dfsPost<T = unknown>(path: string, body: unknown[], retries = 2): Promise<T> {
  const auth = Buffer.from(`${DFS_LOGIN}:${DFS_PASSWORD}`).toString("base64");
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const res = await fetch(`${DFS_BASE}${path}`, {
        method: "POST",
        signal: controller.signal,
        headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`DFS HTTP ${res.status}`);
      const json = (await res.json()) as { status_code?: number; tasks?: Array<{ result?: T[] }> };
      if (json.status_code && json.status_code !== 20000) throw new Error(`DFS API error ${json.status_code}`);
      return (json.tasks?.[0]?.result ?? []) as T;
    } catch (err) {
      if (attempt < retries) {
        await new Promise(r => setTimeout(r, 1000 * 2 ** attempt));
      } else {
        throw err;
      }
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error("DFS unreachable");
}

// ── Supabase / Postgres persistence helpers ───────────────────────────────────

async function upsertSEORow(table: string, id: string, orgId: string, data: Record<string, unknown>): Promise<void> {
  const client = await pool.connect();
  try {
    const keys   = ["id", "org_id", "cached_at", ...Object.keys(data)];
    const values = [id, orgId, new Date(), ...Object.values(data)];
    const placeholders = values.map((_, i) => `$${i + 1}`).join(", ");
    const updates = Object.keys(data).map(k => `${k} = EXCLUDED.${k}`).join(", ");
    await client.query(
      `INSERT INTO ${table} (${keys.join(", ")}) VALUES (${placeholders})
       ON CONFLICT (id) DO UPDATE SET ${updates}, cached_at = now()`,
      values,
    );
  } finally {
    client.release();
  }
}

// ── 1. Keyword Suggestions ────────────────────────────────────────────────────

export interface KeywordSuggestion {
  keyword: string; searchVolume: number | null; cpc: number | null; competition: number | null;
  difficulty: number | null; intent: string; opportunityScore: number | null; trend: number[];
}

export async function getKeywordSuggestions(
  keyword: string, location = "France", language = "fr",
): Promise<KeywordSuggestion[]> {
  const cacheKey = `kw:${keyword}:${location}:${language}`;
  const cached   = cacheGet<KeywordSuggestion[]>(cacheKey);
  if (cached) return cached;

  if (!isDataForSEOConfigured()) {
    const { isDemoMode } = await import("./mock-data.js");
    if (!isDemoMode()) return [];
    return getMockKeywords(keyword);
  }

  const raw = await dfsPost<Record<string, unknown>>("/v3/keywords_data/google_ads/keywords_for_keywords/live", [
    { keywords: [keyword], location_name: location, language_name: language },
  ]);

  const results: KeywordSuggestion[] = ((raw as unknown as Array<Record<string, unknown>>)?.[0] as Record<string, unknown> ?? { items: [] } as Record<string, unknown>)
    ? parseKeywordItems(raw)
    : getMockKeywords(keyword);

  cacheSet(cacheKey, results);
  await saveKeywords(results).catch(() => {});
  return results;
}

function parseKeywordItems(raw: unknown): KeywordSuggestion[] {
  const items = (raw as Record<string, unknown>[])?.[0] 
    ? (raw as Array<{ items?: Array<Record<string, unknown>> }>)?.[0]?.items ?? []
    : [];
  return items.slice(0, 50).map(item => {
    const sv  = item["search_volume"]      != null ? Number(item["search_volume"])      : null;
    const cpc = item["cpc"]               != null ? Number(item["cpc"])               : null;
    const comp= item["competition"]        != null ? Number(item["competition"])        : null;
    const diff= item["keyword_difficulty"] != null ? Number(item["keyword_difficulty"]) : null;
    return {
      keyword:          String(item["keyword"] ?? ""),
      searchVolume:     sv,
      cpc,
      competition:      comp,
      difficulty:       diff,
      intent:           classifyIntent(String(item["keyword"] ?? "")),
      opportunityScore: sv != null && cpc != null && comp != null
        ? calcOpportunityScore(sv, cpc, comp)
        : null,
      trend: Array.isArray(item["monthly_searches"])
        ? (item["monthly_searches"] as Array<{ search_volume?: number }>).map(m => m.search_volume ?? 0).reverse()
        : [],
    };
  });
}

function classifyIntent(kw: string): string {
  const k = kw.toLowerCase();
  if (k.startsWith("acheter") || k.startsWith("commander") || k.includes("prix") || k.includes("tarif")) return "transactional";
  if (k.startsWith("comment") || k.startsWith("qu'est") || k.startsWith("pourquoi")) return "informational";
  if (k.includes(" vs ") || k.includes("meilleur") || k.includes("comparatif")) return "commercial";
  return "navigational";
}

function calcOpportunityScore(vol: number, cpc: number, comp: number): number {
  return Math.min(100, Math.round((Math.log10(vol + 1) * 20) + (cpc * 5) - (comp * 30)));
}

async function saveKeywords(keywords: KeywordSuggestion[]): Promise<void> {
  for (const kw of keywords.slice(0, 10)) {
    await upsertSEORow("seo_keywords", `kw_${encodeURIComponent(kw.keyword)}`, "default", {
      keyword:          kw.keyword,
      search_volume:    kw.searchVolume,
      cpc:              kw.cpc,
      competition:      kw.competition,
      difficulty:       kw.difficulty,
      intent:           kw.intent,
      opportunity_score: kw.opportunityScore,
      raw_data:         JSON.stringify(kw),
    }).catch(() => {});
  }
}

function getMockKeywords(seed: string): KeywordSuggestion[] {
  // Only returns mock data in demo/dev mode.
  // In production without DataForSEO configured, callers receive an empty array.
  const bases = [`${seed}`, `meilleur ${seed}`, `${seed} prix`, `comment ${seed}`, `${seed} avis`, `${seed} pas cher`, `${seed} pro`, `agence ${seed}`, `${seed} local`, `${seed} 2025`];
  return bases.map((k, i) => ({
    keyword: k, searchVolume: 200 + (k.length * 47 + i * 113) % 4800,
    cpc: parseFloat(((k.length % 3) + 0.5).toFixed(2)), competition: parseFloat((0.3 + (i % 5) * 0.1).toFixed(2)),
    difficulty: 20 + (k.length + i * 7) % 60, intent: ["informational","commercial","transactional","navigational"][i % 4],
    opportunityScore: 30 + (k.length * 3 + i * 11) % 60, trend: Array.from({length:12}, (_, m) => 200 + (k.length * m * 13) % 1000),
  }));
}

// ── 2. SERP Intelligence ──────────────────────────────────────────────────────

export interface SERPResult {
  position: number; url: string; title: string; description: string;
  type: string; hasAIOverview: boolean; hasFeaturedSnippet: boolean;
  peopleAlsoAsk: string[]; volatility: number;
}

export async function getSERP(keyword: string, location = "France", language = "fr"): Promise<SERPResult[]> {
  const cacheKey = `serp:${keyword}:${location}`;
  const cached   = cacheGet<SERPResult[]>(cacheKey);
  if (cached) return cached;

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return [];
    return getMockSERP(keyword);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/serp/google/organic/live/advanced", [
      { keyword, location_name: location, language_name: language, depth: 10 },
    ]);
    const items = (raw as Array<{ items?: unknown[] }>)?.[0]?.items ?? [];
    const results: SERPResult[] = (items as Array<Record<string, unknown>>).slice(0, 10).map((item, i) => ({
      position: Number(item["rank_absolute"] ?? i + 1),
      url:      String(item["url"]   ?? ""),
      title:    String(item["title"] ?? ""),
      description: String(item["description"] ?? ""),
      type:        String(item["type"]         ?? "organic"),
      hasAIOverview: false, hasFeaturedSnippet: item["type"] === "featured_snippet",
      peopleAlsoAsk: [], volatility: 0,
    }));
    cacheSet(cacheKey, results);
    await saveSERPSnapshot(keyword, results).catch(() => {});
    return results;
  } catch {
    if (!isDemoMode()) return [];
    return getMockSERP(keyword);
  }
}

async function saveSERPSnapshot(keyword: string, results: SERPResult[]): Promise<void> {
  const id = `serp_${encodeURIComponent(keyword)}_${Date.now()}`;
  await upsertSEORow("seo_serp_snapshots", id, "default", {
    keyword, results: JSON.stringify(results), positions_count: results.length,
  }).catch(() => {});
}

function getMockSERP(keyword: string): SERPResult[] {
  return Array.from({length:10}, (_, i) => ({
    position: i + 1, url: `https://exemple${i+1}.fr/${keyword.toLowerCase().replace(/\s/g,"-")}`,
    title: `${keyword} — ${["Guide complet","Meilleur choix","Expert local","Prix et avis","Top 10","Solutions pro","Comparer","Tout savoir","Résultats rapides","Offre exclusive"][i]}`,
    description: `Découvrez nos solutions ${keyword} pour votre entreprise. Résultats garantis, devis gratuit.`,
    type: i === 0 ? "featured_snippet" : "organic", hasAIOverview: i < 2, hasFeaturedSnippet: i === 0,
    peopleAlsoAsk: i < 3 ? [`Qu'est-ce que ${keyword}?`, `Comment optimiser ${keyword}?`] : [],
    volatility: 0,
  }));
}

// ── 3. Competitors ────────────────────────────────────────────────────────────

export interface CompetitorData {
  domain: string; domainRating: number | null; organicKeywords: number | null;
  estimatedTraffic: number | null; keywordGap: number | null; backlinkGap: number | null;
  commonKeywords: number | null; topKeywords: string[];
}

export async function getCompetitors(domain: string): Promise<CompetitorData[]> {
  const cacheKey = `comps:${domain}`;
  const cached   = cacheGet<CompetitorData[]>(cacheKey);
  if (cached) return cached;

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return [];
    return getMockCompetitors(domain);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/domain_analytics/competitors/live", [
      { target: domain, language_name: "French", location_name: "France", limit: 10 },
    ]);
    const items = (raw as Array<{ items?: unknown[] }>)?.[0]?.items ?? [];
    const results: CompetitorData[] = (items as Array<Record<string, unknown>>).map(c => ({
      domain:           String(c["domain"]    ?? ""),
      domainRating:     c["domain_rank"]     != null ? Number(c["domain_rank"])     : null,
      organicKeywords:  c["keywords"]        != null ? Number(c["keywords"])        : null,
      estimatedTraffic: c["traffic"]         != null ? Number(c["traffic"])         : null,
      keywordGap:    null,
      backlinkGap:   null,
      commonKeywords:null,
      topKeywords: [],
    }));
    cacheSet(cacheKey, results);
    await saveCompetitors(domain, results).catch(() => {});
    return results;
  } catch {
    if (!isDemoMode()) return [];
    return getMockCompetitors(domain);
  }
}

async function saveCompetitors(domain: string, comps: CompetitorData[]): Promise<void> {
  for (const c of comps.slice(0, 5)) {
    await upsertSEORow("seo_competitors", `comp_${encodeURIComponent(domain)}_${c.domain}`, "default", {
      source_domain: domain, competitor_domain: c.domain,
      domain_rating: c.domainRating, organic_keywords: c.organicKeywords,
      estimated_traffic: c.estimatedTraffic, keyword_gap: c.keywordGap,
      raw_data: JSON.stringify(c),
    }).catch(() => {});
  }
}

function getMockCompetitors(domain: string): CompetitorData[] {
  return ["agenceseo.fr","referencement-pro.fr","digitalagency.fr","seoconseil.fr","visibilityfirst.com"].map((d, i) => ({
    domain: d, domainRating: 30 + i * 8, organicKeywords: 500 + i * 300,
    estimatedTraffic: 2000 + i * 1500, keywordGap: 150 + i * 50, backlinkGap: 80 + i * 30,
    commonKeywords: 20 + i * 15, topKeywords: [`seo ${domain}`, "référencement local", "audit seo"],
  }));
}

// ── 4. Backlinks ──────────────────────────────────────────────────────────────

export interface BacklinkData {
  totalBacklinks: number | null; totalDomains: number | null; domainRating: number | null;
  spamScore: number | null; newBacklinks: number | null; lostBacklinks: number | null;
  toxicBacklinks: number | null; topAnchors: Array<{anchor: string; count: number}>;
  topReferrers: Array<{domain: string; rating: number}>;
  available?: boolean;
  planRequired?: boolean;
}

const BL_UNAVAILABLE: BacklinkData = { totalBacklinks: null, totalDomains: null, domainRating: null, spamScore: null, newBacklinks: null, lostBacklinks: null, toxicBacklinks: null, topAnchors: [], topReferrers: [], available: false };

export async function getBacklinks(domain: string): Promise<BacklinkData> {
  const cacheKey = `bl:${domain}`;
  const cached   = cacheGet<BacklinkData>(cacheKey);
  if (cached) return cached;

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return { ...BL_UNAVAILABLE };
    return getMockBacklinks(domain);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/backlinks/summary/live", [
      { target: domain, include_subdomains: true, include_indirect_links: true },
    ]);
    const item = ((raw as unknown[]) ?? [])[0] as Record<string, unknown> ?? {};
    const result: BacklinkData = {
      totalBacklinks:  item["backlinks"]          != null ? Number(item["backlinks"])          : null,
      totalDomains:    item["referring_domains"]   != null ? Number(item["referring_domains"])   : null,
      domainRating:    item["domain_rank"]         != null ? Number(item["domain_rank"])         : null,
      spamScore:       item["spam_score"]          != null ? Number(item["spam_score"])          : null,
      newBacklinks:    item["new_backlinks"]       != null ? Number(item["new_backlinks"])       : null,
      lostBacklinks:   item["lost_backlinks"]      != null ? Number(item["lost_backlinks"])      : null,
      toxicBacklinks:  null,
      topAnchors:      [],
      topReferrers:    [],
      available:       true,
      planRequired:    false,
    };
    cacheSet(cacheKey, result);
    await saveBacklinks(domain, result).catch(() => {});
    return result;
  } catch (err) {
    const isPlanError = /DFS HTTP 40[34]/.test(String(err));
    if (!isDemoMode()) return { ...BL_UNAVAILABLE, planRequired: isPlanError };
    return getMockBacklinks(domain);
  }
}

async function saveBacklinks(domain: string, data: BacklinkData): Promise<void> {
  await upsertSEORow("seo_backlinks", `bl_${encodeURIComponent(domain)}`, "default", {
    domain,
    total_backlinks: data.totalBacklinks ?? null,
    total_domains:   data.totalDomains   ?? null,
    domain_rating:   data.domainRating   ?? null,
    spam_score:      data.spamScore      ?? null,
    new_backlinks:   data.newBacklinks   ?? null,
    lost_backlinks:  data.lostBacklinks  ?? null,
    toxic_backlinks: data.toxicBacklinks ?? null,
    raw_data: JSON.stringify(data),
  }).catch(() => {});
}

function getMockBacklinks(domain: string): BacklinkData {
  return {
    totalBacklinks: 847, totalDomains: 112,
    domainRating: 35, spamScore: 3,
    newBacklinks: 12, lostBacklinks: 5,
    toxicBacklinks: 8,
    topAnchors: [{anchor: domain, count: 210},{anchor: "cliquez ici", count: 87},{anchor: "en savoir plus", count: 54}],
    topReferrers: [{domain: "lemonde.fr", rating: 92},{domain: "leboncoin.fr", rating: 88},{domain: "trustpilot.com", rating: 82}],
  };
}

// ── 5. Domain Metrics ─────────────────────────────────────────────────────────

export interface DomainMetrics {
  domain: string; domainRating: number | null; organicTraffic: number | null;
  organicKeywords: number | null; paidTraffic: number | null; paidKeywords: number | null;
  backlinks: number | null; domainAge: string; isIndexed: boolean;
}

export async function getDomainMetrics(domain: string): Promise<DomainMetrics> {
  const cacheKey = `dm:${domain}`;
  const cached   = cacheGet<DomainMetrics>(cacheKey);
  if (cached) return cached;

  const DM_UNAVAILABLE: DomainMetrics = { domain, domainRating:null, organicTraffic:null, organicKeywords:null, paidTraffic:null, paidKeywords:null, backlinks:null, domainAge:"", isIndexed:false };

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return DM_UNAVAILABLE;
    return getMockDomainMetrics(domain);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/domain_analytics/whois/overview/live", [
      { domains: [domain] },
    ]);
    const item = ((raw as unknown[])?.[0] as Record<string, unknown>) ?? {};
    const result: DomainMetrics = {
      domain,
      domainRating:    item["domain_rank"]      != null ? Number(item["domain_rank"])      : null,
      organicTraffic:  item["organic_traffic"]  != null ? Number(item["organic_traffic"])  : null,
      organicKeywords: item["organic_keywords"] != null ? Number(item["organic_keywords"]) : null,
      paidTraffic:     item["paid_traffic"]     != null ? Number(item["paid_traffic"])     : null,
      paidKeywords:    item["paid_keywords"]    != null ? Number(item["paid_keywords"])    : null,
      backlinks:       item["backlinks"]        != null ? Number(item["backlinks"])        : null,
      domainAge: String(item["created_datetime"] ?? ""),
      isIndexed: true,
    };
    cacheSet(cacheKey, result);
    await saveDomainMetrics(result).catch(() => {});
    return result;
  } catch {
    if (!isDemoMode()) return DM_UNAVAILABLE;
    return getMockDomainMetrics(domain);
  }
}

async function saveDomainMetrics(data: DomainMetrics): Promise<void> {
  await upsertSEORow("seo_domain_metrics", `dm_${encodeURIComponent(data.domain)}`, "default", {
    domain: data.domain, domain_rating: data.domainRating,
    organic_traffic: data.organicTraffic, organic_keywords: data.organicKeywords,
    paid_traffic: data.paidTraffic, backlinks: data.backlinks,
    raw_data: JSON.stringify(data),
  }).catch(() => {});
}

function getMockDomainMetrics(domain: string): DomainMetrics {
  return {
    domain, domainRating: 35,
    organicTraffic: 3000, organicKeywords: 200,
    paidTraffic: 0, paidKeywords: 0, backlinks: 500,
    domainAge: "2018-06-15", isIndexed: true,
  };
}

// ── 6. Keyword Difficulty ─────────────────────────────────────────────────────

export async function getKeywordDifficulty(keyword: string): Promise<number | null> {
  const cacheKey = `kd:${keyword}`;
  const cached   = cacheGet<number | null>(cacheKey);
  if (cached !== null) return cached;

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return null;
    return 30 + (keyword.length % 50);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/keywords_data/google_ads/search_volume/live", [
      { keywords: [keyword], location_name: "France", language_name: "French" },
    ]);
    const item = ((raw as Array<{ items?: Array<Record<string,unknown>> }>)?.[0]?.items ?? [])[0] ?? {};
    const score = item["keyword_difficulty"] != null ? Number(item["keyword_difficulty"]) : null;
    cacheSet(cacheKey, score, 60 * 60 * 1000);
    return score;
  } catch {
    return null;
  }
}

// ── 7. Local Pack Rank ────────────────────────────────────────────────────────

export interface LocalPackResult {
  position: number; businessName: string; address: string;
  rating: number; reviewCount: number; phone: string; category: string;
}

export async function getLocalPackRank(keyword: string, location: string): Promise<LocalPackResult[]> {
  const cacheKey = `lp:${keyword}:${location}`;
  const cached   = cacheGet<LocalPackResult[]>(cacheKey);
  if (cached) return cached;

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return [];
    return getMockLocalPack(keyword);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/serp/google/local_pack/live/advanced", [
      { keyword: `${keyword} ${location}`, location_name: "France", language_name: "French" },
    ]);
    const items = ((raw as Array<{ items?: unknown[] }>)?.[0]?.items ?? []) as Array<Record<string,unknown>>;
    const results: LocalPackResult[] = items.slice(0, 10).map((item, i) => ({
      position:     Number(item["rank_absolute"] ?? i + 1),
      businessName: String(item["title"]         ?? ""),
      address:      String(item["address"]        ?? ""),
      rating:       Number(item["rating"]         ?? 0),
      reviewCount:  Number(item["reviews_count"]  ?? 0),
      phone:        String(item["phone"]          ?? ""),
      category:     String(item["category"]       ?? ""),
    }));
    cacheSet(cacheKey, results);
    await saveLocalRankings(keyword, location, results).catch(() => {});
    return results;
  } catch {
    if (!isDemoMode()) return [];
    return getMockLocalPack(keyword);
  }
}

async function saveLocalRankings(keyword: string, location: string, results: LocalPackResult[]): Promise<void> {
  const id = `lr_${encodeURIComponent(keyword)}_${encodeURIComponent(location)}`;
  await upsertSEORow("seo_local_rankings", id, "default", {
    keyword, location, results: JSON.stringify(results), count: results.length,
  }).catch(() => {});
}

function getMockLocalPack(keyword: string): LocalPackResult[] {
  return Array.from({length:7}, (_, i) => ({
    position: i + 1, businessName: `${keyword} — Entreprise ${i+1}`,
    address: `${10 + i * 5} rue du Commerce`, rating: 4.1,
    reviewCount: 15 + i * 10, phone: `06 00 00 00 0${i}`,
    category: keyword,
  }));
}

// ── 8. Google Maps Results ────────────────────────────────────────────────────

export async function getGoogleMapsResults(keyword: string, location: string): Promise<LocalPackResult[]> {
  return getLocalPackRank(keyword, location);
}

// ── 9. AI Visibility ──────────────────────────────────────────────────────────

export interface AIVisibilityData {
  keyword: string; chatgptMentions: number; geminiMentions: number;
  aiOverviewPresent: boolean; aiOverviewPosition: number;
  topAIMentionDomains: string[]; llmVisibilityScore: number;
}

export async function getAIVisibility(keyword: string): Promise<AIVisibilityData> {
  const cacheKey = `aiv:${keyword}`;
  const cached   = cacheGet<AIVisibilityData>(cacheKey);
  if (cached) return cached;

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return { keyword, chatgptMentions:0, geminiMentions:0, aiOverviewPresent:false, aiOverviewPosition:0, topAIMentionDomains:[], llmVisibilityScore:0 };
    return getMockAIVisibility(keyword);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/content_analysis/search/live", [
      { keyword, filters: [["content_info.content_quality_score", ">", 0]] },
    ]);
    const items = ((raw as Array<{ items?: unknown[] }>)?.[0]?.items ?? []) as Array<Record<string,unknown>>;
    const result: AIVisibilityData = {
      keyword, chatgptMentions: 0,
      geminiMentions: 0,
      aiOverviewPresent: items.length > 0, aiOverviewPosition: items.length > 0 ? 1 : 0,
      topAIMentionDomains: items.slice(0, 3).map(i => String(i["page_types"] ?? "")),
      llmVisibilityScore: 0,
    };
    cacheSet(cacheKey, result);
    await saveAIMentions(result).catch(() => {});
    return result;
  } catch {
    if (!isDemoMode()) return { keyword, chatgptMentions:0, geminiMentions:0, aiOverviewPresent:false, aiOverviewPosition:0, topAIMentionDomains:[], llmVisibilityScore:0 };
    return getMockAIVisibility(keyword);
  }
}

async function saveAIMentions(data: AIVisibilityData): Promise<void> {
  await upsertSEORow("seo_ai_mentions", `aim_${encodeURIComponent(data.keyword)}`, "default", {
    keyword: data.keyword, chatgpt_mentions: data.chatgptMentions,
    gemini_mentions: data.geminiMentions, ai_overview_present: data.aiOverviewPresent,
    llm_visibility_score: data.llmVisibilityScore, raw_data: JSON.stringify(data),
  }).catch(() => {});
}

function getMockAIVisibility(keyword: string): AIVisibilityData {
  return {
    keyword, chatgptMentions: 12, geminiMentions: 8,
    aiOverviewPresent: true, aiOverviewPosition: 2,
    topAIMentionDomains: ["wikipedia.org","hubspot.fr","semrush.com"],
    llmVisibilityScore: 42,
  };
}

// ── 10. Content Optimization ──────────────────────────────────────────────────

export interface ContentOptimizationData {
  url: string; score: number | null; wordCount: number | null; readabilityScore: number | null;
  keywordDensity: number | null; missingKeywords: string[]; recommendations: string[];
  topicCoverage: number | null; headingsCount: number | null; imagesWithAlt: number | null;
}

export async function getContentOptimization(url: string): Promise<ContentOptimizationData> {
  const cacheKey = `co:${url}`;
  const cached   = cacheGet<ContentOptimizationData>(cacheKey);
  if (cached) return cached;

  const CO_UNAVAILABLE: ContentOptimizationData = { url, score:null, wordCount:null, readabilityScore:null, keywordDensity:null, missingKeywords:[], recommendations:[], topicCoverage:null, headingsCount:null, imagesWithAlt:null };

  if (!isDataForSEOConfigured()) {
    if (!isDemoMode()) return CO_UNAVAILABLE;
    return getMockContentOpt(url);
  }

  try {
    const raw = await dfsPost<unknown>("/v3/on_page/content_parsing/live", [
      { url },
    ]);
    const item = ((raw as Array<{items?: Array<Record<string,unknown>>}>)?.[0]?.items ?? [])[0] ?? {};
    const meta = (item["meta"] as Record<string,unknown>) ?? {};
    const result: ContentOptimizationData = {
      url,
      score:            meta["content_score"]      != null ? Number(meta["content_score"])      : null,
      wordCount:        meta["content_length"]      != null ? Number(meta["content_length"])      : null,
      readabilityScore: meta["readability_score"]   != null ? Number(meta["readability_score"])   : null,
      keywordDensity:   null,
      missingKeywords:  [],
      recommendations:  buildRecommendations(meta),
      topicCoverage:    null,
      headingsCount:    meta["htags"]               != null ? Number(meta["htags"])               : null,
      imagesWithAlt:    null,
    };
    cacheSet(cacheKey, result, 30 * 60 * 1000);
    return result;
  } catch {
    if (!isDemoMode()) return CO_UNAVAILABLE;
    return getMockContentOpt(url);
  }
}

function buildRecommendations(meta: Record<string,unknown>): string[] {
  const recs: string[] = [];
  if (!meta["description"]) recs.push("Ajouter une meta description");
  if (!meta["title"]) recs.push("Optimiser la balise title");
  recs.push("Améliorer la densité des mots-clés cibles");
  recs.push("Ajouter des données structurées Schema.org");
  recs.push("Optimiser les images (attributs alt manquants)");
  return recs;
}

function getMockContentOpt(url: string): ContentOptimizationData {
  return {
    url, score: 58,
    wordCount: 800,
    readabilityScore: 55,
    keywordDensity: 1.2,
    missingKeywords: ["avis clients","devis gratuit","certification","livraison express"],
    recommendations: [
      "Ajouter une meta description optimisée",
      "Augmenter la densité du mot-clé principal (actuellement 0.8%)",
      "Améliorer la structure des titres H2/H3",
      "Ajouter des données structurées Schema.org LocalBusiness",
      "Optimiser les 4 images sans attribut alt",
    ],
    topicCoverage: 55,
    headingsCount: 4,
    imagesWithAlt: 2,
  };
}

// ── Auto-mission generation ───────────────────────────────────────────────────

export async function generateSEOMissions(orgId: string, domain: string): Promise<void> {
  try {
    const metrics = await getDomainMetrics(domain);
    const missions: Array<{title: string; description: string; priority: string; type: string}> = [];

    if (metrics.domainRating != null && metrics.domainRating < 30) {
      missions.push({
        title: "🔗 Renforcer l'autorité de domaine",
        description: `Votre Domain Rating est de ${metrics.domainRating}/100. Objectif : obtenir 10 backlinks de qualité en 30 jours.`,
        priority: "high", type: "backlink_building",
      });
    }
    if (metrics.organicKeywords != null && metrics.organicKeywords < 100) {
      missions.push({
        title: "📈 Expansion de couverture de mots-clés",
        description: `Vous êtes positionné sur ${metrics.organicKeywords} mots-clés. Objectif : tripler en 90 jours.`,
        priority: "medium", type: "keyword_opportunity",
      });
    }

    const client = await pool.connect();
    try {
      for (const m of missions) {
        await client.query(
          `INSERT INTO ai_generated_missions (id, org_id, title, description, priority, status, category, source)
           VALUES ($1,$2,$3,$4,$5,'pending',$6,'dataforseo') ON CONFLICT DO NOTHING`,
          [`msn_${Date.now()}_${crypto.randomUUID().replace(/-/g,"").slice(0,8)}`, orgId, m.title, m.description, m.priority, m.type],
        );
      }
    } finally {
      client.release();
    }

    if (missions.length > 0) {
      await store.logActivity({
        type: "mission",
        label: `${missions.length} mission(s) SEO générée(s) automatiquement pour ${domain}`,
        targetId: orgId, targetType: "org",
      }).catch(() => {});
    }
  } catch (e) {
    logger.warn({ e }, "[DataForSEO] generateSEOMissions error");
  }
}

// ── Bulk refresh for cron ─────────────────────────────────────────────────────

export async function refreshSEOCache(domain: string): Promise<void> {
  logger.info({ domain }, "[DataForSEO] Refreshing SEO cache");
  await Promise.allSettled([
    getDomainMetrics(domain),
    getBacklinks(domain),
    getCompetitors(domain),
  ]);
  memCache.delete(`dm:${domain}`);
  memCache.delete(`bl:${domain}`);
  memCache.delete(`comps:${domain}`);
  await Promise.allSettled([
    getDomainMetrics(domain),
    getBacklinks(domain),
    getCompetitors(domain),
  ]);
  logger.info({ domain }, "[DataForSEO] SEO cache refreshed");
}
