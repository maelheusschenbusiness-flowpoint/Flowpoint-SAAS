import { pool } from "@workspace/db";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface ReviewData {
  id: string;
  author_name: string;
  rating: number;
  review_text: string;
  language?: string;
  location_id?: string;
}

export async function analyzeReview(orgId: string, review: ReviewData): Promise<unknown> {
  const sentiment = review.rating >= 4 ? 'positive' : review.rating === 3 ? 'neutral' : 'negative';
  const sentimentScore = (review.rating - 1) / 4;
  let aiReply = '';
  const topics: string[] = [];
  const issues: string[] = [];
  const strengths: string[] = [];

  if (process.env.OPENAI_API_KEY && review.review_text) {
    try {
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        max_tokens: 500,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: 'Tu es un expert en réputation d\'entreprise. Analyse cet avis et génère une réponse professionnelle. Réponds en JSON avec: { topics: string[], issues: string[], strengths: string[], reply: string }' },
          { role: 'user', content: `Note: ${review.rating}/5\nAvis: "${review.review_text}"\nLangue: ${review.language || 'fr'}\n\nGénère une réponse professionnelle en ${review.language || 'français'}.` },
        ],
      });
      const parsed = JSON.parse(completion.choices[0]?.message?.content || '{}');
      aiReply = parsed.reply || '';
      topics.push(...(parsed.topics || []));
      issues.push(...(parsed.issues || []));
      strengths.push(...(parsed.strengths || []));
    } catch { /* non-blocking */ }
  }

  const id = `ra_${Date.now()}_${Math.random().toString(36).slice(2,5)}`;
  const client = await pool.connect();
  try {
    await client.query(`INSERT INTO review_analysis (id,org_id,location_id,review_id,author_name,rating,review_text,language,sentiment,sentiment_score,topics,issues,strengths,ai_reply,analyzed_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,now()) ON CONFLICT DO NOTHING`,
      [id, orgId, review.location_id||null, review.id, review.author_name, review.rating, review.review_text, review.language||'fr', sentiment, sentimentScore.toFixed(3), JSON.stringify(topics), JSON.stringify(issues), JSON.stringify(strengths), aiReply]);
    if (review.rating <= 2) {
      await createReviewAlert(orgId, review.location_id||null, id, review.rating);
    }
    const r = await client.query(`SELECT * FROM review_analysis WHERE id=$1`, [id]);
    return r.rows[0];
  } finally {
    client.release();
  }
}

export async function generateReply(orgId: string, reviewId: string, tone = 'professional', language = 'fr'): Promise<string> {
  const client = await pool.connect();
  try {
    const r = await client.query(`SELECT * FROM review_analysis WHERE id=$1 AND org_id=$2`, [reviewId, orgId]);
    const review = r.rows[0];
    if (!review) throw new Error("Avis introuvable");
    if (review.ai_reply) return review.ai_reply;

    let reply = `Merci pour votre avis, ${review.author_name || 'cher client'} !`;
    if (process.env.OPENAI_API_KEY) {
      try {
        const toneMap: Record<string, string> = { professional:'professionnel', friendly:'chaleureux', apologetic:'d\'excuses sincères', upsell:'valorisant nos services' };
        const completion = await openai.chat.completions.create({
          model: 'gpt-4o-mini',
          max_tokens: 300,
          messages: [
            { role: 'system', content: `Génère une réponse à un avis Google de ton ${toneMap[tone] || 'professionnel'}. Maximum 150 mots, en ${language}.` },
            { role: 'user', content: `Note: ${review.rating}/5\nAvis: "${review.review_text}"\nTon: ${tone}` },
          ],
        });
        reply = completion.choices[0]?.message?.content || reply;
      } catch { /* non-blocking */ }
    }
    await client.query(`UPDATE review_analysis SET ai_reply=$1 WHERE id=$2`, [reply, reviewId]);
    return reply;
  } finally {
    client.release();
  }
}

async function createReviewAlert(orgId: string, locationId: string | null, reviewId: string, rating: number): Promise<void> {
  const id = `reval_${Date.now()}_${Math.random().toString(36).slice(2,5)}`;
  const client = await pool.connect();
  try {
    await client.query(`INSERT INTO review_alerts (id,org_id,location_id,alert_type,severity,title,description,review_id) VALUES ($1,$2,$3,'negative_review',$4,$5,$6,$7) ON CONFLICT DO NOTHING`,
      [id, orgId, locationId, rating <= 1 ? 'critical' : 'high', `Avis négatif ${rating}⭐ détecté`, `Un avis ${rating}/5 nécessite une réponse urgente`, reviewId]);
  } catch { /* non-blocking */ } finally {
    client.release();
  }
}

export async function getReputationDashboard(orgId: string): Promise<Record<string, unknown>> {
  const client = await pool.connect();
  try {
    const [reviewsRes, alertsRes, scoreRes] = await Promise.all([
      client.query(`SELECT * FROM review_analysis WHERE org_id=$1 ORDER BY reviewed_at DESC LIMIT 30`, [orgId]),
      client.query(`SELECT * FROM review_alerts WHERE org_id=$1 AND resolved=false ORDER BY created_at DESC LIMIT 10`, [orgId]),
      client.query(`SELECT * FROM reputation_scores WHERE org_id=$1 ORDER BY created_at DESC LIMIT 1`, [orgId]),
    ]);
    const reviews = reviewsRes.rows;
    const totalReviews = reviews.length;
    const avgRating = totalReviews > 0 ? reviews.reduce((s: number, r: { rating: number }) => s + r.rating, 0) / totalReviews : 0;
    const sentimentDist = {
      positive: reviews.filter((r: { sentiment: string }) => r.sentiment === 'positive').length,
      neutral:  reviews.filter((r: { sentiment: string }) => r.sentiment === 'neutral').length,
      negative: reviews.filter((r: { sentiment: string }) => r.sentiment === 'negative').length,
    };
    const reputationScore = Math.round((avgRating / 5) * 100 * 0.7 + (sentimentDist.positive / Math.max(totalReviews, 1)) * 100 * 0.3);
    return {
      reviews, alerts: alertsRes.rows, score: scoreRes.rows[0] || null,
      stats: {
        totalReviews, avgRating: avgRating.toFixed(1), reputationScore, sentimentDist,
        responseRate: totalReviews > 0 ? Math.round(reviews.filter((r: { reply_status: string }) => r.reply_status === 'published').length / totalReviews * 100) : 0,
        pendingReplies: reviews.filter((r: { reply_status: string }) => r.reply_status === 'pending').length,
        criticalAlerts: alertsRes.rows.filter((a: { severity: string }) => a.severity === 'critical').length,
      },
    };
  } finally {
    client.release();
  }
}

export async function syncReviewsFromGBP(orgId: string, locationId: string): Promise<{ synced: number; analyzed: number }> {
  const client = await pool.connect();
  try {
    const gbpRes = await client.query(`SELECT * FROM google_reviews WHERE location_id=$1 LIMIT 50`, [locationId]).catch(() => ({ rows: [] }));
    const reviews = gbpRes.rows;
    let analyzed = 0;
    for (const rev of reviews.slice(0, 10)) {
      const existing = await client.query(`SELECT id FROM review_analysis WHERE review_id=$1 AND org_id=$2`, [rev.review_id || rev.id, orgId]);
      if (!existing.rows.length) {
        await analyzeReview(orgId, {
          id: rev.review_id || rev.id,
          author_name: rev.reviewer_display_name || 'Anonyme',
          rating: rev.star_rating_value || rev.rating || 3,
          review_text: rev.comment || '',
          language: 'fr',
          location_id: locationId,
        }).catch(() => {});
        analyzed++;
      }
    }
    return { synced: reviews.length, analyzed };
  } finally {
    client.release();
  }
}
