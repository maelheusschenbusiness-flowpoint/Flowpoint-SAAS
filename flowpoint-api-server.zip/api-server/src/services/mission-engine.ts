import { db, pool } from "@workspace/db";
import { logger } from "../lib/logger.js";
import { consumeAICredits } from "./ai-engine.js";
import { store } from "./store.js";

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export type MissionCategory = "seo" | "performance" | "conversion" | "local_seo" | "competitor";
export type MissionPriority = "critical" | "high" | "medium" | "low";
export type MissionStatus = "todo" | "inprogress" | "done" | "dismissed" | "stale";

interface SourceContext {
  gsc?: Record<string, unknown>;
  ga4?: Record<string, unknown>;
  gbp?: Record<string, unknown>;
  audit?: Record<string, unknown>;
  behavioral?: Record<string, unknown>;
  cro?: Record<string, unknown>;
  competitors?: Record<string, unknown>[];
  revenueLeak?: Record<string, unknown>[];
  monitorsDown?: { monitors: Array<{ name: string; url: string; status: string }> };
  gbpUnansweredReviews?: { reviews: Array<{ reviewer_name: string; rating: number; comment: string }> };
  ga4HighBounce?: { pages: Array<{ page: string; bounce_rate: number }> } | null;
  psiHighLcp?: { pages: Array<{ url: string; lcp: number; score: number; strategy: string }> };
}

interface MissionCandidate {
  title: string;
  description: string;
  category: MissionCategory;
  type: string;
  impact: string;
  effort: string;
  priorityScore: number;
  businessImpactScore: number;
  difficultyScore: number;
  estimatedTrafficImpact: number;
  estimatedSeoImpact: number;
  estimatedConversionImpact: number;
  estimatedRevenueImpact: number;
  aiQuickWin: boolean;
  sourceType: string;
  sourceData: Record<string, unknown>;
  steps: Array<{ id: string; title: string; done: boolean }>;
  dueDate: string;
}

function futureDue(days: number): string {
  const d = new Date(Date.now() + days * 86400000);
  return d.toISOString().slice(0, 10);
}

function uid(): string {
  return `m_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function makeSteps(titles: string[]): Array<{ id: string; title: string; done: boolean }> {
  return titles.map((title, i) => ({ id: `s_${i}`, title, done: false }));
}

async function collectContext(orgId: string): Promise<SourceContext> {
  const client = await pool.connect();
  const ctx: SourceContext = {};
  try {
    // GSC — top queries with low CTR
    const gsc = await client.query(`
      SELECT query, SUM(clicks) clicks, SUM(impressions) impressions,
             AVG(ctr) ctr, AVG(position) position
      FROM gsc_search_analytics
      WHERE org_id = $1 AND date >= NOW() - INTERVAL '30 days'
      GROUP BY query ORDER BY impressions DESC LIMIT 20
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.gsc = { queries: gsc.rows };

    // GA4 — basic traffic
    const ga4 = await client.query(`
      SELECT data FROM ga4_report_cache
      WHERE org_id = $1 ORDER BY cached_at DESC LIMIT 1
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.ga4 = ga4.rows[0]?.data || {};

    // GBP — location info
    const gbp = await client.query(`
      SELECT l.name, l.rating, l.review_count, l.status, l.metadata
      FROM google_locations l
      JOIN google_accounts a ON a.id = l.account_id
      WHERE a.org_id = $1 LIMIT 1
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.gbp = gbp.rows[0] || {};

    // Last audit
    const audit = await client.query(`
      SELECT score, issues, metadata FROM audits
      WHERE org_id = $1 ORDER BY created_at DESC LIMIT 1
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.audit = audit.rows[0] || {};

    // Behavioral insights
    const beh = await client.query(`
      SELECT insight_type, severity, title, description
      FROM behavior_insights WHERE org_id = $1
      ORDER BY created_at DESC LIMIT 10
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.behavioral = { insights: beh.rows };

    // CRO recommendations
    const cro = await client.query(`
      SELECT type, severity, title, description, estimated_impact
      FROM cro_recommendations WHERE org_id = $1
      ORDER BY created_at DESC LIMIT 10
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.cro = { recommendations: cro.rows };

    // Competitors
    const comps = await client.query(`
      SELECT domain, domain_rating, traffic_estimate, keywords_count
      FROM seo_competitors WHERE org_id = $1 ORDER BY domain_rating DESC LIMIT 5
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.competitors = comps.rows;

    // Revenue leaks
    const leaks = await client.query(`
      SELECT type, severity, title, estimated_loss_eur
      FROM revenue_leaks WHERE org_id = $1 AND status = 'detected'
      ORDER BY estimated_loss_eur DESC NULLS LAST LIMIT 5
    `, [orgId]).catch(() => ({ rows: [] }));
    ctx.revenueLeak = leaks.rows;

    // Monitors in downtime
    const monitorsDown = await client.query<{ name: string; url: string; status: string }>(`
      SELECT name, url, status FROM monitors WHERE status = 'down' LIMIT 10
    `).catch(() => ({ rows: [] as Array<{ name: string; url: string; status: string }> }));
    ctx.monitorsDown = { monitors: monitorsDown.rows };

    // GBP unanswered negative reviews
    const gbpBadReviews = await client.query<{ reviewer_name: string; rating: number; comment: string }>(`
      SELECT reviewer_name, rating, comment FROM gbp_reviews
      WHERE org_id = $1 AND reply_text IS NULL AND rating <= 3
      ORDER BY created_at DESC LIMIT 10
    `, [orgId]).catch(() => ({ rows: [] as Array<{ reviewer_name: string; rating: number; comment: string }> }));
    ctx.gbpUnansweredReviews = { reviews: gbpBadReviews.rows };

    // PageSpeed pages with LCP > 4s (poor — Google threshold for failing Core Web Vitals)
    const psiLcp = await client.query<{ url: string; lcp: number; score: number; strategy: string }>(`
      SELECT url, lcp::float lcp, score::int, strategy
      FROM pagespeed_results
      WHERE org_id = $1 AND lcp > 4 AND strategy = 'mobile'
      ORDER BY lcp DESC LIMIT 5
    `, [orgId]).catch(() => ({ rows: [] as Array<{ url: string; lcp: number; score: number; strategy: string }> }));
    ctx.psiHighLcp = { pages: psiLcp.rows };

    // GA4 high-bounce pages
    const ga4Bounce = await client.query<{ data: unknown }>(`
      SELECT data FROM ga4_report_cache
      WHERE org_id = $1 AND report_type = 'page_bounce'
      ORDER BY cached_at DESC LIMIT 1
    `, [orgId]).catch(() => ({ rows: [] }));
    if (ga4Bounce.rows[0]?.data) {
      try {
        const d = typeof ga4Bounce.rows[0].data === "string"
          ? JSON.parse(ga4Bounce.rows[0].data)
          : ga4Bounce.rows[0].data;
        ctx.ga4HighBounce = { pages: (d as Record<string, unknown[]>).pages || [] };
      } catch { ctx.ga4HighBounce = null; }
    } else {
      ctx.ga4HighBounce = null;
    }

  } finally {
    client.release();
  }
  return ctx;
}

function generateCandidates(ctx: SourceContext): MissionCandidate[] {
  const candidates: MissionCandidate[] = [];
  const now = Date.now();

  // ── SEO MISSIONS from GSC ──────────────────────────────────────────────────
  const queries = (ctx.gsc?.queries as Array<{ query: string; impressions: number; ctr: number; position: number; clicks: number }>) || [];
  const lowCtrQueries = queries.filter(q => q.impressions > 100 && Number(q.ctr) < 0.03);
  if (lowCtrQueries.length > 0) {
    const topQ = lowCtrQueries.slice(0, 3).map(q => q.query).join(", ");
    candidates.push({
      title: `Optimiser les balises Title/Meta pour améliorer le CTR (${lowCtrQueries.length} requêtes)`,
      description: `${lowCtrQueries.length} requêtes ont un CTR inférieur à 3% malgré un fort volume d'impressions. Requêtes ciblées : ${topQ}.`,
      category: "seo", type: "seo_meta",
      impact: "Élevé", effort: "Faible",
      priorityScore: 82, businessImpactScore: 78, difficultyScore: 25,
      estimatedTrafficImpact: Math.round(lowCtrQueries.reduce((s, q) => s + q.impressions * 0.04, 0)),
      estimatedSeoImpact: 8, estimatedConversionImpact: 0.5, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "gsc", sourceData: { lowCtrQueries: lowCtrQueries.slice(0, 5) },
      steps: makeSteps(["Identifier les pages concernées par ces requêtes", "Rédiger des balises Title attrayantes (< 60 car.)", "Rédiger des méta-descriptions avec CTA (< 155 car.)", "Tester les nouvelles balises", "Monitorer l'évolution du CTR sur 30 jours"]),
      dueDate: futureDue(7),
    });
  }

  const lowPosQueries = queries.filter(q => Number(q.position) > 10 && Number(q.position) < 20 && q.impressions > 200);
  if (lowPosQueries.length > 0) {
    candidates.push({
      title: `Booster ${lowPosQueries.length} mots-clés en position 11-20 vers la page 1`,
      description: `${lowPosQueries.length} mots-clés sont juste hors du top 10. Un effort de contenu et de netlinking ciblé peut les faire passer en première page.`,
      category: "seo", type: "seo_ranking",
      impact: "Très élevé", effort: "Moyen",
      priorityScore: 88, businessImpactScore: 85, difficultyScore: 45,
      estimatedTrafficImpact: Math.round(lowPosQueries.reduce((s, q) => s + q.impressions * 0.08, 0)),
      estimatedSeoImpact: 15, estimatedConversionImpact: 1.2, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "gsc", sourceData: { targetKeywords: lowPosQueries.slice(0, 5) },
      steps: makeSteps(["Auditer le contenu des pages ciblées", "Enrichir le contenu (longueur, champs sémantiques)", "Ajouter du maillage interne vers ces pages", "Obtenir 2-3 backlinks depuis des sources fiables", "Actualiser les données et exemples"]),
      dueDate: futureDue(21),
    });
  }

  // ── PERFORMANCE MISSIONS from audit ───────────────────────────────────────
  const auditScore = Number((ctx.audit as Record<string,unknown>)?.score) || 0;
  if (auditScore > 0 && auditScore < 70) {
    candidates.push({
      title: `Améliorer le score SEO technique de ${auditScore}/100 à 85+`,
      description: `L'audit révèle un score de ${auditScore}/100. Les problèmes techniques freinent l'indexation et le classement.`,
      category: "performance", type: "perf_audit",
      impact: "Élevé", effort: "Moyen",
      priorityScore: 85, businessImpactScore: 80, difficultyScore: 40,
      estimatedTrafficImpact: 300, estimatedSeoImpact: 85 - auditScore, estimatedConversionImpact: 0.8, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "audit", sourceData: { score: auditScore },
      steps: makeSteps(["Corriger les erreurs critiques identifiées", "Optimiser la vitesse de chargement (LCP < 2.5s)", "Résoudre les problèmes de crawl", "Corriger les balises manquantes", "Valider avec Google Search Console"]),
      dueDate: futureDue(14),
    });
  }

  // Core Web Vitals — only when real audit data exists
  if (auditScore > 0) {
    candidates.push({
      title: "Optimiser les Core Web Vitals (LCP, CLS, FID)",
      description: "Les Core Web Vitals sont un facteur de classement Google. Un LCP > 2.5s ou un CLS > 0.1 pénalise directement le positionnement.",
      category: "performance", type: "perf_vitals",
      impact: "Élevé", effort: "Élevé",
      priorityScore: 78, businessImpactScore: 75, difficultyScore: 60,
      estimatedTrafficImpact: 250, estimatedSeoImpact: 10, estimatedConversionImpact: 1.5, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "audit", sourceData: {},
      steps: makeSteps(["Mesurer LCP, CLS, FID via PageSpeed Insights", "Optimiser les images (format WebP, lazy loading)", "Réduire le JavaScript bloquant", "Précharger les polices critiques", "Mettre en cache les ressources statiques"]),
      dueDate: futureDue(14),
    });

    // Image optimization — only when audit exists
    candidates.push({
      title: "Optimiser toutes les images (WebP + compression)",
      description: "Les images non optimisées ralentissent les pages et dégradent l'expérience mobile. La compression sans perte réduit le poids de 40-70%.",
      category: "performance", type: "perf_images",
      impact: "Moyen", effort: "Faible",
      priorityScore: 65, businessImpactScore: 60, difficultyScore: 20,
      estimatedTrafficImpact: 100, estimatedSeoImpact: 5, estimatedConversionImpact: 0.8, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "audit", sourceData: {},
      steps: makeSteps(["Inventorier toutes les images du site", "Convertir en format WebP", "Compresser avec qualité 80%", "Ajouter le lazy loading", "Vérifier les attributs ALT"]),
      dueDate: futureDue(5),
    });
  }

  // ── CONVERSION MISSIONS from CRO ──────────────────────────────────────────
  const croRecs = (ctx.cro?.recommendations as Array<{ type: string; severity: string; title: string; description: string }>) || [];
  if (croRecs.length > 0) {
    const critical = croRecs.filter(r => r.severity === "critical" || r.severity === "high");
    if (critical.length > 0) {
      candidates.push({
        title: `Corriger ${critical.length} problèmes CRO critiques identifiés par l'IA`,
        description: `L'analyse de conversion a détecté ${critical.length} problèmes prioritaires : ${critical.slice(0, 2).map(r => r.title).join(", ")}.`,
        category: "conversion", type: "conversion_cro",
        impact: "Très élevé", effort: "Moyen",
        priorityScore: 90, businessImpactScore: 88, difficultyScore: 35,
        estimatedTrafficImpact: 0, estimatedSeoImpact: 0, estimatedConversionImpact: 2.5, estimatedRevenueImpact: 0,
        aiQuickWin: false, sourceType: "cro", sourceData: { recommendations: critical.slice(0, 3) },
        steps: makeSteps(["Analyser les pages à faible conversion", "Tester de nouveaux CTA (boutons, texte, couleur)", "Simplifier les formulaires (moins de champs)", "Ajouter des preuves sociales (avis, chiffres)", "A/B tester les changements"]),
        dueDate: futureDue(10),
      });
    }
  } else {
    candidates.push({
      title: "Optimiser les CTA et parcours de conversion",
      description: "Des CTAs flous ou mal positionnés réduisent le taux de conversion. Une analyse heatmap + A/B test peut augmenter les leads de 20-40%.",
      category: "conversion", type: "conversion_cta",
      impact: "Élevé", effort: "Moyen",
      priorityScore: 72, businessImpactScore: 80, difficultyScore: 40,
      estimatedTrafficImpact: 0, estimatedSeoImpact: 0, estimatedConversionImpact: 2.0, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "cro", sourceData: {},
      steps: makeSteps(["Analyser les heatmaps des pages clés", "Identifier les points de friction", "Rédiger 3 variantes de CTA", "Lancer un A/B test sur 14 jours", "Déployer la variante gagnante"]),
      dueDate: futureDue(14),
    });
  }

  // Behavioral friction
  const behInsights = (ctx.behavioral?.insights as Array<{ insight_type: string; severity: string; title: string }>) || [];
  const rageclickInsights = behInsights.filter(i => i.insight_type === "rage_click" || i.severity === "high");
  if (rageclickInsights.length > 0) {
    candidates.push({
      title: `Éliminer les frictions UX détectées (${rageclickInsights.length} anomalies comportementales)`,
      description: "L'analyse comportementale révèle des zones de frustration utilisateur : rage clicks, scrolls anormaux, abandons prématurés.",
      category: "conversion", type: "conversion_ux",
      impact: "Élevé", effort: "Moyen",
      priorityScore: 80, businessImpactScore: 75, difficultyScore: 35,
      estimatedTrafficImpact: 0, estimatedSeoImpact: 0, estimatedConversionImpact: 1.8, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "behavioral", sourceData: { insights: rageclickInsights.slice(0, 3) },
      steps: makeSteps(["Analyser les sessions enregistrées", "Identifier les éléments de rage click", "Corriger les éléments non-cliquables", "Améliorer la lisibilité mobile", "Re-tester avec un échantillon d'utilisateurs"]),
      dueDate: futureDue(7),
    });
  }

  // ── LOCAL SEO MISSIONS from GBP ───────────────────────────────────────────
  const gbpData = ctx.gbp as Record<string,unknown> || {};
  const gbpRating = Number(gbpData.rating) || 0;
  const reviewCount = Number(gbpData.review_count) || 0;

  if (Object.keys(gbpData).length > 0) {
    if (gbpRating < 4.0 || reviewCount < 20) {
      candidates.push({
        title: `Booster la réputation Google Business (${gbpRating.toFixed(1)}★, ${reviewCount} avis)`,
        description: `Votre profil Google Business a ${reviewCount} avis avec une note de ${gbpRating.toFixed(1)}/5. Les entreprises avec 50+ avis et 4.5+ étoiles captent 2x plus de leads locaux.`,
        category: "local_seo", type: "local_reviews",
        impact: "Très élevé", effort: "Faible",
        priorityScore: 92, businessImpactScore: 90, difficultyScore: 20,
        estimatedTrafficImpact: 150, estimatedSeoImpact: 12, estimatedConversionImpact: 3.0, estimatedRevenueImpact: 0,
        aiQuickWin: true, sourceType: "gbp", sourceData: { rating: gbpRating, reviewCount },
        steps: makeSteps(["Configurer un email automatique de demande d'avis post-achat", "Répondre à tous les avis existants (positifs + négatifs)", "Partager le lien d'avis Google sur les réseaux sociaux", "Former l'équipe à demander des avis en personne", "Surveiller les nouveaux avis et répondre sous 24h"]),
        dueDate: futureDue(3),
      });
    }

    candidates.push({
      title: "Compléter et optimiser le profil Google Business Profile",
      description: "Un profil GBP complet et optimisé améliore la visibilité dans le Pack Local Google. Photos, horaires, services, description et posts réguliers sont essentiels.",
      category: "local_seo", type: "local_gbp",
      impact: "Élevé", effort: "Faible",
      priorityScore: 75, businessImpactScore: 72, difficultyScore: 15,
      estimatedTrafficImpact: 200, estimatedSeoImpact: 10, estimatedConversionImpact: 2.0, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "gbp", sourceData: gbpData,
      steps: makeSteps(["Compléter la description avec mots-clés locaux", "Ajouter 10+ photos haute qualité", "Configurer les horaires à jour", "Lister tous les services/produits", "Publier un post Google Business par semaine"]),
      dueDate: futureDue(5),
    });
  } else {
    candidates.push({
      title: "Créer et optimiser une fiche Google Business Profile",
      description: "Une fiche GBP complète est indispensable pour apparaître dans les recherches locales et Google Maps. C'est la source #1 de leads locaux.",
      category: "local_seo", type: "local_gbp",
      impact: "Très élevé", effort: "Faible",
      priorityScore: 95, businessImpactScore: 92, difficultyScore: 15,
      estimatedTrafficImpact: 300, estimatedSeoImpact: 20, estimatedConversionImpact: 4.0, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "gbp", sourceData: {},
      steps: makeSteps(["Créer la fiche Google Business Profile", "Vérifier l'établissement par courrier ou téléphone", "Compléter toutes les informations (horaires, services, photos)", "Choisir les bonnes catégories principales et secondaires", "Lancer une campagne de collecte d'avis"]),
      dueDate: futureDue(3),
    });
  }

  // Local citations — only when GBP data confirms a local business
  if (Object.keys(gbpData).length > 0) {
    candidates.push({
      title: "Construire 15 citations locales (annuaires sectoriels)",
      description: "Les citations NAP (Nom, Adresse, Téléphone) cohérentes sur les annuaires locaux renforcent l'autorité locale et le classement dans le Pack Local.",
      category: "local_seo", type: "local_citations",
      impact: "Moyen", effort: "Moyen",
      priorityScore: 62, businessImpactScore: 65, difficultyScore: 30,
      estimatedTrafficImpact: 120, estimatedSeoImpact: 8, estimatedConversionImpact: 1.0, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "audit", sourceData: {},
      steps: makeSteps(["Identifier les 15 annuaires prioritaires du secteur", "Créer/corriger les fiches avec NAP cohérent", "Ajouter photos et description détaillée", "Vérifier la cohérence des informations", "Surveiller les doublons et les corriger"]),
      dueDate: futureDue(21),
    });
  }

  // ── COMPETITOR MISSIONS ────────────────────────────────────────────────────
  const topComp = (ctx.competitors || [])[0] as Record<string,unknown> | undefined;
  if (topComp) {
    candidates.push({
      title: `Combler l'écart de contenu vs ${topComp.domain} (DR ${topComp.domain_rating})`,
      description: `Votre concurrent principal ${topComp.domain} a un Domain Rating de ${topComp.domain_rating} et génère ~${topComp.traffic_estimate || "N/A"} visites/mois. Analyser et combler les gaps de contenu.`,
      category: "competitor", type: "competitor_content",
      impact: "Très élevé", effort: "Élevé",
      priorityScore: 86, businessImpactScore: 82, difficultyScore: 65,
      estimatedTrafficImpact: 400, estimatedSeoImpact: 12, estimatedConversionImpact: 1.5, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "competitor", sourceData: { competitor: topComp },
      steps: makeSteps(["Analyser le top 20 des pages du concurrent", "Identifier les mots-clés qu'il rankait et pas vous", "Créer 3 pages de contenu sur les sujets manquants", "Optimiser les pages existantes vs les siennes", "Surveiller les évolutions de classement"]),
      dueDate: futureDue(30),
    });
  }

  // Backlinks — only when competitor data confirms a competitive landscape
  if (topComp) {
    candidates.push({
      title: "Acquérir 10 backlinks depuis des sources de qualité",
      description: "Le netlinking reste un facteur de classement majeur. 10 backlinks DR 30+ depuis des sites du secteur peuvent améliorer significativement l'autorité de domaine.",
      category: "competitor", type: "competitor_backlinks",
      impact: "Élevé", effort: "Élevé",
      priorityScore: 74, businessImpactScore: 78, difficultyScore: 70,
      estimatedTrafficImpact: 200, estimatedSeoImpact: 18, estimatedConversionImpact: 0.5, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "competitor", sourceData: {},
      steps: makeSteps(["Identifier 30 sites cibles via l'analyse concurrents", "Créer un contenu de qualité pour le link bait", "Lancer des outreach emails personnalisés", "Proposer des guest posts sur 5 blogs du secteur", "Suivre les backlinks obtenus via Google Search Console"]),
      dueDate: futureDue(45),
    });
  }

  // ── REVENUE LEAK MISSIONS ──────────────────────────────────────────────────
  const leaks = (ctx.revenueLeak || []) as Array<{ type: string; severity: string; title: string; estimated_loss_eur: number }>;
  if (leaks.length > 0) {
    const totalLoss = leaks.reduce((s, l) => s + (l.estimated_loss_eur || 0), 0);
    candidates.push({
      title: `Colmater les fuites de revenus détectées (${leaks.length} problèmes · ${totalLoss > 0 ? `${totalLoss.toFixed(0)}€/mois` : "impact estimé"})`,
      description: `${leaks.length} fuites de revenus détectées par l'IA : ${leaks.slice(0, 2).map(l => l.title).join(", ")}.`,
      category: "conversion", type: "conversion_revenue",
      impact: "Très élevé", effort: "Moyen",
      priorityScore: 93, businessImpactScore: 95, difficultyScore: 40,
      estimatedTrafficImpact: 0, estimatedSeoImpact: 0, estimatedConversionImpact: 3.5, estimatedRevenueImpact: totalLoss,
      aiQuickWin: false, sourceType: "revenue_leak", sourceData: { leaks: leaks.slice(0, 3) },
      steps: makeSteps(["Analyser chaque fuite en détail", "Prioriser par impact financier", "Implémenter les correctifs critiques", "Mettre en place des alertes de surveillance", "Mesurer l'impact sur le CA après 30 jours"]),
      dueDate: futureDue(7),
    });
  }

  // ── PSI LCP > 4s MISSIONS ──────────────────────────────────────────────────
  const highLcpPages = ctx.psiHighLcp?.pages ?? [];
  if (highLcpPages.length > 0) {
    const worst = highLcpPages[0]!;
    candidates.push({
      title: `Corriger le LCP critique (${worst.lcp.toFixed(1)}s) sur ${highLcpPages.length} page(s) mobile`,
      description: `${highLcpPages.length} page(s) ont un LCP supérieur à 4s sur mobile (seuil Google "Poor"). Un LCP > 4s pénalise directement le classement et augmente le taux de rebond.`,
      category: "performance", type: "perf_lcp",
      impact: "Très élevé", effort: "Moyen",
      priorityScore: 95, businessImpactScore: 90, difficultyScore: 50,
      estimatedTrafficImpact: Math.round(highLcpPages.length * 150),
      estimatedSeoImpact: 12, estimatedConversionImpact: 2.0, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "pagespeed", sourceData: { pages: highLcpPages.slice(0, 3) },
      steps: makeSteps([
        `Mesurer via PageSpeed Insights la page la plus lente (${worst.url})`,
        "Identifier l'élément LCP (image hero, bloc texte, vidéo) et son temps de chargement",
        "Précharger la ressource LCP via <link rel=preload> ou inline CSS",
        "Compresser / convertir en WebP / dimensionner l'image LCP",
        "Vérifier l'amélioration avec PageSpeed Insights (cible : LCP < 2.5s)",
      ]),
      dueDate: futureDue(7),
    });
  }

  // ── KEYWORDS DEEP-BURIED (position > 20) ──────────────────────────────────
  const deepBuryQueries = queries.filter(q => Number(q.position) > 20 && Number(q.impressions) > 50);
  if (deepBuryQueries.length > 0) {
    candidates.push({
      title: `Récupérer ${deepBuryQueries.length} mots-clés enfouis en page 3+ (position > 20)`,
      description: `${deepBuryQueries.length} requêtes obtiennent des impressions mais sont classées après la page 2. Un travail de contenu ciblé peut les faire remonter vers la page 1.`,
      category: "seo", type: "seo_ranking_deep",
      impact: "Élevé", effort: "Élevé",
      priorityScore: 76, businessImpactScore: 72, difficultyScore: 65,
      estimatedTrafficImpact: Math.round(deepBuryQueries.slice(0, 10).reduce((s, q) => s + Number(q.impressions) * 0.05, 0)),
      estimatedSeoImpact: 10, estimatedConversionImpact: 0.8, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "gsc",
      sourceData: { keywords: deepBuryQueries.slice(0, 5).map(q => ({ query: q.query, position: Number(q.position) })) },
      steps: makeSteps([
        "Identifier les 5 requêtes les plus prometteuses (impressions élevées, difficulté faible)",
        "Analyser la page actuellement positionnée pour ces requêtes",
        "Enrichir le contenu : longueur, champs sémantiques, données structurées",
        "Obtenir 2-3 backlinks internes et externes vers chaque page",
        "Suivre l'évolution des positions sur 30 jours via GSC",
      ]),
      dueDate: futureDue(30),
    });
  }

  // Schema.org — only when GSC queries or GBP data is available
  if (queries.length > 0 || Object.keys(gbpData).length > 0) {
    candidates.push({
      title: "Implémenter le balisage Schema.org (FAQ, LocalBusiness, Review)",
      description: "Les données structurées permettent d'obtenir des Rich Snippets dans les SERPs, augmentant le CTR de 20-30% sans changer les positions.",
      category: "seo", type: "seo_schema",
      impact: "Élevé", effort: "Faible",
      priorityScore: 70, businessImpactScore: 68, difficultyScore: 25,
      estimatedTrafficImpact: 150, estimatedSeoImpact: 6, estimatedConversionImpact: 1.0, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "audit", sourceData: {},
      steps: makeSteps(["Identifier les pages éligibles aux Rich Snippets", "Implémenter Schema FAQ sur les pages question/réponse", "Ajouter LocalBusiness sur la page contact", "Implémenter Review schema si applicable", "Valider avec l'outil de test de données structurées Google"]),
      dueDate: futureDue(10),
    });
  }

  // Internal linking — only when GSC signals real pages exist
  if (queries.length > 0) {
    candidates.push({
      title: "Renforcer le maillage interne vers les pages stratégiques",
      description: "Un bon maillage interne distribue le PageRank vers les pages importantes et améliore l'exploration par les robots de Google.",
      category: "seo", type: "seo_internal_links",
      impact: "Moyen", effort: "Faible",
      priorityScore: 58, businessImpactScore: 55, difficultyScore: 20,
      estimatedTrafficImpact: 80, estimatedSeoImpact: 7, estimatedConversionImpact: 0.4, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "audit", sourceData: {},
      steps: makeSteps(["Cartographier l'architecture du site", "Identifier les pages orphelines", "Ajouter 3+ liens contextuels vers chaque page clé", "Vérifier les textes d'ancre (descriptifs, pas génériques)", "Soumettre le sitemap mis à jour"]),
      dueDate: futureDue(14),
    });
  }

  // ── MONITOR DOWNTIME MISSIONS ──────────────────────────────────────────────
  const downMonitors = ctx.monitorsDown?.monitors ?? [];
  if (downMonitors.length > 0) {
    candidates.push({
      title: `Résoudre ${downMonitors.length} monitor(s) DOWN — fiabilité critique`,
      description: `${downMonitors.length} site(s) sont inaccessibles : ${downMonitors.slice(0, 2).map(m => m.name || m.url).join(", ")}. Chaque minute d'indisponibilité coûte des visiteurs et nuit au SEO.`,
      category: "performance", type: "monitor_downtime",
      impact: "Très élevé", effort: "Faible",
      priorityScore: 98, businessImpactScore: 95, difficultyScore: 15,
      estimatedTrafficImpact: 0, estimatedSeoImpact: 5, estimatedConversionImpact: 0, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "monitor", sourceData: { monitors: downMonitors.slice(0, 3) },
      steps: makeSteps([
        "Vérifier l'hébergeur et le statut DNS du site concerné",
        "Tester l'accès depuis plusieurs réseaux (4G, desktop)",
        "Contacter l'hébergeur si le serveur est hors ligne",
        "Corriger la configuration SSL ou la redirection si applicable",
        "Surveiller l'uptime pendant 1h après la correction",
      ]),
      dueDate: futureDue(0),
    });
  }

  // ── GBP UNANSWERED NEGATIVE REVIEWS ───────────────────────────────────────
  const unansweredReviews = ctx.gbpUnansweredReviews?.reviews ?? [];
  if (unansweredReviews.length > 0) {
    candidates.push({
      title: `Répondre aux ${unansweredReviews.length} avis Google négatifs sans réponse`,
      description: `${unansweredReviews.length} avis avec note ≤ 3★ n'ont pas encore de réponse de votre part. Répondre sous 24h améliore la note perçue et le référencement local.`,
      category: "local_seo", type: "local_reviews_response",
      impact: "Élevé", effort: "Faible",
      priorityScore: 90, businessImpactScore: 85, difficultyScore: 10,
      estimatedTrafficImpact: 80, estimatedSeoImpact: 6, estimatedConversionImpact: 1.5, estimatedRevenueImpact: 0,
      aiQuickWin: true, sourceType: "gbp_reviews", sourceData: { count: unansweredReviews.length },
      steps: makeSteps([
        "Lire chaque avis négatif avec attention",
        "Préparer une réponse empathique et professionnelle",
        "Proposer une solution concrète ou un contact direct",
        "Publier les réponses sur Google Business Profile",
        "Surveiller les avis 7 jours pour détecter toute réaction",
      ]),
      dueDate: futureDue(1),
    });
  }

  // ── GA4 HIGH-BOUNCE PAGES ──────────────────────────────────────────────────
  const highBouncePages = (ctx.ga4HighBounce?.pages ?? []).filter(p => p.bounce_rate > 0.80);
  if (highBouncePages.length > 0) {
    candidates.push({
      title: `Réduire le taux de rebond sur ${highBouncePages.length} page(s) GA4 (>80%)`,
      description: `${highBouncePages.length} page(s) ont un taux de rebond supérieur à 80% selon GA4. Améliorer le contenu et les CTAs peut doubler le temps passé et les conversions.`,
      category: "conversion", type: "conversion_bounce",
      impact: "Élevé", effort: "Moyen",
      priorityScore: 84, businessImpactScore: 80, difficultyScore: 35,
      estimatedTrafficImpact: 0, estimatedSeoImpact: 5, estimatedConversionImpact: 2.0, estimatedRevenueImpact: 0,
      aiQuickWin: false, sourceType: "ga4", sourceData: { pages: highBouncePages.slice(0, 3) },
      steps: makeSteps([
        "Identifier les pages avec le taux de rebond le plus élevé",
        "Analyser le contenu above-the-fold et les CTA visibles",
        "Améliorer le titre H1 et l'introduction (< 3 secondes d'impact)",
        "Ajouter des liens internes vers des contenus connexes",
        "Mesurer l'impact après 14 jours via GA4",
      ]),
      dueDate: futureDue(10),
    });
  }

  return candidates;
}

async function callOpenAI(systemPrompt: string, userPrompt: string): Promise<string | null> {
  if (!OPENAI_API_KEY) return null;
  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        max_tokens: 2000,
        temperature: 0.3,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });
    if (!res.ok) return null;
    const json = await res.json() as { choices: Array<{ message: { content: string } }> };
    return json.choices?.[0]?.message?.content || null;
  } catch {
    return null;
  }
}

async function enrichWithAI(candidates: MissionCandidate[], orgId: string): Promise<MissionCandidate[]> {
  if (!OPENAI_API_KEY) return candidates;

  const summary = candidates.slice(0, 8).map((c, i) =>
    `${i + 1}. [${c.category.toUpperCase()}] ${c.title} — Impact: ${c.impact}, Effort: ${c.effort}, Score: ${c.priorityScore}`
  ).join("\n");

  const systemPrompt = `Tu es un expert SEO et Growth Hacking qui génère des plans d'action ultra-précis pour des PME et TPE locales. Tu réponds TOUJOURS en JSON valide uniquement, sans markdown, sans explication.`;

  const userPrompt = `Voici ${candidates.length} missions SEO/Marketing identifiées pour un client :

${summary}

Pour chaque mission (dans l'ordre), génère :
1. Une explication IA courte (2-3 phrases, ton coach SEO expert)
2. Un résumé de l'impact business (1 phrase avec chiffres)

Réponds avec ce JSON exact (tableau de ${Math.min(candidates.length, 8)} objets) :
[{"explanation": "...", "summary": "..."}]`;

  try {
    const raw = await callOpenAI(systemPrompt, userPrompt);
    if (!raw) return candidates;
    const cleanRaw = raw.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const enrichments = JSON.parse(cleanRaw) as Array<{ explanation: string; summary: string }>;
    return candidates.map((c, i) => {
      const e = enrichments[i];
      if (!e) return c;
      return { ...c, aiExplanation: e.explanation || undefined, aiSummary: e.summary || undefined };
    });
  } catch {
    return candidates;
  }
}

async function upsertMissions(candidates: MissionCandidate[], orgId: string): Promise<number> {
  const client = await pool.connect();
  let upserted = 0;
  try {
    for (const c of candidates) {
      const existingRes = await client.query(
        `SELECT id, status FROM missions WHERE org_id = $1 AND title = $2 LIMIT 1`,
        [orgId, c.title]
      );
      const existing = existingRes.rows[0];

      if (existing) {
        if (existing.status === "done" || existing.status === "dismissed") continue;
        await client.query(`
          UPDATE missions SET
            description = $1, priority = $2, priority_score = $3,
            impact = $4, effort = $5, business_impact_score = $6,
            difficulty_score = $7, estimated_traffic_impact = $8,
            estimated_seo_impact = $9, estimated_conversion_impact = $10,
            estimated_revenue_impact = $11, ai_explanation = $12,
            ai_quick_win = $13, source_data = $14, last_refreshed_at = NOW(),
            updated_at = NOW()
          WHERE id = $15
        `, [
          c.description,
          c.priorityScore >= 90 ? "critical" : c.priorityScore >= 75 ? "high" : c.priorityScore >= 50 ? "medium" : "low",
          c.priorityScore, c.impact, c.effort, c.businessImpactScore,
          c.difficultyScore, c.estimatedTrafficImpact, c.estimatedSeoImpact,
          c.estimatedConversionImpact, c.estimatedRevenueImpact,
          (c as MissionCandidate & { aiExplanation?: string }).aiExplanation || null,
          c.aiQuickWin, JSON.stringify(c.sourceData), existing.id,
        ]);
      } else {
        const id = uid();
        const priority: MissionPriority = c.priorityScore >= 90 ? "critical" : c.priorityScore >= 75 ? "high" : c.priorityScore >= 50 ? "medium" : "low";
        await client.query(`
          INSERT INTO missions (
            id, org_id, title, description, category, type, priority, priority_score,
            status, impact, effort, estimated_traffic_impact, estimated_revenue_impact,
            estimated_seo_impact, estimated_conversion_impact, difficulty_score,
            business_impact_score, ai_explanation, ai_quick_win, ai_summary,
            source_type, source_data, steps, due_date, last_refreshed_at, created_at, updated_at
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,NOW(),NOW(),NOW())
        `, [
          id, orgId, c.title, c.description, c.category, c.type, priority, c.priorityScore,
          "todo", c.impact, c.effort, c.estimatedTrafficImpact, c.estimatedRevenueImpact,
          c.estimatedSeoImpact, c.estimatedConversionImpact, c.difficultyScore,
          c.businessImpactScore,
          (c as MissionCandidate & { aiExplanation?: string }).aiExplanation || null,
          c.aiQuickWin,
          (c as MissionCandidate & { aiSummary?: string }).aiSummary || null,
          c.sourceType, JSON.stringify(c.sourceData), JSON.stringify(c.steps), c.dueDate,
        ]);
        upserted++;
      }
    }
    return upserted;
  } finally {
    client.release();
  }
}

async function cleanStaleMissions(orgId: string): Promise<void> {
  const client = await pool.connect();
  try {
    // Mark missions not refreshed in 30 days as stale
    await client.query(`
      UPDATE missions SET status = 'stale', updated_at = NOW()
      WHERE org_id = $1 AND status = 'todo'
        AND last_refreshed_at < NOW() - INTERVAL '30 days'
    `, [orgId]);

    // Delete dismissed missions older than 60 days
    await client.query(`
      DELETE FROM missions
      WHERE org_id = $1 AND status = 'dismissed'
        AND dismissed_at < NOW() - INTERVAL '60 days'
    `, [orgId]);
  } finally {
    client.release();
  }
}

export async function runMissionEngine(orgId: string = "default", triggerType: string = "manual"): Promise<{
  generated: number;
  total: number;
  quickWins: number;
  executionMs: number;
}> {
  const t0 = Date.now();
  const logId = `mal_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

  logger.info({ orgId, triggerType }, "[MissionEngine] Starting mission engine run");

  try {
    // 1. Consume AI credits
    await consumeAICredits("mission_auto", orgId, "gpt-4o-mini").catch(() => {});

    // 2. Collect context from all data sources
    const ctx = await collectContext(orgId);

    // 3. Generate mission candidates
    let candidates = generateCandidates(ctx);

    // 4. Enrich with AI (explanations, summaries)
    candidates = await enrichWithAI(candidates, orgId);

    // 5. Upsert missions to DB
    const generated = await upsertMissions(candidates, orgId);

    // 6. Clean stale missions
    await cleanStaleMissions(orgId);

    // 7. Get total active count
    const client = await pool.connect();
    const countRes = await client.query(
      `SELECT COUNT(*) cnt, SUM(CASE WHEN ai_quick_win THEN 1 ELSE 0 END) qw FROM missions WHERE org_id = $1 AND status NOT IN ('done','dismissed','stale')`,
      [orgId]
    ).finally(() => client.release());
    const total = parseInt(countRes.rows[0]?.cnt || "0");
    const quickWins = parseInt(countRes.rows[0]?.qw || "0");

    const executionMs = Date.now() - t0;

    // 8. Log the run
    await pool.connect().then(async (c) => {
      await c.query(`
        INSERT INTO mission_ai_logs (id, org_id, trigger_type, model, missions_generated, missions_updated, execution_ms, status, metadata, created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,'success',$8,NOW())
      `, [logId, orgId, triggerType, "gpt-4o-mini", generated, candidates.length - generated, executionMs, JSON.stringify({ candidates: candidates.length, total, quickWins })]);
      c.release();
    }).catch(() => {});

    // 9. Log activity
    await store.logActivity({
      type: "report",
      label: `Mission Engine : ${generated} nouvelles missions générées`,
      targetId: logId,
      targetType: "mission_run",
      metadata: { generated, total, quickWins, triggerType },
    }).catch(() => {});

    logger.info({ generated, total, quickWins, executionMs, orgId }, "[MissionEngine] Run complete");
    return { generated, total, quickWins, executionMs };

  } catch (err) {
    const executionMs = Date.now() - t0;
    logger.error({ err, orgId }, "[MissionEngine] Run failed");
    await pool.connect().then(async (c) => {
      await c.query(`
        INSERT INTO mission_ai_logs (id, org_id, trigger_type, execution_ms, status, error, created_at)
        VALUES ($1,$2,$3,$4,'error',$5,NOW())
      `, [logId, orgId, triggerType, executionMs, String(err)]);
      c.release();
    }).catch(() => {});
    return { generated: 0, total: 0, quickWins: 0, executionMs };
  }
}

export async function getMissionsStats(orgId: string = "default"): Promise<{
  total: number;
  byStatus: Record<string, number>;
  byPriority: Record<string, number>;
  byCategory: Record<string, number>;
  quickWins: number;
  completedThisMonth: number;
  avgBusinessImpact: number;
}> {
  const client = await pool.connect();
  try {
    const [statusRes, priorityRes, catRes, monthRes, impactRes] = await Promise.all([
      client.query(`SELECT status, COUNT(*) cnt FROM missions WHERE org_id = $1 GROUP BY status`, [orgId]),
      client.query(`SELECT priority, COUNT(*) cnt FROM missions WHERE org_id = $1 AND status NOT IN ('done','dismissed','stale') GROUP BY priority`, [orgId]),
      client.query(`SELECT category, COUNT(*) cnt FROM missions WHERE org_id = $1 AND status NOT IN ('done','dismissed','stale') GROUP BY category`, [orgId]),
      client.query(`SELECT COUNT(*) cnt FROM missions WHERE org_id = $1 AND status = 'done' AND completed_at >= DATE_TRUNC('month', NOW())`, [orgId]),
      client.query(`SELECT AVG(business_impact_score) avg_score, SUM(CASE WHEN ai_quick_win THEN 1 ELSE 0 END) qw FROM missions WHERE org_id = $1 AND status NOT IN ('done','dismissed','stale')`, [orgId]),
    ]);

    const byStatus: Record<string, number> = {};
    for (const r of statusRes.rows) byStatus[r.status] = parseInt(r.cnt);

    const byPriority: Record<string, number> = {};
    for (const r of priorityRes.rows) byPriority[r.priority] = parseInt(r.cnt);

    const byCategory: Record<string, number> = {};
    for (const r of catRes.rows) byCategory[r.category] = parseInt(r.cnt);

    const total = Object.values(byStatus).reduce((s, v) => s + v, 0);

    return {
      total,
      byStatus,
      byPriority,
      byCategory,
      quickWins: parseInt(impactRes.rows[0]?.qw || "0"),
      completedThisMonth: parseInt(monthRes.rows[0]?.cnt || "0"),
      avgBusinessImpact: Math.round(Number(impactRes.rows[0]?.avg_score || 0)),
    };
  } finally {
    client.release();
  }
}
