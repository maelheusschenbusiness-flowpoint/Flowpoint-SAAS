import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";

const PSI_BASE = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed";
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes

// ── In-memory cache ───────────────────────────────────────────────────────────
const memCache = new Map<string, { data: PSIResult; expiresAt: number }>();

export interface CWVMetrics {
  lcp: number;
  cls: number;
  inp: number;
  ttfb: number;
  fcp: number;
  tbt: number;
  speedIndex: number;
}

export interface PSIOpportunity {
  id: string;
  title: string;
  description: string;
  savingsMs: number;
  savingsBytes: number;
  score: number | null;
  displayValue: string;
  category: "render-blocking" | "unused-js" | "unused-css" | "images" | "other";
}

export interface PSIResult {
  url: string;
  strategy: "mobile" | "desktop";
  fetchedAt: number;
  scores: {
    performance: number;
    accessibility: number;
    seo: number;
    bestPractices: number;
  };
  cwv: CWVMetrics;
  opportunities: PSIOpportunity[];
  diagnostics: Record<string, unknown>;
  criticalIssues: string[];
  passedAudits: number;
  totalAudits: number;
}

// ── Category classification ───────────────────────────────────────────────────
const OPPORTUNITY_CATEGORIES: Record<string, PSIOpportunity["category"]> = {
  "render-blocking-resources": "render-blocking",
  "unused-javascript": "unused-js",
  "unused-css-rules": "unused-css",
  "uses-optimized-images": "images",
  "uses-webp-images": "images",
  "uses-responsive-images": "images",
  "offscreen-images": "images",
  "uses-rel-preload": "render-blocking",
  "efficient-animated-content": "images",
};

// ── Extract metrics from PSI response ─────────────────────────────────────────
function extractMetrics(data: Record<string, unknown>): {
  scores: PSIResult["scores"];
  cwv: CWVMetrics;
  opportunities: PSIOpportunity[];
  diagnostics: Record<string, unknown>;
  criticalIssues: string[];
  passedAudits: number;
  totalAudits: number;
} {
  const lr = (data.lighthouseResult ?? {}) as Record<string, unknown>;
  const audits = (lr.audits ?? {}) as Record<string, Record<string, unknown>>;
  const cats = (lr.categories ?? {}) as Record<string, Record<string, unknown>>;

  const score = (key: string) =>
    Math.round(((cats[key]?.score as number) ?? 0) * 100);

  const numVal = (key: string) =>
    (audits[key]?.numericValue as number) ?? 0;

  const scores: PSIResult["scores"] = {
    performance:   score("performance"),
    accessibility: score("accessibility"),
    seo:           score("seo"),
    bestPractices: score("best-practices"),
  };

  const cwv: CWVMetrics = {
    lcp:        Math.round(numVal("largest-contentful-paint")),
    cls:        parseFloat(numVal("cumulative-layout-shift").toFixed(3)),
    inp:        Math.round(numVal("interaction-to-next-paint") || numVal("max-potential-fid")),
    ttfb:       Math.round(numVal("server-response-time")),
    fcp:        Math.round(numVal("first-contentful-paint")),
    tbt:        Math.round(numVal("total-blocking-time")),
    speedIndex: Math.round(numVal("speed-index")),
  };

  // Extract opportunities (audits with potential savings)
  const opportunities: PSIOpportunity[] = [];
  let passedAudits = 0;
  let totalAudits = 0;
  const criticalIssues: string[] = [];

  for (const [id, audit] of Object.entries(audits)) {
    if (!audit || typeof audit !== "object") continue;
    totalAudits++;
    const auditScore = audit.score as number | null;
    if (auditScore === 1 || auditScore === null && audit.scoreDisplayMode === "notApplicable") {
      passedAudits++;
      continue;
    }

    const details = audit.details as Record<string, unknown> | undefined;
    const isOpportunity = details?.type === "opportunity";
    const savingsMs = (details?.overallSavingsMs as number) ?? 0;
    const savingsBytes = (details?.overallSavingsBytes as number) ?? 0;

    if (isOpportunity && savingsMs > 100) {
      opportunities.push({
        id,
        title: (audit.title as string) ?? id,
        description: (audit.description as string) ?? "",
        savingsMs: Math.round(savingsMs),
        savingsBytes: Math.round(savingsBytes),
        score: auditScore,
        displayValue: (audit.displayValue as string) ?? "",
        category: OPPORTUNITY_CATEGORIES[id] ?? "other",
      });
    }

    // Flag critical issues (score < 0.5 on important audits)
    if (auditScore !== null && auditScore < 0.5) {
      const important = [
        "largest-contentful-paint", "total-blocking-time", "cumulative-layout-shift",
        "server-response-time", "render-blocking-resources", "unused-javascript",
      ];
      if (important.includes(id)) {
        criticalIssues.push((audit.title as string) ?? id);
      }
    }
  }

  opportunities.sort((a, b) => b.savingsMs - a.savingsMs);

  // Key diagnostics
  const diagnostics: Record<string, unknown> = {
    interactive:         Math.round(numVal("interactive")),
    mainThreadWork:      Math.round(numVal("mainthread-work-breakdown")),
    bootupTime:          Math.round(numVal("bootup-time")),
    networkRequests:     audits["network-requests"]?.details,
    domSize:             numVal("dom-size"),
    criticalRequestChains: audits["critical-request-chains"]?.details,
  };

  return { scores, cwv, opportunities, diagnostics, criticalIssues, passedAudits, totalAudits };
}

// ── Fetch from PSI API with retry ─────────────────────────────────────────────
async function fetchPSI(url: string, strategy: "mobile" | "desktop"): Promise<Record<string, unknown>> {
  const apiKey = process.env["PAGESPEED_API_KEY"] ?? process.env["GOOGLE_API_KEY"] ?? "";
  const categories = ["performance", "accessibility", "seo", "best-practices"]
    .map(c => `category=${c}`)
    .join("&");

  const apiUrl = `${PSI_BASE}?url=${encodeURIComponent(url)}&strategy=${strategy}&${categories}${apiKey ? `&key=${apiKey}` : ""}`;

  let lastErr: unknown;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(apiUrl, { signal: AbortSignal.timeout(45_000) });

      if (!res.ok) {
        const body = await res.text();
        throw new Error(`PSI API error ${res.status}: ${body.slice(0, 200)}`);
      }
      return await res.json() as Record<string, unknown>;
    } catch (err) {
      lastErr = err;
      if (attempt < 3) {
        const delay = attempt * 2000;
        logger.warn({ err, attempt, delay }, "[PSI] Retry after error");
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }
  throw lastErr;
}

// ── Main analyze function ─────────────────────────────────────────────────────
export async function analyzePSI(
  url: string,
  strategy: "mobile" | "desktop",
  orgId = "default",
  bypassCache = false
): Promise<PSIResult> {
  // Normalize URL
  const normalizedUrl = url.startsWith("http") ? url : `https://${url}`;
  const cacheKey = `${orgId}:${normalizedUrl}:${strategy}`;

  // Check memory cache
  if (!bypassCache) {
    const cached = memCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      logger.info({ url: normalizedUrl, strategy }, "[PSI] Cache hit (memory)");
      return cached.data;
    }
  }

  logger.info({ url: normalizedUrl, strategy }, "[PSI] Fetching from API");
  const raw = await fetchPSI(normalizedUrl, strategy);
  const { scores, cwv, opportunities, diagnostics, criticalIssues, passedAudits, totalAudits } = extractMetrics(raw);

  const result: PSIResult = {
    url: normalizedUrl,
    strategy,
    fetchedAt: Date.now(),
    scores,
    cwv,
    opportunities,
    diagnostics,
    criticalIssues,
    passedAudits,
    totalAudits,
  };

  // Cache in memory
  memCache.set(cacheKey, { data: result, expiresAt: Date.now() + CACHE_TTL_MS });

  // Persist to DB
  await persistResult(result, orgId);

  return result;
}

// ── Persist to DB ─────────────────────────────────────────────────────────────
async function persistResult(result: PSIResult, orgId: string): Promise<void> {
  try {
    const client = await pool.connect();
    try {
      const id = `psi_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      await client.query(`
        INSERT INTO pagespeed_results
          (id, org_id, url, strategy, performance_score, accessibility_score, seo_score,
           best_practices_score, lcp, cls, inp, ttfb, fcp, tbt, speed_index,
           opportunities, diagnostics, raw_lighthouse, created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,NOW())
      `, [
        id, orgId, result.url, result.strategy,
        result.scores.performance, result.scores.accessibility, result.scores.seo, result.scores.bestPractices,
        result.cwv.lcp, result.cwv.cls, result.cwv.inp, result.cwv.ttfb,
        result.cwv.fcp, result.cwv.tbt, result.cwv.speedIndex,
        JSON.stringify(result.opportunities),
        JSON.stringify(result.diagnostics),
        "{}",
      ]);

      // Insert into history
      const hid = `psh_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      await client.query(`
        INSERT INTO pagespeed_history
          (id, org_id, url, strategy, performance_score, accessibility_score, seo_score,
           best_practices_score, lcp, cls, inp, ttfb, created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,NOW())
      `, [
        hid, orgId, result.url, result.strategy,
        result.scores.performance, result.scores.accessibility, result.scores.seo, result.scores.bestPractices,
        result.cwv.lcp, result.cwv.cls, result.cwv.inp, result.cwv.ttfb,
      ]);
    } finally {
      client.release();
    }
  } catch (err) {
    logger.error({ err }, "[PSI] Failed to persist result");
  }
}

// ── Get history from DB ───────────────────────────────────────────────────────
export async function getPSIHistory(
  url: string,
  strategy: "mobile" | "desktop",
  orgId = "default",
  days = 30
): Promise<Array<{
  createdAt: string;
  performance: number;
  accessibility: number;
  seo: number;
  bestPractices: number;
  lcp: number;
  cls: number;
  inp: number;
  ttfb: number;
}>> {
  try {
    const client = await pool.connect();
    try {
      const { rows } = await client.query(`
        SELECT created_at, performance_score, accessibility_score, seo_score,
               best_practices_score, lcp, cls, inp, ttfb
        FROM pagespeed_history
        WHERE org_id = $1 AND url = $2 AND strategy = $3
          AND created_at > NOW() - INTERVAL '${days} days'
        ORDER BY created_at ASC
        LIMIT 90
      `, [orgId, url, strategy]);

      return rows.map(r => ({
        createdAt: r.created_at,
        performance:   Number(r.performance_score),
        accessibility: Number(r.accessibility_score),
        seo:           Number(r.seo_score),
        bestPractices: Number(r.best_practices_score),
        lcp:           Number(r.lcp),
        cls:           Number(r.cls),
        inp:           Number(r.inp),
        ttfb:          Number(r.ttfb),
      }));
    } finally {
      client.release();
    }
  } catch (err) {
    logger.error({ err }, "[PSI] Failed to get history");
    return [];
  }
}

// ── Get latest result from DB ─────────────────────────────────────────────────
export async function getLatestPSIResult(
  url: string,
  strategy: "mobile" | "desktop",
  orgId = "default"
): Promise<Record<string, unknown> | null> {
  try {
    const client = await pool.connect();
    try {
      const { rows } = await client.query(`
        SELECT * FROM pagespeed_results
        WHERE org_id = $1 AND url = $2 AND strategy = $3
        ORDER BY created_at DESC
        LIMIT 1
      `, [orgId, url, strategy]);
      return rows[0] ?? null;
    } finally {
      client.release();
    }
  } catch {
    return null;
  }
}

// ── Invalidate cache ──────────────────────────────────────────────────────────
export function invalidatePSICache(url: string, orgId = "default"): void {
  for (const key of memCache.keys()) {
    if (key.startsWith(`${orgId}:${url}:`)) {
      memCache.delete(key);
    }
  }
}
