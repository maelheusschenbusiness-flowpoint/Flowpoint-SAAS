import crypto from "crypto";
import { pool } from "@workspace/db";
import { logger } from "../lib/logger.js";

// ── Supported events ──────────────────────────────────────────────────────────
export const SUPPORTED_EVENTS = [
  "audit.completed", "monitor.down", "monitor.recovered", "report.generated",
  "mission.created", "mission.completed", "review.received",
  "keyword.ranking_changed", "backlink.detected", "competitor.detected",
  "ai.insight.generated", "client.invited", "payment.failed",
  "subscription.updated", "ai.analysis.completed", "team.member.added",
] as const;

export type EventType = typeof SUPPORTED_EVENTS[number];

// ── Plan limits ───────────────────────────────────────────────────────────────
const PLAN_LIMITS: Record<string, number> = {
  Standard: 3,
  Pro: 50,
  Ultra: Infinity,
};

export function getIntegrationLimit(plan: string): number {
  return PLAN_LIMITS[plan] ?? 3;
}

// ── Types ─────────────────────────────────────────────────────────────────────
export interface AutomationIntegration {
  id: string;
  org_id: string;
  name: string;
  type: string;
  platform: string;
  endpoint_url: string | null;
  secret_key: string | null;
  headers: Record<string, string>;
  events: string[];
  active: boolean;
  verified: boolean;
  last_triggered_at: string | null;
  trigger_count: number;
  failure_count: number;
  retry_enabled: boolean;
  max_retries: number;
  timeout_ms: number;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface AutomationRun {
  id: string;
  org_id: string;
  integration_id: string;
  event_type: string;
  payload: Record<string, unknown> | null;
  status: "pending" | "success" | "failed" | "retrying";
  http_status: number | null;
  duration_ms: number | null;
  attempt: number;
  error: string | null;
  triggered_at: string;
  delivered_at: string | null;
}

// ── Generate HMAC signature ───────────────────────────────────────────────────
export function generateSignature(payload: string, secret: string): string {
  return "sha256=" + crypto.createHmac("sha256", secret).update(payload).digest("hex");
}

// ── Create integration ────────────────────────────────────────────────────────
export async function createIntegration(
  orgId: string,
  plan: string,
  data: {
    name: string;
    type: "outgoing" | "incoming";
    platform: string;
    endpointUrl?: string;
    events?: string[];
    headers?: Record<string, string>;
    metadata?: Record<string, unknown>;
    retryEnabled?: boolean;
    maxRetries?: number;
  }
): Promise<AutomationIntegration> {
  const client = await pool.connect();
  try {
    const limit = getIntegrationLimit(plan);
    const count = await client.query(
      `SELECT COUNT(*) FROM automation_integrations WHERE org_id = $1 AND active = true`,
      [orgId]
    );
    if (parseInt(count.rows[0].count, 10) >= limit) {
      throw new Error(`Limite du plan atteinte : ${limit} intégrations max (${plan}). Passez à un plan supérieur.`);
    }

    const id = `intg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const secret = crypto.randomBytes(32).toString("hex");

    const res = await client.query(`
      INSERT INTO automation_integrations
        (id, org_id, name, type, platform, endpoint_url, secret_key, headers, events,
         active, verified, retry_enabled, max_retries, metadata)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,true,false,$10,$11,$12)
      RETURNING *
    `, [
      id, orgId, data.name, data.type, data.platform,
      data.endpointUrl || null, secret,
      JSON.stringify(data.headers || {}),
      JSON.stringify(data.events || []),
      data.retryEnabled ?? true,
      data.maxRetries ?? 3,
      JSON.stringify(data.metadata || {}),
    ]);

    await logEvent(orgId, id, null, "integration.created", "info", `Intégration "${data.name}" créée (${data.platform})`);
    return res.rows[0] as AutomationIntegration;
  } finally {
    client.release();
  }
}

// ── Deliver webhook (single attempt) ─────────────────────────────────────────
async function deliverWebhook(
  integration: AutomationIntegration,
  runId: string,
  event: EventType,
  payload: Record<string, unknown>,
  attempt: number
): Promise<{ success: boolean; statusCode: number | null; durationMs: number; error?: string }> {
  if (!integration.endpoint_url) {
    return { success: false, statusCode: null, durationMs: 0, error: "No endpoint URL configured" };
  }

  const ts = Math.floor(Date.now() / 1000);
  const body = JSON.stringify({
    id: runId,
    event,
    timestamp: ts,
    attempt,
    data: payload,
    source: "flowpoint",
  });

  const sig = integration.secret_key ? generateSignature(body, integration.secret_key) : "";
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "X-FlowPoint-Event": event,
    "X-FlowPoint-Signature": sig,
    "X-FlowPoint-Timestamp": String(ts),
    "X-FlowPoint-Delivery": runId,
    "User-Agent": "FlowPoint-Webhooks/1.0",
    ...(integration.headers || {}),
  };

  const start = Date.now();
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), integration.timeout_ms || 10000);
    const resp = await fetch(integration.endpoint_url, {
      method: "POST",
      headers,
      body,
      signal: controller.signal,
    });
    clearTimeout(timeout);
    const durationMs = Date.now() - start;
    const success = resp.status >= 200 && resp.status < 300;
    return { success, statusCode: resp.status, durationMs };
  } catch (err) {
    const durationMs = Date.now() - start;
    const error = err instanceof Error ? err.message : String(err);
    return { success: false, statusCode: null, durationMs, error };
  }
}

// ── Dispatch event to all matching integrations ───────────────────────────────
export async function dispatchEvent(
  event: EventType,
  payload: Record<string, unknown>,
  orgId = "default"
): Promise<{ dispatched: number; failed: number }> {
  const client = await pool.connect();
  let integrations: AutomationIntegration[] = [];
  try {
    const res = await client.query(
      `SELECT * FROM automation_integrations
       WHERE org_id = $1 AND active = true AND type = 'outgoing'
       AND (events = '[]' OR events @> $2::jsonb)`,
      [orgId, JSON.stringify([event])]
    );
    integrations = res.rows as AutomationIntegration[];
  } finally {
    client.release();
  }

  if (integrations.length === 0) return { dispatched: 0, failed: 0 };

  let dispatched = 0;
  let failed = 0;

  await Promise.all(integrations.map(async (intg) => {
    const runId = `run_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const client2 = await pool.connect();
    try {
      await client2.query(`
        INSERT INTO automation_runs (id, org_id, integration_id, event_type, payload, status, attempt)
        VALUES ($1,$2,$3,$4,$5,'pending',1)
      `, [runId, orgId, intg.id, event, JSON.stringify(payload)]);

      const result = await deliverWebhook(intg, runId, event, payload, 1);

      if (result.success) {
        await client2.query(`
          UPDATE automation_runs SET status='success', http_status=$1, duration_ms=$2, delivered_at=now()
          WHERE id=$3
        `, [result.statusCode, result.durationMs, runId]);
        await client2.query(`
          UPDATE automation_integrations SET last_triggered_at=now(), trigger_count=trigger_count+1 WHERE id=$1
        `, [intg.id]);
        dispatched++;
      } else {
        // Schedule retry if enabled
        if (intg.retry_enabled && intg.max_retries > 1) {
          const nextRetry = new Date(Date.now() + 30000); // 30s
          await client2.query(`
            UPDATE automation_runs SET status='retrying', http_status=$1, duration_ms=$2, error=$3,
            next_retry_at=$4, attempt=1 WHERE id=$5
          `, [result.statusCode, result.durationMs, result.error || null, nextRetry, runId]);
          scheduleRetry(runId, orgId, intg, event, payload, 2, intg.max_retries).catch(() => {});
        } else {
          await client2.query(`
            UPDATE automation_runs SET status='failed', http_status=$1, duration_ms=$2, error=$3 WHERE id=$4
          `, [result.statusCode, result.durationMs, result.error || null, runId]);
          await client2.query(`
            UPDATE automation_integrations SET failure_count=failure_count+1 WHERE id=$1
          `, [intg.id]);
        }
        failed++;
      }
    } catch (err) {
      failed++;
      logger.error({ err, intg: intg.id }, "[IntgService] dispatch error");
    } finally {
      client2.release();
    }
  }));

  return { dispatched, failed };
}

// ── Retry with exponential backoff ────────────────────────────────────────────
async function scheduleRetry(
  runId: string,
  orgId: string,
  intg: AutomationIntegration,
  event: EventType,
  payload: Record<string, unknown>,
  attempt: number,
  maxRetries: number
): Promise<void> {
  const delay = Math.pow(2, attempt - 1) * 30000; // 30s, 60s, 120s
  await new Promise(r => setTimeout(r, delay));

  const result = await deliverWebhook(intg, runId, event, payload, attempt);
  const client = await pool.connect();
  try {
    if (result.success) {
      await client.query(`
        UPDATE automation_runs SET status='success', http_status=$1, duration_ms=$2,
        delivered_at=now(), attempt=$3 WHERE id=$4
      `, [result.statusCode, result.durationMs, attempt, runId]);
      await client.query(`UPDATE automation_integrations SET last_triggered_at=now(), trigger_count=trigger_count+1 WHERE id=$1`, [intg.id]);
    } else if (attempt >= maxRetries) {
      await client.query(`
        UPDATE automation_runs SET status='failed', http_status=$1, duration_ms=$2,
        error=$3, attempt=$4 WHERE id=$5
      `, [result.statusCode, result.durationMs, result.error || null, attempt, runId]);
      await client.query(`UPDATE automation_integrations SET failure_count=failure_count+1 WHERE id=$1`, [intg.id]);
    } else {
      const nextRetry = new Date(Date.now() + Math.pow(2, attempt) * 30000);
      await client.query(`
        UPDATE automation_runs SET status='retrying', http_status=$1, duration_ms=$2,
        error=$3, next_retry_at=$4, attempt=$5 WHERE id=$6
      `, [result.statusCode, result.durationMs, result.error || null, nextRetry, attempt, runId]);
      scheduleRetry(runId, orgId, intg, event, payload, attempt + 1, maxRetries).catch(() => {});
    }
  } finally {
    client.release();
  }
}

// ── Test delivery ─────────────────────────────────────────────────────────────
export async function testIntegration(integrationId: string, orgId: string): Promise<{
  success: boolean;
  statusCode: number | null;
  durationMs: number;
  error?: string;
  signature: string;
}> {
  const client = await pool.connect();
  let intg: AutomationIntegration | null = null;
  try {
    const res = await client.query(
      `SELECT * FROM automation_integrations WHERE id=$1 AND org_id=$2`, [integrationId, orgId]
    );
    intg = res.rows[0] as AutomationIntegration || null;
  } finally {
    client.release();
  }

  if (!intg) throw new Error("Intégration introuvable");

  const testPayload = {
    test: true,
    domain: "example-flowpoint.fr",
    score: 87,
    message: "Test de livraison FlowPoint Webhooks",
    timestamp: new Date().toISOString(),
  };

  const runId = `test_${Date.now()}`;
  const result = await deliverWebhook(intg, runId, "audit.completed", testPayload, 1);
  const sig = intg.secret_key ? generateSignature(JSON.stringify(testPayload), intg.secret_key) : "";

  if (result.success) {
    const c = await pool.connect();
    try {
      await c.query(`UPDATE automation_integrations SET verified=true, updated_at=now() WHERE id=$1`, [intg.id]);
    } finally { c.release(); }
  }

  await logEvent(orgId, integrationId, null, "integration.test", result.success ? "info" : "error",
    result.success ? `Test réussi (${result.statusCode}, ${result.durationMs}ms)` : `Test échoué : ${result.error || result.statusCode}`
  );

  return { ...result, signature: sig };
}

// ── Get integration stats ─────────────────────────────────────────────────────
export async function getIntegrationStats(orgId: string): Promise<{
  total: number;
  active: number;
  totalRuns: number;
  successRuns: number;
  failedRuns: number;
  successRate: number;
  avgDurationMs: number;
  recentErrors: number;
}> {
  const client = await pool.connect();
  try {
    const [intgRes, runRes, recentErrRes] = await Promise.all([
      client.query(`SELECT COUNT(*) total, COUNT(*) FILTER(WHERE active=true) active FROM automation_integrations WHERE org_id=$1`, [orgId]),
      client.query(`SELECT COUNT(*) total, COUNT(*) FILTER(WHERE status='success') success, COUNT(*) FILTER(WHERE status='failed') failed, AVG(duration_ms) FILTER(WHERE duration_ms IS NOT NULL) avg_ms FROM automation_runs WHERE org_id=$1`, [orgId]),
      client.query(`SELECT COUNT(*) FROM automation_runs WHERE org_id=$1 AND status='failed' AND triggered_at > now()-interval'24h'`, [orgId]),
    ]);
    const r = runRes.rows[0];
    const total = parseInt(r.total, 10);
    const success = parseInt(r.success, 10);
    return {
      total: parseInt(intgRes.rows[0].total, 10),
      active: parseInt(intgRes.rows[0].active, 10),
      totalRuns: total,
      successRuns: success,
      failedRuns: parseInt(r.failed, 10),
      successRate: total > 0 ? Math.round(success / total * 100) : 100,
      avgDurationMs: Math.round(parseFloat(r.avg_ms || "0")),
      recentErrors: parseInt(recentErrRes.rows[0].count, 10),
    };
  } finally {
    client.release();
  }
}

// ── Log event ─────────────────────────────────────────────────────────────────
export async function logEvent(
  orgId: string,
  integrationId: string | null,
  runId: string | null,
  eventType: string,
  level: "info" | "warn" | "error",
  message: string,
  metadata?: Record<string, unknown>
): Promise<void> {
  const id = `log_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
  const client = await pool.connect();
  try {
    await client.query(`
      INSERT INTO automation_logs (id, org_id, integration_id, run_id, event_type, level, message, metadata)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `, [id, orgId, integrationId, runId, eventType, level, message, JSON.stringify(metadata || {})]);
  } catch { /* non-blocking */ } finally {
    client.release();
  }
}

// ── Process incoming webhook ──────────────────────────────────────────────────
export async function processIncomingWebhook(
  token: string,
  body: Record<string, unknown>,
  orgId: string
): Promise<{ action: string; result: unknown }> {
  const client = await pool.connect();
  let wh: { id: string; action: string; action_config: Record<string, unknown>; name: string } | null = null;
  try {
    const res = await client.query(
      `SELECT * FROM incoming_webhooks WHERE token=$1 AND active=true`, [token]
    );
    wh = res.rows[0] || null;
    if (wh) {
      await client.query(
        `UPDATE incoming_webhooks SET last_received_at=now(), receive_count=receive_count+1 WHERE id=$1`, [wh.id]
      );
    }
  } finally {
    client.release();
  }

  if (!wh) throw new Error("Token invalide ou webhook inactif");

  await logEvent(orgId, wh.id, null, "incoming.received", "info", `Webhook entrant reçu : ${wh.name} (${wh.action})`);

  // Execute configured action
  let result: unknown = { ok: true };
  switch (wh.action) {
    case "create_mission":
      result = await executeMissionCreate(orgId, body, wh.action_config);
      break;
    case "send_report":
      result = { ok: true, message: "Rapport en cours de génération" };
      break;
    case "notify_team":
      result = { ok: true, message: "Notification équipe envoyée" };
      break;
    case "create_alert":
      result = { ok: true, message: "Alerte créée" };
      break;
    case "trigger_ai_analysis":
      result = { ok: true, message: "Analyse IA lancée" };
      break;
    default:
      result = { ok: true, message: `Action ${wh.action} traitée` };
  }

  return { action: wh.action, result };
}

async function executeMissionCreate(orgId: string, body: Record<string, unknown>, config: Record<string, unknown>): Promise<unknown> {
  const client = await pool.connect();
  try {
    const id = `mission_wh_${Date.now()}`;
    await client.query(`
      INSERT INTO missions (id, org_id, title, description, status, priority, source, created_at)
      VALUES ($1,$2,$3,$4,'todo','medium','webhook',now())
      ON CONFLICT DO NOTHING
    `, [
      id, orgId,
      String(body.title || config.default_title || "Mission via webhook"),
      String(body.description || "Créée via webhook entrant"),
    ]).catch(() => {});
    return { ok: true, mission_id: id };
  } finally {
    client.release();
  }
}
