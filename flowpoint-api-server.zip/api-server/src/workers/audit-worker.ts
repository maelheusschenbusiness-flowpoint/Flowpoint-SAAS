import { queue } from "../queues/index.js";
import { logger } from "../lib/logger.js";
import { db } from "@workspace/db";
import { auditsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { store } from "../services/store.js";
import { analyzePSI } from "../services/pagespeed-service.js";

interface AuditJobData {
  auditId: string;
  url: string;
  userId?: string;
}

queue.register<AuditJobData>("audit:run", async (job) => {
  const { auditId, url } = job.data;
  logger.info({ auditId, url }, "[Audit] Starting real PSI audit job");

  // Check PSI API key
  const apiKey = process.env["PAGESPEED_API_KEY"] ?? process.env["GOOGLE_API_KEY"] ?? "";
  if (!apiKey && process.env["NODE_ENV"] === "production") {
    await db.update(auditsTable)
      .set({ status: "failed" })
      .where(eq(auditsTable.id, auditId));
    store.broadcast({ type: "audit:failed", auditId, reason: "PageSpeed API not configured" });
    logger.error({ auditId }, "[Audit] PAGESPEED_API_KEY not set — cannot run real audit");
    return;
  }

  try {
    await db.update(auditsTable)
      .set({ status: "running" })
      .where(eq(auditsTable.id, auditId));

    store.broadcast({ type: "audit:started", auditId, url });
    store.broadcast({ type: "audit:progress", auditId, phase: "crawl" });

    // Run mobile + desktop in parallel
    const [mobile, desktop] = await Promise.allSettled([
      analyzePSI(url, "mobile",  "default", true),
      analyzePSI(url, "desktop", "default", true),
    ]);

    store.broadcast({ type: "audit:progress", auditId, phase: "analyse" });

    const mobileResult  = mobile.status  === "fulfilled" ? mobile.value  : null;
    const desktopResult = desktop.status === "fulfilled" ? desktop.value : null;

    if (!mobileResult && !desktopResult) {
      throw new Error("Both mobile and desktop PSI requests failed");
    }

    store.broadcast({ type: "audit:progress", auditId, phase: "score" });

    // Composite score: weighted average (mobile 60%, desktop 40%)
    const mPerf  = mobileResult?.scores.performance  ?? 0;
    const dPerf  = desktopResult?.scores.performance ?? 0;
    const mSeo   = mobileResult?.scores.seo          ?? 0;
    const dSeo   = desktopResult?.scores.seo         ?? 0;
    const mA11y  = mobileResult?.scores.accessibility ?? 0;
    const dA11y  = desktopResult?.scores.accessibility ?? 0;
    const mBP    = mobileResult?.scores.bestPractices  ?? 0;
    const dBP    = desktopResult?.scores.bestPractices ?? 0;

    const weightedPerf = mobileResult && desktopResult
      ? Math.round(mPerf * 0.6 + dPerf * 0.4)
      : mobileResult ? mPerf : dPerf;

    const weightedSeo  = mobileResult && desktopResult
      ? Math.round(mSeo * 0.6 + dSeo * 0.4)
      : mobileResult ? mSeo : dSeo;

    const weightedA11y = mobileResult && desktopResult
      ? Math.round(mA11y * 0.5 + dA11y * 0.5)
      : mobileResult ? mA11y : dA11y;

    const weightedBP   = mobileResult && desktopResult
      ? Math.round(mBP * 0.5 + dBP * 0.5)
      : mobileResult ? mBP : dBP;

    // Overall score: perf 40%, seo 30%, a11y 15%, best-practices 15%
    const score = Math.round(
      weightedPerf * 0.40 +
      weightedSeo  * 0.30 +
      weightedA11y * 0.15 +
      weightedBP   * 0.15
    );

    // Status based on score
    const status = score >= 70 ? "ok" : score >= 50 ? "warn" : "error";

    // Speed = desktop performance score (most representative)
    const speed = desktopResult?.scores.performance ?? mobileResult?.scores.performance ?? 0;

    // Issues = count of critical issues from mobile
    const issues = (mobileResult?.criticalIssues?.length ?? 0) +
                   (desktopResult?.criticalIssues?.length ?? 0);

    // Build opportunities summary for metadata
    const topOpportunities = [
      ...(mobileResult?.opportunities?.slice(0, 5) ?? []),
    ].map(o => o.title);

    store.broadcast({ type: "audit:progress", auditId, phase: "report" });

    await db.update(auditsTable)
      .set({
        status,
        score,
        speed,
        date: new Date().toISOString(),
        issues,
        origin: "manual",
      })
      .where(eq(auditsTable.id, auditId));

    store.broadcast({
      type: "audit:completed",
      auditId,
      score,
      status,
      speed,
      issues,
      cwv: mobileResult?.cwv ?? null,
      opportunities: topOpportunities,
    });

    await store.logActivity({
      type: "audit",
      label: `Audit terminé : ${url} (${score}/100)`,
      targetId: auditId,
      targetType: "audit",
      metadata: {
        url, score, status, speed, issues,
        mobile_perf:  mPerf,
        desktop_perf: dPerf,
        lcp: mobileResult?.cwv.lcp,
        cls: mobileResult?.cwv.cls,
      },
    }).catch(() => {});

    logger.info({ auditId, url, score, speed, issues }, "[Audit] Real PSI audit completed");
  } catch (err) {
    logger.error({ err, auditId, url }, "[Audit] PSI audit failed");
    await db.update(auditsTable)
      .set({ status: "failed" })
      .where(eq(auditsTable.id, auditId));
    store.broadcast({ type: "audit:failed", auditId });
    throw err;
  }
});
