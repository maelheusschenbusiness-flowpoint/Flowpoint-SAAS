/**
 * FlowPoint — Centralized cron scheduler
 * Single entry-point for ALL background periodic tasks.
 *
 * IMPORTANT: This is the only place cron jobs are started.
 * Do NOT call startMonitorCron(), startGBPCron(), startDataForSEOCron()
 * from index.ts or anywhere else — they would cause duplicate scheduling.
 */

import cron from "node-cron";
import { logger } from "../lib/logger.js";
import { queue } from "../queues/index.js";
import { pool } from "@workspace/db";

interface CronJob {
  name:     string;
  schedule: string;
  handler:  () => Promise<void>;
  enabled:  boolean;
  lastRun?: number;
}

const _tasks: cron.ScheduledTask[] = [];
let _started = false;

// ── Job registry ──────────────────────────────────────────────────────────────
const JOBS: CronJob[] = [

  // ── Monitor checks — every 5 minutes ─────────────────────────────────────
  {
    name:    "monitor-checks",
    schedule: "*/5 * * * *",
    enabled:  true,
    handler:  async () => {
      const { runMonitorChecks } = await import("../services/monitor-cron.js");
      await runMonitorChecks();
    },
  },

  // ── Scheduled audits (PSI-based) — every hour ────────────────────────────
  {
    name:    "scheduled-audits",
    schedule: "0 * * * *",
    enabled:  true,
    handler:  async () => {
      const { runScheduledAudits } = await import("../services/monitor-cron.js");
      await runScheduledAudits();
    },
  },

  // ── GBP + GSC sync — every 6 hours ───────────────────────────────────────
  {
    name:    "gbp-gsc-sync",
    schedule: "0 */6 * * *",
    enabled:  true,
    handler:  async () => {
      logger.info("[Cron] gbp-gsc-sync starting");
      const [{ syncAll }, { syncGSCData }] = await Promise.all([
        import("../services/google-service.js"),
        import("../services/gsc-service.js"),
      ]);
      await syncAll("default").catch(e =>
        logger.warn({ e }, "[Cron] GBP sync failed")
      );
      await syncGSCData("default").catch(e =>
        logger.warn({ e }, "[Cron] GSC sync failed")
      );
    },
  },

  // ── DataForSEO refresh — every 6 hours ───────────────────────────────────
  {
    name:    "dataforseo-refresh",
    schedule: "30 */6 * * *",
    enabled:  true,
    handler:  async () => {
      const { startDataForSEOCron } = await import("../services/dataforseo-cron.js");
      // Call the run function directly, not the scheduler wrapper
      logger.info("[Cron] dataforseo-refresh starting");
      const client = await pool.connect().catch(() => null);
      if (!client) return;
      try {
        const { rows } = await client.query<{ domain: string }>(
          `SELECT DISTINCT domain FROM seo_domain_metrics WHERE cached_at < now() - interval '6 hours' LIMIT 20`
        );
        client.release();
        if (rows.length === 0) { logger.info("[Cron] No stale domains"); return; }
        const { refreshSEOCache } = await import("../services/dataforseo-service.js");
        for (const { domain } of rows) {
          await refreshSEOCache(domain).catch(e =>
            logger.warn({ domain, e }, "[Cron] DataForSEO refresh error")
          );
        }
        logger.info({ count: rows.length }, "[Cron] dataforseo-refresh done");
      } catch (e) {
        client.release();
        logger.warn({ e }, "[Cron] dataforseo-refresh query failed");
      }
    },
  },

  // ── Keyword ranking sync — daily at 04:00 ────────────────────────────────
  {
    name:    "keyword-ranking-sync",
    schedule: "0 4 * * *",
    enabled:  true,
    handler:  async () => {
      const { runDailyRankingSync } = await import("../services/keyword-engine.js");
      logger.info("[Cron] keyword-ranking-sync starting");
      await runDailyRankingSync().catch(e =>
        logger.warn({ e }, "[Cron] Keyword ranking sync failed")
      );
    },
  },

  // ── Mission engine — daily at 06:00 ──────────────────────────────────────
  {
    name:    "mission-engine-daily",
    schedule: "0 6 * * *",
    enabled:  true,
    handler:  async () => {
      const { runMissionEngine } = await import("../services/mission-engine.js");
      logger.info("[Cron] mission-engine-daily starting");
      await runMissionEngine("default", "cron_daily").catch(e =>
        logger.warn({ e }, "[Cron] Daily missions failed")
      );
    },
  },

  // ── Mission engine — weekly Sunday 03:00 ─────────────────────────────────
  {
    name:    "mission-engine-weekly",
    schedule: "0 3 * * 0",
    enabled:  true,
    handler:  async () => {
      const { runMissionEngine } = await import("../services/mission-engine.js");
      logger.info("[Cron] mission-engine-weekly starting");
      await runMissionEngine("default", "cron_weekly").catch(e =>
        logger.warn({ e }, "[Cron] Weekly missions failed")
      );
    },
  },

  // ── GBP post scheduler — every 15 min ────────────────────────────────────
  {
    name:    "gbp-post-queue",
    schedule: "*/15 * * * *",
    enabled:  true,
    handler:  async () => {
      await queue.add("gbp:sync", { orgId: "default" }, { maxAttempts: 2 });
    },
  },

  // ── Daily digest email — 08:00 ────────────────────────────────────────────
  {
    name:    "daily-digest",
    schedule: "0 8 * * *",
    enabled:  true,
    handler:  async () => {
      await queue.add("email:daily-digest", { orgId: "default" }, { maxAttempts: 3 });
    },
  },

  // ── Heatmap snapshot — Monday 04:00 ──────────────────────────────────────
  {
    name:    "heatmap-snapshot",
    schedule: "0 4 * * 1",
    enabled:  true,
    handler:  async () => {
      await queue.add("local:heatmap-snapshot", { orgId: "default" }, { maxAttempts: 2 });
    },
  },

  // ── Review alerts — every 30 min ─────────────────────────────────────────
  {
    name:    "review-alerts",
    schedule: "*/30 * * * *",
    enabled:  true,
    handler:  async () => {
      await queue.add("review:check-alerts", { orgId: "default" }, { maxAttempts: 1 });
    },
  },

  // ── CRM sync — every 4 hours ─────────────────────────────────────────────
  {
    name:    "crm-sync",
    schedule: "0 */4 * * *",
    enabled:  true,
    handler:  async () => {
      await queue.add("crm:sync", { orgId: "default" }, { maxAttempts: 2 });
    },
  },

  // ── Competitor scan — daily 03:00 ────────────────────────────────────────
  {
    name:    "competitor-scan",
    schedule: "0 3 * * *",
    enabled:  true,
    handler:  async () => {
      await queue.add("seo:competitor-scan", { orgId: "default" }, { maxAttempts: 2 });
    },
  },

  // ── Retention cleanup — daily 02:00 ──────────────────────────────────────
  {
    name:    "retention-cleanup",
    schedule: "0 2 * * *",
    enabled:  true,
    handler:  async () => {
      const client = await pool.connect().catch(() => null);
      if (!client) return;
      try {
        await client.query(`DELETE FROM audit_trail WHERE created_at < now() - interval '90 days'`).catch(() => {});
        await client.query(`DELETE FROM login_audits WHERE created_at < now() - interval '90 days'`).catch(() => {});
        await client.query(`DELETE FROM sessions WHERE expires_at < $1`, [Date.now()]).catch(() => {});
        logger.info("[Cron] retention-cleanup done");
      } finally {
        client.release();
      }
    },
  },

  // ── Forecasting — weekly Sunday 02:00 ────────────────────────────────────
  {
    name:    "weekly-forecast",
    schedule: "0 2 * * 0",
    enabled:  true,
    handler:  async () => {
      await queue.add("forecast:weekly", { orgId: "default" }, { maxAttempts: 2 });
    },
  },

  // ── Local heatmap rankings — fetch real DataForSEO positions every 30 min ─
  {
    name:    "pending-heatmaps",
    schedule: "*/30 * * * *",
    enabled:  true,
    handler:  async () => {
      const { processPendingHeatmaps } = await import("../services/local-maps-service.js");
      // Process all orgs that have pending heatmap cells
      const client = await pool.connect();
      try {
        const orgs = await client.query(
          `SELECT DISTINCT org_id FROM local_heatmaps WHERE cells_data::text LIKE '%"pending":true%' LIMIT 10`
        );
        for (const row of orgs.rows) {
          await processPendingHeatmaps(row.org_id).catch(() => {});
        }
      } finally {
        client.release();
      }
    },
  },
];

// ── Start all cron jobs ───────────────────────────────────────────────────────
export function startCronScheduler(): void {
  if (_started) {
    logger.warn("[Cron] Scheduler already started — ignoring duplicate call");
    return;
  }
  _started = true;

  const enabledJobs = JOBS.filter(j => j.enabled);
  logger.info({ count: enabledJobs.length }, "[Cron] Starting unified scheduler");

  for (const job of enabledJobs) {
    const task = cron.schedule(job.schedule, async () => {
      const start = Date.now();
      job.lastRun = start;
      try {
        await job.handler();
        const dur = Date.now() - start;
        logger.debug({ job: job.name, durationMs: dur }, "[Cron] Job OK");
        pool.query(
          `INSERT INTO cron_history (job_name, status, duration_ms, ran_at) VALUES ($1,'ok',$2,NOW())`,
          [job.name, dur]
        ).catch(() => {});
      } catch (err) {
        const dur = Date.now() - start;
        const errMsg   = String((err as Error)?.message ?? err);
        const errStack = (err as Error)?.stack ?? null;
        logger.error({ err, job: job.name }, "[Cron] Job failed");
        pool.query(
          `INSERT INTO cron_history (job_name, status, duration_ms, error, ran_at) VALUES ($1,'error',$2,$3,NOW())`,
          [job.name, dur, errMsg]
        ).catch(() => {});
        pool.query(
          `INSERT INTO worker_failures (worker_name, error, stack, context, failed_at) VALUES ($1,$2,$3,$4,NOW())`,
          [job.name, errMsg, errStack, JSON.stringify({ durationMs: dur })]
        ).catch(() => {});
      }
    }, { timezone: "Europe/Paris" });

    _tasks.push(task);
    logger.info({ job: job.name, schedule: job.schedule }, "[Cron] Registered");
  }
}

export function stopCronScheduler(): void {
  _tasks.forEach(t => t.stop());
  _tasks.length = 0;
  _started = false;
  logger.info("[Cron] Scheduler stopped");
}

export function getCronStatus(): Array<{
  name: string; schedule: string; enabled: boolean; lastRun: number | null;
}> {
  return JOBS.map(j => ({
    name: j.name,
    schedule: j.schedule,
    enabled: j.enabled,
    lastRun: j.lastRun ?? null,
  }));
}
