import { queue } from "../queues/index.js";
import { logger } from "../lib/logger.js";
import { store } from "../services/store.js";

interface AiAnalyseJobData {
  analysisId: string;
  type: "seo" | "competitor" | "keyword" | "content";
  payload: Record<string, unknown>;
  userId?: string;
}

queue.register<AiAnalyseJobData>("ai:analyse", async (job) => {
  const { analysisId, type, payload } = job.data;
  logger.info({ analysisId, type }, "[AI Worker] Analysis job started");

  store.broadcast({ type: "ai:started", analysisId, analysisType: type });

  const openAiKey = process.env["OPENAI_API_KEY"];

  if (!openAiKey) {
    logger.warn({ analysisId, type }, "[AI Worker] OPENAI_API_KEY not configured — analysis unavailable");
    store.broadcast({
      type: "ai:error",
      analysisId,
      analysisType: type,
      error: "AI analysis is not configured. Set OPENAI_API_KEY to enable this feature.",
      code: "ai_not_configured",
    });
    return;
  }

  let result: {
    analysisId: string;
    analysisType: string;
    summary: string;
    recommendations: Array<{ priority: string; action: string }>;
    completedAt: string;
  };

  try {
    result = await runOpenAIAnalysis(analysisId, type, payload, openAiKey);
    logger.info({ analysisId, type }, "[AI Worker] OpenAI analysis completed");
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error({ err, analysisId, type }, "[AI Worker] OpenAI call failed");
    store.broadcast({
      type: "ai:error",
      analysisId,
      analysisType: type,
      error: "AI analysis failed — please retry in a moment.",
      code: "ai_call_failed",
      detail: message.slice(0, 200),
    });
    return;
  }

  store.broadcast({ type: "ai:completed", ...result });
  logger.info({ analysisId }, "[AI Worker] Job broadcast complete");
});

async function runOpenAIAnalysis(
  analysisId: string,
  type: string,
  payload: Record<string, unknown>,
  apiKey: string,
): Promise<{
  analysisId: string;
  analysisType: string;
  summary: string;
  recommendations: Array<{ priority: string; action: string }>;
  completedAt: string;
}> {
  const { default: OpenAI } = await import("openai");
  const client = new OpenAI({ apiKey });

  const prompts: Record<string, string> = {
    seo: `Analyse SEO pour: ${JSON.stringify(payload)}. Donne 3 recommandations concrètes et prioritaires en JSON: { summary, recommendations: [{priority, action}] }`,
    competitor: `Analyse concurrentielle pour: ${JSON.stringify(payload)}. Donne 3 recommandations en JSON: { summary, recommendations: [{priority, action}] }`,
    keyword: `Analyse mots-clés pour: ${JSON.stringify(payload)}. Donne 3 recommandations en JSON: { summary, recommendations: [{priority, action}] }`,
    content: `Analyse contenu pour: ${JSON.stringify(payload)}. Donne 3 recommandations en JSON: { summary, recommendations: [{priority, action}] }`,
  };

  const prompt = prompts[type] ?? prompts["seo"]!;

  const completion = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "Tu es un expert SEO. Réponds uniquement avec du JSON valide sans markdown." },
      { role: "user", content: prompt },
    ],
    max_tokens: 400,
    temperature: 0.3,
  });

  const raw = completion.choices[0]?.message?.content ?? "{}";

  let parsed: { summary?: string; recommendations?: Array<{ priority: string; action: string }> } = {};
  try {
    parsed = JSON.parse(raw);
  } catch {
    parsed = { summary: raw.slice(0, 200), recommendations: [] };
  }

  return {
    analysisId,
    analysisType: type,
    summary: parsed.summary ?? "Analyse complète — voir les recommandations.",
    recommendations: parsed.recommendations ?? [],
    completedAt: new Date().toISOString(),
  };
}

