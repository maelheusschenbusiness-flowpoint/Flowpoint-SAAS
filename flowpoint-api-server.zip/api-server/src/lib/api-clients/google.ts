/**
 * FlowPoint — Google APIs client wrapper
 * Maps, Places, Geocoding, Search Console, Analytics.
 */

import { logger } from "../logger.js";
import { TIMEOUTS } from "../config.js";

const MAPS_KEY = process.env.GOOGLE_MAPS_API_KEY ?? process.env.GOOGLE_API_KEY ?? '';

async function googleFetch<T>(url: string, params: Record<string, string>): Promise<T> {
  const qs = new URLSearchParams({ ...params, key: MAPS_KEY }).toString();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TIMEOUTS.google);
  try {
    const res = await fetch(`${url}?${qs}`, { signal: controller.signal });
    if (!res.ok) throw new Error(`Google API HTTP ${res.status}`);
    return await res.json() as T;
  } finally {
    clearTimeout(timeout);
  }
}

export interface GeocodingResult {
  lat: number; lng: number; formattedAddress: string; placeId: string;
}

export async function geocodeAddress(address: string): Promise<GeocodingResult | null> {
  if (!MAPS_KEY) { logger.warn('[Google] No Maps API key'); return null; }
  try {
    const res = await googleFetch<{ status: string; results: Array<{ geometry: { location: { lat: number; lng: number } }; formatted_address: string; place_id: string }> }>(
      'https://maps.googleapis.com/maps/api/geocode/json',
      { address }
    );
    if (res.status !== 'OK' || !res.results[0]) return null;
    const r = res.results[0];
    return { lat: r.geometry.location.lat, lng: r.geometry.location.lng, formattedAddress: r.formatted_address, placeId: r.place_id };
  } catch (err) {
    logger.error({ err, address }, '[Google] Geocoding failed');
    return null;
  }
}

export interface PlaceResult {
  name: string; placeId: string; lat: number; lng: number;
  rating: number; reviewCount: number; address: string; types: string[];
}

export async function searchNearby(params: {
  lat: number; lng: number; radius: number; keyword: string; type?: string;
}): Promise<PlaceResult[]> {
  if (!MAPS_KEY) return [];
  try {
    const res = await googleFetch<{ status: string; results: Array<{ name: string; place_id: string; geometry: { location: { lat: number; lng: number } }; rating?: number; user_ratings_total?: number; vicinity?: string; types?: string[] }> }>(
      'https://maps.googleapis.com/maps/api/place/nearbysearch/json',
      { location: `${params.lat},${params.lng}`, radius: String(params.radius), keyword: params.keyword, ...(params.type ? { type: params.type } : {}) }
    );
    if (res.status !== 'OK') return [];
    return res.results.map(r => ({
      name: r.name, placeId: r.place_id,
      lat: r.geometry.location.lat, lng: r.geometry.location.lng,
      rating: r.rating ?? 0, reviewCount: r.user_ratings_total ?? 0,
      address: r.vicinity ?? '', types: r.types ?? [],
    }));
  } catch (err) {
    logger.error({ err }, '[Google] Places nearby search failed');
    return [];
  }
}

export async function getPlaceDetails(placeId: string): Promise<Partial<PlaceResult & { phoneNumber: string; website: string }> | null> {
  if (!MAPS_KEY) return null;
  try {
    const res = await googleFetch<{ status: string; result: { name: string; rating?: number; user_ratings_total?: number; formatted_address?: string; formatted_phone_number?: string; website?: string; geometry: { location: { lat: number; lng: number } }; types?: string[] } }>(
      'https://maps.googleapis.com/maps/api/place/details/json',
      { place_id: placeId, fields: 'name,rating,user_ratings_total,formatted_address,formatted_phone_number,website,geometry,types' }
    );
    if (res.status !== 'OK') return null;
    const r = res.result;
    return {
      name: r.name, placeId,
      lat: r.geometry.location.lat, lng: r.geometry.location.lng,
      rating: r.rating ?? 0, reviewCount: r.user_ratings_total ?? 0,
      address: r.formatted_address ?? '',
      phoneNumber: r.formatted_phone_number ?? '',
      website: r.website ?? '',
      types: r.types ?? [],
    };
  } catch (err) {
    logger.error({ err, placeId }, '[Google] Place details failed');
    return null;
  }
}

export function isMapsConfigured(): boolean {
  return !!MAPS_KEY;
}
