/**
 * FlowPoint — BetterStack (formerly Logtail/Uptime) client
 */

import { logger } from "../logger.js";
import { TIMEOUTS } from "../config.js";

const BS_TOKEN = process.env.BETTERSTACK_API_TOKEN ?? process.env.BETTERSTACK_TOKEN ?? '';
const BS_BASE  = 'https://uptime.betterstack.com/api/v2';

async function bsFetch<T>(path: string, init?: RequestInit): Promise<T> {
  if (!BS_TOKEN) throw new Error('BetterStack API token not configured');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TIMEOUTS.betterstack);
  try {
    const res = await fetch(`${BS_BASE}${path}`, {
      ...init,
      headers: { 'Authorization': `Bearer ${BS_TOKEN}`, 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`BetterStack HTTP ${res.status}`);
    return await res.json() as T;
  } finally {
    clearTimeout(timeout);
  }
}

export interface BSMonitor {
  id: string; name: string; url: string; status: 'up' | 'down' | 'paused';
  availability: number; responseTime: number; lastCheckedAt: string;
}

export async function listMonitors(): Promise<BSMonitor[]> {
  if (!BS_TOKEN) return [];
  try {
    const res = await bsFetch<{ data: Array<{ id: string; attributes: { url: string; pronounceable_name: string; status: string; availability: number; average_response_time: number; last_checked_at: string } }> }>('/monitors');
    return res.data.map(m => ({
      id: m.id, name: m.attributes.pronounceable_name, url: m.attributes.url,
      status: m.attributes.status as 'up' | 'down' | 'paused',
      availability: m.attributes.availability, responseTime: m.attributes.average_response_time,
      lastCheckedAt: m.attributes.last_checked_at,
    }));
  } catch (err) {
    logger.error({ err }, '[BetterStack] listMonitors failed');
    return [];
  }
}

export async function createMonitor(params: { url: string; name: string; checkFrequency?: number }): Promise<string | null> {
  if (!BS_TOKEN) return null;
  try {
    const res = await bsFetch<{ data: { id: string } }>('/monitors', {
      method: 'POST',
      body: JSON.stringify({ url: params.url, pronounceable_name: params.name, check_frequency: params.checkFrequency ?? 30 }),
    });
    return res.data.id;
  } catch (err) {
    logger.error({ err, url: params.url }, '[BetterStack] createMonitor failed');
    return null;
  }
}

export async function deleteMonitor(monitorId: string): Promise<boolean> {
  if (!BS_TOKEN) return false;
  try {
    await bsFetch(`/monitors/${monitorId}`, { method: 'DELETE' });
    return true;
  } catch (err) {
    logger.error({ err, monitorId }, '[BetterStack] deleteMonitor failed');
    return false;
  }
}

export function isConfigured(): boolean { return !!BS_TOKEN; }
