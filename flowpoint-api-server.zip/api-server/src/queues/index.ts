/**
 * FlowPoint Queue System
 *
 * Uses BullMQ (Redis-backed) when REDIS_URL is set.
 * Falls back to in-process lightweight queue when Redis is unavailable.
 * This allows the app to run without Redis in development/single-node mode.
 */

import { logger } from "../lib/logger.js";

export type JobName =
  | "audit:run"
  | "pdf:generate"
  | "email:send"
  | "email:daily-digest"
  | "monitor:ping"
  | "ai:analyse"
  | "ai:local-recommendations"
  | "seo:keyword-refresh"
  | "seo:competitor-scan"
  | "seo:audit-score"
  | "gbp:sync"
  | "gbp:publish-post"
  | "crm:sync"
  | "local:heatmap-generate"
  | "local:heatmap-snapshot"
  | "review:check-alerts"
  | "review:generate-reply"
  | "report:export"
  | "webhook:send"
  | "notification:send";

export interface Job<T = unknown> {
  id: string;
  name: JobName;
  data: T;
  attempts: number;
  maxAttempts: number;
  createdAt: Date;
}

type JobHandler<T = unknown> = (job: Job<T>) => Promise<void>;

class InProcessQueue {
  private handlers = new Map<JobName, JobHandler>();
  private pending: Job[] = [];
  private running = 0;
  private concurrency = 5;

  register<T>(name: JobName, handler: JobHandler<T>) {
    this.handlers.set(name, handler as JobHandler);
  }

  async add<T>(name: JobName, data: T, opts?: { delay?: number; maxAttempts?: number }) {
    const job: Job<T> = {
      id: `${name}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      name,
      data,
      attempts: 0,
      maxAttempts: opts?.maxAttempts ?? 3,
      createdAt: new Date(),
    };
    if (opts?.delay) {
      setTimeout(() => this.enqueue(job as Job), opts.delay);
    } else {
      this.enqueue(job as Job);
    }
    return job.id;
  }

  private enqueue(job: Job) {
    this.pending.push(job);
    this.drain();
  }

  private async drain() {
    while (this.pending.length > 0 && this.running < this.concurrency) {
      const job = this.pending.shift()!;
      this.running++;
      this.process(job).finally(() => {
        this.running--;
        this.drain();
      });
    }
  }

  private async process(job: Job) {
    const handler = this.handlers.get(job.name);
    if (!handler) {
      logger.warn({ jobName: job.name }, "No handler registered for job");
      return;
    }
    job.attempts++;
    try {
      await handler(job);
      logger.debug({ jobId: job.id, jobName: job.name }, "Job completed");
    } catch (err) {
      logger.error({ jobId: job.id, jobName: job.name, err, attempt: job.attempts }, "Job failed");
      if (job.attempts < job.maxAttempts) {
        const backoff = Math.min(1000 * 2 ** job.attempts, 30_000);
        setTimeout(() => this.enqueue(job), backoff);
      } else {
        logger.error({ jobId: job.id }, "Job exhausted all retries");
      }
    }
  }
}

export const queue = new InProcessQueue();
