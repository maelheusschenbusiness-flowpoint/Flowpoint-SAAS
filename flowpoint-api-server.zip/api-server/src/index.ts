import app from "./app.js";
import { logger } from "./lib/logger.js";

// ── Global safety net — log and exit cleanly instead of silent crash ──────────
process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "[Process] Unhandled promise rejection — exiting");
  process.exit(1);
});

process.on("uncaughtException", (err) => {
  logger.error({ err }, "[Process] Uncaught exception — exiting");
  process.exit(1);
});
import { initDb, ensureFkConstraints, ensureDbIndexes, ensureCronTables } from "./services/db-init.js";
import { loadBehavioralCorsAllowlist } from "./routes/behavioral.js";
import { startCronScheduler } from "./workers/cron-scheduler.js";
import { ensureAuditTable } from "./lib/audit.js";
import { ensureSessionsTable } from "./services/sessions.js";
import { ensureOrgSettingsTable } from "./services/org-settings.js";
import { store } from "./services/store.js";

// ── Pre-load all extended workers (registers queue handlers) ──────────────────
import "./workers/extended-workers.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, "0.0.0.0", (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "[FlowPoint] Server listening on 0.0.0.0 — initializing systems…");

  initDb()
    .then(async () => {
      // ── Auxiliary tables (idempotent DDL) ─────────────────────────────────
      await ensureAuditTable().catch(e =>
        logger.warn({ e }, "Audit table init failed (non-fatal)")
      );
      await ensureSessionsTable().catch(e =>
        logger.warn({ e }, "Sessions table init failed (non-fatal)")
      );

      // ── Org settings: persistent plan/addons/usage per org ────────────────
      await ensureOrgSettingsTable().catch(e =>
        logger.warn({ e }, "Org settings table init failed (non-fatal)")
      );
      await store.loadFromDb().catch(e =>
        logger.warn({ e }, "Org settings load failed (non-fatal)")
      );

      // ── Behavioral CORS allowlist — pre-load registered site origins ───────
      // Ensures customer-domain preflight requests pass CORS immediately after
      // server start without requiring a snippet re-generation cycle.
      await loadBehavioralCorsAllowlist().catch(e =>
        logger.warn({ e }, "Behavioral CORS allowlist preload failed (non-fatal)")
      );

      // ── FK constraints (safe, idempotent, non-fatal) ──────────────────────
      await ensureFkConstraints().catch(e =>
        logger.warn({ e }, "FK constraints check failed (non-fatal)")
      );

      // ── Critical DB indexes (idempotent IF NOT EXISTS) ─────────────────────
      await ensureDbIndexes().catch(e =>
        logger.warn({ e }, "DB indexes check failed (non-fatal)")
      );

      // ── Cron history + worker failures tables ──────────────────────────────
      await ensureCronTables().catch(e =>
        logger.warn({ e }, "Cron tables init failed (non-fatal)")
      );

      // ── Single centralized cron scheduler ─────────────────────────────────
      // All periodic jobs are registered inside cron-scheduler.ts.
      // Do NOT call individual startXxxCron() here — that caused duplicate
      // scheduling of GBP sync, DataForSEO refresh, and monitor checks.
      startCronScheduler();

      logger.info("[FlowPoint] All systems initialized ✓");
      logger.info({
        workers: "extended-workers, ai, audit, monitor, email, pdf",
        crons: "monitor(5m), gbp+gsc(6h), dataforseo(6h), keyword(daily), missions(daily+weekly), digest(daily), heatmap(weekly), review-alerts(30m), crm(4h), retention(daily)",
        middleware: "requestId, orgContext, rateLimiter, planGate, errorHandler",
        sessions: "PostgreSQL-backed (memory cache + DB persistence)",
        apis: "OpenAI, Stripe, DataForSEO, Google Maps, BetterStack, PageSpeed",
      }, "[FlowPoint] Architecture v2.1 active");
    })
    .catch((e) => logger.error({ e }, "Failed to initialize DB or start systems"));
});
