import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (chars: ${i - start})`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 3 → 10 sub-pages ─────────────────────
const OLD_SETTINGS_NAV = `  'settings': [{id:null,label:'Général'},{id:'alerts',label:'Alertes'},{id:'api',label:'API & Webhooks'}],`;
const NEW_SETTINGS_NAV = `  'settings': [{id:null,label:'Command Center'},{id:'workspace',label:'Workspace'},{id:'team',label:'Équipe'},{id:'security',label:'Sécurité'},{id:'alerts',label:'Notifications'},{id:'automations',label:'Automatisations'},{id:'integrations',label:'Intégrations'},{id:'api',label:'API & Dev'},{id:'ai-config',label:'IA Config'},{id:'data',label:'Données'}],`;

if (src.includes(OLD_SETTINGS_NAV)) {
  src = src.replace(OLD_SETTINGS_NAV, NEW_SETTINGS_NAV);
  console.log('\u2713 Updated settings sub-nav (3 \u2192 10)');
} else { console.error('SETTINGS SUB-NAV NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderSettings() — 10-sub-page premium Settings platform
// ══════════════════════════════════════════════════════════════
const NEW_SETTINGS = `function renderSettings() {
  const sub  = STATE.subRoute;
  const s    = STATE.settings;
  const me   = STATE.me;
  const plan = me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';
  const wlBranding = JSON.parse(localStorage.getItem('fp-wl-branding') || '{}');

  // ── Shared Toggle helper ──────────────────────────────────
  const Toggle = (key, label, desc, locked) => {
    const on = s[key];
    return \`<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;\${locked ? 'opacity:0.5' : ''}">
      <div style="flex:1">
        <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(label)}\${locked ? ' <span style="font-size:9px;background:rgba(139,92,246,0.15);color:#8b5cf6;padding:1px 6px;border-radius:6px">Ultra</span>' : ''}</div>
        <div style="font-size:11px;color:var(--fp-text-faint)">\${escHtml(desc)}</div>
      </div>
      <button class="fp-toggle\${on ? ' on' : ''}" data-toggle="\${key}" aria-pressed="\${on}" \${locked ? 'onclick="showToast(\'info\',\'Ultra requis\')"' : ''}></button>
    </div>\`;
  };

  // ══════════════════════════════════════════════════════════
  // SUB: WORKSPACE SETTINGS
  // ══════════════════════════════════════════════════════════
  if (sub === 'workspace') {
    return \`
      \${aiBlock(
        "Workspace configuré et en bonne santé. <strong>Branding white-label actif</strong> — logo et couleurs personnalisés détectés. Recommandation : activer le domaine personnalisé pour une expérience client premium.",
        ['Configurer le domaine', 'Optimiser le branding', 'Sauvegarder le workspace']
      )}

      <div class="fp-grid-2 fp-mb-20">
        <!-- PROFIL & ORGANISATION -->
        <div class="fp-card">
          <div class="fp-card-title">
            \${svgIcon('user').replace('stroke="currentColor"','stroke="#2563EB"')}
            Profil & Organisation
          </div>
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:52px;height:52px;border-radius:16px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.25);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#2563EB;flex-shrink:0">\${me.firstName.charAt(0)}</div>
            <div style="flex:1">
              <div style="font-size:14px;font-weight:700;color:var(--fp-text)">\${escHtml(me.firstName)} Héron</div>
              <div style="font-size:11px;color:var(--fp-text-muted)">mael@flowpoint.pro · Plan \${plan}</div>
            </div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Modification avatar…')">Changer</button>
          </div>
          \${[
            {l:'Prénom',v:me.firstName,t:'text'},
            {l:'Nom',v:'Héron',t:'text'},
            {l:'Email',v:'mael@flowpoint.pro',t:'email'},
            {l:'Organisation',v:me.org.name,t:'text'},
            {l:'Site web',v:'https://monagence.fr',t:'url'},
            {l:'Fuseau horaire',v:'Europe/Paris (UTC+2)',t:'text'},
          ].map(f => \`<div class="fp-form-group">
            <label class="fp-form-label">\${escHtml(f.l)}</label>
            <input class="fp-input" type="\${f.t}" value="\${escHtml(f.v)}"/>
          </div>\`).join('')}
          <div style="display:flex;gap:8px;margin-top:4px">
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Profil mis à jour !')">Sauvegarder</button>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Changement de mot de passe…')">Changer le mot de passe</button>
          </div>
        </div>

        <!-- APPARENCE -->
        <div class="fp-card">
          <div class="fp-card-title">
            \${svgIcon('layout').replace('stroke="currentColor"','stroke="#8b5cf6"')}
            Apparence & Personnalisation
          </div>
          <div class="fp-form-group">
            <label class="fp-form-label">Thème</label>
            <div style="display:flex;gap:6px">
              \${['🌗 Automatique','🌑 Sombre','☀️ Clair'].map((t,i) => \`
                <button class="fp-btn fp-btn-ghost fp-btn-sm\${i===0?' active':''}" style="\${i===0?'border-color:var(--fp-accent);color:var(--fp-accent);':''};flex:1;font-size:11px" onclick="showToast('info','Thème changé')">\${t}</button>
              \`).join('')}
            </div>
          </div>
          <div class="fp-form-group">
            <label class="fp-form-label">Langue</label>
            <select class="fp-select" style="width:100%"><option selected>🇫🇷 Français</option><option>🇬🇧 English</option><option>🇪🇸 Español</option></select>
          </div>
          <div class="fp-form-group">
            <label class="fp-form-label">Format de date</label>
            <select class="fp-select" style="width:100%"><option selected>DD/MM/YYYY</option><option>MM/DD/YYYY</option><option>YYYY-MM-DD</option></select>
          </div>
          <div style="margin-top:6px">
            \${Toggle('compactLists',   'Listes compactes',   'Moins d\'espacement entre les éléments')}
            \${Toggle('advancedCards',  'Cartes avancées',    'Affiche plus de détails dans les cartes')}
            \${Toggle('liveStatus',     'Statut temps réel',  'Barre de statut animée dans le header')}
            \${Toggle('reducedMotion',  'Animations réduites','Mode accessibilité — réduit les animations')}
          </div>
        </div>
      </div>

      <!-- BRANDING WHITE LABEL -->
      <div class="fp-card fp-mb-20" id="wl-branding-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('tag').replace('stroke="currentColor"','stroke="#2563EB"')}
            Branding White Label
          </div>
          \${me.addons.whiteLabel
            ? \`<span style="font-size:10px;padding:2px 10px;border-radius:20px;background:rgba(34,197,94,0.12);color:#22c55e;border:1px solid rgba(34,197,94,0.3)">✓ Actif</span>\`
            : \`<span style="font-size:10px;padding:2px 10px;border-radius:20px;background:rgba(245,158,11,0.12);color:#f59e0b;border:1px solid rgba(245,158,11,0.3)">Pro requis</span>\`}
        </div>
        <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:16px">Personnalisez les rapports partagés avec vos clients — logo, couleurs et nom d\'agence.</div>
        <div class="fp-grid-2">
          <div>
            <div class="fp-form-group">
              <label class="fp-form-label">URL du logo</label>
              <input class="fp-input" id="wl-logo-url" type="url" placeholder="https://monagence.fr/logo.png" value="\${escHtml(wlBranding.logoUrl || '')}" style="width:100%"/>
            </div>
            <div class="fp-form-group">
              <label class="fp-form-label">Nom de l\'agence</label>
              <input class="fp-input" id="wl-agency-name" type="text" placeholder="Mon Agence SEO" value="\${escHtml(wlBranding.agencyName || me?.org?.name || '')}" style="width:100%"/>
            </div>
            <div class="fp-form-group">
              <label class="fp-form-label">Pied de page</label>
              <input class="fp-input" id="wl-footer-msg" type="text" placeholder="Rapport confidentiel — © Mon Agence SEO 2026" value="\${escHtml(wlBranding.footerMsg || '')}" style="width:100%"/>
            </div>
          </div>
          <div>
            <div style="display:flex;gap:10px;margin-bottom:12px">
              <div class="fp-form-group" style="flex:1">
                <label class="fp-form-label">Couleur principale</label>
                <div style="display:flex;align-items:center;gap:8px">
                  <input type="color" id="wl-primary-color" value="\${wlBranding.primaryColor || '#2563EB'}" style="width:36px;height:36px;border-radius:8px;border:1px solid var(--fp-border);background:none;cursor:pointer;padding:2px"/>
                  <input class="fp-input" id="wl-primary-color-hex" type="text" value="\${wlBranding.primaryColor || '#2563EB'}" style="flex:1;font-family:var(--fp-font-mono);font-size:12px"/>
                </div>
              </div>
              <div class="fp-form-group" style="flex:1">
                <label class="fp-form-label">Couleur secondaire</label>
                <div style="display:flex;align-items:center;gap:8px">
                  <input type="color" id="wl-secondary-color" value="\${wlBranding.secondaryColor || '#1d4ed8'}" style="width:36px;height:36px;border-radius:8px;border:1px solid var(--fp-border);background:none;cursor:pointer;padding:2px"/>
                  <input class="fp-input" id="wl-secondary-color-hex" type="text" value="\${wlBranding.secondaryColor || '#1d4ed8'}" style="flex:1;font-family:var(--fp-font-mono);font-size:12px"/>
                </div>
              </div>
            </div>
            <div style="padding:14px;border-radius:12px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.15);margin-bottom:14px">
              <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:8px">Aperçu branding client</div>
              <div style="display:flex;align-items:center;gap:10px">
                <div style="width:32px;height:32px;border-radius:8px;background:\${wlBranding.primaryColor || '#2563EB'};display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff">\${(wlBranding.agencyName || me?.org?.name || 'A').charAt(0).toUpperCase()}</div>
                <div>
                  <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(wlBranding.agencyName || me?.org?.name || 'Mon Agence')}</div>
                  <div style="font-size:10px;color:var(--fp-text-muted)">Rapport confidentiel · Mai 2026</div>
                </div>
              </div>
            </div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" id="wl-save-branding" style="width:100%">Sauvegarder le branding</button>
          </div>
        </div>
      </div>

      <!-- WORKSPACE PRESETS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('sliders').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Préréglages workspace
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px">
          \${[
            {name:'Agence Standard',   desc:'Rapports mensuels, alertes email',          icon:'🏢', active:true  },
            {name:'Focus SEO',         desc:'Priorité audits et rankings',                icon:'🔍', active:false },
            {name:'Mode Local SEO',    desc:'GBP, Maps et local pack en avant',           icon:'📍', active:false },
            {name:'Dashboard Compact', desc:'Vue condensée — adapté aux petits écrans',   icon:'📱', active:false },
          ].map(p => \`
            <div style="padding:12px;border-radius:10px;border:2px solid \${p.active ? 'rgba(37,99,235,0.4)' : 'rgba(255,255,255,0.06)'};background:\${p.active ? 'rgba(37,99,235,0.07)' : 'rgba(255,255,255,0.02)'};cursor:pointer" onclick="showToast('success','Préréglage \${escHtml(p.name)} appliqué')">
              <div style="font-size:18px;margin-bottom:6px">\${p.icon}</div>
              <div style="font-size:11px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(p.name)}\${p.active ? ' ✓' : ''}</div>
              <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(p.desc)}</div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ÉQUIPE & PERMISSIONS
  // ══════════════════════════════════════════════════════════
  if (sub === 'team') {
    const members = [
      {name:'Maël Héron',    role:'Owner',   email:'mael@flowpoint.pro',   avatar:'MH', color:'#2563EB', last:'En ligne', status:'active'},
      {name:'Sophie Martin', role:'Manager', email:'sophie@monagence.fr',  avatar:'SM', color:'#8b5cf6', last:'Il y a 2h', status:'active'},
      {name:'Lucas Dupont',  role:'Viewer',  email:'lucas@monagence.fr',   avatar:'LD', color:'#22c55e', last:'Il y a 3j', status:'active'},
    ];
    const roles = ['Owner','Manager','Editor','Viewer'];
    const modules = ['Audits','Monitors','Rapports','Facturation','Paramètres'];
    const permMatrix = {
      Owner:    [true, true, true, true, true],
      Manager:  [true, true, true, false, false],
      Editor:   [true, true, false, false, false],
      Viewer:   [true, false, false, false, false],
    };
    return \`
      \${aiBlock(
        "3 membres actifs. <strong>Sophie Martin (Manager) a accès à la facturation</strong> — vérifiez si ce niveau de permission est souhaité. Recommandation : créer un rôle personnalisé «Rapporteur» pour les utilisateurs qui génèrent uniquement des rapports.",
        ['Créer un rôle custom', 'Auditer les permissions', 'Inviter un membre']
      )}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Membres actifs', String(members.length), plan === 'Standard' ? '1/1 inclus' : plan === 'Pro' ? '3/5 inclus' : 'Illimités', 'up')}
        \${statCard('Rôles définis', String(roles.length), '4 rôles système', 'up')}
        \${statCard('Sièges disponibles', plan === 'Standard' ? '0' : plan === 'Pro' ? '2' : 'Illimités', 'inclus dans votre plan', 'neutral')}
        \${statCard('Dernière activité', 'Il y a 2h', 'Sophie Martin', 'up')}
      </div>

      <!-- MEMBERS -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('users').replace('stroke="currentColor"','stroke="#2563EB"')}
            Membres de l\'équipe
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Invitation envoyée…')">+ Inviter</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${members.map(m => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,\${m.color},\${m.color}88);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff;flex-shrink:0">\${m.avatar}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(m.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(m.email)} · \${escHtml(m.last)}</div>
              </div>
              <select class="fp-select" style="font-size:11px;padding:4px 8px;border-radius:7px;min-width:90px" onchange="showToast('success','Rôle mis à jour')">
                \${roles.map(r => \`<option \${r === m.role ? 'selected' : ''}>\${r}</option>\`).join('')}
              </select>
              \${m.role !== 'Owner' ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('warning','Membre retiré')">Retirer</button>\` : ''}
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- PERMISSION MATRIX -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('lock').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Matrice de permissions
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead>
              <tr>
                <th>Module</th>
                \${roles.map(r => \`<th style="text-align:center;color:var(--fp-accent)">\${r}</th>\`).join('')}
              </tr>
            </thead>
            <tbody>
              \${modules.map((mod, mi) => \`<tr>
                <td style="font-weight:600;font-size:11px">\${escHtml(mod)}</td>
                \${roles.map(r => {
                  const has = permMatrix[r][mi];
                  return \`<td style="text-align:center">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="\${has ? '#22c55e' : 'rgba(255,255,255,0.15)'}" stroke-width="2.5">
                      \${has ? '<polyline points="20 6 9 17 4 12"/>' : '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'}
                    </svg>
                  </td>\`;
                }).join('')}
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- CUSTOM ROLES (Ultra) -->
      <div class="fp-card" style="\${isUltra ? '' : 'opacity:0.65'}">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div class="fp-card-title" style="margin-bottom:0">🔐 Rôles personnalisés \${!isUltra ? '<span style="font-size:9px;background:rgba(139,92,246,0.15);color:#8b5cf6;padding:2px 7px;border-radius:8px;margin-left:6px">Ultra</span>' : ''}</div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','\${isUltra ? 'Nouveau rôle…' : 'Ultra requis'}')">+ Créer un rôle</button>
        </div>
        <div style="font-size:12px;color:var(--fp-text-muted)">Créez des rôles sur mesure avec des permissions granulaires par module, par client et par workspace.</div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CENTRE SÉCURITÉ
  // ══════════════════════════════════════════════════════════
  if (sub === 'security') {
    const secScore = 72;
    const secItems = [
      {label:'Mot de passe fort',         done:true,  weight:20, desc:'Complexité vérifiée'},
      {label:'2FA activé',                done:false, weight:25, desc:'Non configuré — risque élevé'},
      {label:'Sessions actives vérifiées',done:true,  weight:15, desc:'2 appareils reconnus'},
      {label:'API keys sécurisées',       done:true,  weight:15, desc:'Pas d\'accès public détecté'},
      {label:'Alertes de connexion',      done:false, weight:15, desc:'Notifications non activées'},
      {label:'IP de confiance définie',   done:false, weight:10, desc:'Liste blanche non configurée'},
    ];
    const sessions = [
      {device:'MacBook Pro · Chrome 124',  location:'Paris 75015, France',  ip:'82.65.xxx.xxx',  date:'Maintenant',   current:true  },
      {device:'iPhone 15 Pro · Safari',    location:'Lyon 69002, France',   ip:'92.140.xxx.xxx', date:'Il y a 6h',    current:false },
    ];
    const loginHistory = [
      {event:'Connexion réussie',  device:'MacBook Pro · Chrome', ip:'82.65.xxx.xxx', date:'09/05 · 09h14', success:true  },
      {event:'Connexion réussie',  device:'iPhone 15 · Safari',   ip:'92.140.xxx.xxx',date:'08/05 · 18h42', success:true  },
      {event:'Tentative échouée',  device:'Inconnu · Firefox',    ip:'45.33.xxx.xxx', date:'07/05 · 03h21', success:false },
      {event:'Connexion réussie',  device:'MacBook Pro · Chrome', ip:'82.65.xxx.xxx', date:'07/05 · 08h55', success:true  },
    ];
    const circ34 = 2 * Math.PI * 34;
    return \`
      \${aiBlock(
        "<strong>Score de sécurité : 72/100</strong>. 2 vulnérabilités détectées : <strong>2FA non activé (risque critique)</strong> et alertes de connexion désactivées. Action recommandée : activer la double authentification immédiatement.",
        ['Activer le 2FA', 'Configurer les alertes', 'Auditer les sessions']
      )}

      <!-- SECURITY GAUGE -->
      <div class="fp-stat-row fp-mb-20">
        <div class="fp-card" style="display:flex;align-items:center;gap:16px;grid-column:span 1">
          <svg width="80" height="80" viewBox="0 0 90 90">
            <circle cx="45" cy="45" r="34" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="7"/>
            <circle cx="45" cy="45" r="34" fill="none" stroke="\${secScore > 85 ? '#22c55e' : secScore > 60 ? '#f59e0b' : '#ef4444'}" stroke-width="7"
              stroke-dasharray="\${(secScore/100*circ34).toFixed(1)} \${(circ34*(1-secScore/100)).toFixed(1)}"
              stroke-linecap="round" transform="rotate(-90 45 45)"/>
            <text x="45" y="50" text-anchor="middle" font-size="18" font-weight="900" fill="\${secScore > 85 ? '#22c55e' : secScore > 60 ? '#f59e0b' : '#ef4444'}" font-family="Outfit,sans-serif">\${secScore}</text>
          </svg>
          <div>
            <div style="font-size:14px;font-weight:700;color:var(--fp-text)">Score Sécurité</div>
            <div style="font-size:11px;color:#f59e0b;font-weight:600;margin-bottom:4px">⚠ Moyen — 2 actions requises</div>
            <div style="font-size:10px;color:var(--fp-text-faint)">6 critères évalués</div>
          </div>
        </div>
        \${statCard('Sessions actives', String(sessions.length), '2 appareils reconnus', 'up')}
        \${statCard('2FA', 'Non activé', 'Action critique requise', 'down')}
        \${statCard('Dernière alerte', '07/05 · 03h21', 'Tentative échouée (IP inconnue)', 'down')}
      </div>

      <!-- SECURITY CHECKLIST -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">🛡️ Checklist de sécurité</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${secItems.map(item => \`
            <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:10px;background:\${item.done ? 'rgba(34,197,94,0.05)' : 'rgba(239,68,68,0.05)'};border:1px solid \${item.done ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)'}">
              <div style="width:28px;height:28px;border-radius:8px;background:\${item.done ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.12)'};display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="\${item.done ? '#22c55e' : '#ef4444'}" stroke-width="2.5">
                  \${item.done ? '<polyline points="20 6 9 17 4 12"/>' : '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'}
                </svg>
              </div>
              <div style="flex:1">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(item.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(item.desc)} · +\${item.weight} pts</div>
              </div>
              \${!item.done ? \`<button class="fp-btn fp-btn-primary fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Configuration…')">Activer</button>\` : \`<span style="font-size:10px;color:#22c55e;font-weight:700;flex-shrink:0">✓ OK</span>\`}
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- SESSIONS + HISTORY -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
            <div class="fp-card-title" style="margin-bottom:0">💻 Sessions actives</div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('warning','Toutes sessions fermées')">Tout déconnecter</button>
          </div>
          \${sessions.map(sess => \`
            <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid \${sess.current ? 'rgba(37,99,235,0.25)' : 'var(--fp-border)'};margin-bottom:6px">
              <div style="font-size:20px;flex-shrink:0">\${sess.device.includes('Mac') ? '💻' : '📱'}</div>
              <div style="flex:1">
                <div style="font-size:11px;font-weight:700;color:var(--fp-text)">\${escHtml(sess.device)} \${sess.current ? '<span style="font-size:9px;color:#22c55e">● Actuel</span>' : ''}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(sess.location)} · IP \${escHtml(sess.ip)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(sess.date)}</div>
              </div>
              \${!sess.current ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('warning','Session fermée')">Terminer</button>\` : ''}
            </div>
          \`).join('')}
        </div>

        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📋 Historique des connexions</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            \${loginHistory.map(log => \`
              <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:rgba(255,255,255,0.02)">
                <div style="width:6px;height:6px;border-radius:50%;background:\${log.success ? '#22c55e' : '#ef4444'};flex-shrink:0"></div>
                <div style="flex:1;min-width:0">
                  <div style="font-size:11px;font-weight:600;color:\${log.success ? 'var(--fp-text)' : '#ef4444'}">\${escHtml(log.event)}</div>
                  <div style="font-size:10px;color:var(--fp-text-faint);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${escHtml(log.device)} · \${escHtml(log.ip)}</div>
                </div>
                <div style="font-size:9px;color:var(--fp-text-faint);flex-shrink:0">\${escHtml(log.date)}</div>
              </div>
            \`).join('')}
          </div>
        </div>
      </div>

      <!-- 2FA CONFIG -->
      <div class="fp-card" style="border:1px solid rgba(239,68,68,0.25);background:rgba(239,68,68,0.04)">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
          <div style="font-size:24px">🔐</div>
          <div>
            <div style="font-size:13px;font-weight:700;color:#ef4444">Double authentification (2FA) — Non configurée</div>
            <div style="font-size:11px;color:var(--fp-text-muted)">Sans 2FA, votre compte est vulnérable aux accès non autorisés.</div>
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" style="margin-left:auto;flex-shrink:0;background:#ef4444;border-color:#ef4444" onclick="showToast('info','Configuration 2FA…')">Activer le 2FA →</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
          \${['📱 App Authenticator (TOTP)','📧 Email OTP','💬 SMS (Ultra)'].map(m => \`<div style="font-size:11px;padding:8px 12px;background:rgba(255,255,255,0.04);border-radius:8px;border:1px solid rgba(255,255,255,0.07);color:var(--fp-text-soft)">\${m}</div>\`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: AUTOMATIONS & WORKFLOWS
  // ══════════════════════════════════════════════════════════
  if (sub === 'automations') {
    const workflows = [
      {
        name:'Rapport mensuel automatique',   icon:'📄', color:'#2563EB', active:true,
        trigger:'1er du mois à 08h00',         action:'Générer + envoyer PDF clients',
        runs:12, lastRun:'01/05/2026',         category:'Reporting',
      },
      {
        name:'Alerte monitor critique',       icon:'🚨', color:'#ef4444', active:true,
        trigger:'Monitor down > 5 min',        action:'Email + Slack + SMS équipe',
        runs:3,  lastRun:'09/05/2026',         category:'Monitoring',
      },
      {
        name:'Résumé IA hebdomadaire',        icon:'🤖', color:'#8b5cf6', active:true,
        trigger:'Lundi 09h00',                 action:'Analyse IA + email récapitulatif',
        runs:8,  lastRun:'05/05/2026',         category:'IA',
      },
      {
        name:'Audit automatique post-déploiement', icon:'🔄', color:'#22c55e', active:false,
        trigger:'Push GitHub sur branche main', action:'Audit SEO + rapport technique',
        runs:0,  lastRun:'Jamais',              category:'SEO',
      },
      {
        name:'Alerte chute de score SEO',     icon:'📉', color:'#f59e0b', active:true,
        trigger:'Score < 60/100 détecté',      action:'Notification immédiate + plan d\'action',
        runs:2,  lastRun:'03/05/2026',         category:'SEO',
      },
      {
        name:'Backup données mensuel',        icon:'💾', color:'#06b6d4', active:false,
        trigger:'1er du mois à 03h00',         action:'Export complet + stockage cloud',
        runs:0,  lastRun:'Jamais',             category:'Données',
      },
    ];
    const templates = [
      {name:'Rapport client hebdo',   icon:'📊', desc:'Génère et envoie un résumé client chaque semaine'},
      {name:'SLA monitoring strict',  icon:'🛡️', desc:'Alerte multi-canal si uptime < 99.5%'},
      {name:'Pipeline SEO complet',   icon:'🚀', desc:'Audit → analyse → recommandations → rapport'},
      {name:'Workflow onboarding',    icon:'🎯', desc:'Suite automatisée pour nouveaux clients'},
    ];
    return \`
      \${isPro
        ? aiBlock(
            "4 automations actives. <strong>Recommandation : activer le workflow «Audit post-déploiement»</strong> — votre GitHub est déjà connecté. Impact : zéro régression SEO après vos mises à jour. Économie estimée : 45 min/déploiement.",
            ['Activer audit post-deploy', 'Créer un workflow', 'Voir les statistiques']
          )
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">⚡</div><div style="flex:1"><div style="font-size:13px;font-weight:700;margin-bottom:2px">Automatisations avancées — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Workflows multi-étapes, IA automation et triggers intelligents.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Workflows actifs', String(workflows.filter(w => w.active).length), 'sur ' + workflows.length + ' configurés', 'up')}
        \${statCard('Exécutions ce mois', String(workflows.reduce((s,w) => s + w.runs, 0)), 'automatisations réussies', 'up')}
        \${statCard('Temps économisé', '~6h/mois', 'estimé par l\'IA', 'up')}
        \${statCard('Templates dispo', String(templates.length), 'prêts à l\'emploi', 'up')}
      </div>

      <!-- WORKFLOWS LIST -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('zap').replace('stroke="currentColor"','stroke="#f59e0b"')}
            Workflows configurés
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Nouveau workflow…')">+ Créer</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${workflows.map(wf => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:11px;background:\${wf.active ? wf.color + '07' : 'rgba(255,255,255,0.02)'};border:1px solid \${wf.active ? wf.color + '28' : 'rgba(255,255,255,0.06)'}">
              <div style="font-size:20px;flex-shrink:0">\${wf.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:3px">
                  <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(wf.name)}</span>
                  \${badge(wf.category, wf.color)}
                </div>
                <div style="font-size:10px;color:var(--fp-text-faint)">
                  ⚡ <strong>\${escHtml(wf.trigger)}</strong> → \${escHtml(wf.action)}
                </div>
                <div style="font-size:9px;color:var(--fp-text-faint);margin-top:2px">\${wf.runs} exécutions · Dernier : \${escHtml(wf.lastRun)}</div>
              </div>
              <button class="fp-toggle\${wf.active ? ' on' : ''}" onclick="showToast('success','Workflow \${wf.active ? 'désactivé' : 'activé'}')"></button>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Édition workflow…')">Éditer</button>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- TEMPLATES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📦 Templates de workflows</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px">
          \${templates.map(t => \`
            <div style="padding:14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <div style="font-size:20px;margin-bottom:6px">\${t.icon}</div>
              <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(t.name)}</div>
              <div style="font-size:10px;color:var(--fp-text-muted);margin-bottom:10px">\${escHtml(t.desc)}</div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;font-size:10px" onclick="showToast('success','Template chargé !')">Utiliser ce template</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: INTÉGRATIONS HUB
  // ══════════════════════════════════════════════════════════
  if (sub === 'integrations') {
    const integrationCats = [
      {
        cat:'SEO & Analyse', icon:'🔍',
        items:[
          {name:'Google Business Profile', desc:'Gérez vos fiches GBP, avis et posts directement depuis Flowpoint.',       status:'connected',    icon:'globe',        health:100 },
          {name:'Google Analytics 4',      desc:'Importez le trafic, les sessions et les conversions en temps réel.',      status:'connected',    icon:'trending-up',  health:98  },
          {name:'Google Search Console',   desc:'Positions, impressions, CTR et couverture d\'index par page.',            status:'disconnected', icon:'search',       health:0   },
          {name:'Semrush',                 desc:'Mots-clés, backlinks et analyse concurrentielle avancée.',                status:'disconnected', icon:'bar-chart-2',  health:0,  pro:true },
          {name:'Ahrefs',                  desc:'Analyse de backlinks et opportunités de netlinking.',                     status:'disconnected', icon:'link',         health:0,  pro:true },
        ],
      },
      {
        cat:'CMS & Développement', icon:'🛠️',
        items:[
          {name:'GitHub',     desc:'Suivez les déploiements et les commits. Déclenchez des audits à chaque push.',         status:'connected',    icon:'github',       health:100 },
          {name:'WordPress',  desc:'Synchronisez les pages et posts. Auditez directement depuis le CMS.',                 status:'disconnected', icon:'file-text',    health:0   },
          {name:'Webflow',    desc:'Connectez vos projets Webflow pour un audit automatique après publication.',           status:'disconnected', icon:'layout',       health:0   },
          {name:'Shopify',    desc:'Auditez les pages produits et collections. Suivez le SEO e-commerce.',                status:'disconnected', icon:'shopping-bag', health:0   },
        ],
      },
      {
        cat:'Performance & Sécurité', icon:'⚡',
        items:[
          {name:'PageSpeed Insights', desc:'Score Core Web Vitals (LCP, CLS, FID) automatique après chaque audit.',       status:'connected',    icon:'zap',          health:100 },
          {name:'Cloudflare',         desc:'Cache, CDN, SSL et performance réseau. Alertes de sécurité intégrées.',       status:'disconnected', icon:'shield',       health:0   },
          {name:'Sentry',             desc:'Suivez les erreurs JavaScript et les crashs qui impactent votre SEO.',        status:'disconnected', icon:'alert-triangle',health:0  },
        ],
      },
      {
        cat:'Communication & Automatisation', icon:'💬',
        items:[
          {name:'Slack',              desc:'Recevez les alertes monitors, rapports et résumés dans vos canaux.',           status:'disconnected', icon:'message-square',health:0 },
          {name:'Zapier',             desc:'Connectez Flowpoint à +6000 apps : CRM, email, sheets, etc.',                status:'disconnected', icon:'zap',           health:0 },
          {name:'Make (Integromat)',  desc:'Scénarios d\'automatisation avancés : rapports auto, tickets, alertes.',      status:'disconnected', icon:'repeat',        health:0 },
          {name:'Webhook personnalisé',desc:'Envoyez n\'importe quel événement Flowpoint vers votre propre endpoint.',   status:'disconnected', icon:'code',          health:0 },
        ],
      },
    ];
    const connectedCount = integrationCats.flatMap(c => c.items).filter(i => i.status === 'connected').length;
    const totalCount     = integrationCats.flatMap(c => c.items).length;
    return \`
      \${aiBlock(
        "\${connectedCount} intégrations actives sur \${totalCount} disponibles. <strong>Google Search Console non connectée</strong> — vous manquez les données de position et impressions dans vos audits. Recommandation : connecter Slack pour recevoir les alertes critiques en temps réel.",
        ['Connecter GSC', 'Connecter Slack', 'Explorer toutes les intégrations']
      )}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Connectées', String(connectedCount), 'sur ' + totalCount + ' disponibles', 'up')}
        \${statCard('Santé moyenne', String(Math.round(integrationCats.flatMap(c => c.items).filter(i => i.status === 'connected').reduce((s,i) => s + i.health, 0) / connectedCount)) + '%', 'intégrations actives', 'up')}
        \${statCard('Déconnectées', String(totalCount - connectedCount), 'opportunités disponibles', 'neutral')}
        \${statCard('Dernière sync', 'Il y a 4 min', 'GBP + GA4 + GitHub', 'up')}
      </div>

      \${integrationCats.map(cat => \`
        <div class="fp-card fp-mb-20">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
            <span style="font-size:16px">\${cat.icon}</span>
            <div class="fp-card-title" style="margin-bottom:0">\${escHtml(cat.cat)}</div>
            <span style="font-size:10px;color:var(--fp-text-faint)">\${cat.items.filter(i => i.status === 'connected').length}/\${cat.items.length} actives</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:2px">
            \${cat.items.map(intg => \`
              <div style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:9px;transition:background .12s" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='transparent'">
                <div style="width:36px;height:36px;border-radius:9px;background:\${intg.status === 'connected' ? 'rgba(34,197,94,0.1)' : 'rgba(148,163,184,0.08)'};display:flex;align-items:center;justify-content:center;flex-shrink:0">
                  \${svgIcon(intg.icon).replace('stroke="currentColor"','stroke="' + (intg.status === 'connected' ? '#22c55e' : '#64748b') + '"')}
                </div>
                <div style="flex:1;min-width:0">
                  <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
                    <span style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(intg.name)}</span>
                    \${intg.pro ? '<span style="font-size:9px;background:rgba(139,92,246,0.15);color:#8b5cf6;border-radius:4px;padding:1px 5px;font-weight:700">PRO</span>' : ''}
                    \${intg.status === 'connected' ? '<svg width="7" height="7" viewBox="0 0 8 8"><circle cx="4" cy="4" r="3" fill="#22c55e"/></svg>' : ''}
                  </div>
                  <div style="font-size:11px;color:var(--fp-text-faint);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${escHtml(intg.desc)}</div>
                  \${intg.status === 'connected' ? \`<div style="font-size:9px;color:#22c55e;margin-top:2px">Santé \${intg.health}% · Sync il y a 4 min</div>\` : ''}
                </div>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:11px;flex-shrink:0" onclick="showToast('info','\${intg.status === 'connected' ? 'Gestion' : 'Connexion'} \${escHtml(intg.name)}…')">\${intg.status === 'connected' ? 'Gérer' : 'Connecter'}</button>
              </div>
            \`).join('')}
          </div>
        </div>
      \`).join('')}

      <div style="padding:12px 14px;border-radius:10px;background:rgba(37,99,235,0.06);border:1px dashed rgba(37,99,235,0.2);text-align:center">
        <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:6px">Une intégration manque à votre liste ?</div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Demande envoyée à l\'équipe Flowpoint !')">Proposer une intégration</button>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: IA CONFIG LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'ai-config') {
    const aiModules = [
      {key:'dailyAI',      label:'Résumé IA quotidien',           desc:'Analyse IA de vos KPIs chaque matin dans l\'accueil',      color:'#2563EB', plan:'Standard', active:true  },
      {key:'aiAlerts',     label:'Alertes intelligentes IA',      desc:'IA filtre et priorise vos alertes — zéro bruit',           color:'#f59e0b', plan:'Pro',      active:isPro  },
      {key:'aiForecasting',label:'Prévisions IA',                 desc:'Modèle prédictif sur 30/90 jours pour vos KPIs',           color:'#8b5cf6', plan:'Pro',      active:isPro  },
      {key:'aiReporting',  label:'Rapports IA automatiques',      desc:'Génère un résumé exécutif IA chaque mois',                 color:'#22c55e', plan:'Pro',      active:isPro  },
      {key:'aiCRO',        label:'IA CRO & Conversion',           desc:'Recommandations de tests A/B et détection friction',       color:'#ef4444', plan:'Pro',      active:false  },
      {key:'aiStrategist', label:'IA Stratégiste complet',        desc:'Analyse ROI, churn prevention et scaling intelligence',    color:'#8b5cf6', plan:'Ultra',    active:isUltra},
      {key:'aiChurn',      label:'Détection churn IA',            desc:'Signaux faibles de désengagement client détectés',         color:'#f59e0b', plan:'Ultra',    active:isUltra},
      {key:'aiMarket',     label:'Intelligence marché IA',        desc:'Veille concurrentielle et tendances sectorielles',         color:'#06b6d4', plan:'Ultra',    active:false  },
    ];
    const intensityLevels = ['Conservateur','Équilibré','Agressif'];
    return \`
      \${isUltra
        ? aiBlock(
            "IA Config Lab actif. <strong>7 modules IA disponibles</strong> — 5 actifs. Recommandation : activer le module <strong>Intelligence marché IA</strong> pour une veille concurrentielle automatique. Intensité IA actuelle : Équilibré.",
            ['Activer tous les modules', 'Optimiser l\'intensité IA', 'Rapport IA Lab']
          )
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.1),rgba(37,99,235,0.08));border:1px solid rgba(139,92,246,0.25);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px"><div style="font-size:24px">🧠</div><div style="flex:1"><div style="font-size:13px;font-weight:700;margin-bottom:2px">IA Config Lab complet — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">IA Stratégiste, churn prevention, market intelligence et automation agressive.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Modules IA actifs', String(aiModules.filter(m => m.active).length) + '/' + aiModules.length, 'modules configurés', 'up')}
        \${statCard('Intensité IA',      'Équilibré',      'recommandations mesurées', 'up')}
        \${statCard('Crédits IA',        '412/1000',       '41% utilisés ce mois', 'up')}
        \${statCard('Précision IA',      '87%',            'recommandations pertinentes', 'up')}
      </div>

      <!-- AI INTENSITY -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">🎛️ Intensité des recommandations IA</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
          \${intensityLevels.map((lvl, i) => \`
            <div style="padding:14px;border-radius:11px;border:2px solid \${i === 1 ? 'rgba(37,99,235,0.4)' : 'rgba(255,255,255,0.06)'};background:\${i === 1 ? 'rgba(37,99,235,0.07)' : 'rgba(255,255,255,0.02)'};cursor:pointer;text-align:center" onclick="showToast('success','Intensité \${lvl} appliquée')">
              <div style="font-size:18px;margin-bottom:4px">\${['🧘','⚖️','🚀'][i]}</div>
              <div style="font-size:12px;font-weight:700;color:\${i === 1 ? 'var(--fp-accent)' : 'var(--fp-text)'}">\${escHtml(lvl)}\${i === 1 ? ' ✓' : ''}</div>
              <div style="font-size:10px;color:var(--fp-text-faint);\${i === 1 ? 'color:var(--fp-text-muted)' : ''}">\${['Peu de recommandations, fortes certitudes', 'Équilibre pertinence/fréquence', 'Toutes les recommandations IA activées'][i]}</div>
            </div>
          \`).join('')}
        </div>
        <div style="font-size:11px;color:var(--fp-text-muted)">L\'intensité «Équilibré» est recommandée pour la plupart des workspaces.</div>
      </div>

      <!-- AI MODULE TOGGLES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🤖 Modules IA — Configuration individuelle</div>
        <div style="display:flex;flex-direction:column;gap:0">
          \${aiModules.map(m => {
            const locked = (m.plan === 'Pro' && isStd) || (m.plan === 'Ultra' && !isUltra);
            return \`<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.04);\${locked ? 'opacity:0.5' : ''}">
              <div style="width:8px;height:8px;border-radius:50%;flex-shrink:0;background:\${m.active && !locked ? m.color : 'rgba(255,255,255,0.15)'};\${m.active && !locked ? 'box-shadow:0 0 6px ' + m.color + '55' : ''}"></div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
                  <span style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(m.label)}</span>
                  \${badge(m.plan, m.plan === 'Ultra' ? '#8b5cf6' : m.plan === 'Pro' ? '#2563EB' : '#475569')}
                </div>
                <div style="font-size:11px;color:var(--fp-text-faint)">\${escHtml(m.desc)}</div>
              </div>
              \${locked
                ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Mise à niveau nécessaire')">🔒 Upgrader</button>\`
                : \`<button class="fp-toggle\${m.active ? ' on' : ''}" onclick="showToast('success','Module \${escHtml(m.label)} \${m.active ? 'désactivé' : 'activé'}')"></button>\`
              }
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: DONNÉES & RÉTENTION
  // ══════════════════════════════════════════════════════════
  if (sub === 'data') {
    const storageItems = [
      {l:'Audits & Historique',    used:1.8,  total:5,   color:'#2563EB' },
      {l:'Rapports PDF stockés',   used:0.4,  total:2,   color:'#8b5cf6' },
      {l:'Exports & CSV',          used:0.2,  total:1,   color:'#22c55e' },
      {l:'Données monitors',       used:0.8,  total:2,   color:'#f59e0b' },
    ];
    const totalUsed  = storageItems.reduce((s,i) => s + i.used, 0);
    const totalTotal = storageItems.reduce((s,i) => s + i.total, 0);
    return \`
      \${aiBlock(
        "Données en bonne santé — 3.2 GB sur 10 GB utilisés (32%). Rétention actuelle : <strong>90 jours (Pro)</strong>. Recommandation : activer le backup automatique mensuel pour garantir la continuité des données historiques.",
        ['Activer backup auto', 'Exporter toutes les données', 'Voir la rétention']
      )}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Stockage utilisé', totalUsed.toFixed(1) + ' GB', 'sur ' + totalTotal + ' GB disponibles', 'up')}
        \${statCard('Rétention actuelle', isStd ? '30 jours' : isPro && !isUltra ? '90 jours' : '365 jours', 'selon votre plan', 'neutral')}
        \${statCard('Dernier backup', '01/05/2026', 'automatique mensuel', 'up')}
        \${statCard('Conformité RGPD', 'En cours', 'données EU · politique active', 'neutral')}
      </div>

      <!-- STORAGE -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('database').replace('stroke="currentColor"','stroke="#2563EB"')}
            Stockage & Données
          </div>
          <span style="font-size:11px;color:var(--fp-text-faint)">\${totalUsed.toFixed(1)} GB / \${totalTotal} GB</span>
        </div>
        <div class="fp-progress-track" style="height:8px;margin-bottom:14px">
          <div class="fp-progress-fill" style="width:\${(totalUsed/totalTotal*100).toFixed(1)}%;background:linear-gradient(to right,#2563EB,#8b5cf6)"></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${storageItems.map(item => {
            const pct = Math.round(item.used / item.total * 100);
            return \`<div>
              <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                <span style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(item.l)}</span>
                <span style="font-size:11px;font-weight:700;color:var(--fp-text)">\${item.used} GB / \${item.total} GB (\${pct}%)</span>
              </div>
              <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${pct}%;background:\${item.color}"></div></div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- RETENTION + EXPORTS + DANGER -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">
            \${svgIcon('clock').replace('stroke="currentColor"','stroke="#f59e0b"')}
            Politique de rétention
          </div>
          \${[
            {label:'Standard',  days:30,  active:isStd,       color:'#475569'},
            {label:'Pro',       days:90,  active:isPro && !isUltra, color:'#2563EB'},
            {label:'Ultra',     days:365, active:isUltra,     color:'#8b5cf6'},
          ].map(r => \`<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:9px;background:\${r.active ? r.color + '08' : 'rgba(255,255,255,0.01)'};border:1px solid \${r.active ? r.color + '33' : 'rgba(255,255,255,0.05)'};margin-bottom:6px">
            <div style="width:8px;height:8px;border-radius:50%;background:\${r.active ? r.color : 'rgba(255,255,255,0.15)'};flex-shrink:0;\${r.active ? 'box-shadow:0 0 6px ' + r.color + '55' : ''}"></div>
            <div style="flex:1">
              <span style="font-size:12px;font-weight:700;color:\${r.active ? r.color : 'var(--fp-text-faint)'}">Plan \${r.label} — \${r.days} jours</span>
            </div>
            \${r.active ? badge('Actif', r.color) : ''}
          </div>\`).join('')}
          <div style="font-size:11px;color:var(--fp-text-muted);margin-top:8px">Les données antérieures à la limite de rétention sont archivées automatiquement.</div>
        </div>

        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">
            \${svgIcon('download').replace('stroke="currentColor"','stroke="#22c55e"')}
            Exports & Backup
          </div>
          <div style="display:flex;flex-direction:column;gap:7px">
            \${[
              {label:'Exporter toutes mes données',      icon:'download',  action:'export-data'},
              {label:'Historique des audits (CSV)',       icon:'file',      action:'export-audits'},
              {label:'Importer une liste de sites',      icon:'upload',    action:'import-sites'},
              {label:'Synchroniser GBP maintenant',      icon:'refresh',   action:'sync-gbp'},
              {label:'Demander une archive RGPD',        icon:'shield',    action:'rgpd'},
            ].map(a => \`
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="justify-content:flex-start;gap:8px;width:100%;padding:9px 12px" onclick="showToast('info','\${escHtml(a.label)}…')">
                \${svgIcon(a.icon).replace('stroke="currentColor"','stroke="var(--fp-text-muted)"')}
                \${escHtml(a.label)}
              </button>
            \`).join('')}
          </div>
        </div>
      </div>

      <!-- DANGER ZONE -->
      <div class="fp-card" style="border:1px solid rgba(239,68,68,0.25);background:rgba(239,68,68,0.04)">
        <div class="fp-card-title" style="color:#ef4444;margin-bottom:8px">⚠ Zone de danger</div>
        <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:12px">Ces actions sont irréversibles. Agissez avec précaution.</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="fp-btn fp-btn-ghost fp-btn-sm" style="border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('error','Veuillez confirmer dans le modal de sécurité')">Supprimer toutes les données</button>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" style="border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('error','Demande de suppression enregistrée')">Supprimer mon compte</button>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Settings Command Center
  // ══════════════════════════════════════════════════════════
  const workspaceHealth = 85;
  const circ38 = 2 * Math.PI * 38;
  const configTimeline = [
    {d:'09/05/2026', ev:'Workflow «Alerte monitor» activé',             c:'#22c55e' },
    {d:'07/05/2026', ev:'Paramètre notifications mis à jour',           c:'#2563EB' },
    {d:'05/05/2026', ev:'Add-on Monitors +50 configuré',               c:'#8b5cf6' },
    {d:'01/05/2026', ev:'Rapport mensuel généré automatiquement',       c:'#22c55e' },
    {d:'28/04/2026', ev:'Tentative de connexion inconnue bloquée',      c:'#ef4444' },
    {d:'15/04/2026', ev:'Branding white-label configuré',              c:'#06b6d4' },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Settings Command Center
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.35);border-radius:20px;color:#2563EB">✦ INTELLIGENT</span>
        </h1>
        <div class="fp-section-sub">Workspace health \${workspaceHealth}/100 · 4 intégrations actives · 4 workflows actifs</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Sauvegarder','fp-btn fp-btn-primary fp-btn-sm','','id="settings-save" onclick="showToast(\'success\',\'Paramètres sauvegardés !\')"')}
      </div>
    </div>

    <!-- AI INTELLIGENCE -->
    \${isPro
      ? aiBlock(
          "Workspace en bonne santé (\${workspaceHealth}/100). <strong>2 actions prioritaires</strong> : activer le 2FA (risque sécurité critique) et connecter Google Search Console (données de position manquantes). 4 workflows actifs — système automatisé stable.",
          ['Activer le 2FA', 'Connecter GSC', 'Rapport workspace complet']
        )
      : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">🔧</div><div style="flex:1"><div style="font-size:13px;font-weight:700;margin-bottom:2px">Workspace Intelligence IA — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse de santé workspace, recommandations de configuration et audit de sécurité IA.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
    }

    <!-- WORKSPACE HEALTH + STATUS CARDS -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card" style="background:linear-gradient(135deg,rgba(37,99,235,0.07),rgba(139,92,246,0.05));border:1px solid rgba(37,99,235,0.18)">
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px">
          <svg width="80" height="80" viewBox="0 0 90 90">
            <circle cx="45" cy="45" r="38" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="7"/>
            <circle cx="45" cy="45" r="38" fill="none" stroke="\${workspaceHealth > 80 ? '#22c55e' : workspaceHealth > 60 ? '#f59e0b' : '#ef4444'}" stroke-width="7"
              stroke-dasharray="\${(workspaceHealth/100*circ38).toFixed(1)} \${(circ38*(1-workspaceHealth/100)).toFixed(1)}"
              stroke-linecap="round" transform="rotate(-90 45 45)"/>
            <text x="45" y="51" text-anchor="middle" font-size="20" font-weight="900" fill="\${workspaceHealth > 80 ? '#22c55e' : '#f59e0b'}" font-family="Outfit,sans-serif">\${workspaceHealth}</text>
          </svg>
          <div>
            <div style="font-size:16px;font-weight:800;color:var(--fp-text)">Workspace Health</div>
            <div style="font-size:11px;color:#22c55e;font-weight:600">✓ Bon état général</div>
            <div style="font-size:10px;color:var(--fp-text-faint);margin-top:4px">2 actions requises pour atteindre 100</div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          \${[
            {l:'Sécurité',      v:'72/100',  ic:'⚠',  c:'#f59e0b'},
            {l:'Intégrations',  v:'4 actives',ic:'✓', c:'#22c55e'},
            {l:'Automatisations',v:'4 actives',ic:'✓',c:'#22c55e'},
            {l:'IA Config',     v:'5 modules',ic:'✓', c:'#22c55e'},
          ].map(it => \`<div style="padding:9px 10px;border-radius:8px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.06)">
            <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(it.l)}</div>
            <div style="font-size:12px;font-weight:700;color:\${it.c}">\${it.ic} \${escHtml(it.v)}</div>
          </div>\`).join('')}
        </div>
      </div>

      <!-- CONFIG TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('clock').replace('stroke="currentColor"','stroke="#2563EB"')}
          Timeline des modifications
        </div>
        <div style="position:relative;padding-left:18px">
          <div style="position:absolute;left:5px;top:0;bottom:0;width:1px;background:linear-gradient(to bottom,#2563EB,transparent)"></div>
          \${configTimeline.map(ev => \`<div style="position:relative;margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.04)">
            <div style="position:absolute;left:-15px;top:3px;width:7px;height:7px;border-radius:50%;background:\${ev.c};box-shadow:0 0 5px \${ev.c}44"></div>
            <div style="font-size:9px;color:var(--fp-text-faint)">\${escHtml(ev.d)}</div>
            <div style="font-size:11px;font-weight:600;color:var(--fp-text)">\${escHtml(ev.ev)}</div>
          </div>\`).join('')}
        </div>
      </div>
    </div>

    <!-- QUICK NAV TO ALL SUB-PAGES -->
    <div class="fp-card">
      <div class="fp-card-title" style="margin-bottom:14px">🧭 Centre de configuration — Navigation rapide</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px">
        \${[
          {label:'Workspace',         sub:'workspace',    icon:'🏢', desc:'Profil, branding, apparence, préréglages',     status:'✓ Configuré',  sc:'#22c55e'},
          {label:'Équipe & Permissions',sub:'team',       icon:'👥', desc:'3 membres · 4 rôles · Matrice accès',           status:'✓ OK',         sc:'#22c55e'},
          {label:'Centre Sécurité',   sub:'security',     icon:'🛡️', desc:'Score 72/100 · 2FA requis',                    status:'⚠ Action',     sc:'#f59e0b'},
          {label:'Notifications',     sub:'alerts',       icon:'🔔', desc:'Alertes email, push, seuils configurés',        status:'✓ Actif',       sc:'#22c55e'},
          {label:'Automatisations',   sub:'automations',  icon:'⚡', desc:'4 workflows actifs · 25 exécutions',           status:'✓ Actif',       sc:'#22c55e'},
          {label:'Intégrations',      sub:'integrations', icon:'🔌', desc:'4 actives · GSC non connectée',                status:'⚠ À compléter',sc:'#f59e0b'},
          {label:'API & Développeurs',sub:'api',          icon:'💻', desc:'2 clés actives · Webhooks configurés',          status:'✓ Actif',       sc:'#22c55e'},
          {label:'IA Config Lab',     sub:'ai-config',    icon:'🤖', desc:'5 modules IA actifs · Équilibré',              status:'✓ Optimisé',   sc:'#22c55e'},
          {label:'Données & Rétention',sub:'data',        icon:'💾', desc:'3.2 GB / 10 GB · 90 jours rétention',          status:'✓ Sain',        sc:'#22c55e'},
        ].map(n => \`
          <div style="display:flex;align-items:flex-start;gap:10px;padding:11px 12px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${n.sub}')">
            <span style="font-size:16px;flex-shrink:0">\${n.icon}</span>
            <div style="flex:1;min-width:0">
              <div style="font-size:11px;font-weight:700;color:var(--fp-text)">\${escHtml(n.label)}</div>
              <div style="font-size:10px;color:var(--fp-text-faint);line-height:1.4">\${escHtml(n.desc)}</div>
              <div style="font-size:9px;font-weight:700;color:\${n.sc};margin-top:3px">\${n.status}</div>
            </div>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--fp-text-faint)" stroke-width="2" style="flex-shrink:0;margin-top:2px"><polyline points="9 18 15 12 9 6"/></svg>
          </div>
        \`).join('')}
      </div>
    </div>
  \`;
}`;

// ── Apply ──────────────────────────────────────────────────────
src = replaceFunc(src, 'renderSettings', NEW_SETTINGS);
writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Settings Command Center fully replaced (10 sub-pages).');
