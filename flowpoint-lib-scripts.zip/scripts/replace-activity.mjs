import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 4 → 8 sub-pages ───────────────────────
const OLD_SUBNAV = `'activity-feed': [{id:null,label:'Tout'},{id:'audits',label:'Audits'},{id:'monitors',label:'Monitors'},{id:'team',label:'Équipe'}],`;
const NEW_SUBNAV = `'activity-feed': [{id:null,label:'Command Center'},{id:'team',label:'Équipe'},{id:'seo',label:'SEO & Growth'},{id:'monitoring',label:'Monitoring'},{id:'ai',label:'IA & Auto'},{id:'reports',label:'Rapports'},{id:'competitor',label:'Concurrents'},{id:'ops',label:'Ops Lab'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated activity-feed sub-nav (4 \u2192 8)');
} else { console.error('SUB-NAV NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderActivityFeed() — full 8-sub-page AI workspace platform
// ══════════════════════════════════════════════════════════════
const NEW_ACTIVITY = `function renderActivityFeed() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const colors = { success:'#22c55e', error:'#ef4444', info:'#2563EB', warning:'#f59e0b', purple:'#8b5cf6', cyan:'#06b6d4' };

  // ── Shared enriched activity data ───────────────────────────
  const masterFeed = [
    { type:'success',  cat:'seo',        icon:'trending-up',    title:"Score SEO +4pts — boulangerie-martin.fr",           desc:"Audit complet terminé — 82/100 · 4 problèmes corrigés",                                   time:"14 min",  user:"Maël D.",    impact:"Élevé"   },
    { type:'error',    cat:'monitoring',  icon:'wifi-off',       title:"Monitor DOWN — restaurant-lesoleil.com",            desc:"Inaccessible depuis 44 min — incident #INC-001 ouvert",                                   time:"44 min",  user:"Système",    impact:"Critique"},
    { type:'warning',  cat:'competitor',  icon:'users',          title:"Boulangerie Dupont +12 positions",                  desc:"Concurrent en accélération locale — surveiller les mots-clés 15e",                        time:"1h",      user:"IA Radar",   impact:"Élevé"   },
    { type:'info',     cat:'ai',          icon:'cpu',            title:"Plan IA appliqué — coiffeur-lyon.com",              desc:"3 recommandations IA exécutées : vitesse, maillage, balises",                             time:"2h",      user:"IA Engine",  impact:"Moyen"   },
    { type:'purple',   cat:'team',        icon:'message-circle', title:"Sophie M. — Commentaire audit",                    desc:"Priorité confirmée : corriger balises title en premier",                                   time:"2h",      user:"Sophie M.",  impact:"Faible"  },
    { type:'warning',  cat:'seo',         icon:'alert',          title:"Alerte ranking — plombier urgence paris #7→#12",    desc:"Chute de 5 positions — probable mise à jour algo Google",                                 time:"3h",      user:"Système",    impact:"Critique"},
    { type:'success',  cat:'reports',     icon:'file-text',      title:"Rapport mensuel généré",                            desc:"Rapport SEO Executive Mai 2026 · 14 pages · Partagé 3 clients",                           time:"3h",      user:"Lucas D.",   impact:"Moyen"   },
    { type:'cyan',     cat:'ai',          icon:'zap',            title:"Automatisation lancée — 3 fiches GBP",              desc:"Mise à jour horaires et photos programmée sur 3 fiches Google",                           time:"4h",      user:"IA Auto",    impact:"Moyen"   },
    { type:'info',     cat:'monitoring',  icon:'activity',       title:"Monitor configuré — garage-auto-nice.com",          desc:"Nouveau monitor HTTP ajouté · seuil 500ms · alertes Slack",                               time:"5h",      user:"Lucas D.",   impact:"Faible"  },
    { type:'purple',   cat:'team',        icon:'users',          title:"Sophie M. — Fichier partagé",                       desc:"Stratégie contenu Q3 2026.pdf partagé avec l\'équipe",                                    time:"6h",      user:"Sophie M.",  impact:"Faible"  },
    { type:'warning',  cat:'monitoring',  icon:'alert',          title:"Alerte latence — coiffeur-lyon.com 890ms",          desc:"Seuil 500ms dépassé — Core Web Vitals dégradés",                                         time:"8h",      user:"Système",    impact:"Élevé"   },
    { type:'success',  cat:'seo',         icon:'map-pin',        title:"Local Pack #1 — 15e arr. boulangerie",              desc:"Visibilité Maps 74% — position dominante confirmée",                                      time:"10h",     user:"Système",    impact:"Élevé"   },
    { type:'success',  cat:'reports',     icon:'download',       title:"Rapport téléchargé — Lucas D.",                    desc:"Rapport Mai 2026 téléchargé en PDF",                                                      time:"10h",     user:"Lucas D.",   impact:"Faible"  },
    { type:'success',  cat:'seo',         icon:'check-circle',   title:"Audit lancé — pharmacie-centre.fr",                 desc:"Score initial : 55/100 · 18 optimisations identifiées",                                   time:"1j",      user:"Maël D.",    impact:"Moyen"   },
    { type:'info',     cat:'competitor',  icon:'trending-up',    title:"Rapport concurrent — Plomberie Express 75",         desc:"+180% backlinks ce mois — activité suspecte détectée",                                    time:"1j",      user:"IA Radar",   impact:"Élevé"   },
    { type:'cyan',     cat:'ai',          icon:'cpu',            title:"Prévision IA — risque Local Pack 15e",              desc:"Probabilité 68% — fenêtre action 3 semaines identifiée",                                  time:"1j",      user:"IA Engine",  impact:"Critique"},
    { type:'success',  cat:'monitoring',  icon:'check',          title:"Incident clos — restaurant-lesoleil.com",           desc:"Monitor de retour en ligne · durée incident : 44 min",                                    time:"Hier",    user:"Système",    impact:"Faible"  },
    { type:'warning',  cat:'seo',         icon:'alert-triangle', title:"Quota audits 80% — 240/300 utilisés",               desc:"60 audits restants ce mois — planifier les priorités",                                    time:"Hier",    user:"Système",    impact:"Moyen"   },
    { type:'purple',   cat:'team',        icon:'check-circle',   title:"Mission complétée — Maël D.",                       desc:"Correction balises plombier-paris.fr · 3 pages optimisées",                               time:"2j",      user:"Maël D.",    impact:"Moyen"   },
    { type:'info',     cat:'reports',     icon:'mail',           title:"Rapport envoyé — Restaurant Le Soleil",             desc:"Rapport mensuel client envoyé automatiquement · ouvert 2×",                               time:"2j",      user:"Auto",       impact:"Faible"  },
  ];

  // ══════════════════════════════════════════════════════════
  // SUB: ÉQUIPE & COLLABORATION
  // ══════════════════════════════════════════════════════════
  if (sub === 'team') {
    const members = [
      { name:"Maël D.",    role:"Admin SEO",         avatar:"MD", color:"#2563EB", actions:14, score:88, trend:"+3 cette semaine", contribs:["3 audits lancés","2 missions complétées","1 rapport partagé"] },
      { name:"Sophie M.",  role:"Gestionnaire GBP",  avatar:"SM", color:"#8b5cf6", actions:9,  score:74, trend:"+1 cette semaine", contribs:["4 avis répondus","2 fichiers partagés","1 fiche GBP mise à jour"] },
      { name:"Lucas D.",   role:"Reporting & Data",  avatar:"LD", color:"#22c55e", actions:11, score:82, trend:"+5 cette semaine", contribs:["3 rapports générés","2 exports CSV","1 rapport client envoyé"] },
    ];
    const teamActs = masterFeed.filter(a => a.cat === 'team');
    return \`
      \${isPro
        ? aiBlock("Équipe très active cette semaine. <strong>Lucas D. en progression +5 actions</strong>. Sophie M. doit traiter 14 avis Google restants. Productivité globale : 82/100 — en hausse de +8 pts vs semaine dernière.",
            ['Rapport équipe complet', 'Assigner des missions', 'Planifier une réunion'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">👥</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Analytics équipe — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Scores de productivité, contributions par membre et IA collaboration.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Membres actifs', String(members.length), 'cette semaine', 'up')}
        \${statCard('Actions totales', String(members.reduce((s,m) => s + m.actions, 0)), 'toutes catégories', 'up')}
        \${statCard('Score productivité', '82/100', '+8 pts vs S-1', 'up')}
        \${statCard('Missions ouvertes', '4', 'dont 2 prioritaires', 'neutral')}
      </div>

      <!-- MEMBER CARDS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('users').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Contributions par membre — Mai 2026
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${members.map(m => {
            const pct = m.score;
            return \`<div style="padding:16px;border-radius:12px;border:1px solid \${m.color}28;background:\${m.color}07">
              <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
                <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,\${m.color},\${m.color}88);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff;flex-shrink:0">\${m.avatar}</div>
                <div style="flex:1">
                  <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(m.name)}</div>
                  <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(m.role)}</div>
                </div>
                <div style="text-align:right">
                  <div style="font-size:18px;font-weight:800;color:\${m.color}">\${m.score}<span style="font-size:11px;color:var(--fp-text-faint)">/100</span></div>
                  <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(m.trend)}</div>
                </div>
              </div>
              <div class="fp-progress-track" style="height:5px;margin-bottom:10px"><div class="fp-progress-fill" style="width:\${pct}%;background:\${m.color}"></div></div>
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                \${m.contribs.map(c => \`<span style="font-size:10px;padding:2px 8px;border-radius:6px;background:\${m.color}14;color:\${m.color};font-weight:600">\${escHtml(c)}</span>\`).join('')}
                <span style="font-size:10px;padding:2px 8px;border-radius:6px;background:rgba(255,255,255,0.05);color:var(--fp-text-faint);">\${m.actions} actions totales</span>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- TEAM TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">💬 Fil de collaboration récent</div>
        <div class="fp-timeline">
          \${teamActs.concat(masterFeed.filter(a => a.cat !== 'team').slice(0,4)).map(item => {
            const c = colors[item.type] || '#2563EB';
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25">
                \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}
              </div>
              <div class="fp-timeline-body">
                <div class="fp-timeline-title">\${escHtml(item.title)}</div>
                <div class="fp-timeline-desc">\${escHtml(item.desc)}</div>
                <div class="fp-timeline-time">Il y a \${escHtml(item.time)} · \${escHtml(item.user)}</div>
              </div>
              \${badge(escHtml(item.impact), item.impact === 'Critique' ? '#ef4444' : item.impact === 'Élevé' ? '#f59e0b' : '#475569')}
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: SEO & CROISSANCE
  // ══════════════════════════════════════════════════════════
  if (sub === 'seo') {
    const seoActs = masterFeed.filter(a => a.cat === 'seo');
    const milestones = [
      { icon:'🏆', title:"Local Pack #1 — 15e arrondissement",  date:"09/05", detail:"4 mots-clés dominés dans le 15e"   },
      { icon:'📈', title:"Score SEO 82/100 — boulangerie-martin.fr", date:"09/05", detail:"Record absolu depuis le lancement" },
      { icon:'🌍', title:"Trafic organique +130% en 8 mois",    date:"Mai 26", detail:"4 820 sessions organiques ce mois"  },
      { icon:'🔑', title:"25 mots-clés top 10 Google",           date:"Avr 26", detail:"+8 positions nouvelles top 10"      },
    ];
    const kws = [
      { kw:"boulangerie paris 15",          pos:1,  vol:320, delta:+2,  action:"Renforcer les avis" },
      { kw:"plombier urgence paris",         pos:12, vol:580, delta:-5,  action:"Corriger la page"   },
      { kw:"restaurant gastronomique 75018", pos:18, vol:210, delta:-4,  action:"Optimiser contenu"  },
      { kw:"coiffeur lyon centre",           pos:4,  vol:490, delta:+1,  action:"Suivre"             },
      { kw:"fleuriste mariage paris",        pos:22, vol:190, delta:+7,  action:"Amplifier"          },
    ];
    return \`
      \${aiBlock("Activité SEO intense cette semaine. <strong>82/100 record historique</strong> pour boulangerie-martin.fr. Alerte : plombier urgence paris a chuté de 5 places — action immédiate requise. <strong>Momentum global : +7pts ce mois.</strong>",
        ['Timeline SEO complète', 'Rapport croissance', 'Optimiser les baisses'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Actions SEO ce mois', String(seoActs.length + 12), 'dont 4 majeures', 'up')}
        \${statCard('Mots-clés améliorés', '14', '+7 nouvelles positions top 10', 'up')}
        \${statCard('Score moyen portfolio', '71/100', '+5 pts ce mois', 'up')}
        \${statCard('Momentum SEO', '+7 pts', 'accélération confirmée', 'up')}
      </div>

      <!-- MILESTONES -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">🎯 Jalons SEO — Mai 2026</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px">
          \${milestones.map(m => \`<div style="padding:14px;border-radius:10px;border:1px solid rgba(34,197,94,0.2);background:rgba(34,197,94,0.06)">
            <div style="font-size:20px;margin-bottom:6px">\${m.icon}</div>
            <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(m.title)}</div>
            <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(m.detail)}</div>
            <div style="font-size:10px;color:var(--fp-text-faint);margin-top:4px">\${escHtml(m.date)}</div>
          </div>\`).join('')}
        </div>
      </div>

      <!-- KW TRACKING -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">🔑 Suivi positions — Activité récente</div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Mot-clé</th><th>Position</th><th>Delta</th><th>Volume</th><th>Action</th></tr></thead>
            <tbody>
              \${kws.map(k => {
                const dc = k.delta < 0 ? '#ef4444' : k.delta > 0 ? '#22c55e' : 'var(--fp-text-faint)';
                return \`<tr>
                  <td style="font-weight:600;font-size:11px">\${escHtml(k.kw)}</td>
                  <td style="font-weight:800">#\${k.pos}</td>
                  <td style="font-weight:800;color:\${dc}">\${k.delta > 0 ? '+' : ''}\${k.delta}</td>
                  <td style="color:var(--fp-text-faint)">\${k.vol}</td>
                  <td><button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','\${escHtml(k.action)}…')">\${escHtml(k.action)}</button></td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- SEO TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📅 Timeline SEO — Actions récentes</div>
        <div class="fp-timeline">
          \${seoActs.map(item => {
            const c = colors[item.type] || '#22c55e';
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25">
                \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}
              </div>
              <div class="fp-timeline-body">
                <div class="fp-timeline-title">\${escHtml(item.title)}</div>
                <div class="fp-timeline-desc">\${escHtml(item.desc)}</div>
                <div class="fp-timeline-time">Il y a \${escHtml(item.time)} · \${escHtml(item.user)}</div>
              </div>
              \${badge(escHtml(item.impact), item.impact === 'Critique' ? '#ef4444' : item.impact === 'Élevé' ? '#f59e0b' : '#22c55e')}
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: MONITORING & INCIDENTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'monitoring') {
    const monActs = masterFeed.filter(a => a.cat === 'monitoring');
    const slaRows = STATE.monitors.slice(0, 5).map((m, i) => ({
      ...m, uptime: [99.98, 98.72, 100, 99.12, 99.91][i] || 99.5,
      incidents: [0, 1, 0, 1, 0][i],
      lat: [142, 890, 89, 621, 318][i] || 250,
      sla: [true, false, true, true, true][i],
    }));
    const incidentsLog = [
      { id:'INC-001', title:"Monitor DOWN — restaurant-lesoleil.com", start:"09/05 · 14h32", end:"09/05 · 15h16", dur:"44 min", sev:'critical', status:'Résolu', cause:"Timeout serveur" },
      { id:'INC-002', title:"Latence critique — coiffeur-lyon.com",    start:"09/05 · 11h14", end:"En cours",      dur:"3h+",   sev:'warning',  status:'Actif',   cause:"Images non optimisées" },
      { id:'INC-003', title:"API externe down — Plomberie Express",     start:"07/05 · 09h40", end:"07/05 · 10h12",dur:"32 min", sev:'warning',  status:'Résolu', cause:"Timeout API tiers" },
    ];
    return \`
      \${aiBlock("Monitoring globalement sain — <strong>uptime moyen 99.5%</strong>. 1 incident actif (latence coiffeur-lyon). L\'incident INC-001 résolu en 44 min — MTTR dans les normes. <strong>2 sites nécessitent une attention performance.</strong>",
        ['Rapport SLA complet', 'Optimiser les lents', 'Config alertes'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Événements monitoring', String(monActs.length + 8), 'ce mois', 'neutral')}
        \${statCard('Incidents ouverts', '1', 'latence coiffeur-lyon', 'down')}
        \${statCard('Incidents résolus', '2', 'ce mois — MTTR 38 min', 'up')}
        \${statCard('Uptime moyen', '99.5%', 'SLA cible 99.9%', 'neutral')}
      </div>

      <!-- SLA TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('activity').replace('stroke="currentColor"','stroke="#2563EB"')}
          SLA & Uptime — Tableau de bord
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Monitor</th><th>Uptime</th><th>Latence</th><th>Incidents</th><th>SLA</th></tr></thead>
            <tbody>
              \${slaRows.map(m => \`<tr>
                <td style="font-size:11px;font-weight:600">\${escHtml(m.url?.replace('https://','') || m.name || 'Monitor')}</td>
                <td style="font-weight:700;color:\${m.uptime >= 99.9 ? '#22c55e' : m.uptime >= 99 ? '#f59e0b' : '#ef4444'}">\${m.uptime}%</td>
                <td style="font-weight:700;color:\${m.lat > 500 ? '#ef4444' : m.lat > 300 ? '#f59e0b' : '#22c55e'}">\${m.lat}ms</td>
                <td style="font-weight:700;color:\${m.incidents > 0 ? '#f59e0b' : '#22c55e'}">\${m.incidents}</td>
                <td>\${badge(m.sla ? 'OK' : 'NOK', m.sla ? '#22c55e' : '#ef4444')}</td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- INCIDENT LOG + TIMELINE -->
      <div class="fp-grid-2">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🚨 Journal des incidents</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${incidentsLog.map(inc => {
              const ic = inc.sev === 'critical' ? '#ef4444' : '#f59e0b';
              return \`<div style="padding:12px 14px;border-radius:10px;border:1px solid \${ic}28;background:\${ic}07;border-left:3px solid \${ic}">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                  \${badge(inc.id, ic)}
                  \${badge(inc.status, inc.status === 'Résolu' ? '#22c55e' : '#ef4444')}
                </div>
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(inc.title)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">Cause : \${escHtml(inc.cause)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint);margin-top:4px">\${escHtml(inc.start)} → \${escHtml(inc.end)} · \${escHtml(inc.dur)}</div>
              </div>\`;
            }).join('')}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📡 Activité monitoring récente</div>
          <div class="fp-timeline">
            \${monActs.map(item => {
              const c = colors[item.type] || '#2563EB';
              return \`<div class="fp-timeline-item">
                <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25">
                  \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}
                </div>
                <div class="fp-timeline-body">
                  <div class="fp-timeline-title">\${escHtml(item.title)}</div>
                  <div class="fp-timeline-desc">\${escHtml(item.desc)}</div>
                  <div class="fp-timeline-time">Il y a \${escHtml(item.time)}</div>
                </div>
              </div>\`;
            }).join('')}
          </div>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: IA & AUTOMATIONS
  // ══════════════════════════════════════════════════════════
  if (sub === 'ai') {
    const aiActs = masterFeed.filter(a => a.cat === 'ai');
    const automations = [
      { name:"Mise à jour fiches GBP",         freq:"Quotidien", last:"09/05 · 06h00", status:'actif',  runs:28, success:28, icon:'📍' },
      { name:"Rapport hebdomadaire auto",       freq:"Lundi 8h",  last:"06/05 · 08h00", status:'actif',  runs:4,  success:4,  icon:'📄' },
      { name:"Alerte ranking dégradé",          freq:"Temps réel",last:"09/05 · 11h14", status:'actif',  runs:12, success:11, icon:'🔔' },
      { name:"Nettoyage backlinks spam",        freq:"Mensuel",   last:"01/05 · 00h00", status:'actif',  runs:1,  success:1,  icon:'🔗' },
      { name:"Résumé IA activité quotidienne",  freq:"18h00",     last:"08/05 · 18h00", status:'pause',  runs:7,  success:7,  icon:'🤖' },
    ];
    const aiInsights = [
      { icon:'🎯', title:"Plan optimisation plombier-paris.fr",     applied:"09/05", actions:3, result:"Score +4pts anticipé"   },
      { icon:'📊', title:"Analyse concurrentielle automatique",      applied:"08/05", actions:5, result:"2 menaces identifiées"   },
      { icon:'⚡', title:"Recommandations Core Web Vitals",          applied:"07/05", actions:4, result:"LCP estimé -1.2s"        },
      { icon:'🗺️', title:"Stratégie Local Pack renforcée",           applied:"06/05", actions:6, result:"Visibilité Maps +8%"    },
    ];
    return \`
      \${isUltra
        ? aiBlock("Automations très efficaces ce mois : <strong>28 mises à jour GBP exécutées</strong> sans intervention manuelle. 4 plans IA appliqués — résultats mesurables sur 3 sites. Prochaine optimisation planifiée : restructuration maillage interne coiffeur-lyon.com.",
            ['Créer une automatisation', 'Rapport IA complet', 'Voir les prévisions'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px"><div style="font-size:24px">🤖</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">IA & Automations — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Logs complets des actions IA, automatisations avancées et plans exécutés.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Automatisations actives', String(automations.filter(a => a.status === 'actif').length), 'exécutions 24/7', 'up')}
        \${statCard('Plans IA appliqués', String(aiInsights.length), 'ce mois', 'up')}
        \${statCard('Exécutions réussies', String(automations.reduce((s,a) => s + a.success, 0)), 'taux succès 98%', 'up')}
        \${statCard('Gain temps estimé', '14h/mois', 'tâches automatisées', 'up')}
      </div>

      <!-- AUTOMATIONS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('zap').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Automatisations actives
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${automations.map(a => {
            const ac = a.status === 'actif' ? '#22c55e' : '#f59e0b';
            return \`<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid \${ac}22">
              <span style="font-size:20px;flex-shrink:0">\${a.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(a.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">Fréquence : \${escHtml(a.freq)} · Dernier : \${escHtml(a.last)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:11px;font-weight:700;color:var(--fp-text)">\${a.success}/\${a.runs} OK</div>
                \${badge(a.status === 'actif' ? 'Actif' : 'Pause', ac)}
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- AI PLANS APPLIED -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">🧠 Plans IA exécutés ce mois</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${aiInsights.map(a => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(139,92,246,0.06);border:1px solid rgba(139,92,246,0.2)">
              <span style="font-size:20px;flex-shrink:0">\${a.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(a.title)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${a.actions} actions exécutées · \${escHtml(a.applied)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:11px;font-weight:700;color:#22c55e">\${escHtml(a.result)}</div>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- AI ACTIVITY TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">⚡ Log IA — Actions récentes</div>
        <div class="fp-timeline">
          \${aiActs.map(item => {
            const c = colors[item.type] || '#8b5cf6';
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25">
                \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}
              </div>
              <div class="fp-timeline-body">
                <div class="fp-timeline-title">\${escHtml(item.title)}</div>
                <div class="fp-timeline-desc">\${escHtml(item.desc)}</div>
                <div class="fp-timeline-time">Il y a \${escHtml(item.time)} · \${escHtml(item.user)}</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: RAPPORTS & EXPORTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'reports') {
    const repActs = masterFeed.filter(a => a.cat === 'reports');
    const reportHistory = [
      { name:"Rapport SEO Executive Mai 2026",       type:'PDF',  size:'2.4 MB', date:"09/05", shared:3, status:'Partagé',     color:'#2563EB' },
      { name:"Export données trafic — CSV complet",  type:'CSV',  size:'840 KB', date:"08/05", shared:0, status:'Téléchargé',  color:'#22c55e' },
      { name:"Rapport client — Restaurant Le Soleil",type:'PDF',  size:'1.8 MB', date:"07/05", shared:1, status:'Envoyé auto', color:'#8b5cf6' },
      { name:"Rapport Local SEO — Maël D.",          type:'PDF',  size:'3.1 MB', date:"05/05", shared:2, status:'Partagé',     color:'#f59e0b' },
      { name:"Export conversions Q1-Q2 2026",        type:'XLSX', size:'1.2 MB', date:"01/05", shared:0, status:'Téléchargé',  color:'#22c55e' },
    ];
    const scheduled = [
      { name:"Rapport hebdo — lundi 8h",           next:"12/05 · 08h00", status:'actif',  clients:3 },
      { name:"Rapport mensuel executive",           next:"01/06 · 07h00", status:'actif',  clients:5 },
      { name:"Bilan concurrent mensuel",            next:"01/06 · 09h00", status:'actif',  clients:0 },
      { name:"Rapport client — Restaurant le Soleil", next:"15/05 · 09h00", status:'pause',  clients:1 },
    ];
    return \`
      \${aiBlock("Activité rapports intense ce mois : <strong>5 rapports générés, 6 partages</strong>. Le rapport executive a été ouvert 2× par le client. 4 envois automatiques planifiés. Recommandation : activer le rapport Restaurant Le Soleil mis en pause.",
        ['Générer un rapport', 'Gérer les planifications', 'Voir historique complet'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Rapports générés', String(reportHistory.length), 'ce mois', 'up')}
        \${statCard('Rapports partagés', String(reportHistory.reduce((s,r) => s + r.shared, 0)), 'avec des clients', 'up')}
        \${statCard('Envois planifiés', String(scheduled.filter(s => s.status === 'actif').length), 'actifs ce mois', 'up')}
        \${statCard('Taille totale', '9.3 MB', 'exports et rapports', 'neutral')}
      </div>

      <div class="fp-grid-2 fp-mb-20">
        <!-- REPORT HISTORY -->
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📄 Historique des rapports</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${reportHistory.map(r => \`
              <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
                <div style="width:32px;height:32px;border-radius:8px;background:\${r.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                  \${svgIcon('file-text').replace('stroke="currentColor"',\`stroke="\${r.color}"\`).replace('width="14"','width="13"').replace('height="14"','height="13"')}
                </div>
                <div style="flex:1;min-width:0">
                  <div style="font-size:11px;font-weight:600;color:var(--fp-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${escHtml(r.name)}</div>
                  <div style="font-size:10px;color:var(--fp-text-faint)">\${r.type} · \${r.size} · \${escHtml(r.date)}</div>
                </div>
                \${badge(r.status, r.status === 'Partagé' ? '#2563EB' : r.status === 'Envoyé auto' ? '#8b5cf6' : '#22c55e')}
              </div>
            \`).join('')}
          </div>
        </div>

        <!-- SCHEDULED -->
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🕐 Envois planifiés</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${scheduled.map(s => {
              const sc = s.status === 'actif' ? '#22c55e' : '#f59e0b';
              return \`<div style="padding:12px 14px;border-radius:9px;background:\${sc}08;border:1px solid \${sc}22">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
                  <span style="font-size:11px;font-weight:600;color:var(--fp-text)">\${escHtml(s.name)}</span>
                  \${badge(s.status === 'actif' ? 'Actif' : 'Pause', sc)}
                </div>
                <div style="font-size:10px;color:var(--fp-text-faint)">Prochain : \${escHtml(s.next)}\${s.clients ? ' · ' + s.clients + ' client(s)' : ''}</div>
              </div>\`;
            }).join('')}
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" style="width:100%;margin-top:12px" onclick="showToast('info','Planification…')">Planifier un rapport →</button>
        </div>
      </div>

      <!-- REPORT ACTIVITY TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📊 Activité rapports récente</div>
        <div class="fp-timeline">
          \${repActs.map(item => {
            const c = colors[item.type] || '#2563EB';
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25">
                \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}
              </div>
              <div class="fp-timeline-body">
                <div class="fp-timeline-title">\${escHtml(item.title)}</div>
                <div class="fp-timeline-desc">\${escHtml(item.desc)}</div>
                <div class="fp-timeline-time">Il y a \${escHtml(item.time)} · \${escHtml(item.user)}</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CONCURRENTS & MARCHÉ
  // ══════════════════════════════════════════════════════════
  if (sub === 'competitor') {
    const compActs = masterFeed.filter(a => a.cat === 'competitor');
    const marketMoves = [
      { comp:"Boulangerie Dupont",   event:"Ranking +12 positions Local Pack 15e", date:"09/05", sev:'critical', icon:'📈', color:'#ef4444', detail:"Accélération backlinks +180% + GBP renforcé — menace critique" },
      { comp:"Plomberie Express 75", event:"+180% backlinks ce mois",               date:"08/05", sev:'warning',  icon:'🔗', color:'#f59e0b', detail:"Activité de link building anormale détectée — probable campagne" },
      { comp:"Café Montmartre",      event:"3 articles publiés — mots-clés ciblés", date:"07/05", sev:'warning',  icon:'📝', color:'#f59e0b', detail:"Contenu optimisé ciblant café brunch paris 18" },
      { comp:"Fleurs du Marais",     event:"GBP renforcé +6 nouveaux avis",         date:"06/05", sev:'info',     icon:'⭐', color:'#2563EB', detail:"Score GBP passé de 4.2 à 4.4 — local pack renforcé" },
      { comp:"Coiffure Chic Lyon",   event:"Recul ranking — opportunité",           date:"05/05", sev:'positive', icon:'⬇️', color:'#22c55e', detail:"Perte de 3 positions sur coiffeur lyon centre — à saisir" },
    ];
    return \`
      \${isPro
        ? aiBlock("Semaine concurrentielle intense. <strong>Boulangerie Dupont représente la menace critique</strong> — fenêtre d\'action : 3 semaines. Opportunité : Coiffure Chic Lyon recule sur vos mots-clés. <strong>Action prioritaire : renforcer GBP + publier contenu local.</strong>",
            ['Plan contre-offensive', 'Surveiller les backlinks', 'Rapport concurrent'])
        : \`<div style="padding:14px 16px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">🎯</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Veille concurrentielle — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Timeline des mouvements concurrents, alertes backlinks et opportunités marché.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Mouvements détectés', String(marketMoves.length), 'ce mois', 'neutral')}
        \${statCard('Menace critique', 'Boulangerie Dupont', '+12 positions · -3 sem.', 'down')}
        \${statCard('Opportunité', 'Coiffure Chic Lyon', 'recul détecté', 'up')}
        \${statCard('Backlinks suspects', '+180%', 'Plomberie Express 75', 'down')}
      </div>

      <!-- MARKET MOVES -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('trending-up').replace('stroke="currentColor"','stroke="#ef4444"')}
          Mouvements marché — Timeline mai 2026
        </div>
        <div class="fp-timeline">
          \${marketMoves.map(m => {
            const c = m.color;
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25;font-size:16px;justify-content:center;align-items:center;display:flex">\${m.icon}</div>
              <div class="fp-timeline-body">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                  \${badge(m.sev === 'critical' ? 'Critique' : m.sev === 'warning' ? 'Alerte' : m.sev === 'positive' ? 'Opportunité' : 'Info', c)}
                  <span style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(m.comp)} · \${escHtml(m.date)}</span>
                </div>
                <div class="fp-timeline-title">\${escHtml(m.event)}</div>
                <div class="fp-timeline-desc">\${escHtml(m.detail)}</div>
              </div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Analyse…')">Analyser</button>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- COMPETITOR ACTIVITY FEED -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📡 Activité radar concurrent récente</div>
        <div class="fp-timeline">
          \${compActs.map(item => {
            const c = colors[item.type] || '#ef4444';
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25">
                \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}
              </div>
              <div class="fp-timeline-body">
                <div class="fp-timeline-title">\${escHtml(item.title)}</div>
                <div class="fp-timeline-desc">\${escHtml(item.desc)}</div>
                <div class="fp-timeline-time">Il y a \${escHtml(item.time)} · \${escHtml(item.user)}</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: OPS LAB (Operational Analytics)
  // ══════════════════════════════════════════════════════════
  if (sub === 'ops') {
    const opsScores = [
      { label:'Momentum global',   val:74, color:'#22c55e', icon:'🚀' },
      { label:'Productivité équipe',val:68, color:'#2563EB', icon:'👥' },
      { label:'Vélocité SEO',      val:71, color:'#f59e0b', icon:'🔍' },
      { label:'Stabilité ops',     val:88, color:'#22c55e', icon:'🛡️' },
      { label:'Actions IA',        val:58, color:'#8b5cf6', icon:'🤖' },
      { label:'Growth Score',      val:64, color:'#06b6d4', icon:'📈' },
    ];
    const forecasts = [
      { metric:'Activité SEO M+1',   current:'+12%',  pred:'+18%', conf:72, color:'#22c55e' },
      { metric:'Incidents M+1',       current:'3',     pred:'1-2',  conf:65, color:'#22c55e' },
      { metric:'Productivité équipe', current:'82',    pred:'86',   conf:58, color:'#2563EB' },
      { metric:'Actions IA M+1',      current:'14',    pred:'22',   conf:81, color:'#8b5cf6' },
    ];
    const circ46 = 2 * Math.PI * 46;
    const weeks = ['S18','S19','S20','S21','S22'];
    const momentum = [61, 68, 65, 71, 74];
    const maxM = Math.max(...momentum);
    return \`
      \${isUltra
        ? aiBlock("Performance opérationnelle solide — score global 71/100. <strong>Momentum en hausse</strong> depuis 3 semaines consécutives (+13 pts). Productivité équipe à améliorer : Lucas D. sur-performant, Sophie M. sous-chargée. Prévision : activité SEO +18% M+1.",
            ['Rapport ops complet', 'Optimiser la productivité', 'Voir les prévisions'])
        : \`<div style="background:linear-gradient(135deg,rgba(6,182,212,0.08),rgba(37,99,235,0.06));border:1px solid rgba(6,182,212,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px"><div style="font-size:24px">🔬</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Ops Lab — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Prévisions opérationnelles, scoring de productivité et intelligence stratégique.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Score ops global', '71/100', '+13 pts 3 semaines', 'up')}
        \${statCard('Actions totales', String(masterFeed.length), 'toutes catégories', 'up')}
        \${statCard('Taux automatisation', '38%', 'objectif 60%', 'up')}
        \${statCard('MTTR incidents', '38 min', 'SLA respecté', 'up')}
      </div>

      <!-- 6 OPS SCORES GAUGES -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('cpu').replace('stroke="currentColor"','stroke="#06b6d4"')}
          Scores opérationnels — Analyse IA
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
          \${opsScores.map(k => {
            const filled = k.val / 100 * circ46;
            const dash   = circ46 - filled;
            return \`<div style="padding:14px;border-radius:12px;border:1px solid \${k.color}28;background:\${k.color}07;text-align:center">
              <svg width="64" height="64" viewBox="0 0 120 120" style="margin:0 auto 6px">
                <circle cx="60" cy="60" r="46" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="8"/>
                <circle cx="60" cy="60" r="46" fill="none" stroke="\${k.color}" stroke-width="8"
                  stroke-dasharray="\${filled.toFixed(1)} \${dash.toFixed(1)}"
                  stroke-dashoffset="\${(circ46*0.25).toFixed(1)}"
                  stroke-linecap="round" transform="rotate(-90 60 60)"/>
                <text x="60" y="65" text-anchor="middle" font-size="22" font-weight="800" fill="\${k.color}" font-family="Outfit,sans-serif">\${k.val}</text>
              </svg>
              <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${k.icon} \${escHtml(k.label)}</div>
              \${badge(k.val>=70?'Bon':k.val>=50?'Moyen':'Faible', k.color)}
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- MOMENTUM CHART + FORECASTS -->
      <div class="fp-grid-2">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📈 Évolution momentum — 5 semaines</div>
          <div style="display:flex;gap:6px;align-items:flex-end;height:100px;margin-bottom:10px">
            \${weeks.map((w, i) => {
              const h = Math.round(momentum[i] / maxM * 90);
              const isLast = i === weeks.length - 1;
              return \`<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:0">
                <div style="font-size:9px;color:#22c55e;font-weight:700;margin-bottom:2px">\${isLast ? momentum[i] : ''}</div>
                <div style="width:100%;height:\${h}px;background:linear-gradient(180deg,\${isLast ? 'rgba(34,197,94,0.9)' : 'rgba(37,99,235,0.5)'},\${isLast ? 'rgba(34,197,94,0.2)' : 'rgba(37,99,235,0.1)'});border-radius:4px 4px 0 0;\${isLast ? 'box-shadow:0 0 12px rgba(34,197,94,0.3)' : ''}"></div>
                <div style="font-size:9px;color:var(--fp-text-faint);margin-top:4px">\${w}</div>
              </div>\`;
            }).join('')}
          </div>
          <div style="font-size:11px;color:var(--fp-text-muted);text-align:center">Momentum ops : <strong style="color:#22c55e">74/100</strong> — record historique</div>
        </div>

        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🔮 Prévisions opérationnelles M+1</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${forecasts.map(f => \`
              <div style="padding:12px 14px;border-radius:9px;background:\${f.color}07;border:1px solid \${f.color}28">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                  <span style="font-size:11px;font-weight:600;color:var(--fp-text)">\${escHtml(f.metric)}</span>
                  <div style="text-align:right">
                    <div style="font-size:12px;font-weight:800;color:\${f.color}">\${escHtml(f.pred)}</div>
                    <div style="font-size:9px;color:var(--fp-text-faint)">conf. \${f.conf}%</div>
                  </div>
                </div>
                <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${f.conf}%;background:\${f.color}"></div></div>
                <div style="font-size:10px;color:var(--fp-text-faint);margin-top:4px">Actuel : \${escHtml(f.current)}</div>
              </div>
            \`).join('')}
          </div>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Activity Command Center
  // ══════════════════════════════════════════════════════════
  const cmdScores = [
    { label:'Momentum global',    val:74, color:'#22c55e', icon:'🚀' },
    { label:'Score équipe',       val:68, color:'#2563EB', icon:'👥' },
    { label:'SEO Progress',       val:71, color:'#f59e0b', icon:'🔍' },
    { label:'Monitoring',         val:82, color:'#22c55e', icon:'📡' },
    { label:'IA Actions',         val:58, color:'#8b5cf6', icon:'🤖' },
    { label:'Growth Score',       val:64, color:'#06b6d4', icon:'📈' },
    { label:'Stabilité ops',      val:88, color:'#22c55e', icon:'🛡️' },
  ];
  const circ36 = 2 * Math.PI * 36;

  const catCounts = {
    team:      masterFeed.filter(a => a.cat === 'team').length,
    seo:       masterFeed.filter(a => a.cat === 'seo').length,
    monitoring:masterFeed.filter(a => a.cat === 'monitoring').length,
    ai:        masterFeed.filter(a => a.cat === 'ai').length,
    reports:   masterFeed.filter(a => a.cat === 'reports').length,
    competitor:masterFeed.filter(a => a.cat === 'competitor').length,
  };

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Activity Command Center
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);border-radius:20px;color:#22c55e;animation:pulse 2s infinite">● LIVE</span>
        </h1>
        <div class="fp-section-sub">\${masterFeed.length} événements · 6 catégories · Mis à jour à l\'instant</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Exporter', 'fp-btn fp-btn-ghost fp-btn-sm', 'download', "onclick=\\"showToast('success','Export en cours…')\\"")}
        \${btn('Filtrer',  'fp-btn fp-btn-ghost fp-btn-sm', 'filter',   "onclick=\\"showToast('info','Filtres bientôt disponibles')\\"")}
      </div>
    </div>

    <!-- AI INTELLIGENCE -->
    \${isPro
      ? aiBlock("Activité opérationnelle soutenue cette semaine — <strong>momentum en hausse +13 pts</strong>. Pic : correction audit boulangerie-martin.fr (82/100 record). Incident INC-001 résolu en 44 min. Alerte concurrentielle active : Boulangerie Dupont accélère. <strong>38% des actions automatisées</strong> — objectif 60%.",
          ['Rapport activité complet', 'Analyser la productivité', 'Voir les tendances'])
      : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">⚡</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">IA Activité Intelligence — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse IA de l\'activité, insights productivité et corrélations opérationnelles.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
    }

    <!-- KPI CARDS -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Activités totales', String(masterFeed.length), 'toutes catégories', 'up')}
      \${statCard('Actions critiques', String(masterFeed.filter(a => a.impact === 'Critique').length), 'à fort impact', 'neutral')}
      \${statCard('Automations exec.', '52', 'ce mois · 98% succès', 'up')}
      \${statCard('Membres actifs', '3', 'cette semaine', 'up')}
    </div>

    <!-- 7 SCORE GAUGES -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('activity').replace('stroke="currentColor"','stroke="#22c55e"')}
          Scores opérationnels — Intelligence workspace
        </div>
        <span style="font-size:11px;color:var(--fp-text-faint)">Momentum : <strong style="color:#22c55e">74/100</strong> ↑</span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(108px,1fr));gap:8px">
        \${cmdScores.map(k => {
          const filled = k.val / 100 * circ36;
          const dash   = circ36 - filled;
          return \`<div style="padding:12px;border-radius:11px;border:1px solid \${k.color}28;background:\${k.color}07;text-align:center">
            <svg width="52" height="52" viewBox="0 0 90 90" style="margin:0 auto 4px">
              <circle cx="45" cy="45" r="36" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="7"/>
              <circle cx="45" cy="45" r="36" fill="none" stroke="\${k.color}" stroke-width="7"
                stroke-dasharray="\${filled.toFixed(1)} \${dash.toFixed(1)}"
                stroke-dashoffset="\${(circ36*0.25).toFixed(1)}"
                stroke-linecap="round" transform="rotate(-90 45 45)"/>
              <text x="45" y="50" text-anchor="middle" font-size="18" font-weight="800" fill="\${k.color}" font-family="Outfit,sans-serif">\${k.val}</text>
            </svg>
            <div style="font-size:9px;font-weight:600;color:var(--fp-text-faint)">\${k.icon} \${escHtml(k.label)}</div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- LIVE FEED + QUICK NAV -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card" style="grid-column:span 1">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#22c55e;margin-right:6px;animation:pulse 1.5s infinite"></span>
            Flux d\'activité en temps réel
          </div>
          <span style="font-size:10px;color:var(--fp-text-faint)">Mis à jour à l\'instant</span>
        </div>
        <div class="fp-timeline" style="gap:6px">
          \${masterFeed.slice(0, 10).map(item => {
            const c = colors[item.type] || '#2563EB';
            return \`<div class="fp-timeline-item">
              <div class="fp-timeline-dot" style="background:\${c}12;border-color:\${c}25;width:28px;height:28px;min-width:28px">
                \${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`).replace('width="14"','width="11"').replace('height="14"','height="11"')}
              </div>
              <div class="fp-timeline-body" style="flex:1;min-width:0">
                <div class="fp-timeline-title" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${escHtml(item.title)}</div>
                <div class="fp-timeline-time" style="font-size:9px">Il y a \${escHtml(item.time)} · \${escHtml(item.user)} · \${escHtml(item.cat)}</div>
              </div>
              \${badge(escHtml(item.impact), item.impact === 'Critique' ? '#ef4444' : item.impact === 'Élevé' ? '#f59e0b' : '#475569')}
            </div>\`;
          }).join('')}
        </div>
      </div>

      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧭 Centres d\'activité spécialisés</div>
        <div style="display:flex;flex-direction:column;gap:7px">
          \${[
            { label:'Équipe & Collaboration', sub:'team',       icon:'👥', count:catCounts.team,       desc:members => '3 membres actifs' },
            { label:'SEO & Croissance',        sub:'seo',        icon:'🔍', count:catCounts.seo,        desc:members => String(catCounts.seo) + ' actions SEO ce mois' },
            { label:'Monitoring & Incidents', sub:'monitoring', icon:'📡', count:catCounts.monitoring, desc:members => '1 incident actif · SLA OK' },
            { label:'IA & Automations',        sub:'ai',         icon:'🤖', count:catCounts.ai,         desc:members => String(catCounts.ai) + ' plans IA exécutés' },
            { label:'Rapports & Exports',      sub:'reports',    icon:'📄', count:catCounts.reports,    desc:members => String(catCounts.reports) + ' rapports générés' },
            { label:'Concurrents & Marché',   sub:'competitor', icon:'🎯', count:catCounts.competitor, desc:members => '1 menace critique détectée' },
            { label:'Ops Lab',                 sub:'ops',        icon:'🔬', count:0,                    desc:members => 'Scores et prévisions ops' },
          ].map(n => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${n.sub}')">
              <span style="font-size:16px">\${n.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(n.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${n.desc()}</div>
              </div>
              \${n.count ? \`<span style="font-size:11px;font-weight:800;color:var(--fp-text-soft)">\${n.count}</span>\` : ''}
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--fp-text-faint)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply replacement ──────────────────────────────────────────
src = replaceFunc(src, 'renderActivityFeed', NEW_ACTIVITY);
writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Activity Feed fully replaced (8 sub-pages).');
