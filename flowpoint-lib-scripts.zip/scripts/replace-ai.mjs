import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Add AI sub-nav to SUB_NAVS ───────────────────────────────
const OLD_SUBNAV_SETTINGS = `  'settings': [{id:null,label:'Command Center'},{id:'workspace',label:'Workspace'},{id:'team',label:'Équipe'},{id:'security',label:'Sécurité'},{id:'alerts',label:'Notifications'},{id:'automations',label:'Automatisations'},{id:'integrations',label:'Intégrations'},{id:'api',label:'API & Dev'},{id:'ai-config',label:'IA Config'},{id:'data',label:'Données'}],`;
const NEW_SUBNAV_SETTINGS  = OLD_SUBNAV_SETTINGS + `
  'ai':        [{id:null,label:'Chat'},{id:'intelligence',label:'Intelligence'},{id:'insights',label:'Insights'},{id:'actions',label:'Actions Rapides'},{id:'strategist',label:'IA Stratégiste'}],`;

if (src.includes(OLD_SUBNAV_SETTINGS)) {
  src = src.replace(OLD_SUBNAV_SETTINGS, NEW_SUBNAV_SETTINGS);
  console.log('\u2713 AI sub-nav added (5 sub-pages)');
} else { console.error('Settings sub-nav anchor NOT FOUND'); }

// ══════════════════════════════════════════════════════════════════
// renderAI() — premium 5-sub-page AI co-pilot
// ══════════════════════════════════════════════════════════════════
const NEW_RENDER_AI = `function renderAI() {
  const sub  = STATE.subRoute;
  const me   = STATE.me;
  const plan = me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  // ── Action chip helper ─────────────────────────────────────
  const chip = (label, route, sub_) => {
    const onclick = sub_
      ? \`navigate('\${route}');setTimeout(()=>navigateSub('\${sub_}'),50)\`
      : \`navigate('\${route}')\`;
    return \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:3px 10px;border-radius:20px;height:auto;line-height:1.4" onclick="\${onclick}">\${escHtml(label)} →</button>\`;
  };

  // ── Proactive insight card ─────────────────────────────────
  const insightCard = (icon, title, body, chips, color) => \`
    <div style="padding:14px 16px;border-radius:12px;background:\${color}08;border:1px solid \${color}25;margin-bottom:10px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
        <span style="font-size:16px">\${icon}</span>
        <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(title)}</span>
      </div>
      <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:8px;line-height:1.5">\${body}</div>
      \${chips.length ? \`<div style="display:flex;gap:6px;flex-wrap:wrap">\${chips.join('')}</div>\` : ''}
    </div>
  \`;

  // ══════════════════════════════════════════════════════════
  // SUB: WORKSPACE INTELLIGENCE
  // ══════════════════════════════════════════════════════════
  if (sub === 'intelligence') {
    const systems = [
      {name:'SEO & Audits',      icon:'🔍', score:74,  status:'Bon',      color:'#22c55e', route:'audits',        detail:'4 sites actifs · Score moyen 74/100'},
      {name:'Monitors',          icon:'📡', score:61,  status:'Attention', color:'#f59e0b', route:'monitors',      detail:'3 DOWN · Uptime moyen 97.2%'},
      {name:'Local SEO',         icon:'📍', score:68,  status:'Moyen',    color:'#f59e0b', route:'local-seo',     detail:'2 zones non couvertes · GBP actif'},
      {name:'Concurrents',       icon:'🏁', score:82,  status:'Alerte',   color:'#ef4444', route:'competitor',    detail:'Boulangerie Dupont +4 pts cette semaine'},
      {name:'Conversion',        icon:'💰', score:61,  status:'Faible',   color:'#ef4444', route:'conversion',    detail:'Friction mobile détectée · CTA sous-optimaux'},
      {name:'Rapports',          icon:'📄', score:90,  status:'Excellent',color:'#22c55e', route:'reports',       detail:'Rapport mensuel généré · 3 clients actifs'},
      {name:'Alertes',           icon:'🔔', score:55,  status:'Attention', color:'#f59e0b', route:'alerts-center', detail:'3 incidents actifs · 2 non résolus'},
      {name:'Facturation',       icon:'💳', score:88,  status:'Bon',      color:'#22c55e', route:'billing',       detail:'Plan Pro actif · Prochain débit 01/06'},
    ];
    const correlations = [
      {
        icon:'🔗', color:'#ef4444',
        title:'SEO + Monitors',
        body:'restaurant-lesoleil.com est DOWN depuis 44 min — votre score SEO chute en temps réel. Un monitor down génère en moyenne -3 pts/jour de crawl Google.',
        chips:[chip('Voir les monitors','monitors',null), chip('Auditer le site','audits','analysis')],
      },
      {
        icon:'🔗', color:'#f59e0b',
        title:'Local SEO + Concurrents',
        body:'Boulangerie Dupont a capturé 2 nouveaux mots-clés locaux cette semaine pendant que votre visibilité Map stagne à 68%. Opportunité : optimiser les horaires GBP.',
        chips:[chip('Local SEO','local-seo',null), chip('Analyser les concurrents','competitor','local')],
      },
      {
        icon:'🔗', color:'#8b5cf6',
        title:'Conversion + Performance mobile',
        body:'Score Core Web Vitals mobile < 60 sur plombier-paris.fr. Corrélation directe avec le taux de conversion mobile à 1.2% (benchmark secteur : 3.8%).',
        chips:[chip('Analyser la conversion','conversion','ux-lab'), chip('Audit performance','audits','analysis')],
      },
      {
        icon:'🔗', color:'#06b6d4',
        title:'Rapports + Mode Client',
        body:'3 rapports PDF programmés ce mois — aucun n\'a été consulté par vos clients. Suggérez un accès Mode Client pour améliorer l\'engagement.',
        chips:[chip('Mode Client','client-mode',null), chip('Voir les rapports','reports',null)],
      },
    ];
    return \`
      <div class="fp-section-header">
        <div><h1 style="display:flex;align-items:center;gap:10px">Workspace Intelligence <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(139,92,246,0.15);border:1px solid rgba(139,92,246,0.3);border-radius:20px;color:#8b5cf6">✦ IA</span></h1>
        <div class="fp-section-sub">État en temps réel de tous vos systèmes · Corrélations inter-modules détectées</div></div>
      </div>

      <!-- SYSTEMS GRID -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-bottom:20px">
        \${systems.map(sys => {
          const circ22 = 2 * Math.PI * 22;
          return \`<div style="padding:14px;border-radius:12px;background:rgba(255,255,255,0.02);border:1px solid \${sys.color}22;cursor:pointer" onclick="navigate('\${sys.route}')">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <div style="display:flex;align-items:center;gap:7px">
                <span style="font-size:16px">\${sys.icon}</span>
                <span style="font-size:11px;font-weight:700;color:var(--fp-text)">\${escHtml(sys.name)}</span>
              </div>
              <svg width="36" height="36" viewBox="0 0 54 54">
                <circle cx="27" cy="27" r="22" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="5"/>
                <circle cx="27" cy="27" r="22" fill="none" stroke="\${sys.color}" stroke-width="5"
                  stroke-dasharray="\${(sys.score/100*circ22).toFixed(1)} \${(circ22*(1-sys.score/100)).toFixed(1)}"
                  stroke-linecap="round" transform="rotate(-90 27 27)"/>
                <text x="27" y="32" text-anchor="middle" font-size="12" font-weight="900" fill="\${sys.color}" font-family="Outfit,sans-serif">\${sys.score}</text>
              </svg>
            </div>
            <div style="font-size:10px;color:var(--fp-text-faint);line-height:1.4">\${escHtml(sys.detail)}</div>
            <div style="margin-top:6px;font-size:10px;font-weight:700;color:\${sys.color}">\${escHtml(sys.status)}</div>
          </div>\`;
        }).join('')}
      </div>

      <!-- CROSS-SYSTEM CORRELATIONS -->
      <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:12px">🔗 Corrélations inter-systèmes détectées par l\'IA</div>
      \${correlations.map(c => insightCard(c.icon, c.title, c.body, c.chips, c.color)).join('')}
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: INSIGHTS & RECOMMANDATIONS
  // ══════════════════════════════════════════════════════════
  if (sub === 'insights') {
    const insights = [
      {
        icon:'🔴', color:'#ef4444', priority:'Critique',
        title:'Monitor DOWN depuis 44 min',
        body:'restaurant-lesoleil.com est inaccessible. Impact SEO immédiat : pénalité crawl Google si > 2h.',
        chips:[chip('Voir les monitors','monitors',null), chip('Incidents','alerts-center','incidents')],
      },
      {
        icon:'🟠', color:'#f59e0b', priority:'Urgent',
        title:'Visibilité locale stagnante à 68%',
        body:'2 zones géographiques non couvertes. Vos concurrents gagnent du terrain sur les requêtes locales.',
        chips:[chip('Analyser Local SEO','local-seo',null), chip('Heatmap zones','local-seo','zones')],
      },
      {
        icon:'🟠', color:'#f59e0b', priority:'Urgent',
        title:'Pression concurrentielle en hausse',
        body:'Boulangerie Dupont +4 pts cette semaine. 2 nouveaux concurrents actifs sur vos mots-clés cibles.',
        chips:[chip('Veille concurrents','competitor',null), chip('Analyse mots-clés','competitor','keywords')],
      },
      {
        icon:'🟡', color:'#eab308', priority:'Cette semaine',
        title:'Friction mobile sur plombier-paris.fr',
        body:'Score mobile 52/100. Taux de conversion mobile 1.2% vs benchmark 3.8%. LCP > 4s identifié.',
        chips:[chip('Analyse UX','conversion','ux-lab'), chip('Revenue Leak','conversion','revenue-leak')],
      },
      {
        icon:'🟡', color:'#eab308', priority:'Cette semaine',
        title:'14 avis Google sans réponse',
        body:'Impact négatif sur le score GBP et le trust signal local. Recommandation : répondre sous 24h.',
        chips:[chip('Gérer le GBP','local-seo','gbp'), chip('Dashboard local','local-seo',null)],
      },
      {
        icon:'🟢', color:'#22c55e', priority:'Opportunité',
        title:'Quick wins SEO disponibles',
        body:'+8 points SEO atteignables en 2 semaines via balises title (3 sites) et Core Web Vitals.',
        chips:[chip('Quick Wins','overview','quick-wins'), chip('Lancer les audits','audits',null)],
      },
      {
        icon:'🟢', color:'#22c55e', priority:'Opportunité',
        title:'Plan d\'expansion Local SEO',
        body:'2 nouvelles zones à fort potentiel identifiées : 18e arrondissement et Boulogne-Billancourt.',
        chips:[chip('Voir les opportunités','local-seo','opportunities'), chip('Analyser les zones','local-seo','zones')],
      },
      {
        icon:'🔵', color:'#2563EB', priority:'Pro tip',
        title:'Rapport mensuel prêt à envoyer',
        body:'Votre rapport PDF mai 2026 est généré. 3 clients attendent leur résumé mensuel.',
        chips:[chip('Voir les rapports','reports',null), chip('Mode Client','client-mode',null)],
      },
    ];
    return \`
      <div class="fp-section-header">
        <div><h1>Insights & Recommandations IA</h1>
        <div class="fp-section-sub">Analyse proactive de votre workspace · Mis à jour en temps réel</div></div>
        <div class="fp-section-actions">
          <span style="font-size:11px;color:var(--fp-text-faint)">\${insights.length} insights actifs</span>
        </div>
      </div>
      <div class="fp-stat-row fp-mb-20">
        \${statCard('Critiques', String(insights.filter(i => i.priority === 'Critique').length), 'actions immédiates', 'down')}
        \${statCard('Urgents', String(insights.filter(i => i.priority === 'Urgent').length), 'cette semaine', 'neutral')}
        \${statCard('Opportunités', String(insights.filter(i => i.priority === 'Opportunité').length), 'quick wins détectés', 'up')}
        \${statCard('Score global', '69/100', '+4 pts cette semaine', 'up')}
      </div>
      \${['Critique','Urgent','Cette semaine','Opportunité','Pro tip'].map(prio => {
        const group = insights.filter(i => i.priority === prio);
        if (!group.length) return '';
        const colors = {Critique:'#ef4444',Urgent:'#f59e0b','Cette semaine':'#eab308','Opportunité':'#22c55e','Pro tip':'#2563EB'};
        return \`<div style="margin-bottom:20px">
          <div style="font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:\${colors[prio]};margin-bottom:8px">— \${prio}</div>
          \${group.map(i => insightCard(i.icon, i.title, i.body, i.chips, i.color)).join('')}
        </div>\`;
      }).join('')}
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ACTIONS RAPIDES
  // ══════════════════════════════════════════════════════════
  if (sub === 'actions') {
    const groups = [
      {
        label:'🔍 SEO & Audits', color:'#2563EB',
        actions:[
          {label:'Lancer un audit complet',     icon:'🚀', onclick:"navigate('audits')",                                      desc:'Audite tous vos sites en une fois'},
          {label:'Voir les Quick Wins',          icon:'⚡', onclick:"navigate('overview');setTimeout(()=>navigateSub('quick-wins'),50)", desc:'+8 pts atteignables rapidement'},
          {label:'Comparer les concurrents',     icon:'🏁', onclick:"navigate('competitor')",                                 desc:'Benchmark SEO en temps réel'},
          {label:'Analyser les opportunités',    icon:'💡', onclick:"navigate('audits');setTimeout(()=>navigateSub('opportunites'),50)", desc:'Mots-clés et pages à fort potentiel'},
        ],
      },
      {
        label:'📍 Local SEO', color:'#22c55e',
        actions:[
          {label:'Ouvrir la heatmap locale',    icon:'🗺️', onclick:"navigate('local-seo');setTimeout(()=>navigateSub('zones'),50)", desc:'Visualiser la couverture géographique'},
          {label:'Gérer les fiches GBP',        icon:'📋', onclick:"navigate('local-seo');setTimeout(()=>navigateSub('gbp'),50)",  desc:'Posts, avis et optimisation'},
          {label:'Analyser les concurrents locaux',icon:'👁', onclick:"navigate('local-seo');setTimeout(()=>navigateSub('competitors'),50)", desc:'Benchmark local détaillé'},
          {label:'Voir les opportunités locales',icon:'📈', onclick:"navigate('local-seo');setTimeout(()=>navigateSub('opportunities'),50)", desc:'Zones à fort potentiel'},
        ],
      },
      {
        label:'📡 Monitoring & Alertes', color:'#f59e0b',
        actions:[
          {label:'Voir les incidents actifs',   icon:'🚨', onclick:"navigate('alerts-center')",                              desc:'3 incidents · restaurant-lesoleil DOWN'},
          {label:'Status monitors',             icon:'📊', onclick:"navigate('monitors')",                                  desc:'18 monitors · 3 DOWN'},
          {label:'Créer une règle d\'alerte',   icon:'🔔', onclick:"navigate('settings');setTimeout(()=>navigateSub('automations'),50)", desc:'Automatisations et workflows'},
          {label:'Rapport SLA',                 icon:'📄', onclick:"navigate('monitors');setTimeout(()=>navigateSub('sla'),50)", desc:'Uptime et disponibilité'},
        ],
      },
      {
        label:'📄 Rapports & Clients', color:'#8b5cf6',
        actions:[
          {label:'Générer un rapport mensuel',  icon:'📥', onclick:"navigate('reports')",                                   desc:'PDF white-label automatique'},
          {label:'Ouvrir le Mode Client',       icon:'👥', onclick:"navigate('client-mode')",                               desc:'Dashboard et rapports partagés'},
          {label:'Rapport exécutif',            icon:'🏆', onclick:"navigate('reports');setTimeout(()=>navigateSub('exec'),50)", desc:'Résumé direction 2 pages'},
          {label:'Analytics client',            icon:'📈', onclick:"navigate('client-mode');setTimeout(()=>navigateSub('analytics'),50)", desc:'Suivi performances clients'},
        ],
      },
      {
        label:'💰 Conversion & Revenue', color:'#ef4444',
        actions:[
          {label:'Analyser le funnel',          icon:'🔄', onclick:"navigate('conversion');setTimeout(()=>navigateSub('funnel'),50)", desc:'Taux de conversion par étape'},
          {label:'Détecter la friction UX',     icon:'🖱️', onclick:"navigate('conversion');setTimeout(()=>navigateSub('ux-lab'),50)", desc:'Heatmaps et points de friction'},
          {label:'Revenue Leak',                icon:'💸', onclick:"navigate('conversion');setTimeout(()=>navigateSub('revenue-leak'),50)", desc:'Fuites de revenus identifiées'},
          {label:'CRO avec l\'IA',              icon:'🤖', onclick:"navigate('conversion');setTimeout(()=>navigateSub('cro'),50)", desc:'Recommandations A/B automatiques'},
        ],
      },
      {
        label:'📊 Data & Intelligence', color:'#06b6d4',
        actions:[
          {label:'Data Explorer',               icon:'🗄️', onclick:"navigate('data-explorer')",                             desc:'Analyse avancée de vos données'},
          {label:'Prévisions IA',               icon:'🔮', onclick:"navigate('data-explorer');setTimeout(()=>navigateSub('forecast'),50)", desc:'Modèle prédictif 30/90 jours'},
          {label:'IA Insights',                 icon:'🧠', onclick:"navigate('data-explorer');setTimeout(()=>navigateSub('insights'),50)", desc:'Insights automatiques IA'},
          {label:'Exporter les données',        icon:'📤', onclick:"navigate('data-explorer');setTimeout(()=>navigateSub('export'),50)", desc:'CSV, JSON, intégrations'},
        ],
      },
    ];
    return \`
      <div class="fp-section-header">
        <div><h1>Actions Rapides</h1>
        <div class="fp-section-sub">Naviguez vers n\'importe quel système Flowpoint en un clic</div></div>
      </div>
      \${groups.map(g => \`
        <div class="fp-card fp-mb-20">
          <div style="font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:\${g.color};margin-bottom:12px">\${g.label}</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px">
            \${g.actions.map(a => \`
              <div style="padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);cursor:pointer;transition:border-color .15s,background .15s"
                onmouseover="this.style.borderColor='\${g.color}33';this.style.background='\${g.color}06'"
                onmouseout="this.style.borderColor='rgba(255,255,255,0.05)';this.style.background='rgba(255,255,255,0.02)'"
                onclick="\${a.onclick}">
                <div style="font-size:18px;margin-bottom:5px">\${a.icon}</div>
                <div style="font-size:11px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(a.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(a.desc)}</div>
              </div>
            \`).join('')}
          </div>
        </div>
      \`).join('')}
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: IA STRATÉGISTE (Ultra)
  // ══════════════════════════════════════════════════════════
  if (sub === 'strategist') {
    const strategies = [
      {
        n:1, color:'#ef4444',
        title:'Domination Local SEO — 60 jours',
        body:'Votre score local stagne à 68% pendant que vos concurrents gagnent du terrain. Plan d\'action : optimiser les fiches GBP des 3 sites principaux, couvrir 2 nouvelles zones, générer 20 posts locaux IA.',
        metrics:[{l:'Impact estimé',v:'+18 pts local'},{l:'Leads potentiels',v:'+40%'},{l:'Durée',v:'60 jours'}],
        chips:[chip('Lancer le plan Local SEO','local-seo',null), chip('Analyser les zones','local-seo','zones')],
      },
      {
        n:2, color:'#f59e0b',
        title:'Recovery SEO — 3 sites critiques',
        body:'Plombier Paris (38/100), Restaurant Le Soleil (61/100) et 1 autre site sont sous le seuil de rentabilité SEO. ROI estimé : +35% leads organiques en 45 jours avec les corrections prioritaires.',
        metrics:[{l:'ROI estimé',v:'+35% leads'},{l:'Corrections',v:'47 issues'},{l:'Durée',v:'45 jours'}],
        chips:[chip('Voir les audits','audits',null), chip('Quick Wins','overview','quick-wins')],
      },
      {
        n:3, color:'#8b5cf6',
        title:'Conversion Intelligence — Mobile First',
        body:'Votre taux de conversion mobile est 3x inférieur au benchmark sectoriel. Chaque mois de retard représente ~2 400 € de revenus manqués. Plan : CWV mobile, CTA optimization, A/B testing IA.',
        metrics:[{l:'Revenus manqués',v:'~2 400€/mois'},{l:'Conversion actuelle',v:'1.2%'},{l:'Objectif',v:'3.5%'}],
        chips:[chip('Analyse conversion','conversion','cro'), chip('UX & Friction','conversion','ux-lab')],
      },
      {
        n:4, color:'#22c55e',
        title:'Scale Agency — 5 nouveaux clients',
        body:'Votre infrastructure est prête pour 5 clients supplémentaires sans surcoût. Add-ons actifs, Mode Client opérationnel, rapports white-label configurés. Seul manque : la prospection ciblée.',
        metrics:[{l:'Capacité disponible',v:'5 clients'},{l:'MRR potentiel',v:'+2 000€'},{l:'Setup',v:'2 jours'}],
        chips:[chip('Mode Client','client-mode','agency'), chip('Facturation','billing','enterprise')],
      },
    ];
    return \`
      <div class="fp-section-header">
        <div><h1 style="display:flex;align-items:center;gap:10px">IA Stratégiste
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(139,92,246,0.15);border:1px solid rgba(139,92,246,0.3);border-radius:20px;color:#8b5cf6">✦ Ultra</span>
        </h1>
        <div class="fp-section-sub">Analyse stratégique complète · Plans d\'action priorisés · ROI calculé</div></div>
      </div>

      \${!isUltra ? \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.1),rgba(37,99,235,0.08));border:1px solid rgba(139,92,246,0.25);border-radius:var(--fp-radius-lg);padding:20px;margin-bottom:20px;text-align:center">
        <div style="font-size:28px;margin-bottom:8px">🧠</div>
        <div style="font-size:15px;font-weight:800;margin-bottom:6px">IA Stratégiste — Plan Ultra requis</div>
        <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:14px">Analyse stratégique complète, plans d\'action ROI et intelligence prédictive.</div>
        <button class="fp-btn fp-btn-primary" onclick="navigate('billing');setTimeout(()=>navigateSub('plans'),50)">Passer Ultra — 199€/mois →</button>
      </div>\` : ''}

      <div style="\${!isUltra ? 'opacity:0.55;pointer-events:none' : ''}">
        <div class="fp-stat-row fp-mb-20">
          \${statCard('Score optimisation', '61/100', '4 plans d\'action disponibles', 'up')}
          \${statCard('ROI total estimé', '+4 400€/mois', 'si tous les plans appliqués', 'up')}
          \${statCard('Priorité n°1', 'Local SEO', 'impact le plus rapide', 'up')}
          \${statCard('Horizon stratégique', '60 jours', 'plan complet', 'neutral')}
        </div>
        \${strategies.map(s => \`
          <div style="padding:18px 20px;border-radius:14px;background:\${s.color}07;border:1px solid \${s.color}22;margin-bottom:12px">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
              <div style="width:28px;height:28px;border-radius:50%;background:\${s.color}20;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:900;color:\${s.color};flex-shrink:0">\${s.n}</div>
              <div style="font-size:13px;font-weight:800;color:var(--fp-text)">\${escHtml(s.title)}</div>
            </div>
            <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:10px;line-height:1.6">\${escHtml(s.body)}</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
              \${s.metrics.map(m => \`<div style="padding:5px 10px;border-radius:8px;background:\${s.color}12;border:1px solid \${s.color}25">
                <div style="font-size:9px;color:var(--fp-text-faint)">\${escHtml(m.l)}</div>
                <div style="font-size:12px;font-weight:800;color:\${s.color}">\${escHtml(m.v)}</div>
              </div>\`).join('')}
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">\${s.chips.join('')}</div>
          </div>
        \`).join('')}
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Chat premium compact
  // ══════════════════════════════════════════════════════════
  const promptCats = [
    {
      cat:'🔍 SEO & Audits',
      prompts:['Quels sont mes 3 sites les plus critiques ?','Analyser les balises title manquantes','Que faire pour passer de 74 à 85/100 ?','Comparer mon score vs mes concurrents'],
    },
    {
      cat:'📍 Local SEO',
      prompts:['Optimiser ma fiche Google Business','Quels mots-clés locaux capter ?','Générer 3 posts GBP pour cette semaine','Mes concurrents ont-ils des failles ?'],
    },
    {
      cat:'📊 Rapports & Data',
      prompts:['Créer un rapport mensuel pour mon client','Résumer les performances de mai 2026','Quels KPIs mettre en avant ?','Générer un résumé exécutif (2 pages)'],
    },
    {
      cat:'⚡ Actions prioritaires',
      prompts:['Que faire en priorité aujourd\'hui ?','Comment améliorer mon uptime ?','Plan d\'action 30 jours pour +10 pts SEO','Identifier les fuites de conversion'],
    },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Assistant IA Flowpoint
          <span style="font-size:10px;font-weight:600;padding:2px 8px;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);border-radius:20px;color:#22c55e">● En ligne</span>
        </h1>
        <div class="fp-section-sub">GPT-4o · Contexte complet workspace · Réponses &lt; 3s</div>
      </div>
      <div class="fp-section-actions">
        <select class="fp-select" style="font-size:11px" onchange="showToast('info','Modèle : '+this.options[this.selectedIndex].text)">
          <option selected>GPT-4o</option>
          <option>GPT-4 Turbo</option>
          <option>Claude 3.5 Sonnet</option>
          <option>Gemini 1.5 Pro</option>
        </select>
        \${btn('Nouvelle conv.','fp-btn fp-btn-ghost fp-btn-sm','','onclick="STATE.aiMessages=[];updateAIUI();render()"')}
      </div>
    </div>

    <!-- USAGE STRIP -->
    <div style="display:flex;align-items:center;gap:16px;padding:8px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);margin-bottom:16px;flex-wrap:wrap">
      \${[
        {l:'Requêtes',      v:'47/100'},
        {l:'Tokens',        v:'82k/200k'},
        {l:'Temps moyen',   v:'2.4s'},
        {l:'Satisfaction',  v:'94%'},
      ].map(k => \`<div style="display:flex;align-items:center;gap:6px"><span style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(k.l)} :</span><span style="font-size:11px;font-weight:700;color:var(--fp-text)">\${escHtml(k.v)}</span></div>\`).join('<span style="color:rgba(255,255,255,0.1)">|</span>')}
    </div>

    <!-- QUICK PROMPTS -->
    <div class="fp-card fp-card-sm fp-mb-16">
      <div style="font-size:10px;font-weight:700;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.07em;margin-bottom:8px">Suggestions rapides</div>
      <div class="fp-ai-quick-prompts">
        \${['Améliorer mon score SEO moyen','Analyser les monitors DOWN','Que faire en priorité ?','Plan d\'action 30 jours','Créer un rapport mensuel','Opportunités Local SEO'].map(p =>\`<button class="fp-ai-quick" data-ai-prompt="\${p}">\${p}</button>\`).join('')}
      </div>
    </div>

    <!-- CHAT -->
    <div class="fp-card" style="padding:0;overflow:hidden;margin-bottom:16px">
      <div class="fp-ai-wrap" id="ai-messages" style="padding:16px;min-height:200px;max-height:46vh;overflow-y:auto">
        \${renderAIMessages()}
      </div>
      <div style="border-top:1px solid rgba(255,255,255,0.06);padding:10px 12px">
        <div class="fp-ai-input-row">
          <input class="fp-ai-input" id="ai-input" placeholder="Posez votre question… (moniteurs, SEO, conversions, rapports…)" type="text"/>
          <button class="fp-ai-send" id="ai-send">\${svgIcon('send').replace('width="14"','width="15"').replace('height="14"','height="15"')}</button>
        </div>
      </div>
    </div>

    <!-- PROMPT TEMPLATES -->
    <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:10px">Bibliothèque de prompts</div>
    <div class="fp-grid-2" style="gap:10px;margin-bottom:24px">
      \${promptCats.map(cat => \`
        <div class="fp-card fp-card-sm">
          <div style="font-size:11px;font-weight:700;color:var(--fp-text);margin-bottom:8px">\${cat.cat}</div>
          <div style="display:flex;flex-direction:column;gap:3px">
            \${cat.prompts.map(p => \`<button class="fp-ai-quick" data-ai-prompt="\${p}" style="text-align:left;justify-content:flex-start;font-size:11px;padding:5px 9px">\${p}</button>\`).join('')}
          </div>
        </div>
      \`).join('')}
    </div>

    <!-- WORKSPACE CONTEXT -->
    <div class="fp-card fp-card-sm">
      <div style="font-size:10px;font-weight:700;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.07em;margin-bottom:10px">Contexte workspace actif</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:6px">
        \${[
          {l:'Plan',       v:plan,                                  c:'#2563EB'},
          {l:'Audits',     v:me.usage.audit.used+'/'+me.usage.audit.limit, c:'#22c55e'},
          {l:'Monitors DOWN', v:'3',                               c:'#ef4444'},
          {l:'Score moyen',v:avgScore()+'/100',                    c:avgScore()>75?'#22c55e':'#f59e0b'},
          {l:'Alerts',     v:'3 actives',                          c:'#f59e0b'},
          {l:'Clients',    v:'3 actifs',                           c:'#8b5cf6'},
        ].map(k => \`<div style="padding:8px 10px;border-radius:8px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05)">
          <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(k.l)}</div>
          <div style="font-size:12px;font-weight:800;color:\${k.c}">\${escHtml(String(k.v))}</div>
        </div>\`).join('')}
      </div>
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════════
// renderAIMessages() — compact premium bubbles + contextual action chips
// ══════════════════════════════════════════════════════════════════
const NEW_RENDER_AI_MESSAGES = `function renderAIMessages() {
  if (STATE.aiMessages.length === 0) {
    STATE.aiMessages = [{ from:'ai', text:'Bonjour ! Je suis votre co-pilote Flowpoint IA. J\'ai accès à vos audits, monitors, score SEO (74/100), alertes actives et métriques clients. Par où commençons-nous ?', chips:['audits','monitors'] }];
  }

  // Detect contextual chips to add from message content
  function detectChips(text) {
    const chips = [];
    const t = text.toLowerCase();
    if (t.includes('monitor') || t.includes('down') || t.includes('uptime') || t.includes('incident'))
      chips.push({label:'Voir les monitors',       route:'monitors',       sub:null});
    if (t.includes('local') || t.includes('gbp') || t.includes('google business') || t.includes('maps'))
      chips.push({label:'Local SEO',               route:'local-seo',      sub:null});
    if (t.includes('concurrent') || t.includes('benchmark') || t.includes('compétiteur'))
      chips.push({label:'Analyse concurrents',     route:'competitor',     sub:null});
    if (t.includes('rapport') || t.includes('pdf') || t.includes('client') || t.includes('export'))
      chips.push({label:'Rapports',                route:'reports',        sub:null});
    if (t.includes('conversion') || t.includes('cta') || t.includes('friction') || t.includes('mobile'))
      chips.push({label:'Analyse conversion',      route:'conversion',     sub:'ux-lab'});
    if (t.includes('alerte') || t.includes('alert') || t.includes('incident'))
      chips.push({label:'Centre d\'alertes',       route:'alerts-center',  sub:null});
    if (t.includes('priorit') || t.includes('mission') || t.includes('action'))
      chips.push({label:'Missions IA',             route:'missions',       sub:'ai'});
    if (t.includes('score') || t.includes('audit') || t.includes('seo') || t.includes('balise'))
      chips.push({label:'Audits SEO',              route:'audits',         sub:null});
    if (t.includes('facturation') || t.includes('plan') || t.includes('upgrade') || t.includes('billing'))
      chips.push({label:'Facturation',             route:'billing',        sub:null});
    if (t.includes('données') || t.includes('data') || t.includes('analytics') || t.includes('trafic'))
      chips.push({label:'Data Explorer',           route:'data-explorer',  sub:null});
    return chips.slice(0, 3); // max 3 chips per message
  }

  const renderChips = (chips) => {
    if (!chips || !chips.length) return '';
    return \`<div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:7px">
      \${chips.map(c => {
        const onclick = c.sub
          ? \`navigate('\${c.route}');setTimeout(()=>navigateSub('\${c.sub}'),50)\`
          : \`navigate('\${c.route}')\`;
        return \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:2px 9px;border-radius:16px;height:auto;line-height:1.5;color:var(--fp-accent);border-color:rgba(37,99,235,0.3)" onclick="\${onclick}">\${escHtml(c.label)} →</button>\`;
      }).join('')}
    </div>\`;
  };

  const messages = STATE.aiMessages.map(m => {
    const isAI = m.from === 'ai';
    const autoChips = isAI ? detectChips(m.text) : [];
    const allChips  = isAI ? [...(m.chips || []).map(r => ({label:r,route:r,sub:null})), ...autoChips] : [];
    const dedupedChips = allChips.filter((c, i, arr) => arr.findIndex(x => x.route === c.route) === i);

    return \`<div class="fp-ai-message \${m.from}" style="margin-bottom:10px;display:flex;align-items:flex-start;gap:8px;flex-direction:\${isAI ? 'row' : 'row-reverse'}">
      <div style="width:24px;height:24px;border-radius:8px;background:\${isAI ? 'rgba(37,99,235,0.15)' : 'rgba(139,92,246,0.15)'};display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px">
        \${isAI ? svgIcon('bot').replace('stroke="currentColor"','stroke="#2563EB"').replace('width="14"','width="12"').replace('height="14"','height="12"') : svgIcon('user').replace('stroke="currentColor"','stroke="#8b5cf6"').replace('width="14"','width="12"').replace('height="14"','height="12"')}
      </div>
      <div style="max-width:82%;min-width:0">
        <div style="padding:9px 12px;border-radius:\${isAI ? '4px 12px 12px 12px' : '12px 4px 12px 12px'};background:\${isAI ? 'rgba(255,255,255,0.04)' : 'rgba(37,99,235,0.12)'};border:1px solid \${isAI ? 'rgba(255,255,255,0.07)' : 'rgba(37,99,235,0.2)'};font-size:12px;color:var(--fp-text-soft);line-height:1.6">
          \${escHtml(m.text).replace(/\\*\\*(.+?)\\*\\*/g,'<strong style="color:var(--fp-text)">$1</strong>').replace(/\\n/g,'<br>')}
        </div>
        \${isAI ? renderChips(dedupedChips) : ''}
      </div>
    </div>\`;
  }).join('');

  const typing = STATE.aiLoading ? \`<div class="fp-ai-message ai" style="margin-bottom:10px;display:flex;align-items:flex-start;gap:8px">
    <div style="width:24px;height:24px;border-radius:8px;background:rgba(37,99,235,0.15);display:flex;align-items:center;justify-content:center;flex-shrink:0">
      \${svgIcon('bot').replace('stroke="currentColor"','stroke="#2563EB"').replace('width="14"','width="12"').replace('height="14"','height="12"')}
    </div>
    <div style="padding:9px 12px;border-radius:4px 12px 12px 12px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07)">
      <div class="fp-ai-typing"><div class="fp-ai-typing-dot"></div><div class="fp-ai-typing-dot"></div><div class="fp-ai-typing-dot"></div></div>
    </div>
  </div>\` : '';

  return messages + typing;
}`;

// ══════════════════════════════════════════════════════════════════
// renderAIPanelContent() — compact upgraded side panel
// ══════════════════════════════════════════════════════════════════
const NEW_RENDER_AI_PANEL = `function renderAIPanelContent() {
  const navChips = [
    {l:'📊 Data',   r:'data-explorer', s:null},
    {l:'📍 Local',  r:'local-seo',     s:null},
    {l:'🚨 Alertes',r:'alerts-center', s:null},
    {l:'📄 Rapports',r:'reports',      s:null},
  ];
  return \`
    <div style="margin-bottom:10px">
      <div style="font-size:9px;font-weight:700;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px">Navigation rapide</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap">
        \${navChips.map(c => \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:2px 8px;border-radius:16px;height:auto;line-height:1.5"
          onclick="navigate('\${c.r}')\${c.s ? \`;setTimeout(()=>navigateSub('\${c.s}'),50)\` : ''}">\${c.l}</button>\`).join('')}
      </div>
    </div>
    <div class="fp-ai-quick-prompts" style="margin-bottom:10px">
      \${['Que faire en priorité ?','Monitors DOWN','Score SEO moyen','Rapport mensuel'].map(p =>\`<button class="fp-ai-quick" data-ai-prompt="\${p}" style="font-size:10px;padding:4px 9px">\${p}</button>\`).join('')}
    </div>
    <div id="ai-panel-messages" style="display:flex;flex-direction:column;max-height:280px;overflow-y:auto;margin-bottom:10px">
      \${renderAIMessages()}
    </div>
    <div class="fp-ai-input-row">
      <input class="fp-ai-input" id="ai-panel-input" placeholder="Posez votre question…" style="font-size:11px"/>
      <button class="fp-ai-send" id="ai-panel-send">\${svgIcon('send').replace('width="14"','width="13"').replace('height="14"','height="13"')}</button>
    </div>
  \`;
}`;

// ── Apply replacements ─────────────────────────────────────────
src = replaceFunc(src, 'renderAI',           NEW_RENDER_AI);
src = replaceFunc(src, 'renderAIMessages',   NEW_RENDER_AI_MESSAGES);
src = replaceFunc(src, 'renderAIPanelContent', NEW_RENDER_AI_PANEL);

writeFileSync(file, src, 'utf8');
console.log('\n\u2705 AI system upgraded: 5 sub-pages + compact chat + contextual chips + workspace intelligence.');
