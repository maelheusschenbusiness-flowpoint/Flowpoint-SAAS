import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`✓ Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ══════════════════════════════════════════════════════════════
// 1. renderLocalSEO() — Aperçu / Overview
// ══════════════════════════════════════════════════════════════
const NEW_LOCAL_SEO = `function renderLocalSEO() {
  const plan = STATE.me?.plan || 'Pro';
  const isStd  = plan === 'Standard';
  const isPro  = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const domScore = 72;
  const circ = 2 * Math.PI * 52;
  const dominatedZones = 4;
  const totalZones = 8;
  const oppCount = 12;

  const cities = [
    { name: 'Paris Centre',   pos: 2,  delta: +1, mobile: 3,  desktop: 2,  cov: 91 },
    { name: 'Lyon 1-4',       pos: 1,  delta:  0, mobile: 2,  desktop: 1,  cov: 88 },
    { name: 'Liège',          pos: 4,  delta: +2, mobile: 5,  desktop: 4,  cov: 67 },
    { name: 'Verviers',       pos: 7,  delta: -1, mobile: 9,  desktop: 7,  cov: 41 },
    { name: 'Spa',            pos: 4,  delta: +3, mobile: 6,  desktop: 4,  cov: 58 },
    { name: 'Namur',          pos: 11, delta:  0, mobile: 14, desktop: 11, cov: 22 },
    { name: 'Bordeaux',       pos: 6,  delta: +1, mobile: 7,  desktop: 6,  cov: 53 },
    { name: 'Marseille',      pos: 9,  delta: -2, mobile: 12, desktop: 9,  cov: 31 },
  ];

  const milestones = [
    { icon: '🏆', label: 'Domination locale', desc: '70%+ de couverture', done: true },
    { icon: '⭐', label: 'GBP Elite',          desc: '4.5+ avec 50 avis',  done: true },
    { icon: '🗺️', label: 'Expansion Pro',      desc: '5+ zones actives',  done: false },
    { icon: '🤖', label: 'IA Stratège',         desc: 'Ultra requis',      done: false, locked: !isUltra },
  ];

  const forecasts = [
    { month: 'Juin',   val: 1420, prev: 1180 },
    { month: 'Juil.',  val: 1680, prev: 1420 },
    { month: 'Août',   val: 1540, prev: 1680 },
    { month: 'Sept.',  val: 1910, prev: 1540 },
  ];
  const maxForecast = Math.max(...forecasts.map(f => f.val));

  const missingPages = [
    { city: 'Paris 13-15', kw: 'boulangerie artisanale', vol: 340 },
    { city: 'Marseille 6', kw: 'coiffeur haut de gamme',  vol: 210 },
    { city: 'Bordeaux Sud', kw: 'plombier urgence',       vol: 480 },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Domination Locale
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.3);border-radius:20px;color:var(--fp-accent)">IA</span>
        </h1>
        <div class="fp-section-sub">Plateforme de visibilité locale — Intelligence géographique en temps réel</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Rapport local', 'fp-btn fp-btn-ghost fp-btn-sm', 'download', "onclick=\\"showToast('info','Génération rapport local…')\\"" )}
        \${btn('+ Mission locale', 'fp-btn fp-btn-primary fp-btn-sm', 'plus', "onclick=\\"showToast('success','Mission locale créée !')\\"" )}
      </div>
    </div>

    <!-- AI STRATEGIST -->
    \${isUltra
      ? aiBlock('<strong>Score de domination : 72/100</strong> · Vous dominez <strong>63% des recherches locales</strong> dans votre zone cible. Opportunité majeure : <strong>Bordeaux Sud</strong> et <strong>Paris 13-15</strong> — aucun concurrent bien optimisé. Créer 3 pages locales peut générer <strong>+1 030 visites/mois</strong>.', ['Voir les opportunités', 'Générer pages locales', 'Rapport stratégique'])
      : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.08));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
          <div style="font-size:24px;flex-shrink:0">🤖</div>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">Stratège IA Local — Plan Ultra requis</div>
            <div style="font-size:12px;color:var(--fp-text-muted)">Accédez aux recommandations IA personnalisées, aux prévisions de croissance et à la détection automatique des opportunités locales non exploitées.</div>
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" style="flex-shrink:0" onclick="showToast('info','Mise à niveau vers Ultra…')">Passer Ultra</button>
        </div>\`
    }

    <!-- KPI ROW -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Score domination', domScore + '/100', '+5 pts ce mois', 'up')}
      \${statCard('Zones dominées', dominatedZones + '/' + totalZones, 'à 70%+ couverture', 'neutral')}
      \${statCard('Opportunités détectées', oppCount, 'non exploitées', 'down')}
      \${statCard('Menaces actives', '3', 'concurrents en hausse', 'neutral')}
    </div>

    <!-- HEATMAP + DOMINATION SCORE -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- HEATMAP -->
      <div class="fp-card" style="overflow:hidden;padding:18px 20px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('map').replace('stroke="currentColor"','stroke="#2563EB"')}
            Heatmap de visibilité locale
          </div>
          \${!isPro ? \`<span style="font-size:10px;padding:2px 8px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);border-radius:10px;color:#f59e0b">Pro+</span>\` : ''}
        </div>
        \${isPro ? \`
        <div style="position:relative;width:100%;height:200px;background:linear-gradient(135deg,#050810 0%,#0a1628 100%);border-radius:12px;overflow:hidden;border:1px solid var(--fp-border)">
          <!-- Grid lines -->
          <svg width="100%" height="100%" style="position:absolute;inset:0;opacity:0.15">
            <defs>
              <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
                <path d="M 32 0 L 0 0 0 32" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)"/>
          </svg>
          <!-- Heatmap blobs -->
          <svg width="100%" height="100%" style="position:absolute;inset:0">
            <defs>
              <radialGradient id="h1" cx="50%" cy="50%"><stop offset="0%" stop-color="#2563EB" stop-opacity="0.7"/><stop offset="100%" stop-color="#2563EB" stop-opacity="0"/></radialGradient>
              <radialGradient id="h2" cx="50%" cy="50%"><stop offset="0%" stop-color="#22c55e" stop-opacity="0.6"/><stop offset="100%" stop-color="#22c55e" stop-opacity="0"/></radialGradient>
              <radialGradient id="h3" cx="50%" cy="50%"><stop offset="0%" stop-color="#8b5cf6" stop-opacity="0.5"/><stop offset="100%" stop-color="#8b5cf6" stop-opacity="0"/></radialGradient>
              <radialGradient id="h4" cx="50%" cy="50%"><stop offset="0%" stop-color="#f59e0b" stop-opacity="0.4"/><stop offset="100%" stop-color="#f59e0b" stop-opacity="0"/></radialGradient>
              <radialGradient id="h5" cx="50%" cy="50%"><stop offset="0%" stop-color="#ef4444" stop-opacity="0.35"/><stop offset="100%" stop-color="#ef4444" stop-opacity="0"/></radialGradient>
            </defs>
            <ellipse cx="38%" cy="42%" rx="90" ry="70" fill="url(#h1)"/>
            <ellipse cx="62%" cy="35%" rx="70" ry="55" fill="url(#h2)"/>
            <ellipse cx="78%" cy="65%" rx="55" ry="45" fill="url(#h3)"/>
            <ellipse cx="22%" cy="70%" rx="50" ry="40" fill="url(#h4)"/>
            <ellipse cx="55%" cy="75%" rx="40" ry="30" fill="url(#h5)"/>
            <!-- City dots -->
            <circle cx="38%" cy="42%" r="5" fill="#2563EB" opacity="0.9"/>
            <circle cx="62%" cy="35%" r="4" fill="#22c55e" opacity="0.9"/>
            <circle cx="78%" cy="65%" r="4" fill="#8b5cf6" opacity="0.9"/>
            <circle cx="22%" cy="70%" r="4" fill="#f59e0b" opacity="0.9"/>
            <circle cx="55%" cy="75%" r="3" fill="#ef4444" opacity="0.9"/>
            <!-- You are here -->
            <circle cx="50%" cy="50%" r="7" fill="none" stroke="#2563EB" stroke-width="2" opacity="0.8"/>
            <circle cx="50%" cy="50%" r="3" fill="#2563EB"/>
          </svg>
          <!-- Labels -->
          <div style="position:absolute;top:8px;left:12px;font-size:10px;color:var(--fp-text-faint)">Zone couverte : ~45km²</div>
          <div style="position:absolute;bottom:8px;right:12px;font-size:10px;color:var(--fp-text-faint)">Mis à jour il y a 2h</div>
        </div>
        <div style="display:flex;gap:12px;margin-top:10px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:5px;font-size:10px;color:var(--fp-text-faint)"><div style="width:8px;height:8px;border-radius:50%;background:#2563EB"></div>Position forte</div>
          <div style="display:flex;align-items:center;gap:5px;font-size:10px;color:var(--fp-text-faint)"><div style="width:8px;height:8px;border-radius:50%;background:#22c55e"></div>Zone dominée</div>
          <div style="display:flex;align-items:center;gap:5px;font-size:10px;color:var(--fp-text-faint)"><div style="width:8px;height:8px;border-radius:50%;background:#f59e0b"></div>Potentiel</div>
          <div style="display:flex;align-items:center;gap:5px;font-size:10px;color:var(--fp-text-faint)"><div style="width:8px;height:8px;border-radius:50%;background:#ef4444"></div>Faible</div>
        </div>
        \` : \`<div style="height:200px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:rgba(0,0,0,0.2);border-radius:12px;border:1px dashed var(--fp-border)">
          <div style="font-size:32px">🗺️</div>
          <div style="font-size:13px;font-weight:600;color:var(--fp-text-soft)">Heatmap disponible en Pro</div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau vers Pro…')">Passer Pro</button>
        </div>\`}
      </div>

      <!-- DOMINATION SCORE -->
      <div class="fp-card" style="text-align:center">
        <div class="fp-card-title" style="justify-content:center;margin-bottom:16px">Score de domination territoriale</div>
        <div style="display:flex;justify-content:center;margin-bottom:16px">
          <svg width="140" height="140" viewBox="0 0 140 140">
            <circle cx="70" cy="70" r="52" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="12"/>
            <circle cx="70" cy="70" r="52" fill="none" stroke="url(#domGrad)" stroke-width="12"
              stroke-dasharray="\${(circ*domScore/100).toFixed(1)} \${(circ*(1-domScore/100)).toFixed(1)}"
              stroke-dashoffset="\${(circ*0.25).toFixed(1)}"
              stroke-linecap="round" transform="rotate(-90 70 70)"/>
            <defs><linearGradient id="domGrad" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#2563EB"/><stop offset="100%" stop-color="#8b5cf6"/></linearGradient></defs>
            <text x="70" y="64" text-anchor="middle" font-family="Outfit,sans-serif" font-size="26" font-weight="800" fill="var(--fp-text)">\${domScore}</text>
            <text x="70" y="80" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" fill="var(--fp-text-muted)">/100</text>
          </svg>
        </div>
        <div style="font-size:14px;font-weight:700;color:var(--fp-text);margin-bottom:4px">Territoire maîtrisé</div>
        <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:16px">Vous dominez <strong style="color:var(--fp-accent)">63%</strong> des recherches locales cibles</div>
        <div style="border-top:1px solid var(--fp-border);padding-top:14px;display:flex;flex-direction:column;gap:8px">
          \${[
            { label: 'Autorité régionale',  val: 78, color: '#2563EB' },
            { label: 'Couverture visibilité', val: 63, color: '#8b5cf6' },
            { label: 'Force GBP',             val: 71, color: '#22c55e' },
            { label: 'Pression citiation',    val: 55, color: '#f59e0b' },
          ].map(m => \`<div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:11px;color:var(--fp-text-muted);min-width:120px;text-align:left">\${m.label}</span>
            <div class="fp-progress-track" style="flex:1;height:5px"><div class="fp-progress-fill" style="width:\${m.val}%;background:\${m.color}"></div></div>
            <span style="font-size:11px;font-weight:700;color:\${m.color};min-width:28px;text-align:right">\${m.val}</span>
          </div>\`).join('')}
        </div>
      </div>
    </div>

    <!-- GEO RANKING GRID -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('grid').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Grille de positionnement géographique
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('zones')">Voir toutes les zones →</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px">
        \${cities.map(c => {
          const posColor = c.pos <= 3 ? '#22c55e' : c.pos <= 7 ? '#f59e0b' : '#ef4444';
          const deltaStr = c.delta > 0 ? '+' + c.delta : c.delta < 0 ? String(c.delta) : '—';
          const deltaColor = c.delta > 0 ? '#22c55e' : c.delta < 0 ? '#ef4444' : 'var(--fp-text-faint)';
          return \`<div style="background:rgba(255,255,255,0.03);border:1px solid var(--fp-border);border-radius:10px;padding:12px;text-align:center;position:relative">
            <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft);margin-bottom:8px">\${c.name}</div>
            <div style="font-size:28px;font-weight:900;color:\${posColor};line-height:1">#\${c.pos}</div>
            <div style="font-size:10px;color:var(--fp-text-faint);margin-top:2px">position Google</div>
            <div style="display:flex;justify-content:center;gap:10px;margin-top:8px;font-size:10px">
              <span style="color:var(--fp-text-faint)">📱 #\${c.mobile}</span>
              <span style="color:var(--fp-text-faint)">🖥 #\${c.desktop}</span>
            </div>
            <div style="position:absolute;top:8px;right:8px;font-size:10px;font-weight:700;color:\${deltaColor}">\${deltaStr}</div>
            <div style="margin-top:8px"><div class="fp-progress-track" style="height:3px"><div class="fp-progress-fill" style="width:\${c.cov}%;background:\${posColor}"></div></div></div>
            <div style="font-size:9px;color:var(--fp-text-faint);margin-top:3px">\${c.cov}% couverture</div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- GROWTH FORECAST + MILESTONES -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- FORECASTING -->
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('trending-up').replace('stroke="currentColor"','stroke="#22c55e"')}
            Prévisions de croissance locale
          </div>
          \${!isUltra ? \`<span style="font-size:10px;padding:2px 8px;background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.3);border-radius:10px;color:#8b5cf6">Ultra</span>\` : ''}
        </div>
        \${isUltra ? \`
        <div style="display:flex;gap:4px;align-items:flex-end;height:100px;padding:0 4px">
          \${forecasts.map(f => \`
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
              <div style="font-size:10px;font-weight:700;color:#22c55e">\${f.val}</div>
              <div style="width:100%;max-width:48px;height:\${Math.round(f.val/maxForecast*75)}px;background:linear-gradient(180deg,rgba(34,197,94,0.4),rgba(34,197,94,0.1));border-radius:4px 4px 0 0;border-top:2px solid #22c55e;position:relative">
                <div style="position:absolute;bottom:0;width:100%;height:\${Math.round(f.prev/maxForecast*75)}px;background:rgba(37,99,235,0.2);border-top:1px dashed #2563EB;border-radius:4px 4px 0 0"></div>
              </div>
              <div style="font-size:9px;color:var(--fp-text-faint)">\${f.month}</div>
            </div>
          \`).join('')}
        </div>
        <div style="display:flex;gap:12px;margin-top:10px;font-size:10px;color:var(--fp-text-faint)">
          <span>▬ <span style="color:#22c55e">Prévu</span></span>
          <span>▬ <span style="color:#2563EB">Actuel</span></span>
        </div>
        <div style="margin-top:12px;padding:10px;background:rgba(34,197,94,0.05);border:1px solid rgba(34,197,94,0.15);border-radius:8px;font-size:12px;color:#22c55e">
          📈 <strong>+62% de trafic local estimé</strong> en 4 mois si les 12 opportunités sont activées
        </div>
        \` : \`<div style="height:120px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;opacity:0.5">
          <div style="font-size:28px">📈</div>
          <div style="font-size:12px;color:var(--fp-text-muted)">Prévisions IA disponibles en Ultra</div>
        </div>\`}
      </div>

      <!-- MILESTONES & GAMIFICATION -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          🏆 Jalons de domination locale
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${milestones.map(m => \`
            <div style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;background:\${m.done?'rgba(34,197,94,0.06)':'rgba(255,255,255,0.02)'};border:1px solid \${m.done?'rgba(34,197,94,0.2)':m.locked?'rgba(139,92,246,0.15)':'var(--fp-border)'}">
              <div style="font-size:22px;flex-shrink:0">\${m.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:\${m.done?'var(--fp-text)':'var(--fp-text-muted)'}">\${m.label}</div>
                <div style="font-size:10px;color:\${m.locked?'#8b5cf6':'var(--fp-text-faint)'}">\${m.desc}</div>
              </div>
              \${m.done
                ? \`<span style="font-size:18px">✅</span>\`
                : m.locked
                  ? \`<span style="font-size:11px;padding:2px 7px;background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.3);border-radius:10px;color:#8b5cf6">Ultra</span>\`
                  : \`<div style="width:18px;height:18px;border-radius:50%;border:2px dashed var(--fp-border)"></div>\`
              }
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- MISSING LOCAL PAGES ALERT -->
    <div class="fp-card fp-mb-20" style="border-color:rgba(245,158,11,0.25);background:linear-gradient(135deg,rgba(245,158,11,0.04),transparent)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
        <div class="fp-card-title" style="margin-bottom:0;color:#f59e0b">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          Pages locales manquantes détectées
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('opportunities')">Voir toutes →</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        \${missingPages.map(p => \`
          <div style="display:flex;align-items:center;gap:12px;padding:8px 10px;background:rgba(255,255,255,0.02);border-radius:8px">
            <div style="width:8px;height:8px;border-radius:50%;background:#f59e0b;flex-shrink:0"></div>
            <div style="flex:1;font-size:12px;color:var(--fp-text-soft)"><strong>\${p.city}</strong> — "\${p.kw}"</div>
            <div style="font-size:11px;font-weight:700;color:#22c55e">+\${p.vol} rech./mois</div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:3px 8px" onclick="showToast('info','Création de page locale en cours…')">Créer</button>
          </div>
        \`).join('')}
      </div>
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 2. renderLocalSEOZones() — Geo Intelligence Center
// ══════════════════════════════════════════════════════════════
const NEW_LOCAL_SEO_ZONES = `function renderLocalSEOZones() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro  = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const zones = [
    { name: 'Paris Centre',    region: 'Île-de-France', status: 'fort',   pos: 2,  mobile: 3,  desktop: 2,  delta: +1, cov: 91, traffic: 620, pages: 4, kw: 18 },
    { name: 'Lyon 1-4',        region: 'Auvergne-RA',   status: 'fort',   pos: 1,  mobile: 2,  desktop: 1,  delta:  0, cov: 88, traffic: 580, pages: 3, kw: 14 },
    { name: 'Bordeaux Centre', region: 'Nouvelle-Aq.',  status: 'moyen',  pos: 6,  mobile: 7,  desktop: 6,  delta: +1, cov: 53, traffic: 290, pages: 2, kw: 9  },
    { name: 'Liège Centre',    region: 'Wallonie',       status: 'moyen',  pos: 4,  mobile: 5,  desktop: 4,  delta: +2, cov: 67, traffic: 340, pages: 2, kw: 11 },
    { name: 'Verviers',        region: 'Wallonie',       status: 'faible', pos: 7,  mobile: 9,  desktop: 7,  delta: -1, cov: 41, traffic: 130, pages: 1, kw: 5  },
    { name: 'Spa',             region: 'Wallonie',       status: 'moyen',  pos: 4,  mobile: 6,  desktop: 4,  delta: +3, cov: 58, traffic: 210, pages: 1, kw: 7  },
    { name: 'Marseille 1-6',   region: 'PACA',           status: 'faible', pos: 9,  mobile: 12, desktop: 9,  delta: -2, cov: 31, traffic: 80,  pages: 0, kw: 3  },
    { name: 'Namur',           region: 'Wallonie',       status: 'faible', pos: 11, mobile: 14, desktop: 11, delta:  0, cov: 22, traffic: 50,  pages: 0, kw: 2  },
  ];

  const expansion = [
    { city: 'Paris 13-15', opp: 'Aucun concurrent fort', potential: '+340 vis/mois', effort: '2h',   pages: 2, priority: 'Haute'   },
    { city: 'Namur Sud',   opp: 'Zone non couverte',     potential: '+180 vis/mois', effort: '1h30', pages: 1, priority: 'Haute'   },
    { city: 'Liège Est',   opp: 'Croissance +12%',       potential: '+220 vis/mois', effort: '2h30', pages: 2, priority: 'Moyenne' },
  ];

  return \`
    \${aiBlock('Couverture forte sur <strong>Paris Centre</strong> et <strong>Lyon 1-4</strong>. Opportunité stratégique : <strong>Namur</strong> et <strong>Marseille 1-6</strong> ne sont pas du tout couverts — 0 page locale. Gains estimés : <strong>+130 visites/mois</strong> avec 2 pages.', ['Développer Marseille', 'Créer pages Namur', 'Rapport zones'])}

    <div class="fp-stat-row fp-mb-20">
      \${statCard('Zones fortes', zones.filter(z => z.status === 'fort').length + '/' + zones.length, 'à 70%+ couverture', 'neutral')}
      \${statCard('Trafic total', zones.reduce((s,z) => s + z.traffic, 0) + '/mois', 'toutes zones', 'up')}
      \${statCard('Position moy.', '#' + (zones.reduce((s,z) => s + z.pos, 0) / zones.length).toFixed(1), 'moyenne globale', 'neutral')}
      \${statCard('Zones à développer', zones.filter(z => z.status !== 'fort').length, 'opportunités', 'down')}
    </div>

    <!-- ZONE CARDS GRID -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;margin-bottom:20px">
      \${zones.map(z => {
        const sc = z.status === 'fort' ? '#22c55e' : z.status === 'moyen' ? '#f59e0b' : '#ef4444';
        const sl = z.status === 'fort' ? 'Fort' : z.status === 'moyen' ? 'Moyen' : 'Faible';
        const dc = z.delta > 0 ? '#22c55e' : z.delta < 0 ? '#ef4444' : 'var(--fp-text-faint)';
        const ds = z.delta > 0 ? '↑+' + z.delta : z.delta < 0 ? '↓' + z.delta : '→';
        return \`
          <div class="fp-card" style="border-color:\${z.status === 'faible' ? 'rgba(239,68,68,0.2)' : z.status === 'fort' ? 'rgba(34,197,94,0.2)' : 'var(--fp-border)'}">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:12px">
              <div>
                <div style="font-size:14px;font-weight:700;color:var(--fp-text)">\${z.name}</div>
                <div style="font-size:10px;color:var(--fp-text-faint);margin-top:2px">\${z.region} · \${z.traffic} visites/mois</div>
              </div>
              \${badge(sl, sc)}
            </div>

            <!-- Coverage bar -->
            <div style="margin-bottom:12px">
              <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                <span style="font-size:11px;color:var(--fp-text-muted)">Couverture locale</span>
                <span style="font-size:11px;font-weight:700;color:\${sc}">\${z.cov}%</span>
              </div>
              <div class="fp-progress-track" style="height:6px">
                <div class="fp-progress-fill" style="width:\${z.cov}%;background:linear-gradient(90deg,\${sc},\${sc}aa)"></div>
              </div>
            </div>

            <!-- Stats grid -->
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;text-align:center;margin-bottom:12px;padding:10px;background:rgba(0,0,0,0.2);border-radius:8px">
              <div>
                <div style="font-size:16px;font-weight:800;color:\${z.pos<=3?'#22c55e':z.pos<=7?'#f59e0b':'#ef4444'}">#\${z.pos}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">Google</div>
              </div>
              <div>
                <div style="font-size:16px;font-weight:800;color:var(--fp-text-soft)">#\${z.mobile}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">📱 Mobile</div>
              </div>
              <div>
                <div style="font-size:16px;font-weight:800;color:var(--fp-text-soft)">\${z.kw}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">Mots-clés</div>
              </div>
              <div>
                <div style="font-size:16px;font-weight:800;color:\${dc}">\${ds}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">Tendance</div>
              </div>
            </div>

            <!-- Pages count -->
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
              <span style="font-size:11px;color:var(--fp-text-muted)">\${z.pages} page\${z.pages !== 1 ? 's' : ''} locale\${z.pages !== 1 ? 's' : ''}</span>
              \${z.pages === 0 ? \`<span style="font-size:10px;font-weight:700;color:#ef4444">⚠ Aucune page locale</span>\` : ''}
            </div>

            \${z.status !== 'fort'
              ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%" onclick="STATE.missions.push({id:'ms'+Date.now(),title:'Développer la zone \${z.name}',category:'Local SEO',impact:'Élevé',status:'todo',date:new Date(Date.now()+7*86400000).toISOString().slice(0,10),steps:[]});saveMissions();showToast('success','Mission créée !')">+ Mission pour cette zone</button>\`
              : \`<div style="font-size:11px;color:#22c55e;text-align:center;padding:6px">✓ Zone bien couverte</div>\`
            }
          </div>
        \`;
      }).join('')}
    </div>

    <!-- EXPANSION OPPORTUNITIES -->
    <div class="fp-card" style="border-color:rgba(34,197,94,0.2)">
      <div class="fp-card-title" style="margin-bottom:14px">
        \${svgIcon('trending-up').replace('stroke="currentColor"','stroke="#22c55e"')}
        Zones d'expansion prioritaires
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        \${expansion.map(e => \`
          <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:rgba(34,197,94,0.04);border:1px solid rgba(34,197,94,0.15);border-radius:10px">
            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                <span style="font-size:13px;font-weight:700;color:var(--fp-text)">\${e.city}</span>
                \${badge(e.priority, e.priority === 'Haute' ? '#22c55e' : '#f59e0b')}
              </div>
              <div style="font-size:11px;color:var(--fp-text-muted)">\${e.opp} · \${e.pages} page\${e.pages > 1 ? 's' : ''} à créer · \${e.effort}</div>
              <div style="font-size:12px;font-weight:700;color:#22c55e;margin-top:2px">\${e.potential}</div>
            </div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Mission expansion créée !')">Déployer</button>
          </div>
        \`).join('')}
      </div>
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 3. renderLocalSEOCompetitors() — Intelligence Center
// ══════════════════════════════════════════════════════════════
const NEW_LOCAL_SEO_COMPETITORS = `function renderLocalSEOCompetitors() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro  = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';
  const myScore = 82;

  const comps = [
    { name: 'Boulangerie Dupont',    url: 'boulangerie-dupont.fr',    score: 88, speed: 74, gbp: true,  reviews: 142, rating: 4.8, posts: 2, photos: 48, threat: 'high',   delta: +3, keywords: 34, citations: 22 },
    { name: 'Plomberie Rapide IDF',  url: 'plomberie-rapide-idf.fr',  score: 72, speed: 58, gbp: true,  reviews: 89,  rating: 4.5, posts: 0, photos: 18, threat: 'medium', delta: +1, keywords: 21, citations: 14 },
    { name: 'Coiffure Elite Lyon',   url: 'coiffure-elite-lyon.fr',   score: 65, speed: 42, gbp: false, reviews: 56,  rating: 4.2, posts: 1, photos: 12, threat: 'low',    delta: -1, keywords: 15, citations: 8  },
    { name: 'Restaurant Sud-Ouest',  url: 'restaurant-sudouest.fr',   score: 60, speed: 51, gbp: true,  reviews: 201, rating: 4.7, posts: 3, photos: 62, threat: 'medium', delta: +2, keywords: 19, citations: 18 },
    { name: 'Auto Garage Rapide',    url: 'garage-rapide-idf.fr',     score: 55, speed: 38, gbp: false, reviews: 34,  rating: 3.9, posts: 0, photos: 6,  threat: 'low',    delta: 0,  keywords: 11, citations: 5  },
  ];
  const tc = { high: '#ef4444', medium: '#f59e0b', low: '#22c55e' };
  const tl = { high: 'Menace forte', medium: 'À surveiller', low: 'Faible risque' };

  const kwGaps = [
    { kw: 'boulangerie artisanale paris', yours: false, comp: 'Boulangerie Dupont', vol: 320 },
    { kw: 'livraison pain bio',            yours: false, comp: 'Boulangerie Dupont', vol: 180 },
    { kw: 'traiteur paris 11',             yours: false, comp: 'Restaurant Sud-Ouest', vol: 240 },
    { kw: 'plombier urgence nuit',         yours: true,  comp: null,                  vol: 410 },
    { kw: 'dépannage chaudière rapide',    yours: false, comp: 'Plomberie Rapide IDF', vol: 290 },
  ];

  const movements = [
    { comp: 'Boulangerie Dupont',   change: 'Gained 3 positions sur "boulangerie paris"', type: 'up',   days: 7  },
    { comp: 'Restaurant Sud-Ouest', change: '3 nouveaux avis 5 étoiles cette semaine',    type: 'up',   days: 5  },
    { comp: 'Coiffure Elite Lyon',  change: 'Perte de 2 positions sur "coiffeur lyon"',   type: 'down', days: 14 },
    { comp: 'Plomberie Rapide IDF', change: 'Nouveau concurrent détecté dans votre zone', type: 'alert',days: 3  },
  ];

  return \`
    \${aiBlock('<strong>' + comps.length + ' concurrents surveillés</strong>. <strong>Boulangerie Dupont</strong> vous surpasse (88 vs ' + myScore + '/100) — menace forte. Point faible de la concurrence : <strong>vitesse mobile</strong> (moy. 53/100 vs votre 68). Votre avantage clé : exploitez la vitesse dans vos pages locales.', ['Analyse approfondie', 'Surveiller nouveaux', 'Rapport concurrent'])}

    <div class="fp-stat-row fp-mb-20">
      \${statCard('Votre score', myScore + '/100', 'vs moy. 68 concurrents', 'up')}
      \${statCard('Menaces fortes', comps.filter(c => c.threat === 'high').length, 'à traiter en priorité', 'down')}
      \${statCard('Avantage vitesse', '+' + (68 - Math.round(comps.reduce((s,c) => s+c.speed,0)/comps.length)) + ' pts', 'mobile vs concurrents', 'up')}
      \${statCard('Gaps mots-clés', kwGaps.filter(k => !k.yours).length, 'opportunités non prises', 'neutral')}
    </div>

    <!-- COMPETITOR TABLE -->
    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:14px">
        \${svgIcon('eye').replace('stroke="currentColor"','stroke="#ef4444"')}
        Surveillance concurrentielle en temps réel
      </div>
      <div style="overflow-x:auto">
        <table class="fp-data-table">
          <thead>
            <tr>
              <th>Concurrent</th>
              <th>SEO</th>
              <th>Speed</th>
              <th>GBP</th>
              <th>Avis</th>
              <th>Note</th>
              <th>Photos</th>
              <th>Mots-clés</th>
              <th>Tendance</th>
              <th>Menace</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr style="background:rgba(37,99,235,0.06);border-left:3px solid #2563EB">
              <td><strong style="color:#2563EB">🎯 Vous</strong></td>
              <td><strong style="color:#2563EB">\${myScore}</strong></td>
              <td><strong style="color:#22c55e">68</strong></td>
              <td>\${badge('GBP ✓', '#22c55e')}</td>
              <td>47</td>
              <td style="color:#f59e0b">4.4★</td>
              <td>24</td>
              <td>28</td>
              <td>—</td>
              <td>—</td>
              <td>—</td>
            </tr>
            \${comps.map(c => \`
              <tr>
                <td>
                  <div style="font-weight:600;font-size:12px">\${escHtml(c.name)}</div>
                  <div style="font-size:10px;color:var(--fp-text-faint);font-family:monospace">\${escHtml(c.url)}</div>
                </td>
                <td><span style="font-weight:700;color:\${scoreColor(c.score)}">\${c.score}</span></td>
                <td><span style="color:\${c.speed>=70?'#22c55e':c.speed>=50?'#f59e0b':'#ef4444'}">\${c.speed}</span></td>
                <td>\${badge(c.gbp?'✓':'✗', c.gbp?'#22c55e':'#ef4444')}</td>
                <td>\${c.reviews}</td>
                <td style="color:#f59e0b">\${c.rating}★</td>
                <td>\${c.photos}</td>
                <td>\${c.keywords}</td>
                <td style="font-weight:700;color:\${c.delta>0?'#22c55e':c.delta<0?'#ef4444':'var(--fp-text-faint)'}">
                  \${c.delta > 0 ? '↑+' + c.delta : c.delta < 0 ? '↓' + c.delta : '→'}
                </td>
                <td>\${badge(tl[c.threat], tc[c.threat])}</td>
                <td><button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Analyse de \${escHtml(c.name)}…')">Analyser</button></td>
              </tr>
            \`).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- COMPETITOR MOVEMENTS + KEYWORD GAP -->
    <div class="fp-grid-2 fp-mb-16">

      <!-- MOVEMENTS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:12px">
          \${svgIcon('activity').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Mouvements concurrents récents
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${movements.map(m => \`
            <div style="display:flex;align-items:flex-start;gap:10px;padding:10px;background:rgba(255,255,255,0.02);border-radius:8px;border-left:2px solid \${m.type==='up'?'#22c55e':m.type==='down'?'#ef4444':'#f59e0b'}">
              <span style="font-size:16px;flex-shrink:0">\${m.type==='up'?'📈':m.type==='down'?'📉':'⚠️'}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:11px;font-weight:700;color:var(--fp-text-soft)">\${escHtml(m.comp)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);margin-top:2px">\${escHtml(m.change)}</div>
              </div>
              <span style="font-size:10px;color:var(--fp-text-faint);flex-shrink:0">il y a \${m.days}j</span>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- KEYWORD GAP -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:12px">
          \${svgIcon('search').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Analyse des gaps mots-clés locaux
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${kwGaps.map(k => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:\${k.yours?'rgba(34,197,94,0.05)':'rgba(239,68,68,0.04)'}">
              <span style="font-size:14px;flex-shrink:0">\${k.yours ? '✅' : '❌'}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">"\${escHtml(k.kw)}"</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${k.yours ? 'Vous êtes positionné' : 'Dominé par ' + escHtml(k.comp)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:11px;font-weight:700;color:\${k.yours?'#22c55e':'#ef4444'}">\${k.vol}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">rech/mois</div>
              </div>
            </div>
          \`).join('')}
        </div>
        \${!isPro ? \`<div style="margin-top:10px;text-align:center;font-size:11px;color:var(--fp-text-faint)">Analyse complète disponible en Pro</div>\` : ''}
      </div>
    </div>

    <!-- RADAR COMPARISON -->
    <div class="fp-card">
      <div class="fp-card-title" style="margin-bottom:14px">Comparaison multidimensionnelle</div>
      <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap">
        <!-- SVG Radar -->
        <div style="flex-shrink:0;display:flex;justify-content:center">
          <svg width="200" height="200" viewBox="0 0 200 200">
            <defs>
              <polygon id="radarBg" points="100,20 172,60 172,140 100,180 28,140 28,60"/>
            </defs>
            <!-- Grid -->
            \${[0.2,0.4,0.6,0.8,1].map(s => \`
              <polygon points="\${[
                [100,20],[172,60],[172,140],[100,180],[28,140],[28,60]
              ].map(([x,y]) => [(x-100)*s+100,(y-100)*s+100].join(',')).join(' ')}"
              fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>
            \`).join('')}
            <!-- Axes -->
            \${[[100,20],[172,60],[172,140],[100,180],[28,140],[28,60]].map(([x,y]) =>
              \`<line x1="100" y1="100" x2="\${x}" y2="\${y}" stroke="rgba(255,255,255,0.05)" stroke-width="1"/>\`
            ).join('')}
            <!-- Competitor area -->
            <polygon points="100,38 154,72 154,131 100,162 47,131 47,72"
              fill="rgba(239,68,68,0.12)" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4,2"/>
            <!-- Your area -->
            <polygon points="100,36 158,68 158,136 100,166 43,136 43,68"
              fill="rgba(37,99,235,0.2)" stroke="#2563EB" stroke-width="2"/>
            <!-- Labels -->
            <text x="100" y="14" text-anchor="middle" font-size="9" fill="var(--fp-text-muted)">SEO</text>
            <text x="178" y="62" font-size="9" fill="var(--fp-text-muted)">GBP</text>
            <text x="178" y="143" font-size="9" fill="var(--fp-text-muted)">Vitesse</text>
            <text x="100" y="195" text-anchor="middle" font-size="9" fill="var(--fp-text-muted)">Avis</text>
            <text x="2" y="143" font-size="9" fill="var(--fp-text-muted)">Citations</text>
            <text x="2" y="62" font-size="9" fill="var(--fp-text-muted)">Contenu</text>
          </svg>
        </div>
        <!-- Stats vs competitors -->
        <div style="flex:1;min-width:200px;display:flex;flex-direction:column;gap:10px">
          \${[
            { label: 'Score SEO',       you: myScore, them: 68, unit: '/100' },
            { label: 'Vitesse mobile',  you: 68,      them: 53, unit: '/100' },
            { label: 'Note GBP',        you: 44,      them: 46, unit: '/50'  },
            { label: 'Nb avis',         you: 47,      them: 104,unit: ''     },
            { label: 'Posts/semaine',   you: 20,      them: 12, unit: '/10'  },
            { label: 'Citations locales',you: 18,     them: 13, unit: ''     },
          ].map(m => \`
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:11px;color:var(--fp-text-muted);min-width:120px">\${m.label}</span>
              <div style="flex:1;display:flex;flex-direction:column;gap:3px">
                <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${Math.min(100,m.you)}%;background:#2563EB"></div></div>
                <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${Math.min(100,m.them)}%;background:#ef444488"></div></div>
              </div>
              <span style="font-size:11px;font-weight:700;color:\${m.you>m.them?'#22c55e':'#ef4444'};min-width:32px;text-align:right">\${m.you > m.them ? '+' : ''}\${Math.round(m.you - m.them)}</span>
            </div>
          \`).join('')}
          <div style="display:flex;gap:16px;font-size:10px;color:var(--fp-text-faint);margin-top:4px">
            <span>■ <span style="color:#2563EB">Vous</span></span>
            <span>■ <span style="color:#ef4444">Meilleur concurrent</span></span>
          </div>
        </div>
      </div>
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 4. renderLocalSEOOpportunities() — Opportunity Engine
// ══════════════════════════════════════════════════════════════
const NEW_LOCAL_SEO_OPPORTUNITIES = `function renderLocalSEOOpportunities() {
  const plan = STATE.me?.plan || 'Pro';
  const isStd  = plan === 'Standard';
  const isPro  = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const opps = [
    { id: 'o1', title: 'Page locale "boulangerie artisanale Paris 13"', type: 'Page locale',   effort: '1h30', potential: '+340 rech/mois', difficulty: 'Facile',  impact: 'Élevé',   icon: '📄', cat: 'pages'    },
    { id: 'o2', title: 'Catégorie secondaire "traiteur" sur GBP',       type: 'GBP',           effort: '10 min', potential: '+180 rech/mois', difficulty: 'Facile', impact: 'Moyen',  icon: '🏪', cat: 'gbp'      },
    { id: 'o3', title: 'Posts GBP "offre du moment" hebdomadaires',     type: 'Contenu',       effort: '15 min/sem', potential: '+12% engagement', difficulty: 'Moyen', impact: 'Moyen', icon: '📝', cat: 'content'  },
    { id: 'o4', title: 'Liens NAP cohérents sur 15 annuaires',          type: 'Citations',     effort: '1h30', potential: '+11% autorité', difficulty: 'Moyen',  impact: 'Élevé',   icon: '📋', cat: 'citations' },
    { id: 'o5', title: 'Répondre aux 14 avis sans réponse',             type: 'Réputation',    effort: '2 min/avis', potential: '+0.3 étoile moy.', difficulty: 'Facile', impact: 'Élevé', icon: '⭐', cat: 'gbp'    },
    { id: 'o6', title: 'Balises Q&A sur la fiche GBP',                  type: 'GBP',           effort: '45 min', potential: '+18% visibilité', difficulty: 'Moyen', impact: 'Moyen', icon: '❓', cat: 'gbp'      },
    { id: 'o7', title: 'Ajouter photos de produits et de l\'équipe',    type: 'Médias',        effort: '30 min', potential: '+28% CTR', difficulty: 'Facile', impact: 'Élevé',    icon: '📸', cat: 'media'    },
    { id: 'o8', title: 'Page service "plomberie urgence Bordeaux"',      type: 'Page locale',   effort: '2h', potential: '+480 rech/mois', difficulty: 'Moyen', impact: 'Élevé',    icon: '📄', cat: 'pages'    },
  ];

  const citations = [
    { name: 'Pages Jaunes',    domain: 'pagesjaunes.fr',  da: 72, status: 'missing',  type: 'Annuaire général' },
    { name: 'Yelp France',     domain: 'yelp.fr',         da: 68, status: 'missing',  type: 'Avis & resto'     },
    { name: 'Hotfrog',         domain: 'hotfrog.fr',      da: 45, status: 'present',  type: 'Annuaire PME'     },
    { name: 'Foursquare',      domain: 'foursquare.com',  da: 81, status: 'missing',  type: 'Local discovery'  },
    { name: 'Kompass',         domain: 'kompass.com',     da: 63, status: 'present',  type: 'B2B directory'    },
    { name: 'Cylex',           domain: 'cylex.fr',        da: 41, status: 'missing',  type: 'Annuaire local'   },
  ];

  const hyperlocal = [
    { title: 'Cibler le quartier Marais (Paris 3-4)',        type: 'Micro-zone',  gain: '+120 vis/mois' },
    { title: 'Créer une page pour la Fête de la Musique',    type: 'Événement',   gain: '+200 vis (juin)' },
    { title: 'Contenu spécial rentrée scolaire',             type: 'Saisonnier',  gain: '+150 vis (sept.)' },
    { title: 'Cibler "à proximité de la gare Saint-Lazare"', type: 'Géo-ciblage', gain: '+90 vis/mois' },
  ];

  return \`
    \${aiBlock('J\'ai identifié <strong>8 opportunités non exploitées</strong> pouvant générer <strong>+1 169 visites/mois supplémentaires</strong> et <strong>+47% de trafic local</strong> en 60 jours. Priorité absolue : les 4 opportunités "Facile" à impact élevé.', ['Créer toutes les missions', 'Prioriser par impact', 'Rapport opportunités'])}

    <!-- STATS -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Opportunités totales', opps.length, 'non exploitées', 'down')}
      \${statCard('Potentiel cumulé', '+1 169', 'visites/mois', 'up')}
      \${statCard('Citations manquantes', citations.filter(c => c.status === 'missing').length, 'annuaires locaux', 'neutral')}
      \${statCard('Faciles à faire', opps.filter(o => o.difficulty === 'Facile').length, 'moins de 1h chacune', 'up')}
    </div>

    <!-- OPPORTUNITY CARDS -->
    <div class="fp-card fp-mb-20">
      <div class="fp-card-title" style="margin-bottom:14px">
        \${svgIcon('zap').replace('stroke="currentColor"','stroke="#f59e0b"')}
        Moteur d'opportunités IA
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        \${opps.map(o => {
          const dc = o.difficulty === 'Facile' ? '#22c55e' : o.difficulty === 'Moyen' ? '#f59e0b' : '#ef4444';
          const ic = o.impact === 'Élevé' ? '#ef4444' : '#f59e0b';
          return \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid var(--fp-border);border-radius:var(--fp-radius-lg);background:var(--fp-bg-card)">
              <div style="font-size:24px;flex-shrink:0">\${o.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:13px;font-weight:600;color:var(--fp-text);margin-bottom:4px">\${escHtml(o.title)}</div>
                <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
                  \${badge(o.type, '#64748b')}
                  \${badge(o.difficulty, dc)}
                  <span style="font-size:10px;color:var(--fp-text-faint)">· \${o.effort}</span>
                </div>
                <div style="font-size:12px;font-weight:700;color:#22c55e;margin-top:4px">\${o.potential}</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0">
                \${badge('Impact ' + o.impact, ic)}
                <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="STATE.missions.push({id:'ms'+Date.now(),title:\${JSON.stringify(o.title)},category:'Local SEO',impact:o.impact,status:'todo',date:new Date(Date.now()+7*86400000).toISOString().slice(0,10),steps:[]});saveMissions();showToast('success','Mission créée !')">Créer</button>
              </div>
            </div>
          \`;
        }).join('')}
      </div>
    </div>

    <!-- CITATIONS + HYPERLOCAL -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- CITATIONS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('link').replace('stroke="currentColor"','stroke="#06b6d4"')}
          Opportunités de citations locales
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${citations.map(c => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:\${c.status==='missing'?'rgba(239,68,68,0.04)':'rgba(34,197,94,0.04)'}">
              <div style="width:8px;height:8px;border-radius:50%;background:\${c.status==='missing'?'#ef4444':'#22c55e'};flex-shrink:0"></div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(c.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${c.type} · DA \${c.da}</div>
              </div>
              \${c.status === 'missing'
                ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:3px 8px" onclick="showToast('info','Ajout citation \${escHtml(c.name)}…')">Ajouter</button>\`
                : \`<span style="font-size:11px;color:#22c55e;font-weight:600">✓ Présent</span>\`
              }
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- HYPERLOCAL -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('crosshair').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Suggestions hyperlocalres
          \${!isUltra ? \`<span style="font-size:10px;padding:2px 7px;background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.3);border-radius:10px;color:#8b5cf6;margin-left:8px">Ultra</span>\` : ''}
        </div>
        \${isUltra ? \`
        <div style="display:flex;flex-direction:column;gap:8px">
          \${hyperlocal.map(h => \`
            <div style="padding:10px 12px;background:rgba(139,92,246,0.06);border:1px solid rgba(139,92,246,0.15);border-radius:10px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
                <span style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(h.title)}</span>
                \${badge(h.type, '#8b5cf6')}
              </div>
              <div style="font-size:11px;font-weight:700;color:#22c55e">\${h.gain}</div>
            </div>
          \`).join('')}
        </div>
        \` : \`<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:160px;gap:10px;opacity:0.5">
          <div style="font-size:32px">🎯</div>
          <div style="font-size:12px;color:var(--fp-text-muted);text-align:center">Suggestions hyperlocalres IA<br>disponibles en Ultra</div>
        </div>\`}
      </div>
    </div>

    <!-- SEASONAL CALENDAR -->
    \${isPro ? \`
    <div class="fp-card">
      <div class="fp-card-title" style="margin-bottom:14px">📅 Calendrier d'opportunités saisonnières</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
        \${[
          { month: 'Juin',  event: 'Fête de la Musique',   action: 'Post GBP + page événement',    gain: '+200 vis' },
          { month: 'Juil.', event: 'Soldes été',            action: 'Promotions locales GBP',        gain: '+150 vis' },
          { month: 'Sept.', event: 'Rentrée scolaire',      action: 'Contenu local ciblé familles',  gain: '+300 vis' },
          { month: 'Nov.',  event: 'Black Friday',          action: 'Offres locales + citations',    gain: '+180 vis' },
        ].map(s => \`
          <div style="padding:12px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.15);border-radius:10px">
            <div style="font-size:10px;font-weight:700;color:var(--fp-accent);text-transform:uppercase;margin-bottom:4px">\${s.month}</div>
            <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${s.event}</div>
            <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:6px">\${s.action}</div>
            <div style="font-size:11px;font-weight:700;color:#22c55e">\${s.gain}</div>
          </div>
        \`).join('')}
      </div>
    </div>
    \` : ''}
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 5. renderLocalSEOGBP() — GBP Intelligence Center
// ══════════════════════════════════════════════════════════════
const NEW_LOCAL_SEO_GBP = `function renderLocalSEOGBP() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro  = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const reviews = [
    { author: 'Marie L.',       stars: 5, text: 'Excellent service, très réactif et professionnel.', date: 'Il y a 2 jours',    replied: false, sentiment: 'positive' },
    { author: 'Jean-Pierre M.', stars: 4, text: 'Bon travail, délais respectés.',                    date: 'Il y a 1 semaine',  replied: true,  sentiment: 'positive' },
    { author: 'Sophie R.',      stars: 5, text: 'Je recommande vivement, qualité irréprochable.',    date: 'Il y a 2 semaines', replied: true,  sentiment: 'positive' },
    { author: 'Marc D.',        stars: 3, text: 'Prestation correcte mais communication à améliorer.',date: 'Il y a 3 semaines',replied: false, sentiment: 'neutral'  },
    { author: 'Isabelle T.',    stars: 1, text: 'Délais non respectés, pas de retour client.',       date: 'Il y a 1 mois',     replied: false, sentiment: 'negative' },
  ];

  const timeline = [
    { date: '09/05', type: 'review',  icon: '⭐', text: 'Nouvel avis 5 étoiles — Marie L.', color: '#22c55e' },
    { date: '08/05', type: 'post',    icon: '📝', text: 'Post GBP "Promotion Mai" publié',  color: '#2563EB'  },
    { date: '06/05', type: 'photo',   icon: '📸', text: '3 nouvelles photos ajoutées',       color: '#8b5cf6'  },
    { date: '04/05', type: 'review',  icon: '⭐', text: 'Avis 3 étoiles — Marc D. (sans réponse)', color: '#f59e0b' },
    { date: '02/05', type: 'edit',    icon: '✏️', text: 'Heures ouverture mises à jour',    color: '#06b6d4'  },
    { date: '01/05', type: 'qa',      icon: '❓', text: 'Nouvelle question client sans réponse', color: '#ef4444' },
  ];

  const gbpHealth = 71;
  const gbpCirc = 2 * Math.PI * 40;

  const completeness = [
    { label: 'Description complète',       done: true  },
    { label: 'Photos produits (15+)',       done: false },
    { label: 'Heures ouverture à jour',     done: true  },
    { label: 'Numéro de téléphone',         done: true  },
    { label: 'Q&A complètes',               done: false },
    { label: 'Attributs de service',        done: false },
    { label: 'Catégories secondaires',      done: false },
    { label: 'Site web lié',               done: true  },
    { label: 'Posts réguliers (2+/sem)',    done: false },
    { label: 'Réponses avis à jour',        done: false },
  ];
  const completePct = Math.round(completeness.filter(c => c.done).length / completeness.length * 100);

  const reviewKeywords = [
    { word: 'professionnel', count: 8, sentiment: 'positive' },
    { word: 'réactif',       count: 6, sentiment: 'positive' },
    { word: 'qualité',       count: 7, sentiment: 'positive' },
    { word: 'communication', count: 3, sentiment: 'negative' },
    { word: 'délais',        count: 4, sentiment: 'mixed'    },
  ];

  const stars = n => '<span style="color:#f59e0b">' + '★'.repeat(n) + '</span><span style="color:rgba(255,255,255,0.12)">' + '★'.repeat(5-n) + '</span>';

  const aiPosts = [
    { title: 'Promotion de mai — jusqu\'à -20%',  type: 'Offre',      preview: 'Profitez de notre promotion exclusive ce mois-ci. Qualité garantie, prix réduits pour nos clients locaux.' },
    { title: 'Notre équipe vous accueille',        type: 'Actualité',  preview: 'Toute notre équipe est heureuse de vous retrouver. Nouveaux horaires disponibles ce mois-ci.' },
    { title: 'Témoignage client de la semaine',   type: 'Post',       preview: 'Merci à Marie pour son excellent retour. Votre satisfaction est notre priorité absolue.' },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          GBP Intelligence
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.3);border-radius:20px;color:var(--fp-accent)">Centre de contrôle</span>
        </h1>
        <div class="fp-section-sub">Google Business Profile — Analytique, avis et contenu IA</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Publier un post', 'fp-btn fp-btn-primary fp-btn-sm', 'plus', "onclick=\\"showToast('success','Post GBP publié !')\\"" )}
      </div>
    </div>

    <!-- AI GBP ASSISTANT -->
    <div style="margin-top:20px">
      \${aiBlock('<strong>14 avis sans réponse</strong> — répondre sous 48h améliore votre classement local de <strong>+15%</strong>. Votre score GBP est à <strong>71/100</strong> — manque principal : photos et catégories secondaires. Publier 2 posts/semaine pourrait augmenter la visibilité de <strong>+22%</strong>.', ['Répondre aux avis', 'Optimiser la fiche', 'Planifier des posts'])}
    </div>

    <!-- GBP HEALTH + STATS -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Score GBP', gbpHealth + '/100', 'santé de la fiche', 'up')}
      \${statCard('Note moyenne', '4.4★', '47 avis au total', 'up')}
      \${statCard('Sans réponse', '14', 'à traiter en priorité', 'down')}
      \${statCard('Vues fiche', '1 842', 'ce mois · +12%', 'up')}
    </div>

    <!-- HEALTH GAUGE + COMPLETENESS -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- GBP HEALTH GAUGE -->
      <div class="fp-card" style="text-align:center">
        <div class="fp-card-title" style="justify-content:center;margin-bottom:16px">Santé de la fiche GBP</div>
        <div style="display:flex;justify-content:center;margin-bottom:16px">
          <svg width="100" height="100" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="10"/>
            <circle cx="50" cy="50" r="40" fill="none" stroke="#22c55e" stroke-width="10"
              stroke-dasharray="\${(gbpCirc*gbpHealth/100).toFixed(1)} \${(gbpCirc*(1-gbpHealth/100)).toFixed(1)}"
              stroke-dashoffset="\${(gbpCirc*0.25).toFixed(1)}"
              stroke-linecap="round" transform="rotate(-90 50 50)"/>
            <text x="50" y="46" text-anchor="middle" font-size="18" font-weight="800" fill="var(--fp-text)">\${gbpHealth}</text>
            <text x="50" y="58" text-anchor="middle" font-size="9" fill="var(--fp-text-muted)">/100</text>
          </svg>
        </div>
        <div style="display:flex;justify-content:center;gap:16px;margin-bottom:16px">
          <div style="text-align:center"><div style="font-size:18px;font-weight:700;color:#22c55e">4.4★</div><div style="font-size:10px;color:var(--fp-text-faint)">Note moy.</div></div>
          <div style="text-align:center"><div style="font-size:18px;font-weight:700;color:#2563EB">47</div><div style="font-size:10px;color:var(--fp-text-faint)">Avis total</div></div>
          <div style="text-align:center"><div style="font-size:18px;font-weight:700;color:#8b5cf6">24</div><div style="font-size:10px;color:var(--fp-text-faint)">Photos</div></div>
        </div>
        <div style="border-top:1px solid var(--fp-border);padding-top:14px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <span style="font-size:12px;font-weight:600;color:var(--fp-text-soft)">Complétude de la fiche</span>
            <span style="font-size:13px;font-weight:800;color:\${completePct>=80?'#22c55e':completePct>=50?'#f59e0b':'#ef4444'}">\${completePct}%</span>
          </div>
          <div class="fp-progress-track" style="height:6px;margin-bottom:4px">
            <div class="fp-progress-fill" style="width:\${completePct}%;background:\${completePct>=80?'#22c55e':completePct>=50?'#f59e0b':'#ef4444'}"></div>
          </div>
          <div style="font-size:10px;color:var(--fp-text-faint)">\${completeness.filter(c=>!c.done).length} éléments manquants</div>
        </div>
      </div>

      <!-- COMPLETENESS CHECKLIST -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:12px">Optimisation de la fiche</div>
        <div style="display:flex;flex-direction:column;gap:6px;max-height:280px;overflow-y:auto">
          \${completeness.map(item => \`
            <div style="display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:8px;background:\${item.done?'rgba(34,197,94,0.04)':'rgba(239,68,68,0.03)'}">
              <div style="width:18px;height:18px;border-radius:5px;background:\${item.done?'rgba(34,197,94,0.15)':'rgba(239,68,68,0.1)'};display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="\${item.done?'#22c55e':'#ef4444'}" stroke-width="3">\${item.done?'<polyline points="20 6 9 17 4 12"/>':'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'}</svg>
              </div>
              <span style="flex:1;font-size:12px;color:\${item.done?'var(--fp-text-soft)':'var(--fp-text-muted)'}">\${item.label}</span>
              \${!item.done ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:2px 6px" onclick="showToast('info','Optimisation en cours…')">Corriger</button>\` : ''}
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- ACTIVITY TIMELINE + REVIEWS -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('clock').replace('stroke="currentColor"','stroke="#06b6d4"')}
          Activité GBP
        </div>
        <div style="position:relative;padding-left:20px">
          <div style="position:absolute;left:7px;top:0;bottom:0;width:1px;background:var(--fp-border)"></div>
          \${timeline.map(t => \`
            <div style="position:relative;margin-bottom:14px;padding-left:16px">
              <div style="position:absolute;left:-14px;top:1px;width:10px;height:10px;border-radius:50%;background:\${t.color};box-shadow:0 0 6px \${t.color}66"></div>
              <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
                <div>
                  <span style="font-size:16px">\${t.icon}</span>
                  <span style="font-size:12px;color:var(--fp-text-soft);margin-left:6px">\${escHtml(t.text)}</span>
                </div>
                <span style="font-size:10px;color:var(--fp-text-faint);flex-shrink:0">\${t.date}</span>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- RECENT REVIEWS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('star').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Avis récents
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${reviews.slice(0,4).map(r => \`
            <div style="padding:10px;border-radius:10px;border:1px solid \${r.sentiment==='negative'?'rgba(239,68,68,0.2)':r.sentiment==='neutral'?'rgba(245,158,11,0.15)':'var(--fp-border)'};background:\${r.sentiment==='negative'?'rgba(239,68,68,0.03)':'rgba(255,255,255,0.02)'}">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px">
                <div style="display:flex;align-items:center;gap:8px">
                  <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(r.author)}</span>
                  <span style="font-size:13px">\${stars(r.stars)}</span>
                </div>
                <span style="font-size:10px;color:var(--fp-text-faint)">\${r.date}</span>
              </div>
              <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:8px;font-style:italic">&ldquo;\${escHtml(r.text)}&rdquo;</div>
              \${r.replied
                ? \`<span style="font-size:10px;color:#22c55e">✓ Répondu</span>\`
                : \`<button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Réponse IA envoyée !')">Répondre avec IA</button>\`
              }
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- REVIEW INTELLIGENCE + AI POST GENERATOR -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- REVIEW INTELLIGENCE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('bar-chart-2').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Intelligence des avis
          \${!isPro ? \`<span style="font-size:10px;padding:2px 7px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);border-radius:10px;color:#f59e0b;margin-left:8px">Pro+</span>\` : ''}
        </div>
        \${isPro ? \`
        <!-- Sentiment bars -->
        <div style="display:flex;gap:4px;margin-bottom:14px;height:60px;align-items:flex-end">
          \${[5,4,3,2,1].map(n => {
            const count = reviews.filter(r => r.stars === n).length || 0;
            const h = Math.max(8, count / reviews.length * 55);
            const c = n >= 4 ? '#22c55e' : n === 3 ? '#f59e0b' : '#ef4444';
            return \`<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px">
              <div style="font-size:9px;color:\${c};font-weight:700">\${count}</div>
              <div style="width:100%;height:\${h}px;background:\${c}33;border-radius:4px 4px 0 0;border-top:2px solid \${c}"></div>
              <div style="font-size:9px;color:var(--fp-text-faint)">\${n}★</div>
            </div>\`;
          }).join('')}
        </div>
        <!-- Sentiment score -->
        <div style="display:flex;gap:8px;margin-bottom:14px">
          \${[{label:'Positifs',val:reviews.filter(r=>r.sentiment==='positive').length,c:'#22c55e'},{label:'Neutres',val:reviews.filter(r=>r.sentiment==='neutral').length,c:'#f59e0b'},{label:'Négatifs',val:reviews.filter(r=>r.sentiment==='negative').length,c:'#ef4444'}].map(s=>\`
            <div style="flex:1;text-align:center;padding:8px;background:\${s.c}11;border:1px solid \${s.c}33;border-radius:8px">
              <div style="font-size:18px;font-weight:800;color:\${s.c}">\${s.val}</div>
              <div style="font-size:10px;color:var(--fp-text-faint)">\${s.label}</div>
            </div>
          \`).join('')}
        </div>
        <!-- Keywords -->
        <div class="fp-card-title" style="font-size:11px;margin-bottom:8px">Mots-clés fréquents</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px">
          \${reviewKeywords.map(k => \`
            <span style="padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;background:\${k.sentiment==='positive'?'rgba(34,197,94,0.1)':k.sentiment==='negative'?'rgba(239,68,68,0.1)':'rgba(245,158,11,0.1)'};color:\${k.sentiment==='positive'?'#22c55e':k.sentiment==='negative'?'#ef4444':'#f59e0b'}">
              \${escHtml(k.word)} (\${k.count})
            </span>
          \`).join('')}
        </div>
        <!-- Photo analytics -->
        <div style="margin-top:14px;padding:10px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.15);border-radius:8px">
          <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft);margin-bottom:6px">📸 Performance des photos</div>
          \${[
            { label: 'Vues photos ce mois', val: '1 240' },
            { label: 'Engagement moyen',    val: '+32%'  },
            { label: 'Photos manquantes',   val: '6'     },
          ].map(p => \`<div style="display:flex;justify-content:space-between;font-size:11px;padding:3px 0"><span style="color:var(--fp-text-muted)">\${p.label}</span><span style="font-weight:700;color:var(--fp-text-soft)">\${p.val}</span></div>\`).join('')}
        </div>
        \` : \`<div style="height:160px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;opacity:0.5">
          <div style="font-size:28px">📊</div>
          <div style="font-size:12px;color:var(--fp-text-muted)">Intelligence avis disponible en Pro</div>
        </div>\`}
      </div>

      <!-- AI POST GENERATOR -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          🤖 Générateur de posts GBP IA
          \${!isUltra ? \`<span style="font-size:10px;padding:2px 7px;background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.3);border-radius:10px;color:#8b5cf6;margin-left:8px">Ultra</span>\` : ''}
        </div>
        \${isUltra ? \`
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px">
          \${aiPosts.map(p => \`
            <div style="padding:12px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.15);border-radius:10px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(p.title)}</span>
                \${badge(p.type, '#2563EB')}
              </div>
              <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.5;margin-bottom:8px">\${escHtml(p.preview)}</div>
              <div style="display:flex;gap:6px">
                <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Post GBP publié !')">Publier</button>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Planification en cours…')">Planifier</button>
              </div>
            </div>
          \`).join('')}
        </div>
        \` : \`<div style="height:120px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;opacity:0.5;margin-bottom:14px">
          <div style="font-size:28px">🤖</div>
          <div style="font-size:12px;color:var(--fp-text-muted)">Générateur IA disponible en Ultra</div>
        </div>\`}
        <!-- Q&A MONITORING -->
        <div class="fp-card-title" style="font-size:12px;margin-bottom:10px">❓ Questions & réponses (Q&A)</div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${[
            { q: 'Êtes-vous ouvert le dimanche ?',           answered: false, date: 'il y a 3 jours' },
            { q: 'Proposez-vous des devis gratuits ?',        answered: true,  date: 'il y a 1 sem.'  },
            { q: 'Livraison disponible dans tout Paris ?',    answered: false, date: 'il y a 2 sem.'  },
          ].map(qa => \`
            <div style="padding:8px 10px;border-radius:8px;background:\${qa.answered?'rgba(34,197,94,0.04)':'rgba(239,68,68,0.04)'};border:1px solid \${qa.answered?'rgba(34,197,94,0.1)':'rgba(239,68,68,0.15)'}">
              <div style="font-size:11px;color:var(--fp-text-soft);margin-bottom:4px">\${escHtml(qa.q)}</div>
              <div style="display:flex;align-items:center;justify-content:space-between">
                <span style="font-size:10px;color:var(--fp-text-faint)">\${qa.date}</span>
                \${qa.answered
                  ? \`<span style="font-size:10px;color:#22c55e;font-weight:600">✓ Répondu</span>\`
                  : \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:2px 6px" onclick="showToast('success','Réponse IA générée !')">Répondre</button>\`
                }
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply all replacements ──────────────────────────────────
src = replaceFunc(src, 'renderLocalSEO',              NEW_LOCAL_SEO);
src = replaceFunc(src, 'renderLocalSEOZones',          NEW_LOCAL_SEO_ZONES);
src = replaceFunc(src, 'renderLocalSEOCompetitors',    NEW_LOCAL_SEO_COMPETITORS);
src = replaceFunc(src, 'renderLocalSEOOpportunities',  NEW_LOCAL_SEO_OPPORTUNITIES);
src = replaceFunc(src, 'renderLocalSEOGBP',            NEW_LOCAL_SEO_GBP);

writeFileSync(file, src, 'utf8');
console.log('\n✅ All Local SEO functions replaced successfully.');
