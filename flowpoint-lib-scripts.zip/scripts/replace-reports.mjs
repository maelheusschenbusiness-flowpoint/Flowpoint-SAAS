import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 3 → 8 sub-pages ───────────────────────
const OLD_SUBNAV = `'reports':    [{id:null,label:'Générer'},{id:'history',label:'Historique'},{id:'templates',label:'Templates'}],`;
const NEW_SUBNAV = `'reports':    [{id:null,label:'Command Center'},{id:'exec',label:'Executive'},{id:'seo',label:'SEO'},{id:'monitoring',label:'Monitoring'},{id:'local',label:'Local SEO'},{id:'conversion',label:'Conversion'},{id:'client',label:'White-Label'},{id:'ai',label:'IA Lab'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated reports sub-nav (3 \u2192 8)');
} else { console.error('SUB-NAV NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderReports() — full 8-sub-page premium BI reporting platform
// ══════════════════════════════════════════════════════════════
const NEW_REPORTS = `function renderReports() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';
  const circ52  = 2 * Math.PI * 52;

  // ── Shared data ────────────────────────────────────────────
  const reportScores = [
    { label: 'BI Score',            val: 74, color: '#2563EB', icon: '🧠' },
    { label: 'Automation Score',    val: 61, color: '#06b6d4', icon: '⚙️' },
    { label: 'Client Reporting',    val: 82, color: '#22c55e', icon: '👔' },
    { label: 'Engagement Score',    val: 58, color: '#f59e0b', icon: '📊' },
    { label: 'SEO Reporting',       val: 71, color: '#8b5cf6', icon: '🔍' },
    { label: 'Performance Score',   val: 88, color: '#22c55e', icon: '⚡' },
  ];

  const allReports = [
    { id:'r1', name:'Rapport SEO Executive — Mai 2026',    date:'Aujourd\'hui', type:'PDF', pages:14, shared:true,  size:'2.8 MB',  client:'Global',           score:'+7 pts', color:'#2563EB' },
    { id:'r2', name:'Rapport client Boulangerie Martin',   date:'05/05/2026',   type:'PDF', pages:8,  shared:true,  size:'1.6 MB',  client:'Boulangerie Martin',score:'+5 pts', color:'#22c55e' },
    { id:'r3', name:'Monitoring SLA — Avril 2026',         date:'01/05/2026',   type:'PDF', pages:6,  shared:false, size:'0.9 MB',  client:'Interne',          score:'99.1%',  color:'#22c55e' },
    { id:'r4', name:'Rapport concurrent — Mai 2026',       date:'29/04/2026',   type:'PDF', pages:10, shared:false, size:'2.1 MB',  client:'Interne',          score:'Critique',color:'#ef4444' },
    { id:'r5', name:'Rapport Q1 2026 — Synthese globale', date:'01/04/2026',   type:'PDF', pages:22, shared:true,  size:'4.8 MB',  client:'Global',           score:'+18 pts',color:'#8b5cf6' },
    { id:'r6', name:'Export donnees CSV — Audits',         date:'28/04/2026',   type:'CSV', pages:1,  shared:false, size:'34 KB',   client:'Interne',          score:'—',      color:'#64748b' },
  ];

  const scheduled = [
    { name: 'Rapport SEO mensuel',         freq: 'Mensuel · 1er', dest: 'client@boulangerie.fr', next: '01/06', active: true  },
    { name: 'Rapport Executive interne',   freq: 'Hebdo · Lundi', dest: 'equipe@agence.fr',      next: '13/05', active: true  },
    { name: 'Export CSV donnees',           freq: 'Quotidien · 8h',dest: 'Webhook CRM',           next: 'Demain', active: false },
  ];

  // ══════════════════════════════════════════════════════════
  // SUB: EXECUTIVE REPORTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'exec') {
    const months4 = ['Fev', 'Mar', 'Avr', 'Mai'];
    const seoScores  = [62, 66, 69, 74];
    const convScores = [38, 42, 44, 48];
    const perfScores = [78, 82, 85, 88];
    const bizHealth  = [58, 64, 67, 72];
    const recs = [
      { icon: '🎯', title: 'Priorite absolue : conversion mobile',  body: 'Le taux de conversion mobile est 2.8x inferieur au desktop. Simplifier le formulaire de contact pourrait generer +12 clients/mois.',         gain: '+12 clients/mois', color: '#ef4444' },
      { icon: '📍', title: 'Accelerer le Local SEO Maps',            body: 'Google Maps est votre source la plus qualitative (conv. 3.2%). Renforcer la fiche GBP et les avis peut accelerer le trafic local de +30%.',    gain: '+30% trafic local', color: '#22c55e' },
      { icon: '🔗', title: 'Reconquerir le trafic referent',         body: 'Les referents ont baisse de -4% avec un taux de rebond de 58%. Revoir les partenariats et creer du contenu co-marque cible.',                  gain: '+400 sessions/mois', color: '#f59e0b' },
    ];
    return \`
      \${isPro
        ? aiBlock("Votre business affiche une trajectoire positive sur 4 mois : score SEO +12 pts, sante business +14 pts. <strong>Point critique</strong> : la conversion reste votre maillon faible (48/100). Le potentiel de revenue non capture est evalue a <strong>-3 800€/mois</strong>.",
            ['Rapport complet PDF', 'Plan actions prioritaires', 'Partager au client'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">📈</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Rapports Executive — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Syntheses business IA, recommandations strategiques et analyse de performance executive.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise a niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Score business global', '72/100', '+14 pts en 4 mois', 'up')}
        \${statCard('Score SEO', '74/100', '+12 pts en 4 mois', 'up')}
        \${statCard('Score conversion', '48/100', '+10 pts — encore critique', 'up')}
        \${statCard('Score performance', '88/100', 'Excellent — SLA tenu', 'up')}
      </div>

      <!-- 4-MONTH PERFORMANCE CHART -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('trending-up').replace('stroke="currentColor"','stroke="#2563EB"')}
            Evolution globale — 4 mois
          </div>
          <div style="display:flex;gap:12px;font-size:10px;color:var(--fp-text-faint)">
            \${[{l:'SEO',c:'#2563EB'},{l:'Conversion',c:'#ef4444'},{l:'Performance',c:'#22c55e'},{l:'Business',c:'#8b5cf6'}].map(x=>\`<span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:3px;background:\${x.c};border-radius:2px;display:inline-block"></span>\${x.l}</span>\`).join('')}
          </div>
        </div>
        <div style="display:flex;gap:10px;align-items:flex-end">
          \${months4.map((m, i) => \`
            <div style="flex:1;display:flex;flex-direction:column;gap:6px">
              \${[{v:seoScores[i],c:'#2563EB'},{v:convScores[i],c:'#ef4444'},{v:perfScores[i],c:'#22c55e'},{v:bizHealth[i],c:'#8b5cf6'}].map(s=>\`
                <div style="display:flex;align-items:center;gap:6px">
                  <div style="flex:1;background:rgba(255,255,255,0.03);border-radius:4px;height:8px;overflow:hidden">
                    <div style="height:100%;width:\${s.v}%;background:\${s.c};border-radius:4px;transition:width 0.6s ease\${i===3?';box-shadow:0 0 6px '+s.c+'66':''}"></div>
                  </div>
                  <span style="font-size:10px;font-weight:\${i===3?700:400};color:\${i===3?s.c:'var(--fp-text-faint)';width:24px">\${s.v}</span>
                </div>
              \`).join('')}
              <div style="font-size:10px;color:var(--fp-text-faint);text-align:center;margin-top:4px">\${m}</div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- STRATEGIC RECOMMENDATIONS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🎯 Recommandations strategiques IA</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${recs.map(r => \`
            <div style="display:flex;align-items:flex-start;gap:12px;padding:14px 16px;border-radius:10px;border-left:3px solid \${r.color};background:\${r.color}07">
              <span style="font-size:20px;flex-shrink:0">\${r.icon}</span>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(r.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.55">\${escHtml(r.body)}</div>
              </div>
              <div style="text-align:center;flex-shrink:0">
                <div style="font-size:13px;font-weight:800;color:\${r.color}">\${escHtml(r.gain)}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">potentiel</div>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: SEO REPORTING CENTER
  // ══════════════════════════════════════════════════════════
  if (sub === 'seo') {
    const mths = ['Jan','Fev','Mar','Avr','Mai'];
    const seoM = [58, 62, 66, 69, 74];
    const kwds = [
      { kw: 'boulangerie paris 15', pos: 2,  prev: 4,  vol: 320, diff: 34, trend: +2, opp: 'high'   },
      { kw: 'plombier urgence paris', pos: 7,  prev: 12, vol: 580, diff: 51, trend: +5, opp: 'medium' },
      { kw: 'restaurant gastronomique montmartre', pos: 14, prev: 18, vol: 210, diff: 48, trend: +4, opp: 'medium' },
      { kw: 'serrurier 75011',   pos: 1,  prev: 1,  vol: 440, diff: 28, trend: 0,  opp: 'low'    },
      { kw: 'fleuriste mariage paris', pos: 22, prev: 29, vol: 190, diff: 62, trend: +7, opp: 'high'  },
    ];
    const maxSeo = Math.max(...seoM);
    return \`
      \${aiBlock("Score SEO global : <strong>74/100 (+12 pts en 5 mois)</strong>. 3 mots-cles ont progresse significativement ce mois. Opportunite detectee : <strong>boulangerie paris 15</strong> peut atteindre la 1ere position avec 2 actions techniques (schema markup + vitesse mobile).",
        ['Generer rapport SEO PDF', 'Plan mots-cles', 'Optimiser les 3 priorites'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Score SEO moyen', '74/100', '+12 pts en 5 mois', 'up')}
        \${statCard('Mots-cles Top 3', '1', '+1 vs M-1', 'up')}
        \${statCard('Mots-cles Top 10', '2', '+1 vs M-1', 'up')}
        \${statCard('Opportunites SEO', '2', 'a impact eleve', 'neutral')}
      </div>

      <!-- SEO SCORE EVOLUTION -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('bar-chart-2').replace('stroke="currentColor"','stroke="#2563EB"')}
            Evolution du score SEO — 5 mois
          </div>
          <span style="font-size:11px;color:var(--fp-text-faint)">+12 pts progression</span>
        </div>
        <div style="display:flex;gap:8px;align-items:flex-end;height:110px;margin-bottom:10px">
          \${mths.map((m, i) => \`
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
              <div style="font-size:10px;font-weight:\${i===4?800:400};color:\${i===4?'#2563EB':'var(--fp-text-faint)'}">\${seoM[i]}</div>
              <div style="width:100%;height:\${Math.round(seoM[i]/maxSeo*90)}px;background:linear-gradient(180deg,rgba(37,99,235,\${i===4?0.8:0.4}),rgba(37,99,235,0.1));border-radius:5px 5px 0 0;\${i===4?'box-shadow:0 0 10px rgba(37,99,235,0.3);border-top:2px solid #2563EB':''}"></div>
              <div style="font-size:9px;color:var(--fp-text-faint)">\${m}</div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- KEYWORD TABLE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('search').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Positions mots-cles — Mai 2026
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Mot-cle</th><th>Position</th><th>Prev.</th><th>Volume</th><th>Difficulte</th><th>Tendance</th><th>Opportunite</th></tr></thead>
            <tbody>
              \${kwds.map(k => {
                const pc = k.pos <= 3 ? '#22c55e' : k.pos <= 10 ? '#f59e0b' : '#ef4444';
                const oc = k.opp === 'high' ? '#ef4444' : k.opp === 'medium' ? '#f59e0b' : '#64748b';
                const tc = k.trend > 0 ? '#22c55e' : k.trend < 0 ? '#ef4444' : 'var(--fp-text-faint)';
                return \`<tr>
                  <td style="font-weight:600;font-size:11px">\${escHtml(k.kw)}</td>
                  <td style="font-weight:800;font-size:14px;color:\${pc}">#\${k.pos}</td>
                  <td style="font-size:11px;color:var(--fp-text-faint)">#\${k.prev}</td>
                  <td>\${k.vol}</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:5px">
                      <div class="fp-progress-track" style="width:50px;height:4px"><div class="fp-progress-fill" style="width:\${k.diff}%;background:\${k.diff<40?'#22c55e':k.diff<60?'#f59e0b':'#ef4444'}"></div></div>
                      <span style="font-size:10px;color:var(--fp-text-faint)">\${k.diff}</span>
                    </div>
                  </td>
                  <td style="font-weight:700;color:\${tc}">\${k.trend > 0 ? '\u2191+' : k.trend < 0 ? '\u2193' : '\u2192'}\${Math.abs(k.trend)||''}</td>
                  <td>\${badge(k.opp === 'high' ? 'Haute' : k.opp === 'medium' ? 'Moyenne' : 'Faible', oc)}</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: MONITORING & INCIDENT REPORTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'monitoring') {
    const monSLA = STATE.monitors.slice(0, 5).map((m, i) => ({
      ...m,
      uptime: [99.98, 99.91, 100, 98.72, 99.44][i] || 99.5,
      sla:    [99.9, 99.9, 99.9, 99.0, 99.9][i] || 99.9,
      ok:     [true, true, true, false, true][i],
      latAvg: [142, 318, 89, 621, 203][i] || 200,
      incidents:[0, 1, 0, 4, 1][i] || 0,
    }));
    const incidents = [
      { site: 'restaurant-lesoleil.fr', date: '04/05 · 14h32',  dur: '18 min', impact: 'Moyen',  cause: 'Timeout serveur — pic de trafic',  resolved: true  },
      { site: 'plombier-urgence.fr',    date: '28/04 · 03h14', dur: '2h 41m', impact: 'Critique',cause: 'Serveur hors ligne — coupure hebergeur', resolved: true  },
      { site: 'fleuriste-paris.fr',     date: '21/04 · 09h08',  dur: '6 min',  impact: 'Faible',  cause: 'Certificat SSL expire — renouvele',  resolved: true  },
    ];
    return \`
      \${aiBlock("Stabilite globale <strong>excellente</strong> ce mois : uptime moyen 99.6%. Un seul incident critique detecte le 28/04 (2h41 hors ligne). <strong>restaurant-lesoleil.fr</strong> est sous le seuil SLA (98.72%) — action requise pour le mois prochain.",
        ['Rapport SLA complet', 'Configurer alertes', 'Generer rapport client'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Uptime moyen', '99.6%', '+0.2% vs M-1', 'up')}
        \${statCard('Incidents critiques', '1', '2h41 — resolu', 'neutral')}
        \${statCard('Sites sous SLA', '1', 'restaurant-lesoleil.fr', 'down')}
        \${statCard('Latence moyenne', '275ms', '-42ms vs M-1', 'up')}
      </div>

      <!-- SLA TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('activity').replace('stroke="currentColor"','stroke="#22c55e"')}
          Rapport SLA — Mai 2026
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Site</th><th>Uptime reel</th><th>SLA cible</th><th>Latence moy.</th><th>Incidents</th><th>Statut SLA</th></tr></thead>
            <tbody>
              \${monSLA.map(m => \`<tr>
                <td style="font-size:11px;font-weight:600">\${escHtml(m.url?.replace('https://','') || m.name)}</td>
                <td style="font-weight:800;color:\${m.uptime >= m.sla ? '#22c55e' : '#ef4444'}">\${m.uptime}%</td>
                <td style="color:var(--fp-text-muted)">\${m.sla}%</td>
                <td style="color:\${m.latAvg > 400 ? '#ef4444' : m.latAvg > 250 ? '#f59e0b' : '#22c55e'}">\${m.latAvg}ms</td>
                <td style="font-weight:700;color:\${m.incidents > 2 ? '#ef4444' : m.incidents > 0 ? '#f59e0b' : '#22c55e'}">\${m.incidents}</td>
                <td>\${badge(m.uptime >= m.sla ? 'SLA OK' : 'SLA NOK', m.uptime >= m.sla ? '#22c55e' : '#ef4444')}</td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- INCIDENT TIMELINE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">⚡ Timeline des incidents — 30 jours</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${incidents.map(inc => {
            const ic = inc.impact === 'Critique' ? '#ef4444' : inc.impact === 'Moyen' ? '#f59e0b' : '#2563EB';
            return \`<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:10px;background:\${ic}08;border-left:3px solid \${ic}">
              <div style="flex:1">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                  \${badge(inc.impact, ic)}
                  <span style="font-size:11px;font-weight:700;color:var(--fp-text)">\${escHtml(inc.site)}</span>
                </div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(inc.cause)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:11px;color:var(--fp-text-faint)">\${escHtml(inc.date)}</div>
                <div style="font-size:11px;font-weight:700;color:\${ic}">\${escHtml(inc.dur)}</div>
                <div style="font-size:10px;color:#22c55e">Resolu</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: LOCAL SEO REPORTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'local') {
    const zones = [
      { name: '15e arrondissement', vis: 78, prev: 71, kw: 14, reviews: 4.4, comp: 'Moyen',   trend: +7,  dominant: true  },
      { name: '16e arrondissement', vis: 62, prev: 58, kw: 9,  reviews: 4.1, comp: 'Fort',    trend: +4,  dominant: false },
      { name: 'Montmartre',         vis: 44, prev: 38, kw: 6,  reviews: 4.6, comp: 'Tres fort',trend: +6, dominant: false },
      { name: 'Marais',             vis: 31, prev: 33, kw: 4,  reviews: 3.8, comp: 'Moyen',   trend: -2,  dominant: false },
    ];
    const gbpStats = [
      { label: 'Appels depuis GBP',   val: 47,  trend: +12, unit: '',   color: '#22c55e' },
      { label: 'Itineraires demandes',val: 134, trend: +28, unit: '',   color: '#2563EB' },
      { label: 'Visites fiche',       val: 2840,trend: +21, unit: '',   color: '#8b5cf6' },
      { label: 'Note moyenne',        val: 4.4, trend: +0.2,unit: '★', color: '#f59e0b' },
      { label: 'Avis sans reponse',   val: 14,  trend: +5,  unit: '',   color: '#ef4444' },
    ];
    return \`
      \${aiBlock("Visibilite locale en hausse sur 3 des 4 zones. <strong>Le 15e progresse fortement (+7 pts)</strong> — dominance quasi-acquise. Alerte : le Marais recule (-2 pts) face a une concurrence renforcee. <strong>14 avis sans reponse</strong> menacent votre note moyenne.",
        ['Rapport local complet', 'Plan zones cibles', 'Repondre aux avis'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Zones analysees', String(zones.length), '1 dominee, 3 en progression', 'up')}
        \${statCard('Visibilite moy.', '54%', '+4% vs M-1', 'up')}
        \${statCard('Note GBP moy.', '4.4 \u2605', '+0.2 vs M-1', 'up')}
        \${statCard('Avis sans reponse', '14', 'Action requise', 'down')}
      </div>

      <!-- ZONES TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('map').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Visibilite locale par zone — Mai 2026
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Zone</th><th>Visibilite</th><th>Prev.</th><th>Mots-cles</th><th>Note GBP</th><th>Competition</th><th>Tendance</th></tr></thead>
            <tbody>
              \${zones.map(z => {
                const vc = z.vis >= 70 ? '#22c55e' : z.vis >= 50 ? '#f59e0b' : '#ef4444';
                const tc = z.trend > 0 ? '#22c55e' : z.trend < 0 ? '#ef4444' : 'var(--fp-text-faint)';
                return \`<tr>
                  <td style="font-weight:600">\${escHtml(z.name)}\${z.dominant ? ' <span style="font-size:9px;color:#22c55e">★</span>' : ''}</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:6px">
                      <div class="fp-progress-track" style="width:60px;height:5px"><div class="fp-progress-fill" style="width:\${z.vis}%;background:\${vc}"></div></div>
                      <span style="font-weight:800;color:\${vc}">\${z.vis}%</span>
                    </div>
                  </td>
                  <td style="color:var(--fp-text-faint)">\${z.prev}%</td>
                  <td style="font-weight:700">\${z.kw}</td>
                  <td style="font-weight:700;color:#f59e0b">\${z.reviews} \u2605</td>
                  <td style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(z.comp)}</td>
                  <td style="font-weight:700;color:\${tc}">\${z.trend > 0 ? '\u2191+' : z.trend < 0 ? '\u2193' : '\u2192'}\${Math.abs(z.trend) || '0'}pts</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- GBP PERFORMANCE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📍 Performance Google Business Profile — Mai 2026</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">
          \${gbpStats.map(g => {
            const nt = g.trend > 0 ? '+' + g.trend : String(g.trend);
            const nc = g.color === '#ef4444' ? '#ef4444' : '#22c55e';
            return \`<div style="padding:14px;border-radius:10px;border:1px solid \${g.color}28;background:\${g.color}07;text-align:center">
              <div style="font-size:22px;font-weight:800;color:\${g.color};margin-bottom:4px">\${g.val}\${g.unit}</div>
              <div style="font-size:10px;color:var(--fp-text-muted);margin-bottom:6px">\${escHtml(g.label)}</div>
              <div style="font-size:11px;font-weight:700;color:\${nc}">\${nt} vs M-1</div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CONVERSION & REVENUE REPORTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'conversion') {
    const funnelSteps = [
      { stage: 'Visiteurs',        n: 12640, pct: 100, drop: null },
      { stage: 'Engages',          n: 7820,  pct: 61.9, drop: 38.1 },
      { stage: 'Page service',     n: 3240,  pct: 25.6, drop: 58.6 },
      { stage: 'Contact initie',   n: 892,   pct: 7.1,  drop: 72.5 },
      { stage: 'Conversion',       n: 134,   pct: 1.1,  drop: 85.0 },
    ];
    const ctaData = [
      { cta: 'Demander un devis',    ctr: 2.8, mob: 0.9, pos: 'Hero',    impact: 'Critique' },
      { cta: 'Appeler maintenant',   ctr: 4.1, mob: 6.2, pos: 'Header', impact: 'Positif'  },
      { cta: 'Voir nos services',    ctr: 8.4, mob: 6.1, pos: 'Milieu', impact: 'Bon'      },
      { cta: 'Prendre RDV',          ctr: 1.2, mob: 0.4, pos: 'Pied',   impact: 'Faible'   },
    ];
    const leaks = [
      { desc: 'Formulaire mobile trop long', impact: 2840, urgent: true  },
      { desc: 'Page Tarifs sans CTA visible',impact: 1260, urgent: true  },
      { desc: 'Vitesse page Contact 58/100', impact: 620,  urgent: false },
      { desc: 'Absence de chat live',        impact: 380,  urgent: false },
    ];
    return \`
      \${aiBlock("Taux de conversion global : <strong>1.06%</strong> — potentiel estime a 2.8% avec le plan CRO complet. <strong>Perte mensuelle</strong> de -3 800€ revenue identifiee. Priorite #1 : formulaire mobile (perte 2 840€/mois).",
        ['Rapport CRO complet', 'Plan conversion mobile', 'Generer rapport client'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Taux de conversion', '1.06%', '+0.12% vs M-1', 'up')}
        \${statCard('Clients convertis', '134', 'ce mois', 'neutral')}
        \${statCard('Revenue capture', '3 220\u20ac', 'estime ce mois', 'up')}
        \${statCard('Revenue perdu', '-3 800\u20ac', '4 fuites detectees', 'down')}
      </div>

      <!-- FUNNEL -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('filter').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Entonnoir de conversion — Mai 2026
        </div>
        \${funnelSteps.map((s, idx) => \`
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
            <div style="width:110px;font-size:11px;color:var(--fp-text-muted);text-align:right;flex-shrink:0">\${escHtml(s.stage)}</div>
            <div style="flex:1;background:rgba(255,255,255,0.03);border-radius:6px;height:28px;overflow:hidden">
              <div style="height:100%;width:\${s.pct}%;background:linear-gradient(90deg,\${idx===0?'#2563EB':idx===4?'#22c55e':'#8b5cf6'}99,\${idx===0?'#2563EB':idx===4?'#22c55e':'#8b5cf6'}33);border-radius:6px;display:flex;align-items:center;padding-left:8px">
                \${s.n >= 3000 ? \`<span style="font-size:10px;font-weight:700;color:#fff">\${s.n.toLocaleString('fr-FR')}</span>\` : ''}
              </div>
            </div>
            <div style="min-width:90px;text-align:right;flex-shrink:0">
              <div style="font-size:12px;font-weight:800;color:\${idx===0?'#2563EB':idx===4?'#22c55e':'#8b5cf6'}">\${s.n.toLocaleString('fr-FR')}</div>
              \${s.drop !== null ? \`<div style="font-size:10px;color:#ef4444;font-weight:600">-\${s.drop}%</div>\` : ''}
            </div>
          </div>
        \`).join('')}
      </div>

      <!-- CTA + REVENUE LEAKS -->
      <div class="fp-grid-2">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🎯 Performance CTA</div>
          <table class="fp-data-table">
            <thead><tr><th>CTA</th><th>CTR</th><th>Mobile</th><th>Impact</th></tr></thead>
            <tbody>
              \${ctaData.map(c => {
                const ic = c.impact === 'Critique' ? '#ef4444' : c.impact === 'Positif' ? '#22c55e' : c.impact === 'Bon' ? '#2563EB' : '#64748b';
                return \`<tr>
                  <td style="font-size:11px;font-weight:600">\${escHtml(c.cta)}</td>
                  <td style="font-weight:700;color:\${c.ctr>3?'#22c55e':c.ctr>1.5?'#f59e0b':'#ef4444'}">\${c.ctr}%</td>
                  <td style="font-weight:700;color:\${c.mob>3?'#22c55e':c.mob>1?'#f59e0b':'#ef4444'}">\${c.mob}%</td>
                  <td>\${badge(c.impact, ic)}</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">💸 Revenue Leaks detectees</div>
          \${leaks.map(l => \`
            <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
              <div style="flex:1;font-size:11px;color:var(--fp-text-muted)">\${escHtml(l.desc)}</div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:13px;font-weight:800;color:#ef4444">-\${l.impact.toLocaleString('fr-FR')}\u20ac</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">/mois</div>
              </div>
              \${badge(l.urgent ? 'Urgent' : 'Moyen', l.urgent ? '#ef4444' : '#f59e0b')}
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CLIENT & WHITE-LABEL REPORTING
  // ══════════════════════════════════════════════════════════
  if (sub === 'client') {
    const clients = [
      { name: 'Boulangerie Martin',   reports: 3, lastSent: '05/05', nextSend: '01/06', score: 74, trend: +5, logo: '🥐', active: true  },
      { name: 'Restaurant Le Soleil', reports: 2, lastSent: '01/05', nextSend: '01/06', score: 61, trend: +2, logo: '🍽️', active: true  },
      { name: 'Plombier Urgences 75', reports: 4, lastSent: '29/04', nextSend: '01/06', score: 82, trend: +8, logo: '🔧', active: true  },
      { name: 'Fleuriste Madeleine',  reports: 1, lastSent: '15/04', nextSend: 'Manuel', score: 48, trend: -3, logo: '🌹', active: false },
    ];
    const brandFields = [
      { label: 'Logo agence',        type: 'upload', val: 'logo-agence.png',   locked: !isUltra },
      { label: 'Couleur principale', type: 'color',  val: '#2563EB',           locked: !isUltra },
      { label: 'Couleur secondaire', type: 'color',  val: '#22c55e',           locked: !isUltra },
      { label: 'Nom agence',         type: 'text',   val: 'Flowpoint Agency',  locked: false    },
      { label: 'Site agence',        type: 'text',   val: 'https://agence.fr', locked: false    },
      { label: 'Pied de page custom',type: 'text',   val: 'Rapport prepare par Flowpoint Agency', locked: !isUltra },
    ];
    return \`
      \${isUltra
        ? aiBlock("4 clients configures. <strong>3 rapports actifs</strong> avec envoi automatique mensuel. Boulangerie Martin est le client le plus engage (3 rapports consultes). Fleuriste Madeleine n\'a pas recu de rapport depuis 3 semaines — risque de desengagement.",
            ['Generer rapport groupe', 'Config white-label', 'Ajouter un client'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
            <div style="font-size:24px">👔</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Rapports White-Label — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Branding personnalise, logo agence, couleurs custom et rapports co-marques pour vos clients.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise a niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Clients actifs', String(clients.filter(c => c.active).length), 'avec rapports planifies', 'up')}
        \${statCard('Rapports envoyes', String(clients.reduce((s,c)=>s+c.reports,0)), 'ce mois', 'up')}
        \${statCard('Prochain envoi', '01/06', '3 clients', 'neutral')}
        \${statCard('White-label', isUltra ? 'Actif' : 'Ultra requis', isUltra ? 'Branding custom' : 'Passer Ultra', isUltra ? 'up' : 'neutral')}
      </div>

      <!-- CLIENT LIST -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">👥 Gestion des clients</div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Client ajoute !')">+ Ajouter</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${clients.map(c => {
            const sc = c.score >= 70 ? '#22c55e' : c.score >= 50 ? '#f59e0b' : '#ef4444';
            const tc = c.trend > 0 ? '#22c55e' : c.trend < 0 ? '#ef4444' : 'var(--fp-text-faint)';
            return \`<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <div style="font-size:24px;flex-shrink:0">\${c.logo}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(c.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">Dernier envoi : \${escHtml(c.lastSent)} · Prochain : \${escHtml(c.nextSend)}</div>
              </div>
              <div style="text-align:center;flex-shrink:0">
                <div style="font-size:16px;font-weight:800;color:\${sc}">\${c.score}</div>
                <div style="font-size:10px;font-weight:700;color:\${tc}">\${c.trend >= 0 ? '+' : ''}\${c.trend} pts</div>
              </div>
              <div style="font-size:11px;color:var(--fp-text-faint);flex-shrink:0">\${c.reports} rapports</div>
              \${badge(c.active ? 'Actif' : 'Pause', c.active ? '#22c55e' : '#64748b')}
              <div style="display:flex;gap:6px;flex-shrink:0">
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Rapport genere !')">Generer</button>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Envoye !')">Envoyer</button>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- WHITE-LABEL CONFIG -->
      <div class="fp-card" style="opacity:\${isUltra ? 1 : 0.55}">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">🎨 Configuration White-Label</div>
          \${!isUltra ? badge('Ultra', '#8b5cf6') : badge('Actif', '#22c55e')}
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
          \${brandFields.map(f => \`
            <div style="padding:12px 14px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid \${f.locked ? 'var(--fp-border)' : 'rgba(139,92,246,0.2)'}">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <div style="font-size:10px;font-weight:700;color:var(--fp-text-faint);text-transform:uppercase">\${escHtml(f.label)}</div>
                \${f.locked ? '<span style="font-size:10px;color:#8b5cf6">🔒 Ultra</span>' : ''}
              </div>
              \${f.type === 'color'
                ? \`<div style="display:flex;align-items:center;gap:8px"><div style="width:20px;height:20px;border-radius:5px;background:\${f.val};flex-shrink:0"></div><span style="font-size:12px;font-weight:600;color:var(--fp-text-soft)">\${f.val}</span></div>\`
                : \`<div style="font-size:12px;color:var(--fp-text-soft);font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${escHtml(f.val)}</div>\`
              }
              \${!f.locked ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;width:100%;margin-top:8px" onclick="showToast('info','Configuration ouverte…')">Modifier</button>\` : ''}
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: AI INSIGHTS REPORTING LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'ai') {
    const aiInsights = [
      { pri: 'critical', icon: '🚨', cat: 'Conversion',  title: 'Perte revenue weekend confirmee',        body: 'Samedi et dimanche representent 0% de conversion malgre 22% du trafic mensuel. Impact estime : -800€/weekend. Cause probable : formulaire de contact ferme ou non visible en mobile.', action: 'Corriger le formulaire' },
      { pri: 'critical', icon: '📱', cat: 'Mobile UX',   title: 'Conversion mobile critique (0.12%)',     body: 'Le segment mobile (58% du trafic) convertit 14× moins bien que le desktop. La page Tarifs affiche 61% d\'abandons. Chaque point de conversion mobile = +47 clients/mois.',              action: 'Plan UX mobile'          },
      { pri: 'high',     icon: '📍', cat: 'Local SEO',   title: 'Opportunite Maps non capturee',          body: 'Google Maps est votre source la plus qualitative (conv. 3.2%, qualite 88/100) mais represente seulement 14% du trafic. Potentiel x3 si GBP renforce et avis manages.',              action: 'Renforcer GBP'           },
      { pri: 'high',     icon: '🔗', cat: 'Trafic',      title: 'Declin referents accelere',              body: 'Le trafic referent a baisse 4% avec un taux de rebond 58% — source la moins qualitative. 3 partenaires cles ont reduit ou supprime leurs liens entrants ce trimestre.',             action: 'Analyser les referents'  },
      { pri: 'positive', icon: '📈', cat: 'Croissance',  title: 'Acceleration trafic organique',          body: 'Le trafic organique a progresse de +130% en 8 mois — acceleration confirmee depuis mars. Le 15e arrondissement domine deja 4 mots-cles cles. Continuer sur cette lancee.',           action: 'Amplifier la strategie'  },
    ];
    const forecast = [
      { metric: 'Trafic M+3',    val: '+22%', conf: 78, color: '#2563EB', note: 'Avec maintien strategie SEO actuelle'     },
      { metric: 'Conversion M+3',val: '+0.8%',conf: 64, color: '#22c55e', note: 'Si plan CRO mobile execute en juin'       },
      { metric: 'Revenue M+3',   val: '+68%', conf: 71, color: '#8b5cf6', note: 'Combinaison trafic + conversion optimisee'},
      { metric: 'Local SEO M+3', val: '+31%', conf: 82, color: '#f59e0b', note: 'Si renforcement GBP confirme en juin'     },
    ];
    const priC = { critical: '#ef4444', high: '#f59e0b', medium: '#2563EB', positive: '#22c55e' };
    const priL = { critical: 'Critique', high: 'Priorite haute', medium: 'Moyen', positive: 'Positif' };
    return \`
      \${isUltra
        ? aiBlock("Rapport IA genere automatiquement — <strong>Mai 2026</strong>. 2 alertes critiques actives. Potentiel de revenue non capture : <strong>-3 800€/mois</strong>. Score de sante business : 72/100 (+14 pts en 4 mois). Trajectoire : <strong>positive avec 2 risques a traiter en urgence</strong>.",
            ['Rapport narratif complet', 'Exporter en PDF', 'Programmer envoi auto'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
            <div style="font-size:24px">🤖</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">IA Reporting Lab — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Rapports narratifs IA, previsions avancees, detection d\'anomalies et recommandations strategiques.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise a niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Insights generes', String(aiInsights.length), 'cette semaine', 'neutral')}
        \${statCard('Alertes critiques', String(aiInsights.filter(i => i.pri === 'critical').length), 'action immediate', 'down')}
        \${statCard('Score business', '72/100', '+14 pts — 4 mois', 'up')}
        \${statCard('Previsions actives', String(forecast.length), 'horizon M+3', 'neutral')}
      </div>

      <!-- AI INSIGHTS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('cpu').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Insights IA — Rapport mai 2026
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${aiInsights.map(ins => \`
            <div style="display:flex;align-items:flex-start;gap:12px;padding:14px;border-radius:10px;border:1px solid \${priC[ins.pri]}28;background:\${priC[ins.pri]}07;border-left-width:3px">
              <span style="font-size:20px;flex-shrink:0">\${ins.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
                  \${badge(priL[ins.pri], priC[ins.pri])}
                  \${badge(ins.cat, '#475569')}
                </div>
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(ins.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.55">\${escHtml(ins.body)}</div>
              </div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="flex-shrink:0;white-space:nowrap" onclick="showToast('info','\${escHtml(ins.action)}…')">\${escHtml(ins.action)}</button>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- FORECASTS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🔮 Previsions IA — Horizon M+3 (Aout 2026)</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
          \${forecast.map(f => \`
            <div style="padding:16px;border-radius:12px;border:1px solid \${f.color}28;background:\${f.color}08;text-align:center">
              <div style="font-size:26px;font-weight:900;color:\${f.color};margin-bottom:4px">\${f.val}</div>
              <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(f.metric)}</div>
              <div style="font-size:10px;color:var(--fp-text-muted);margin-bottom:8px">\${escHtml(f.note)}</div>
              <div style="font-size:10px;color:var(--fp-text-faint)">Confiance IA : <strong style="color:\${f.color}">\${f.conf}%</strong></div>
              <div class="fp-progress-track" style="height:4px;margin-top:6px"><div class="fp-progress-fill" style="width:\${f.conf}%;background:\${f.color}"></div></div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Report Command Center
  // ══════════════════════════════════════════════════════════
  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Executive Reporting Hub
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);border-radius:20px;color:#22c55e">AI-POWERED</span>
        </h1>
        <div class="fp-section-sub">Plateforme de reporting business · \${allReports.length} rapports disponibles · Prochain envoi auto : 01/06</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Generer rapport', 'fp-btn fp-btn-primary fp-btn-sm', 'file', "onclick=\\"showToast('success','Generation en cours…')\\"" )}
        \${btn('Exporter tout',   'fp-btn fp-btn-ghost fp-btn-sm',   'download',  "onclick=\\"showToast('info','Export groupé…')\\"" )}
      </div>
    </div>

    <!-- AI EXECUTIVE SUMMARY -->
    \${isUltra
      ? aiBlock("Bilan executif mai 2026 : score business <strong>72/100 (+4 pts)</strong>. 6 rapports generes dont 3 partages clients. <strong>2 alertes critiques</strong> : conversion mobile 0.12% et weekend a 0%. Revenue non capture estime : <strong>-3 800€/mois</strong>. Tendance globale : positive.",
          ['Rapport executif PDF', 'Briefing client', 'Plan actions'])
      : \`<div style="padding:14px 16px;background:rgba(34,197,94,0.06);border:1px solid rgba(34,197,94,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
          <div style="font-size:22px">📋</div>
          <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Syntheses IA — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Rapports narratifs automatiques, analyse business et recommandations strategiques generees par IA.</div></div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise a niveau…')">Passer Ultra</button>
        </div>\`
    }

    <!-- KPI STAT ROW -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Rapports generes', String(allReports.length), 'ce mois', 'up')}
      \${statCard('Partages clients', String(allReports.filter(r => r.shared).length), 'liens actifs', 'up')}
      \${statCard('Envois auto actifs', String(scheduled.filter(s => s.active).length), 'planifies ce mois', 'neutral')}
      \${statCard('Score BI global', '74/100', '+6 pts vs M-1', 'up')}
    </div>

    <!-- 6 SCORE GAUGES -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('activity').replace('stroke="currentColor"','stroke="#22c55e"')}
          Scores de reporting — 6 indicateurs cles
        </div>
        <span style="font-size:11px;color:var(--fp-text-faint)">Moyenne : <strong style="color:#22c55e">72/100</strong></span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
        \${reportScores.map(k => {
          const filled = k.val / 100 * circ52;
          const dash   = circ52 - filled;
          return \`<div style="padding:14px;border-radius:12px;border:1px solid \${k.color}28;background:\${k.color}07;text-align:center">
            <svg width="72" height="72" viewBox="0 0 120 120" style="margin:0 auto 6px">
              <circle cx="60" cy="60" r="46" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="8"/>
              <circle cx="60" cy="60" r="46" fill="none" stroke="\${k.color}" stroke-width="8"
                stroke-dasharray="\${filled.toFixed(1)} \${dash.toFixed(1)}"
                stroke-dashoffset="\${(circ52*0.25).toFixed(1)}"
                stroke-linecap="round" transform="rotate(-90 60 60)"/>
              <text x="60" y="65" text-anchor="middle" font-size="22" font-weight="800" fill="\${k.color}" font-family="Outfit,sans-serif">\${k.val}</text>
            </svg>
            <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${k.icon} \${escHtml(k.label)}</div>
            <div style="margin-top:6px">\${badge(k.val>=75?'Bon':k.val>=55?'Moyen':'Critique', k.color)}</div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- RECENT REPORTS + SCHEDULED -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('file-text').replace('stroke="currentColor"','stroke="#2563EB"')}
            Rapports recents
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('ai')">IA Lab →</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${allReports.slice(0,5).map(r => \`
            <div style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <div style="width:32px;height:32px;border-radius:7px;background:\${r.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <span style="font-size:9px;font-weight:800;color:\${r.color}">\${r.type}</span>
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-size:11px;font-weight:600;color:var(--fp-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${escHtml(r.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(r.date)} · \${escHtml(r.size)}\${r.shared ? ' · <span style="color:#22c55e">Partage</span>' : ''}</div>
              </div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Telechargement…')">↓</button>
            </div>
          \`).join('')}
        </div>
      </div>

      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">⏰ Envois planifies</div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('success','Planification creee !')">+ Planifier</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px">
          \${scheduled.map(s => \`
            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:8px;background:rgba(255,255,255,0.02);border:1px solid \${s.active ? 'rgba(34,197,94,0.2)' : 'var(--fp-border)'}">
              <div style="flex:1">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(s.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(s.freq)} · \${escHtml(s.dest)} · Prochain : \${escHtml(s.next)}</div>
              </div>
              \${badge(s.active ? 'Actif' : 'En pause', s.active ? '#22c55e' : '#64748b')}
            </div>
          \`).join('')}
        </div>

        <!-- QUICK NAV -->
        <div class="fp-card-title" style="margin-bottom:10px">🧩 Navigation rapide</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
          \${[
            {label:'Executive',  sub:'exec',      icon:'📊'},
            {label:'SEO',        sub:'seo',        icon:'🔍'},
            {label:'Monitoring', sub:'monitoring', icon:'⚡'},
            {label:'Local SEO',  sub:'local',      icon:'📍'},
            {label:'Conversion', sub:'conversion', icon:'🎯'},
            {label:'IA Lab',     sub:'ai',         icon:'🤖'},
          ].map(n => \`
            <div style="display:flex;align-items:center;gap:7px;padding:8px 10px;border-radius:7px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${n.sub}')">
              <span style="font-size:13px">\${n.icon}</span>
              <span style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${n.label}</span>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- QUICK REPORT BUILDER -->
    <div class="fp-card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('zap').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Generateur de rapport rapide
        </div>
        \${isPro ? badge('Pro actif', '#2563EB') : badge('Standard', '#64748b')}
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-bottom:14px">
        <div class="fp-form-group" style="margin:0">
          <label class="fp-form-label">Sites inclus</label>
          <select class="fp-select" style="width:100%"><option>Tous les sites (6)</option>\${STATE.audits.map(a=>\`<option>\${escHtml(a.url)}</option>\`).join('')}</select>
        </div>
        <div class="fp-form-group" style="margin:0">
          <label class="fp-form-label">Periode</label>
          <select class="fp-select" style="width:100%"><option>Mai 2026</option><option>Avril 2026</option><option>T2 2026</option><option>12 mois</option></select>
        </div>
        <div class="fp-form-group" style="margin:0">
          <label class="fp-form-label">Format</label>
          <select class="fp-select" style="width:100%"><option>PDF executif</option><option>PDF client</option>\${isUltra?'<option>PDF White-Label</option>':''}<option>CSV donnees</option></select>
        </div>
        <div class="fp-form-group" style="margin:0">
          <label class="fp-form-label">Envoyer a</label>
          <input class="fp-input" placeholder="client@exemple.fr" style="width:100%"/>
        </div>
      </div>
      <div style="margin-bottom:12px">
        <div class="fp-form-label" style="margin-bottom:8px">Sections</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          \${['Score SEO', 'Monitors SLA', 'Local SEO', 'Conversion', 'Concurrents', 'Recommandations IA', 'Previsions'].map(s=>\`
            <label style="display:flex;align-items:center;gap:5px;cursor:pointer;font-size:12px;color:var(--fp-text-soft)">
              <input type="checkbox" checked style="accent-color:#2563EB"/> \${s}
            </label>
          \`).join('')}
        </div>
      </div>
      \${btn('Generer le rapport IA', 'fp-btn fp-btn-primary fp-btn-sm', 'file', "onclick=\\"showToast('success','Rapport en cours de generation…')\\"" )}
    </div>
  \`;
}`;

// ── 2. Stub out old helper functions (they're now dead code) ──
const STUB_HISTORY = `function renderReportsHistory() {
  return renderReports();
}`;

const STUB_TEMPLATES = `function renderReportsTemplates() {
  return renderReports();
}`;

src = replaceFunc(src, 'renderReports', NEW_REPORTS);
src = replaceFunc(src, 'renderReportsHistory', STUB_HISTORY);
src = replaceFunc(src, 'renderReportsTemplates', STUB_TEMPLATES);

writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Reports fully replaced (8 sub-pages).');
