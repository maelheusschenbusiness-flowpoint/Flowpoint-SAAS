#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# FlowPoint Production Smoke Test
# Usage:
#   BASE_URL=https://your-app.replit.app API_KEY=your-api-key bash scripts/production-smoke-test.sh
#   Locally: BASE_URL=http://localhost:3001 API_KEY=your-key bash scripts/production-smoke-test.sh
#
# Exit code: 0 = all tests passed, 1 = one or more tests failed
# ─────────────────────────────────────────────────────────────────────────────

BASE_URL="${BASE_URL:-http://localhost:3001}"
API_KEY="${API_KEY:-}"

PASS=0
FAIL=0
TOTAL=0

GREEN="\033[0;32m"
RED="\033[0;31m"
YELLOW="\033[0;33m"
RESET="\033[0m"
BOLD="\033[1m"

# ── Helpers ───────────────────────────────────────────────────────────────────
header() {
  echo ""
  echo -e "${BOLD}$1${RESET}"
  echo "────────────────────────────────────────"
}

# Sends WITH auth header (if API_KEY is set)
check() {
  local label="$1"
  local expected_status="$2"
  local path="$3"
  shift 3
  TOTAL=$((TOTAL + 1))

  local auth_header=()
  if [ -n "$API_KEY" ]; then
    auth_header=(-H "Authorization: Bearer ${API_KEY}")
  fi

  actual_status=$(curl -s -o /dev/null -w "%{http_code}" \
    "${auth_header[@]}" \
    -H "Content-Type: application/json" \
    --max-time 12 \
    "$@" \
    "${BASE_URL}${path}" 2>/dev/null)

  if [ "$actual_status" = "$expected_status" ]; then
    echo -e "  ${GREEN}✓ PASS${RESET}  [$actual_status]  $label"
    PASS=$((PASS + 1))
  else
    echo -e "  ${RED}✗ FAIL${RESET}  [got $actual_status, expected $expected_status]  $label"
    FAIL=$((FAIL + 1))
  fi
}

# Sends WITHOUT any auth header (for boundary checks)
check_no_auth() {
  local label="$1"
  local expected_status="$2"
  local path="$3"
  TOTAL=$((TOTAL + 1))

  actual_status=$(curl -s -o /dev/null -w "%{http_code}" \
    -H "Content-Type: application/json" \
    --max-time 12 \
    "${BASE_URL}${path}" 2>/dev/null)

  if [ "$actual_status" = "$expected_status" ]; then
    echo -e "  ${GREEN}✓ PASS${RESET}  [$actual_status]  $label"
    PASS=$((PASS + 1))
  else
    echo -e "  ${RED}✗ FAIL${RESET}  [got $actual_status, expected $expected_status]  $label"
    FAIL=$((FAIL + 1))
  fi
}

# Body contains expected string (with auth)
check_contains() {
  local label="$1"
  local path="$2"
  local expected_field="$3"
  # Guard: fail loudly if called with fewer than 3 arguments (prevents silent false positives)
  if [ -z "$label" ] || [ -z "$path" ] || [ -z "$expected_field" ]; then
    echo -e "  ${RED}✗ SCRIPT BUG${RESET}  check_contains called with missing arguments: label='$label' path='$path' field='$expected_field'"
    FAIL=$((FAIL + 1))
    TOTAL=$((TOTAL + 1))
    return
  fi
  TOTAL=$((TOTAL + 1))

  local auth_header=()
  if [ -n "$API_KEY" ]; then
    auth_header=(-H "Authorization: Bearer ${API_KEY}")
  fi

  body=$(curl -s \
    "${auth_header[@]}" \
    -H "Content-Type: application/json" \
    --max-time 12 \
    "${BASE_URL}${path}" 2>/dev/null)

  if echo "$body" | grep -q "$expected_field"; then
    echo -e "  ${GREEN}✓ PASS${RESET}  [contains '${expected_field}']  $label"
    PASS=$((PASS + 1))
  else
    echo -e "  ${RED}✗ FAIL${RESET}  [missing '${expected_field}']  $label"
    echo -e "         Preview: ${body:0:160}"
    FAIL=$((FAIL + 1))
  fi
}

# Body does NOT contain string (with auth)
check_not_contains() {
  local label="$1"
  local path="$2"
  local unexpected="$3"
  if [ -z "$label" ] || [ -z "$path" ] || [ -z "$unexpected" ]; then
    echo -e "  ${RED}✗ SCRIPT BUG${RESET}  check_not_contains called with missing arguments: label='$label' path='$path' unexpected='$unexpected'"
    FAIL=$((FAIL + 1))
    TOTAL=$((TOTAL + 1))
    return
  fi
  TOTAL=$((TOTAL + 1))

  local auth_header=()
  if [ -n "$API_KEY" ]; then
    auth_header=(-H "Authorization: Bearer ${API_KEY}")
  fi

  body=$(curl -s \
    "${auth_header[@]}" \
    -H "Content-Type: application/json" \
    --max-time 12 \
    "${BASE_URL}${path}" 2>/dev/null)

  if echo "$body" | grep -q "$unexpected"; then
    echo -e "  ${RED}✗ FAIL${RESET}  [unexpectedly contains '${unexpected}']  $label"
    FAIL=$((FAIL + 1))
  else
    echo -e "  ${GREEN}✓ PASS${RESET}  [does not contain '${unexpected}']  $label"
    PASS=$((PASS + 1))
  fi
}

# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}FlowPoint Production Smoke Test${RESET}"
echo -e "Target: ${YELLOW}${BASE_URL}${RESET}"
echo -e "Auth:   $([ -n "$API_KEY" ] && echo "${GREEN}API key provided${RESET}" || echo "${YELLOW}No API key — protected endpoints will 401${RESET}")"
echo ""

# ── 1. Public health (no auth) ────────────────────────────────────────────────
header "1. Health Checks (public — no auth required)"
check_no_auth "GET /api/healthz — 200 public"             "200" "/api/healthz"
check_contains  "GET /api/healthz — has uptime"           "/api/healthz" '"uptime"'
check_contains  "GET /api/healthz — status:ok"            "/api/healthz" '"status":"ok"'
check_no_auth "GET /api/healthz/deep — 200 public"        "200" "/api/healthz/deep"
# Deep checks must include all required service probes
check_contains  "healthz/deep — database check present"   "/api/healthz/deep" '"database"'
check_contains  "healthz/deep — stripe check present"     "/api/healthz/deep" '"stripe"'
check_contains  "healthz/deep — openai check present"     "/api/healthz/deep" '"openai"'
check_contains  "healthz/deep — betterstack check present"  "/api/healthz/deep" '"betterstack"'
check_contains  "healthz/deep — dataforseo check present" "/api/healthz/deep" '"dataforseo"'
check_contains  "healthz/deep — resend check present"     "/api/healthz/deep" '"resend"'
check_contains  "healthz/deep — google_oauth check present"  "/api/healthz/deep" '"google_oauth"'
# Each check must include latencyMs (runtime probe, not just flag)
check_contains  "healthz/deep — has latencyMs fields"     "/api/healthz/deep" '"latencyMs"'
# Top-level checks object must have 'status' per check, not just bool
check_contains  "healthz/deep — per-check status field"   "/api/healthz/deep" '"status":"ok"'

# ── 2. Auth boundary ──────────────────────────────────────────────────────────
header "2. Auth Boundary (explicit no-auth requests)"
check_no_auth "GET /api/audits — 401 no auth"          "401" "/api/audits"
check_no_auth "GET /api/monitors — 401 no auth"        "401" "/api/monitors"
check_no_auth "GET /api/me — 401 no auth"              "401" "/api/me"
check_no_auth "GET /api/ai/usage — 401 no auth"        "401" "/api/ai/usage"
check_no_auth "GET /api/diagnostics — 401 no auth"     "401" "/api/diagnostics"

# ── 3. Core endpoints (authenticated) ────────────────────────────────────────
header "3. Core Endpoints (authenticated)"
check "GET /api/me"              "200" "/api/me"
check "GET /api/audits"          "200" "/api/audits"
check "GET /api/monitors"        "200" "/api/monitors"
check "GET /api/overview"        "200" "/api/overview"
check "GET /api/missions"        "200" "/api/missions"
check "GET /api/notifications"   "200" "/api/notifications"
check "GET /api/alert-rules"     "200" "/api/alert-rules"
check "GET /api/keywords"        "200" "/api/keywords"

# ── 4. Billing & AI ───────────────────────────────────────────────────────────
header "4. Billing & AI"
check_no_auth "GET /api/billing/config — 200 public"      "200" "/api/billing/config"
check         "GET /api/ai/usage — 200 authenticated"     "200" "/api/ai/usage"
check         "POST /api/ai/chat — 400 empty body"        "400" "/api/ai/chat" -X POST -d '{}'

# ── 5. Diagnostics — content assertions ───────────────────────────────────────
header "5. Diagnostics Aggregate"
check          "GET /api/diagnostics — 200"                    "200"   "/api/diagnostics"
check_contains "diagnostics — checks.database present"         "/api/diagnostics" '"database"'
check_contains "diagnostics — cronCount field"                 "/api/diagnostics" '"cronCount"'
check_contains "diagnostics — indexCount field"                "/api/diagnostics" '"indexCount"'
check_contains "diagnostics — activeSessions field"            "/api/diagnostics" '"activeSessions"'
check_contains "diagnostics — sessionStoreType field"          "/api/diagnostics" '"sessionStoreType"'
check_contains "diagnostics — plan field"                      "/api/diagnostics" '"plan"'
check_contains "diagnostics — envVars inventory present"       "/api/diagnostics" '"envVars"'
check_contains "diagnostics — envVars OPENAI_API_KEY"         "/api/diagnostics" '"OPENAI_API_KEY"'
check_contains "diagnostics — envMissingCritical present"      "/api/diagnostics" '"envMissingCritical"'
# Values in envVars must be "set" or "not_set", never actual secret values
check_not_contains "diagnostics — envVars leaks no values"     "/api/diagnostics" 'sk-'

header "5b. Diagnostics Workers"
check          "GET /api/diagnostics/workers — 200"          "200" "/api/diagnostics/workers"
check_contains "workers — has workers array"                 "/api/diagnostics/workers" '"workers"'
check_contains "workers — has total field"                   "/api/diagnostics/workers" '"total"'

header "5c. Diagnostics Integrations — live probes"
check          "GET /api/diagnostics/integrations — 200"     "200" "/api/diagnostics/integrations"
check_contains "integrations — summary block"                "/api/diagnostics/integrations" '"summary"'
check_contains "integrations — integrations array"           "/api/diagnostics/integrations" '"integrations"'
check_contains "integrations — stripe entry"                 "/api/diagnostics/integrations" '"stripe"'
check_contains "integrations — openai entry"                 "/api/diagnostics/integrations" '"openai"'
check_contains "integrations — dataforseo entry"             "/api/diagnostics/integrations" '"dataforseo"'
check_contains "integrations — betterstack entry"            "/api/diagnostics/integrations" '"betterstack"'
check_contains "integrations — resend entry"                 "/api/diagnostics/integrations" '"resend"'
check_contains "integrations — gsc entry"                    "/api/diagnostics/integrations" '"gsc"'
check_contains "integrations — latencyMs in entries"         "/api/diagnostics/integrations" '"latencyMs"'
check_contains "integrations — liveProbe field"              "/api/diagnostics/integrations" '"liveProbe"'
# Status values must be in the allowed set
check_contains "integrations — status domain valid"          "/api/diagnostics/integrations" '"status":"connected"\|"status":"setup_required"\|"status":"error"'

header "5d. Diagnostics Billing"
check          "GET /api/diagnostics/billing — 200"          "200" "/api/diagnostics/billing"
check_contains "billing — plan field"                        "/api/diagnostics/billing" '"plan"'
check_contains "billing — stripeApiStatus field"             "/api/diagnostics/billing" '"stripeApiStatus"'
check_contains "billing — stripeKeyPresent field"            "/api/diagnostics/billing" '"stripeKeyPresent"'
check_contains "billing — subscriptionStatus field"          "/api/diagnostics/billing" '"subscriptionStatus"'

header "5e. Diagnostics Database"
check          "GET /api/diagnostics/database — 200"         "200" "/api/diagnostics/database"
check_contains "database — tableCount"                       "/api/diagnostics/database" '"tableCount"'
check_contains "database — indexCount"                       "/api/diagnostics/database" '"indexCount"'
check_contains "database — fkCount"                          "/api/diagnostics/database" '"fkCount"'
check_contains "database — rowCounts"                        "/api/diagnostics/database" '"rowCounts"'
check_contains "database — tables list"                      "/api/diagnostics/database" '"tables"'

# ── 6. Error handling ─────────────────────────────────────────────────────────
header "6. Error Handling"
check "GET /api/nonexistent — 404"          "404" "/api/nonexistent_endpoint_xyz"
check "GET /api/audits/unknown_id — 404"    "404" "/api/audits/nonexistent_audit_id_xyz"

# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════"
if [ $FAIL -eq 0 ]; then
  echo -e "  ${GREEN}${BOLD}ALL $TOTAL TESTS PASSED${RESET}"
else
  echo -e "  ${RED}${BOLD}$FAIL / $TOTAL TESTS FAILED${RESET}  ($PASS/$TOTAL passed)"
fi
echo "════════════════════════════════════════"
echo ""

exit $FAIL
