import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 3 → 7 sub-pages ───────────────────────
const OLD_SUBNAV = `'data-explorer': [{id:null,label:'Données'},{id:'queries',label:'Requêtes'},{id:'exports',label:'Exports'}],`;
const NEW_SUBNAV = `'data-explorer': [{id:null,label:'Command Center'},{id:'traffic',label:'Traffic Intel'},{id:'behavior',label:'Comportement'},{id:'dashboards',label:'Dashboards'},{id:'insights',label:'IA Insights'},{id:'forecast',label:'Prévisions'},{id:'export',label:'Exports'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated data-explorer sub-nav (3 \u2192 7)');
} else { console.error('SUB-NAV NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderDataExplorer() — full 7-sub-page premium BI platform
// ══════════════════════════════════════════════════════════════
const NEW_DE = `function renderDataExplorer() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  // ── Shared data ────────────────────────────────────────────
  const trafficSources = [
    { src: 'Organique Google', sessions: 4820, pct: 38, quality: 82, bounce: 41, conv: 1.8,  trend: +12, color: '#22c55e' },
    { src: 'Direct',           sessions: 2140, pct: 17, quality: 74, bounce: 34, conv: 2.4,  trend: +3,  color: '#2563EB' },
    { src: 'Google Maps',      sessions: 1780, pct: 14, quality: 88, bounce: 28, conv: 3.2,  trend: +21, color: '#f59e0b' },
    { src: 'Référents',        sessions: 1320, pct: 10, quality: 61, bounce: 58, conv: 0.9,  trend: -4,  color: '#8b5cf6' },
    { src: 'Réseaux sociaux',  sessions: 980,  pct: 8,  quality: 48, bounce: 67, conv: 0.4,  trend: +8,  color: '#06b6d4' },
    { src: 'Publicité payante',sessions: 640,  pct: 5,  quality: 71, bounce: 44, conv: 1.6,  trend: -2,  color: '#ef4444' },
    { src: 'Email',            sessions: 390,  pct: 3,  quality: 91, bounce: 22, conv: 4.1,  trend: +5,  color: '#a78bfa' },
    { src: 'Autres',           sessions: 570,  pct: 5,  quality: 52, bounce: 62, conv: 0.6,  trend: 0,   color: '#475569' },
  ];

  const kpiScores = [
    { label: 'Business Health',    val: 72, color: '#22c55e', icon: '🏢' },
    { label: 'Growth Momentum',    val: 64, color: '#2563EB', icon: '📈' },
    { label: 'Traffic Intel',      val: 78, color: '#06b6d4', icon: '🚦' },
    { label: 'Conversion Intel',   val: 44, color: '#ef4444', icon: '🎯' },
    { label: 'SEO Data Score',     val: 71, color: '#f59e0b', icon: '🔍' },
    { label: 'Perf. Stability',    val: 83, color: '#22c55e', icon: '⚡' },
    { label: 'Revenue Opportunity',val: 52, color: '#8b5cf6', icon: '💰' },
  ];

  const circ46 = 2 * Math.PI * 46;

  // ══════════════════════════════════════════════════════════
  // SUB: TRAFFIC INTELLIGENCE
  // ══════════════════════════════════════════════════════════
  if (sub === 'traffic') {
    const months = ['Oct', 'Nov', 'Déc', 'Jan', 'Fév', 'Mar', 'Avr', 'Mai'];
    const organic = [2100, 2380, 2290, 2610, 2840, 3120, 3890, 4820];
    const local   = [480,  520,  610,  720,  850,  1010, 1340, 1780];
    const total   = organic.map((v, i) => v + local[i]);
    const maxT    = Math.max(...total);

    return \`
      \${aiBlock("Le trafic organique a progressé de <strong>+130% en 8 mois</strong> — accélération notable depuis mars. <strong>Google Maps est votre source la plus qualitative</strong> (score 88, conv. 3.2%). Alerte : le trafic référent est en déclin (-4%) avec un taux de rebond élevé à 58%.",
        ['Analyser les sources', 'Optimiser les référents', 'Plan trafic local'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Sessions totales', '12 640', '+18% vs M-1', 'up')}
        \${statCard('Meilleure source', 'Google Maps', 'Conv. 3.2% — score 88', 'up')}
        \${statCard('Source en déclin', 'Référents', '-4% · rebond 58%', 'down')}
        \${statCard('Qualité trafic moy.', '72/100', '+6 pts vs M-1', 'up')}
      </div>

      <!-- TREND CHART -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('trending-up').replace('stroke="currentColor"', 'stroke="#22c55e"')}
            Évolution du trafic — 8 mois
          </div>
          <div style="display:flex;gap:12px;font-size:10px;color:var(--fp-text-faint)">
            <span style="display:flex;align-items:center;gap:4px"><span style="width:8px;height:3px;background:#22c55e;border-radius:2px;display:inline-block"></span>Organique</span>
            <span style="display:flex;align-items:center;gap:4px"><span style="width:8px;height:3px;background:#f59e0b;border-radius:2px;display:inline-block"></span>Maps</span>
          </div>
        </div>
        <div style="display:flex;gap:6px;align-items:flex-end;height:120px;margin-bottom:10px">
          \${months.map((m, i) => \`
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:0">
              <div style="width:100%;display:flex;flex-direction:column;justify-content:flex-end;height:110px;gap:2px">
                <div style="width:100%;height:\${Math.round(organic[i] / maxT * 100)}px;background:linear-gradient(180deg,rgba(34,197,94,0.7),rgba(34,197,94,0.2));border-radius:3px 3px 0 0;\${i === months.length-1 ? 'box-shadow:0 0 10px rgba(34,197,94,0.3)' : ''}"></div>
                <div style="width:100%;height:\${Math.round(local[i] / maxT * 100)}px;background:linear-gradient(180deg,rgba(245,158,11,0.7),rgba(245,158,11,0.2));border-radius:3px 3px 0 0"></div>
              </div>
              <div style="font-size:9px;color:var(--fp-text-faint);margin-top:4px">\${m}</div>
            </div>
          \`).join('')}
        </div>
        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--fp-text-faint)">
          <span>Pic mai : <strong style="color:#22c55e">4 820</strong> sessions organiques</span>
          <span>Maps mai : <strong style="color:#f59e0b">1 780</strong> sessions</span>
        </div>
      </div>

      <!-- SOURCES TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('pie-chart').replace('stroke="currentColor"', 'stroke="#2563EB"')}
          Analyse par source de trafic
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Source</th><th>Sessions</th><th>Part</th><th>Qualité</th><th>Rebond</th><th>Conv.</th><th>Tendance</th></tr></thead>
            <tbody>
              \${trafficSources.map(s => {
                const tc = s.trend > 10 ? '#22c55e' : s.trend > 0 ? '#f59e0b' : s.trend < 0 ? '#ef4444' : 'var(--fp-text-faint)';
                return \`<tr>
                  <td><div style="display:flex;align-items:center;gap:8px"><span style="width:8px;height:8px;border-radius:50%;background:\${s.color};flex-shrink:0"></span><strong>\${escHtml(s.src)}</strong></div></td>
                  <td>\${s.sessions.toLocaleString('fr-FR')}</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:6px">
                      <div class="fp-progress-track" style="width:60px;height:4px"><div class="fp-progress-fill" style="width:\${s.pct}%;background:\${s.color}"></div></div>
                      <span style="font-size:11px;color:var(--fp-text-muted)">\${s.pct}%</span>
                    </div>
                  </td>
                  <td style="font-weight:700;color:\${s.quality>=80?'#22c55e':s.quality>=60?'#f59e0b':'#ef4444'}">\${s.quality}/100</td>
                  <td style="color:\${s.bounce>55?'#ef4444':s.bounce>40?'#f59e0b':'#22c55e'}">\${s.bounce}%</td>
                  <td style="font-weight:700;color:\${s.conv>=2?'#22c55e':s.conv>=1?'#f59e0b':'#ef4444'}">\${s.conv}%</td>
                  <td style="font-weight:700;color:\${tc}">\${s.trend>0?'↑+':s.trend<0?'↓':'→'}\${Math.abs(s.trend)||'0'}%</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- MOBILE VS DESKTOP -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📱 Mobile vs 💻 Desktop — Qualité par segment</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
          \${[
            { label: 'Sessions',      mob: 58, desk: 42, unit: '%', higher: 'Mobile' },
            { label: 'Taux de conv.', mob: 0.12, desk: 0.34, unit: '%', higher: 'Desktop' },
            { label: 'Score qualité', mob: 61, desk: 78, unit: '/100', higher: 'Desktop' },
            { label: 'Taux rebond',   mob: 64, desk: 42, unit: '%', higher: 'Desktop (moins rebond)' },
          ].map(m => \`
            <div style="padding:14px;border-radius:10px;border:1px solid var(--fp-border);background:rgba(255,255,255,0.02)">
              <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:8px">\${m.label}</div>
              <div style="display:flex;justify-content:space-between;margin-bottom:8px">
                <div style="text-align:center;flex:1">
                  <div style="font-size:18px;font-weight:800;color:#8b5cf6">\${m.mob}\${m.unit}</div>
                  <div style="font-size:9px;color:var(--fp-text-faint)">Mobile</div>
                </div>
                <div style="text-align:center;flex:1">
                  <div style="font-size:18px;font-weight:800;color:#06b6d4">\${m.desk}\${m.unit}</div>
                  <div style="font-size:9px;color:var(--fp-text-faint)">Desktop</div>
                </div>
              </div>
              <div style="font-size:10px;color:var(--fp-text-faint);text-align:center">Avantage : <strong style="color:#22c55e">\${m.higher}</strong></div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: USER BEHAVIOR LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'behavior') {
    const userFlowSteps = [
      { stage: 'Atterrissage',     users: 12640, drop: null,  next: 7820 },
      { stage: 'Navigation',       users: 7820,  drop: 38.1,  next: 3240 },
      { stage: 'Page de service',  users: 3240,  drop: 58.6,  next: 892  },
      { stage: 'Contact initié',   users: 892,   drop: 72.5,  next: 134  },
      { stage: 'Conversion',       users: 134,   drop: 85.0,  next: 28   },
    ];
    const segments = [
      { name: 'Visiteurs fidèles',    pct: 18, conv: 4.8, eng: 88, color: '#22c55e', desc: '2+ visites · session > 3 min' },
      { name: 'Explorateurs mobiles', pct: 42, conv: 0.8, eng: 41, color: '#f59e0b', desc: 'Mobile · 1 session · rebond 72%' },
      { name: 'Chercheurs locaux',    pct: 24, conv: 3.2, eng: 76, color: '#2563EB', desc: 'Google Maps · recherche locale' },
      { name: 'Rebondisseurs',        pct: 16, conv: 0.0, eng: 12, color: '#ef4444', desc: '< 10 sec · 0 interaction' },
    ];
    const pageEngage = [
      { page: 'Accueil',    eng: 62, scroll: 48, time: '1m 12s', abandon: 38 },
      { page: 'Services',   eng: 71, scroll: 61, time: '2m 04s', abandon: 29 },
      { page: 'Tarifs',     eng: 48, scroll: 39, time: '0m 58s', abandon: 61 },
      { page: 'Contact',    eng: 38, scroll: 28, time: '0m 32s', abandon: 67 },
      { page: 'Blog',       eng: 84, scroll: 78, time: '3m 28s', abandon: 16 },
    ];
    return \`
      \${isPro
        ? aiBlock("Les <strong>explorateurs mobiles (42%)</strong> ont un taux de conversion 6× inférieur aux visiteurs fidèles. Anomalie clé : la page Tarifs génère 61% d'abandons avec 39% de scroll seulement — les visiteurs ne voient pas les CTAs. Les visiteurs locaux (Google Maps) sont votre segment le plus précieux : conv. 3.2%.",
            ['Optimiser pour les mobiles', 'Analyser la page Tarifs', 'Plan segmentation'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">🧬</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">User Behavior Lab — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Segmentation comportementale, flux utilisateur, scoring engagement et analyse de friction.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Sessions analysées', '12 640', 'ce mois', 'neutral')}
        \${statCard('Taux engagement moy.', '61%', '+8% vs M-1', 'up')}
        \${statCard('Abandons funnel', '85%', 'avant conversion', 'down')}
        \${statCard('Durée session moy.', '1m 52s', '+18s vs M-1', 'up')}
      </div>

      <!-- USER FLOW -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('git-branch').replace('stroke="currentColor"', 'stroke="#8b5cf6"')}
          Flux utilisateur — Du trafic à la conversion
        </div>
        <div style="display:flex;flex-direction:column;gap:4px">
          \${userFlowSteps.map((s, idx) => \`
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:130px;font-size:11px;color:var(--fp-text-muted);text-align:right;flex-shrink:0">\${escHtml(s.stage)}</div>
              <div style="flex:1;background:rgba(255,255,255,0.03);border-radius:6px;height:32px;overflow:hidden">
                <div style="height:100%;width:\${Math.max(2, s.users / 12640 * 100)}%;background:linear-gradient(90deg,\${idx === 0 ? '#2563EB' : idx === 4 ? '#22c55e' : '#8b5cf6'}99,\${idx === 0 ? '#2563EB' : idx === 4 ? '#22c55e' : '#8b5cf6'}33);border-radius:6px;display:flex;align-items:center;padding-left:8px">
                  \${s.users >= 3000 ? \`<span style="font-size:10px;font-weight:700;color:#fff">\${s.users.toLocaleString('fr-FR')}</span>\` : ''}
                </div>
              </div>
              <div style="min-width:80px;text-align:right;flex-shrink:0">
                <div style="font-size:12px;font-weight:800;color:\${idx === 0 ? '#2563EB' : idx === 4 ? '#22c55e' : '#8b5cf6'}">\${s.users.toLocaleString('fr-FR')}</div>
                \${s.drop !== null ? \`<div style="font-size:10px;color:#ef4444;font-weight:600">-\${s.drop}%</div>\` : ''}
              </div>
            </div>
          \`).join('')}
        </div>
        <div style="margin-top:12px;padding:10px;background:rgba(239,68,68,0.06);border-radius:8px;font-size:11px;color:#ef4444">
          ⚠ 85% des visiteurs n'atteignent pas la conversion — la plus grande perte : Navigation → Service (-59%)
        </div>
      </div>

      <!-- SEGMENTS + PAGE ENGAGEMENT -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">👥 Segments comportementaux</div>
          <div style="display:flex;flex-direction:column;gap:10px">
            \${segments.map(seg => \`
              <div style="padding:12px 14px;border-radius:10px;border-left:3px solid \${seg.color};background:\${seg.color}08">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
                  <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(seg.name)}</span>
                  <div style="display:flex;gap:8px">
                    <span style="font-size:11px;font-weight:700;color:\${seg.color}">\${seg.pct}%</span>
                    <span style="font-size:11px;font-weight:700;color:\${seg.conv>=2?'#22c55e':seg.conv>=0.5?'#f59e0b':'#ef4444'}">conv. \${seg.conv}%</span>
                  </div>
                </div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(seg.desc)}</div>
                <div style="margin-top:6px">
                  <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${seg.eng}%;background:\${seg.color}"></div></div>
                </div>
              </div>
            \`).join('')}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📄 Engagement par type de page</div>
          <table class="fp-data-table">
            <thead><tr><th>Page</th><th>Eng.</th><th>Scroll</th><th>Durée</th><th>Abandon</th></tr></thead>
            <tbody>
              \${pageEngage.map(p => \`<tr>
                <td style="font-weight:600">\${p.page}</td>
                <td style="color:\${p.eng>=70?'#22c55e':p.eng>=50?'#f59e0b':'#ef4444'};font-weight:700">\${p.eng}%</td>
                <td style="color:var(--fp-text-muted)">\${p.scroll}%</td>
                <td style="font-family:monospace;font-size:11px">\${p.time}</td>
                <td style="color:\${p.abandon>=60?'#ef4444':p.abandon>=40?'#f59e0b':'#22c55e'};font-weight:700">\${p.abandon}%</td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CUSTOM DASHBOARDS
  // ══════════════════════════════════════════════════════════
  if (sub === 'dashboards') {
    const presets = [
      { name: 'Dashboard SEO Executive',   widgets: 8,  updated: 'Aujourd\'hui', icon: '🔍', color: '#2563EB',  desc: 'Score SEO, positions, backlinks, local SEO domination' },
      { name: 'Dashboard Marketing',        widgets: 6,  updated: 'Hier',         icon: '📢', color: '#8b5cf6',  desc: 'Sources trafic, conversion, campagnes, ROI' },
      { name: 'Dashboard Performance',      widgets: 7,  updated: '02/05',        icon: '⚡', color: '#22c55e',  desc: 'Uptime, vitesse, Core Web Vitals, SLA' },
      { name: 'Dashboard Client (white)',   widgets: 5,  updated: '01/05',        icon: '👔', color: '#f59e0b',  desc: 'Vue simplifiée branded pour présentations client' },
    ];
    const widgetTypes = [
      { name: 'Score SEO',         icon: '📊', plan: 'Standard' },
      { name: 'Funnel conversion',  icon: '🔄', plan: 'Pro'      },
      { name: 'Heatmap trafic',     icon: '🔥', plan: 'Pro'      },
      { name: 'Radar concurrents',  icon: '🎯', plan: 'Pro'      },
      { name: 'Prévision trafic',   icon: '📈', plan: 'Ultra'    },
      { name: 'IA Insights live',   icon: '🤖', plan: 'Ultra'    },
      { name: 'KPI revenue',        icon: '💰', plan: 'Ultra'    },
      { name: 'Alerte en temps réel',icon:'🔔', plan: 'Pro'      },
    ];
    return \`
      \${isPro
        ? aiBlock("Votre dashboard SEO Executive est consulté 3× plus souvent que les autres. Suggestion IA : ajouter un widget <strong>Opportunités locales</strong> et <strong>Radar concurrents</strong> pour un executive briefing complet en un coup d'oeil.",
            ['Créer un dashboard', 'Ajouter des widgets', 'Partager au client'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">📊</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Dashboards personnalisés — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Créez et partagez des dashboards sur-mesure avec vos KPIs, vos widgets et votre branding.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Dashboards créés', String(presets.length), isPro ? '+ Nouveau' : 'Pro requis pour créer', 'neutral')}
        \${statCard('Widgets disponibles', String(widgetTypes.length), '3 Ultra exclusifs', 'neutral')}
        \${statCard('Partages actifs', '2', 'liens client actifs', 'up')}
        \${statCard('Vues cette semaine', '34', '+12 vs semaine passée', 'up')}
      </div>

      <!-- PRESET DASHBOARDS -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">Dashboards sauvegardés</div>
          \${isPro ? \`<button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Nouveau dashboard créé !')">+ Créer</button>\` : ''}
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px">
          \${presets.map(p => \`
            <div style="padding:16px;border-radius:12px;border:1px solid \${p.color}30;background:\${p.color}08;position:relative">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px">
                <div>
                  <div style="font-size:20px;margin-bottom:4px">\${p.icon}</div>
                  <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(p.name)}</div>
                </div>
                <span style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(p.updated)}</span>
              </div>
              <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:12px">\${escHtml(p.desc)}</div>
              <div style="display:flex;align-items:center;justify-content:space-between">
                <span style="font-size:10px;color:\${p.color};font-weight:600">\${p.widgets} widgets</span>
                <div style="display:flex;gap:6px">
                  <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','Ouverture du dashboard…')">Ouvrir</button>
                  <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Lien copié !')">Partager</button>
                </div>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- WIDGET GALLERY -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧩 Galerie de widgets</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">
          \${widgetTypes.map(w => {
            const locked = (w.plan === 'Pro' && isStd) || (w.plan === 'Ultra' && !isUltra);
            const pc = w.plan === 'Ultra' ? '#8b5cf6' : w.plan === 'Pro' ? '#2563EB' : '#22c55e';
            return \`<div style="padding:14px;border-radius:10px;border:1px solid \${locked ? 'var(--fp-border)' : pc + '30'};background:\${locked ? 'rgba(255,255,255,0.01)' : pc + '08'};text-align:center;opacity:\${locked ? 0.6 : 1}">
              <div style="font-size:24px;margin-bottom:6px">\${w.icon}</div>
              <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft);margin-bottom:6px">\${escHtml(w.name)}</div>
              <div style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:8px;display:inline-block;background:\${pc}20;color:\${pc}">\${w.plan}</div>
              \${!locked ? \`<div style="margin-top:8px"><button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;width:100%" onclick="showToast('success','Widget ajouté !')">Ajouter</button></div>\` : \`<div style="margin-top:8px;font-size:10px;color:var(--fp-text-faint)">🔒 \${w.plan}</div>\`}
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: AI INSIGHTS CENTER
  // ══════════════════════════════════════════════════════════
  if (sub === 'insights') {
    const insights = [
      { cat: 'Trafic',      pri: 'critical', icon: '🚦', title: 'Déclin du trafic référent accéléré',           body: 'Le trafic référent a baissé de 4% avec un taux de rebond de 58% — source la moins qualitative. Vérifier les partenariats et backlinks actifs.',    action: 'Analyser les référents' },
      { cat: 'SEO',         pri: 'high',     icon: '🔍', title: 'Opportunité mots-clés locaux sous-exploités',  body: 'Détection de 3 mots-clés locaux à fort volume (> 200 rech/mois) où aucun concurrent bien optimisé. Capture estimée : +480 sessions/mois.',          action: 'Voir les mots-clés'     },
      { cat: 'Conversion',  pri: 'critical', icon: '🎯', title: 'Perte de conversion mobile critique',          body: 'Le taux de conversion mobile (0.12%) est 2.8× inférieur au desktop. La page Tarifs a 61% d\'abandons. Action prioritaire : simplifier le formulaire.',  action: 'Corriger le formulaire' },
      { cat: 'Comportement',pri: 'high',     icon: '🧬', title: 'Segment rebondisseurs en hausse (+3%)',        body: '16% des sessions durent moins de 10 secondes. Ces visiteurs arrivent majoritairement via réseaux sociaux. Améliorer la cohérence message/page.',     action: 'Analyser les segments'  },
      { cat: 'Performance', pri: 'medium',   icon: '⚡', title: 'Corrélation vitesse/conversion confirmée',     body: 'Les pages avec vitesse > 80/100 convertissent 2.4× mieux. 2 pages principales sont à 55-62/100. Impact estimé sur conversion : -18%.',               action: 'Voir la performance'    },
      { cat: 'Croissance',  pri: 'positive', icon: '📈', title: 'Accélération trafic local Maps remarquable',  body: '+21% de trafic Maps ce mois — votre meilleure source (conv. 3.2%, qualité 88). La fiche GBP renforcée en avril explique cette accélération.',         action: 'Renforcer GBP'          },
    ];
    const anomalies = [
      { title: 'Pic de trafic anormal — mardi 6 mai', desc: '+340 sessions en 2h entre 14h et 16h — origine : partage viral sur Facebook local. Taux de rebond 89%.', sev: 'info',    date: '06/05' },
      { title: 'Chute soudaine de position #3',       desc: 'boulangerie-paris.fr est passé de #3 à #7 en 48h. Probable mise à jour algorithmique Google ou action concurrente.', sev: 'warning', date: '04/05' },
      { title: 'Conversion 0% weekend 3-4 mai',       desc: 'Aucune conversion samedi et dimanche. Historiquement 20% du volume mensuel. Vérifier formulaire de contact.', sev: 'critical', date: '04/05' },
    ];
    const priC = { critical: '#ef4444', high: '#f59e0b', medium: '#2563EB', positive: '#22c55e' };
    const priL = { critical: 'Critique', high: 'Priorité haute', medium: 'Moyen', positive: 'Positif' };
    return \`
      \${isUltra
        ? aiBlock("6 insights générés cette semaine. 2 menaces critiques nécessitent une action immédiate : <strong>conversion mobile à 0.12%</strong> et <strong>conversion week-end à 0%</strong>. Opportunité positive : le trafic Maps accélère fortement — potentiel +30% si GBP renforcé.",
            ['Plan actions critiques', 'Rapport IA complet', 'Programmer les alertes'])
        : \`<div style="padding:14px 16px;background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">🤖</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">IA Insights Center — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Insights stratégiques générés automatiquement, détection d\'anomalies et recommandations business.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Insights générés', String(insights.length), 'cette semaine', 'neutral')}
        \${statCard('Insights critiques', String(insights.filter(i => i.pri === 'critical').length), 'action requise', 'down')}
        \${statCard('Anomalies détectées', String(anomalies.length), '30 derniers jours', 'neutral')}
        \${statCard('Insights positifs', String(insights.filter(i => i.pri === 'positive').length), 'à amplifier', 'up')}
      </div>

      <!-- INSIGHTS LIST -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('cpu').replace('stroke="currentColor"', 'stroke="#8b5cf6"')}
          Insights IA — Cette semaine
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${insights.map(ins => \`
            <div style="display:flex;align-items:flex-start;gap:12px;padding:14px;border-radius:10px;border:1px solid \${priC[ins.pri]}28;background:\${priC[ins.pri]}07;border-left-width:3px">
              <span style="font-size:20px;flex-shrink:0">\${ins.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
                  \${badge(priL[ins.pri], priC[ins.pri])}
                  \${badge(ins.cat, '#475569')}
                </div>
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(ins.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.55">\${escHtml(ins.body)}</div>
              </div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="flex-shrink:0;white-space:nowrap" onclick="showToast('info','\${escHtml(ins.action)}…')">\${escHtml(ins.action)}</button>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- ANOMALIES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">⚠️ Anomalies détectées — 30 derniers jours</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${anomalies.map(a => {
            const ac = a.sev === 'critical' ? '#ef4444' : a.sev === 'warning' ? '#f59e0b' : '#2563EB';
            return \`<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:10px;background:\${ac}08;border:1px solid \${ac}25">
              \${badge(a.sev === 'critical' ? 'Critique' : a.sev === 'warning' ? 'Alerte' : 'Info', ac)}
              <div style="flex:1">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(a.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.5">\${escHtml(a.desc)}</div>
              </div>
              <span style="font-size:10px;color:var(--fp-text-faint);flex-shrink:0">\${a.date}</span>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: DATA FORECASTING LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'forecast') {
    const fMonths = ['Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov'];
    const fTraffic   = [13800, 15200, 14100, 16400, 17800, 19200];
    const fConv      = [0.27, 0.31, 0.29, 0.34, 0.38, 0.41];
    const fRev       = [3240, 3800, 3400, 4420, 5140, 5920];
    const maxF       = Math.max(...fTraffic);
    const scenarios  = [
      { name: 'Scénario conservateur',   traffic: '+8%',  conv: '+0.02%', rev: '+8%',  color: '#64748b', desc: 'Sans actions supplémentaires' },
      { name: 'Scénario recommandé',     traffic: '+24%', conv: '+0.12%', rev: '+78%', color: '#2563EB', desc: 'Plan CRO + GBP + contenu local' },
      { name: 'Scénario optimiste',      traffic: '+52%', conv: '+0.21%', rev: '+142%',color: '#22c55e', desc: 'Plan maximal + publicité payante' },
    ];
    return \`
      \${isUltra
        ? aiBlock("Prévision trafic M+6 : <strong>+52% de sessions</strong> dans le scénario recommandé. La conversion devrait atteindre <strong>0.41%</strong> avec le plan CRO complet. Revenue forecast M+6 : <strong>+5 920€/mois</strong>. Confiance IA : 74% (basée sur 8 mois de données).",
            ['Voir le plan recommandé', 'Simuler un scénario', 'Rapport prévision'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
            <div style="font-size:24px">🔮</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Forecasting Lab — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Prévisions trafic, conversion, revenue et ranking basées sur l\'IA et vos données historiques.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Trafic M+6 (reco)', '+24%', '16 400 sessions prévues', 'up')}
        \${statCard('Conversion M+6', '0.41%', 'avec plan CRO complet', 'up')}
        \${statCard('Revenue M+6', '5 920€', 'scénario recommandé', 'up')}
        \${statCard('Confiance IA', '74%', 'basé sur 8 mois', 'neutral')}
      </div>

      <!-- TRAFFIC FORECAST CHART -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('trending-up').replace('stroke="currentColor"', 'stroke="#2563EB"')}
            Prévision de trafic — 6 prochains mois
          </div>
          <span style="font-size:11px;color:var(--fp-text-faint)">Scénario recommandé</span>
        </div>
        <div style="display:flex;gap:8px;align-items:flex-end;height:130px;margin-bottom:10px">
          \${fMonths.map((m, i) => \`
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
              <div style="font-size:10px;font-weight:700;color:#2563EB">\${(fTraffic[i]/1000).toFixed(1)}k</div>
              <div style="width:100%;height:\${Math.round(fTraffic[i] / maxF * 110)}px;background:linear-gradient(180deg,rgba(37,99,235,0.7),rgba(37,99,235,0.15));border-radius:6px 6px 0 0;border-top:2px solid #2563EB;position:relative">
                <div style="position:absolute;top:-2px;left:-2px;right:-2px;height:4px;border-radius:4px;background:#2563EB;box-shadow:0 0 10px rgba(37,99,235,0.6)"></div>
              </div>
              <div style="font-size:9px;color:var(--fp-text-faint)">\${m}</div>
            </div>
          \`).join('')}
        </div>
        <div style="display:flex;gap:12px;padding:10px;background:rgba(37,99,235,0.06);border-radius:8px">
          \${[{label:'Conv. prévue',vals:fConv,unit:'%'},{label:'Revenue prévu',vals:fRev,unit:'€'}].map(f => \`
            <div style="flex:1">
              <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:4px">\${f.label}</div>
              <div style="display:flex;gap:4px">
                \${f.vals.map((v, i) => \`<div style="flex:1;text-align:center;font-size:9px;color:\${i===f.vals.length-1?'#22c55e':'var(--fp-text-faint)'};font-weight:\${i===f.vals.length-1?700:400}">\${v}\${f.unit}</div>\`).join('')}
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- SCENARIOS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🎯 Simulation de scénarios — Horizon 6 mois</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${scenarios.map(s => \`
            <div style="display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:10px;border:1px solid \${s.color}30;background:\${s.color}08">
              <div style="width:10px;height:10px;border-radius:50%;background:\${s.color};flex-shrink:0;box-shadow:0 0 8px \${s.color}60"></div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">\${escHtml(s.name)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(s.desc)}</div>
              </div>
              <div style="display:flex;gap:16px;flex-shrink:0">
                \${[{l:'Trafic',v:s.traffic},{l:'Conv.',v:s.conv},{l:'Revenue',v:s.rev}].map(m=>\`
                  <div style="text-align:center">
                    <div style="font-size:14px;font-weight:800;color:\${s.color}">\${m.v}</div>
                    <div style="font-size:9px;color:var(--fp-text-faint)">\${m.l}</div>
                  </div>
                \`).join('')}
              </div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Scénario sélectionné…')">Simuler</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: DATA EXPORT & REPORTING CENTER
  // ══════════════════════════════════════════════════════════
  if (sub === 'export') {
    const reports = [
      { name: 'Rapport SEO Executive — Mai 2026',       type: 'PDF',  size: '2.4 MB', date: 'Aujourd\'hui', brand: true,  auto: true  },
      { name: 'Audits SEO — Données complètes',          type: 'CSV',  size: '34 KB',  date: 'Aujourd\'hui', brand: false, auto: false },
      { name: 'Monitors — Historique uptime Q2',         type: 'CSV',  size: '18 KB',  date: 'Hier',         brand: false, auto: false },
      { name: 'Rapport Client Boulangerie Martin',       type: 'PDF',  size: '1.8 MB', date: '05/05',        brand: true,  auto: false },
      { name: 'Dashboard Data — Export JSON',            type: 'JSON', size: '88 KB',  date: '03/05',        brand: false, auto: false },
      { name: 'Rapport mensuel — Avril 2026',            type: 'PDF',  size: '3.1 MB', date: '01/05',        brand: true,  auto: true  },
    ];
    const scheduled = [
      { name: 'Rapport SEO mensuel',    freq: 'Mensuel · 1er du mois',   dest: 'email',   next: '01/06', active: true  },
      { name: 'Rapport client Dupont',  freq: 'Hebdomadaire · Lundi',    dest: 'email',   next: '13/05', active: true  },
      { name: 'Export données CSV',     freq: 'Quotidien · 8h00',         dest: 'Webhook', next: 'Demain', active: false },
    ];
    return \`
      \${isPro
        ? aiBlock("2 rapports automatisés actifs ce mois. Votre <strong>rapport SEO Executive de mai</strong> est le plus téléchargé. Suggestion : activer l\'export automatique CSV quotidien pour intégrer les données dans votre CRM.",
            ['Créer un rapport', 'Planifier un export', 'Rapport white-label'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">📋</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Exports avancés — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Rapports PDF brandés, exports planifiés, white-label et générateur de rapports client.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Rapports disponibles', String(reports.length), 'dont 3 PDF brandés', 'neutral')}
        \${statCard('Exports planifiés', String(scheduled.filter(s => s.active).length), 'actifs ce mois', 'up')}
        \${statCard('Volume exporté', '6.3 MB', 'ce mois', 'neutral')}
        \${statCard('Rapports white-label', '2', isUltra ? 'actifs' : 'Ultra requis', isUltra ? 'up' : 'neutral')}
      </div>

      <!-- REPORTS LIST -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('file-text').replace('stroke="currentColor"', 'stroke="#06b6d4"')}
            Rapports et exports disponibles
          </div>
          \${isPro ? \`<button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Génération rapport…')">+ Générer</button>\` : ''}
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${reports.map(r => {
            const tc = r.type === 'PDF' ? '#ef4444' : r.type === 'CSV' ? '#22c55e' : '#8b5cf6';
            return \`<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <div style="width:36px;height:36px;border-radius:8px;background:\${tc}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <span style="font-size:10px;font-weight:800;color:\${tc}">\${r.type}</span>
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${escHtml(r.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${r.size} · \${escHtml(r.date)}\${r.brand ? ' · <span style="color:#8b5cf6">White-label</span>' : ''}\${r.auto ? ' · <span style="color:#22c55e">Auto</span>' : ''}</div>
              </div>
              <div style="display:flex;gap:6px;flex-shrink:0">
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','Téléchargement…')">↓ Télécharger</button>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Lien copié !')">Partager</button>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- SCHEDULED REPORTS -->
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">⏰ Rapports planifiés</div>
          \${isPro ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('success','Planification créée !')">+ Planifier</button>\` : ''}
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${scheduled.map(s => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid \${s.active ? 'rgba(34,197,94,0.2)' : 'var(--fp-border)'}">
              <div style="flex:1">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text);margin-bottom:2px">\${escHtml(s.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(s.freq)} · via \${escHtml(s.dest)} · Prochain : \${escHtml(s.next)}</div>
              </div>
              \${badge(s.active ? 'Actif' : 'En pause', s.active ? '#22c55e' : '#64748b')}
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','Configuration ouverte…')">Config.</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Data Command Center
  // ══════════════════════════════════════════════════════════
  const totalEntries = STATE.audits.length + STATE.monitors.length + STATE.missions.length;
  const correlations = [
    { a: 'Vitesse mobile',     b: 'Taux de conversion', strength: 84, dir: 'Positive', color: '#22c55e' },
    { a: 'Trafic Maps',        b: 'Leads qualifiés',    strength: 91, dir: 'Positive', color: '#22c55e' },
    { a: 'Rebond réseaux soc.',b: 'Perte de revenue',   strength: 73, dir: 'Négative', color: '#ef4444' },
  ];
  const patterns = [
    { icon: '📉', title: 'Conversion week-end à 0%',        sev: 'critical', desc: 'Sam 3 mai et dim 4 mai — 0 client converti malgré 1 200 sessions' },
    { icon: '📈', title: 'Pic trafic Maps +21% ce mois',    sev: 'positive', desc: 'Accélération confirmée depuis renforcement GBP avril' },
    { icon: '⚠',  title: 'Taux rebond mobile en hausse +8%',sev: 'warning',  desc: 'Dégradation UX mobile corrélée avec chute conversion mobile' },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Business Intelligence Hub
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.3);border-radius:20px;color:#06b6d4">AI-POWERED</span>
        </h1>
        <div class="fp-section-sub">Plateforme d'intelligence business · \${totalEntries} entrées de données · \${trafficSources.reduce((s,t)=>s+t.sessions,0).toLocaleString('fr-FR')} sessions analysées</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Rapport complet', 'fp-btn fp-btn-primary fp-btn-sm', 'download', "onclick=\\"showToast('info','Génération rapport…')\\"" )}
        \${btn('Nouvel export',   'fp-btn fp-btn-ghost fp-btn-sm',   'share-2',  "onclick=\\"showToast('info','Export…')\\"" )}
      </div>
    </div>

    <!-- AI DATA INTELLIGENCE -->
    \${isUltra
      ? aiBlock("3 patterns critiques détectés cette semaine. <strong>Corrélation forte (91%)</strong> entre trafic Maps et leads qualifiés — renforcer GBP est la priorité absolue. La conversion week-end à 0% représente <strong>-23% du potentiel mensuel</strong>. Trafic organique en accélération : +130% en 8 mois.",
          ['Rapport IA complet', 'Prioriser les actions', 'Simuler un scénario'])
      : \`<div style="background:linear-gradient(135deg,rgba(6,182,212,0.07),rgba(37,99,235,0.06));border:1px solid rgba(6,182,212,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
          <div style="font-size:24px">🧠</div>
          <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">IA Business Intelligence — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Insights stratégiques automatiques, corrélations inter-métriques, anomalies et prévisions business.</div></div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
        </div>\`
    }

    <!-- KPI STAT ROW -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Entrées de données', String(totalEntries), 'multi-sources', 'neutral')}
      \${statCard('Sessions analysées', '12 640', '+18% vs M-1', 'up')}
      \${statCard('Insights IA générés', '6', 'cette semaine', 'neutral')}
      \${statCard('Score business global', '68/100', '+4 pts ce mois', 'up')}
    </div>

    <!-- 7 SCORE GAUGES -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('activity').replace('stroke="currentColor"', 'stroke="#06b6d4"')}
          Executive KPI Dashboard — 7 indicateurs IA
        </div>
        <span style="font-size:11px;color:var(--fp-text-faint)">Moy. globale : <strong style="color:#2563EB">66/100</strong></span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
        \${kpiScores.map(k => {
          const filled = k.val / 100 * circ46;
          return \`<div style="padding:14px;border-radius:12px;border:1px solid \${k.color}28;background:\${k.color}07;text-align:center">
            <svg width="64" height="64" viewBox="0 0 64 64" style="margin:0 auto 6px">
              <circle cx="32" cy="32" r="24" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="7"/>
              <circle cx="32" cy="32" r="24" fill="none" stroke="\${k.color}" stroke-width="7"
                stroke-dasharray="\${filled.toFixed(1)} \${(circ46-filled).toFixed(1)}"
                stroke-dashoffset="\${(circ46*0.25).toFixed(1)}"
                stroke-linecap="round" transform="rotate(-90 32 32)"/>
              <text x="32" y="36" text-anchor="middle" font-size="13" font-weight="800" fill="\${k.color}">\${k.val}</text>
            </svg>
            <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${k.icon} \${escHtml(k.label)}</div>
            <div style="margin-top:6px">\${badge(k.val>=70?'Bon':k.val>=50?'Moyen':'Critique', k.color)}</div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- TRAFFIC OVERVIEW + CORRELATIONS -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('pie-chart').replace('stroke="currentColor"', 'stroke="#2563EB"')}
            Sources de trafic — Répartition
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('traffic')">Analyse →</button>
        </div>
        \${trafficSources.slice(0,6).map(s => \`
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:7px">
            <div style="width:8px;height:8px;border-radius:50%;background:\${s.color};flex-shrink:0"></div>
            <span style="font-size:11px;color:var(--fp-text-muted);min-width:120px">\${escHtml(s.src)}</span>
            <div class="fp-progress-track" style="flex:1;height:5px">
              <div class="fp-progress-fill" style="width:\${s.pct}%;background:\${s.color}"></div>
            </div>
            <span style="font-size:11px;font-weight:700;color:\${s.color};min-width:28px;text-align:right">\${s.pct}%</span>
          </div>
        \`).join('')}
      </div>

      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('link-2').replace('stroke="currentColor"', 'stroke="#8b5cf6"')}
            Corrélations IA inter-métriques
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('insights')">IA Insights →</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
          \${correlations.map(c => \`
            <div style="padding:12px 14px;border-radius:10px;border:1px solid \${c.color}28;background:\${c.color}06">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
                <div style="font-size:11px;color:var(--fp-text-soft)"><strong>\${escHtml(c.a)}</strong> ↔ <strong>\${escHtml(c.b)}</strong></div>
                <span style="font-size:11px;font-weight:700;color:\${c.color}">\${c.dir}</span>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <div class="fp-progress-track" style="flex:1;height:6px"><div class="fp-progress-fill" style="width:\${c.strength}%;background:\${c.color}"></div></div>
                <span style="font-size:11px;font-weight:800;color:\${c.color}">\${c.strength}%</span>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- AI PATTERNS + QUICK LINKS -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('cpu').replace('stroke="currentColor"', 'stroke="#8b5cf6"')}
            Patterns IA détectés
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('insights')">Tous les insights →</button>
        </div>
        \${patterns.map(p => {
          const pc = p.sev === 'critical' ? '#ef4444' : p.sev === 'positive' ? '#22c55e' : '#f59e0b';
          return \`<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
            <span style="font-size:18px;flex-shrink:0">\${p.icon}</span>
            <div style="flex:1">
              <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:2px">\${escHtml(p.title)}</div>
              <div style="font-size:10px;color:var(--fp-text-muted);line-height:1.4">\${escHtml(p.desc)}</div>
            </div>
            <div style="width:6px;height:6px;border-radius:50%;background:\${pc};flex-shrink:0;margin-top:4px"></div>
          </div>\`;
        }).join('')}
      </div>

      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧩 Navigation rapide</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${[
            { label: 'Traffic Intelligence',   sub: 'traffic',    icon: '🚦', desc: 'Sources, qualité, tendances, mobile vs desktop' },
            { label: 'User Behavior Lab',       sub: 'behavior',   icon: '🧬', desc: 'Flux, segments, engagement, abandons' },
            { label: 'Dashboards custom',       sub: 'dashboards', icon: '📊', desc: 'Widgets, layouts, partage client' },
            { label: 'IA Insights Center',      sub: 'insights',   icon: '🤖', desc: 'Anomalies, recommandations, patterns' },
            { label: 'Forecasting Lab',         sub: 'forecast',   icon: '🔮', desc: 'Prévisions trafic, conversion, revenue' },
            { label: 'Exports & Rapports',      sub: 'export',     icon: '📋', desc: 'PDF, CSV, planification, white-label' },
          ].map(nav => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${nav.sub}')">
              <span style="font-size:16px">\${nav.icon}</span>
              <div style="flex:1">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(nav.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(nav.desc)}</div>
              </div>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--fp-text-faint)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply replacement ──────────────────────────────────────────
src = replaceFunc(src, 'renderDataExplorer', NEW_DE);
writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Data Explorer fully replaced (7 sub-pages).');
