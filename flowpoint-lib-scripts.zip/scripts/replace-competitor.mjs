import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

// ── Helper: replace function by name ──────────────────────────
function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav to 7 sub-pages ──────────────────────────
const OLD_SUBNAV = `'competitor': [{id:null,label:'Comparaison'},{id:'opportunities',label:'Opportunités'},{id:'positioning',label:'Positionnement'}],`;
const NEW_SUBNAV = `'competitor': [{id:null,label:'Command Center'},{id:'overview',label:'Aperçu'},{id:'keywords',label:'Mots-clés'},{id:'content',label:'Contenu'},{id:'backlinks',label:'Backlinks'},{id:'local',label:'Local'},{id:'alerts',label:'Alertes'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated competitor sub-nav (3 → 7 sub-pages)');
} else {
  console.error('SUB-NAV NOT FOUND');
}

// ══════════════════════════════════════════════════════════════
// renderCompetitor() — full 7-sub-page implementation
// ══════════════════════════════════════════════════════════════
const NEW_COMPETITOR = `function renderCompetitor() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd  = plan === 'Standard';
  const isPro  = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  // ── Shared data ────────────────────────────────────────────
  const comps = [
    { name: 'Boulangerie Dupont',   url: 'boulangerie-dupont.fr',  score: 88, speed: 77, reviews: 142, stars: 4.8, local: true,  auth: 52, traffic: 4200, delta: +3, kw: 48, bl: 210, content: 34, threat: 'high'   },
    { name: 'Restaurant Panorama',  url: 'restaurant-panorama.fr', score: 79, speed: 74, reviews: 87,  stars: 4.5, local: true,  auth: 41, traffic: 2800, delta: +1, kw: 32, bl: 140, content: 22, threat: 'medium' },
    { name: 'Plomberie Express IDF',url: 'plomberie-express.fr',   score: 72, speed: 68, reviews: 63,  stars: 4.2, local: false, auth: 35, traffic: 1900, delta:  0, kw: 25, bl: 89,  content: 15, threat: 'medium' },
    { name: 'Pharmacie Saint-Michel',url:'pharmacie-saint-michel.fr',score:58,speed: 55, reviews: 31,  stars: 3.9, local: false, auth: 28, traffic: 980,  delta: -1, kw: 18, bl: 54,  content: 9,  threat: 'low'    },
    { name: 'Auto Garage Rapide',   url: 'garage-rapide-idf.fr',   score: 51, speed: 42, reviews: 24,  stars: 3.6, local: false, auth: 21, traffic: 620,  delta:  0, kw: 12, bl: 31,  content: 6,  threat: 'low'    },
  ];
  const myScore = 74; const mySpeed = 84; const myAuth = 38; const myTraffic = 3200;
  const tc = { high: '#ef4444', medium: '#f59e0b', low: '#22c55e' };
  const tl = { high: 'Menace forte', medium: 'À surveiller', low: 'Faible risque' };

  // ══════════════════════════════════════════════════════════
  // SUB: APERÇU — Competitor Overview
  // ══════════════════════════════════════════════════════════
  if (sub === 'overview') {
    const mktShare = [
      { name: 'Boulangerie Dupont',  share: 28, color: '#ef4444' },
      { name: 'Vous',                share: 22, color: '#2563EB' },
      { name: 'Restaurant Panorama', share: 18, color: '#f59e0b' },
      { name: 'Plomberie Express',   share: 14, color: '#8b5cf6' },
      { name: 'Autres',              share: 18, color: '#334155' },
    ];
    return \`
      \${aiBlock("Le marché devient plus compétitif sur mobile. <strong>Boulangerie Dupont</strong> a accéléré sa croissance locale (+3 pts ce mois). Votre position est solide mais la pression augmente sur les mots-clés transactionnels. Différenciez-vous par la <strong>vitesse mobile</strong> et le <strong>contenu local</strong>.",
        ['Voir les opportunités', 'Rapport concurrentiel', 'Alertes marché'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Leader du marché', 'Boulangerie Dupont', '88/100 SEO — +3 pts', 'down')}
        \${statCard('Votre position', '#2/' + comps.length, 'sur le marché local', 'up')}
        \${statCard('Part de marché est.', '22%', '+2% vs mois dernier', 'up')}
        \${statCard('Menaces actives', comps.filter(c => c.threat === 'high').length, 'concurrents à surveiller', 'neutral')}
      </div>

      <!-- LEADERBOARD -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:16px">
          \${svgIcon('award').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Classement marché — Score de domination global
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${[{name:'Boulangerie Dupont',score:88,delta:+3,pos:1,color:'#ef4444'},
              {name:'Vous (Flowpoint)',  score:myScore,delta:+2,pos:2,color:'#2563EB'},
              {name:'Restaurant Panorama',score:79,delta:+1,pos:3,color:'#f59e0b'},
              {name:'Plomberie Express',score:72,delta:0,pos:4,color:'#8b5cf6'},
              {name:'Pharmacie Saint-Michel',score:58,delta:-1,pos:5,color:'#64748b'}
            ].map(c => {
              const isYou = c.name.startsWith('Vous');
              return \`<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:10px;background:\${isYou?'rgba(37,99,235,0.08)':'rgba(255,255,255,0.02)'};border:1px solid \${isYou?'rgba(37,99,235,0.25)':'var(--fp-border)'}">
                <div style="width:24px;height:24px;border-radius:50%;background:\${c.color}22;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:\${c.color};flex-shrink:0">\${c.pos}</div>
                <div style="flex:1;font-size:13px;font-weight:\${isYou?700:600};color:\${isYou?'var(--fp-accent)':'var(--fp-text)'}">\${escHtml(c.name)}</div>
                <div style="width:180px">
                  <div class="fp-progress-track" style="height:5px"><div class="fp-progress-fill" style="width:\${c.score}%;background:\${c.color}"></div></div>
                </div>
                <div style="font-size:14px;font-weight:800;color:\${c.color};min-width:30px;text-align:right">\${c.score}</div>
                <div style="font-size:11px;font-weight:700;color:\${c.delta>0?'#22c55e':c.delta<0?'#ef4444':'var(--fp-text-faint)'};min-width:40px;text-align:right">\${c.delta>0?'↑+':c.delta<0?'↓':''}\${Math.abs(c.delta)||'—'}</div>
              </div>\`;
            }).join('')}
        </div>
      </div>

      <!-- MARKET SHARE + AUTHORITY -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">Part de marché estimée</div>
          \${mktShare.map(s => \`
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <div style="width:8px;height:8px;border-radius:50%;background:\${s.color};flex-shrink:0"></div>
              <span style="font-size:12px;color:var(--fp-text-soft);min-width:140px">\${escHtml(s.name)}</span>
              <div class="fp-progress-track" style="flex:1;height:6px"><div class="fp-progress-fill" style="width:\${s.share}%;background:\${s.color}"></div></div>
              <span style="font-size:12px;font-weight:700;color:\${s.color};min-width:32px;text-align:right">\${s.share}%</span>
            </div>
          \`).join('')}
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">Autorité de domaine</div>
          \${[{name:'Vous',auth:myAuth,c:'#2563EB'},...comps.slice(0,4).map(c=>({name:c.name.split(' ')[0],auth:c.auth,c:tc[c.threat]}))].map(m=>\`
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <span style="font-size:12px;color:var(--fp-text-soft);min-width:120px">\${escHtml(m.name)}</span>
              <div class="fp-progress-track" style="flex:1;height:5px"><div class="fp-progress-fill" style="width:\${m.auth}%;background:\${m.c}"></div></div>
              <span style="font-size:12px;font-weight:700;color:\${m.c};min-width:24px;text-align:right">\${m.auth}</span>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: KEYWORDS — War Room Mots-clés
  // ══════════════════════════════════════════════════════════
  if (sub === 'keywords') {
    const kwBattle = [
      { kw: 'boulangerie paris',              vol: 1800, yours: 4,  top: { name: 'Dupont', pos: 1 }, gap: -3 },
      { kw: 'boulangerie artisanale paris',   vol: 480,  yours: 2,  top: { name: 'Vous',   pos: 2 }, gap: 0  },
      { kw: 'pain bio livraison',             vol: 320,  yours: 12, top: { name: 'Dupont', pos: 2 }, gap: -10},
      { kw: 'plombier urgence paris',         vol: 2100, yours: 5,  top: { name: 'Plomberie', pos: 3 }, gap: -2},
      { kw: 'restaurant vue panoramique',     vol: 890,  yours: 8,  top: { name: 'Panorama', pos: 1 }, gap: -7},
      { kw: 'traiteur paris 11',              vol: 240,  yours: 3,  top: { name: 'Vous',   pos: 3 }, gap: 0  },
      { kw: 'coiffeur haut de gamme lyon',    vol: 190,  yours: null, top: { name: 'Non positionné', pos: null }, gap: null },
    ];
    const clusters = [
      { name: 'Transactionnel', yours: 45, comp: 68, desc: 'Achats et services', color: '#2563EB' },
      { name: 'Informationnel',  yours: 62, comp: 44, desc: 'Contenu et conseils', color: '#22c55e' },
      { name: 'Local',           yours: 38, comp: 71, desc: 'Géographique', color: '#f59e0b' },
      { name: 'Long-tail',       yours: 29, comp: 52, desc: 'Requêtes spécifiques', color: '#8b5cf6' },
    ];
    return \`
      \${aiBlock("Les concurrents dominent les mots-clés <strong>transactionnels</strong> et <strong>locaux</strong>. Votre avantage : <strong>mots-clés informationnels</strong> (+18 pts d'avance). Opportunité non exploitée : 3 mots-clés locaux à fort volume où aucun concurrent n'est bien optimisé.",
        ['Exploiter les gaps', 'Créer du contenu ciblé', 'Rapport mots-clés'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Mots-clés suivis', kwBattle.length * 8, 'dans le battlefield', 'neutral')}
        \${statCard('Vous en tête', kwBattle.filter(k => k.gap >= 0).length, 'positions gagnées', 'up')}
        \${statCard('Gaps détectés', kwBattle.filter(k => k.gap < -5).length, 'opportunités urgentes', 'down')}
        \${statCard('Volume gagnable', '+4 120', 'recherches/mois', 'up')}
      </div>

      <!-- BATTLEFIELD TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('crosshair').replace('stroke="currentColor"','stroke="#ef4444"')}
          Battlefield des mots-clés
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Mot-clé</th><th>Vol/mois</th><th>Votre position</th><th>Leader</th><th>Écart</th><th>Opportunité</th></tr></thead>
            <tbody>
              \${kwBattle.map(k => {
                const posColor = !k.yours ? '#64748b' : k.yours <= 3 ? '#22c55e' : k.yours <= 7 ? '#f59e0b' : '#ef4444';
                const gapColor = k.gap === null ? '#64748b' : k.gap >= 0 ? '#22c55e' : k.gap >= -3 ? '#f59e0b' : '#ef4444';
                return \`<tr>
                  <td style="font-weight:600">\${escHtml(k.kw)}</td>
                  <td>\${k.vol}</td>
                  <td style="color:\${posColor};font-weight:700">\${k.yours ? '#' + k.yours : '—'}</td>
                  <td style="font-size:11px;color:var(--fp-text-muted)">\${k.top.pos ? '#' + k.top.pos + ' · ' : ''}\${escHtml(k.top.name)}</td>
                  <td style="font-weight:700;color:\${gapColor}">\${k.gap === null ? '—' : k.gap >= 0 ? 'En tête' : k.gap + ' pos.'}</td>
                  <td>\${k.gap !== null && k.gap < 0 ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Optimisation de \${escHtml(k.kw)}…')">Optimiser</button>\` : k.gap === null ? \`<button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Mission créée !')">Cibler</button>\` : '<span style="font-size:11px;color:#22c55e">✓ Bonne position</span>'}</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- SEMANTIC CLUSTERS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('pie-chart').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Domination par cluster sémantique
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
          \${clusters.map(cl => \`
            <div style="padding:14px;border-radius:12px;border:1px solid \${cl.color}33;background:\${cl.color}08">
              <div style="font-size:12px;font-weight:700;color:\${cl.color};margin-bottom:4px">\${cl.name}</div>
              <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:12px">\${cl.desc}</div>
              <div style="display:flex;gap:8px;margin-bottom:6px">
                <div style="flex:1;text-align:center">
                  <div style="font-size:18px;font-weight:800;color:\${cl.yours>cl.comp?'#22c55e':'#ef4444'}">\${cl.yours}</div>
                  <div style="font-size:9px;color:var(--fp-text-faint)">Vous</div>
                </div>
                <div style="flex:1;text-align:center">
                  <div style="font-size:18px;font-weight:800;color:var(--fp-text-muted)">\${cl.comp}</div>
                  <div style="font-size:9px;color:var(--fp-text-faint)">Concurrent</div>
                </div>
              </div>
              <div class="fp-progress-track" style="height:4px;margin-bottom:3px"><div class="fp-progress-fill" style="width:\${cl.yours}%;background:\${cl.color}"></div></div>
              <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${cl.comp}%;background:#334155"></div></div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- VULNERABLE KEYWORDS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🎯 Mots-clés vulnérables des concurrents</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${[
            { kw: 'traiteur livraison paris', comp: 'Boulangerie Dupont', pos: 8,  vol: 290, weakness: 'Contenu faible' },
            { kw: 'depannage plombier nuit',  comp: 'Plomberie Express',  pos: 11, vol: 420, weakness: 'Pas de page locale' },
            { kw: 'restaurant privatisable',  comp: 'Restaurant Panorama',pos: 9,  vol: 180, weakness: 'Vitesse mobile 42/100' },
          ].map(v => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:rgba(34,197,94,0.05);border:1px solid rgba(34,197,94,0.15);border-radius:10px">
              <div style="flex:1">
                <div style="font-size:13px;font-weight:600;color:var(--fp-text);margin-bottom:3px">"\${escHtml(v.kw)}"</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(v.comp)} est en position #\${v.pos} · \${escHtml(v.weakness)}</div>
              </div>
              <div style="text-align:center;flex-shrink:0">
                <div style="font-size:12px;font-weight:700;color:#22c55e">+\${v.vol} rech/mois</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">à capter</div>
              </div>
              <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Mission créée !')">Saisir</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CONTENT — Intelligence Contenu
  // ══════════════════════════════════════════════════════════
  if (sub === 'content') {
    const topics = [
      { topic: 'Guides pratiques locaux',   yours: false, comps: 3, vol: 340, type: 'Informationnel' },
      { topic: 'FAQ service client',         yours: false, comps: 2, vol: 220, type: 'FAQ'            },
      { topic: 'Comparatifs produits',       yours: true,  comps: 4, vol: 180, type: 'Commercial'     },
      { topic: 'Contenu saisonnier',         yours: false, comps: 3, vol: 290, type: 'Saisonnier'     },
      { topic: 'Témoignages vidéo',          yours: false, comps: 1, vol: 110, type: 'Social proof'   },
      { topic: 'Pages quartier par quartier',yours: false, comps: 2, vol: 480, type: 'Local'          },
    ];
    const freq = [
      { name: 'Boulangerie Dupont',  posts: 12, color: '#ef4444' },
      { name: 'Restaurant Panorama', posts: 8,  color: '#f59e0b' },
      { name: 'Vous',                posts: 4,  color: '#2563EB' },
      { name: 'Plomberie Express',   posts: 2,  color: '#8b5cf6' },
    ];
    return \`
      \${aiBlock("Les concurrents publient en moyenne <strong>7 contenus/mois</strong> vs vos 4. Points faibles de leur stratégie : <strong>aucun contenu hyperlocal</strong> par quartier et <strong>FAQ incomplètes</strong>. Créer 3 pages locales + une FAQ structurée peut générer <strong>+540 visites/mois</strong>.",
        ['Plan de contenu IA', 'Créer les pages manquantes', 'Rapport contenu'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Sujets non couverts', topics.filter(t => !t.yours).length, 'vs concurrents', 'down')}
        \${statCard('Volume manquant', '+1 330', 'rech/mois potentielles', 'up')}
        \${statCard('Fréquence pub.', '4/mois', 'vs 7 moy. concurrents', 'neutral')}
        \${statCard('Score qualité', '68/100', 'vs 74 moy. marché', 'neutral')}
      </div>

      <!-- PUBLICATION FREQUENCY -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('edit-3').replace('stroke="currentColor"','stroke="#06b6d4"')}
          Fréquence de publication (contenus/mois)
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${freq.map(f => \`
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:12px;color:var(--fp-text-soft);min-width:140px">\${escHtml(f.name)}</span>
              <div class="fp-progress-track" style="flex:1;height:10px;border-radius:5px">
                <div class="fp-progress-fill" style="width:\${f.posts/14*100}%;background:\${f.color};border-radius:5px"></div>
              </div>
              <span style="font-size:13px;font-weight:800;color:\${f.color};min-width:24px;text-align:right">\${f.posts}</span>
            </div>
          \`).join('')}
          <div style="font-size:11px;color:var(--fp-text-faint);margin-top:4px">Objectif recommandé : <strong style="color:#22c55e">8+ contenus/mois</strong></div>
        </div>
      </div>

      <!-- TOPIC GAPS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('file-text').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Analyse des gaps thématiques
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Sujet</th><th>Type</th><th>Couverts par N concurrents</th><th>Volume potentiel</th><th>Vous</th><th>Action</th></tr></thead>
            <tbody>
              \${topics.map(t => \`<tr>
                <td style="font-weight:600">\${escHtml(t.topic)}</td>
                <td>\${badge(t.type, '#64748b')}</td>
                <td style="text-align:center;color:\${t.comps>=3?'#ef4444':'#f59e0b'}">\${t.comps}/\${comps.length}</td>
                <td style="font-weight:700;color:#22c55e">+\${t.vol}</td>
                <td>\${badge(t.yours?'✓ Couvert':'✗ Manquant', t.yours?'#22c55e':'#ef4444')}</td>
                <td>\${!t.yours ? \`<button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Mission contenu créée !')">Créer</button>\` : '<span style="font-size:10px;color:#22c55e">OK</span>'}</td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- CONTENT QUALITY SCORING -->
      \${isPro ? \`
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">Score qualité du contenu</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${[
            { dim: 'Profondeur sémantique',  you: 68, comp: 74 },
            { dim: 'Optimisation locale',     you: 42, comp: 61 },
            { dim: 'Structuration HTML',      you: 78, comp: 65 },
            { dim: 'Fraîcheur du contenu',    you: 55, comp: 72 },
            { dim: 'Engagement estimé',       you: 61, comp: 68 },
          ].map(d => \`
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:11px;color:var(--fp-text-muted);min-width:160px">\${d.dim}</span>
              <div style="flex:1;display:flex;flex-direction:column;gap:3px">
                <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${d.you}%;background:#2563EB"></div></div>
                <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${d.comp}%;background:#ef444466"></div></div>
              </div>
              <span style="font-size:11px;font-weight:700;color:\${d.you>d.comp?'#22c55e':'#ef4444'};min-width:32px;text-align:right">\${d.you>d.comp?'+':''}\${d.you-d.comp}</span>
            </div>
          \`).join('')}
          <div style="display:flex;gap:16px;font-size:10px;color:var(--fp-text-faint);margin-top:4px">
            <span>▬ <span style="color:#2563EB">Vous</span></span>
            <span>▬ <span style="color:#ef4444">Moy. concurrents</span></span>
          </div>
        </div>
      </div>
      \` : \`<div class="fp-upsell-banner fp-upsell-banner--blue"><div class="fp-upsell-text"><strong>Analyse qualité contenu</strong> disponible en Pro</div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`}
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: BACKLINKS — Intelligence Backlinks
  // ══════════════════════════════════════════════════════════
  if (sub === 'backlinks') {
    const blData = [
      { name: 'Vous',               auth: 38, bl: 127, rd: 48, gained: +12, lost: -2,  trend: 'up'   },
      { name: 'Boulangerie Dupont', auth: 52, bl: 210, rd: 81, gained: +28, lost: -3,  trend: 'up'   },
      { name: 'Plomberie Express',  auth: 35, bl: 89,  rd: 34, gained: +4,  lost: -8,  trend: 'down' },
      { name: 'Panorama',           auth: 41, bl: 140, rd: 55, gained: +9,  lost: -1,  trend: 'up'   },
    ];
    const linkOpps = [
      { site: 'pagesjaunes.fr',         da: 72, type: 'Annuaire', effort: '10 min', gained: false },
      { site: 'mairie-paris.fr',         da: 88, type: 'Local public', effort: '1h', gained: false },
      { site: 'chambre-commerce-idf.fr', da: 61, type: 'Pro',   effort: '30 min', gained: false },
      { site: 'yelp.fr',                 da: 68, type: 'Avis',   effort: '15 min', gained: true  },
    ];
    return \`
      \${aiBlock("L'autorité de <strong>Boulangerie Dupont</strong> croît via des domaines locaux à fort DA (mairies, associations). Vous avez <strong>4 opportunités faciles de backlinks</strong> non exploitées (+14 DA potentiel). 2 backlinks perdus ce mois à récupérer en priorité.",
        ['Voir les opportunités', 'Rapport backlinks', 'Alertes nouveaux liens'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Vos backlinks', '127', '+12 ce mois', 'up')}
        \${statCard('Domaines référents', '48', 'vs 81 leader', 'neutral')}
        \${statCard('Backlinks perdus', '2', 'ce mois', 'down')}
        \${statCard('Opportunités liens', linkOpps.filter(l => !l.gained).length, 'à exploiter', 'up')}
      </div>

      <!-- AUTHORITY + BL COMPARISON -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('link').replace('stroke="currentColor"','stroke="#06b6d4"')}
          Comparaison backlinks & autorité
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Site</th><th>Autorité (DA)</th><th>Backlinks</th><th>Domaines réf.</th><th>Gagnés/mois</th><th>Perdus/mois</th><th>Tendance</th></tr></thead>
            <tbody>
              \${blData.map((b, idx) => {
                const isYou = idx === 0;
                return \`<tr style="\${isYou?'background:rgba(37,99,235,0.06);':''}">
                  <td><strong style="\${isYou?'color:var(--fp-accent)':''}">\${isYou?'🎯 ':''}\${escHtml(b.name)}</strong></td>
                  <td style="font-weight:700;color:\${b.auth>=50?'#22c55e':b.auth>=35?'#f59e0b':'#ef4444'}">\${b.auth}</td>
                  <td>\${b.bl}</td>
                  <td>\${b.rd}</td>
                  <td style="color:#22c55e;font-weight:600">+\${b.gained}</td>
                  <td style="color:#ef4444;font-weight:600">\${b.lost}</td>
                  <td>\${badge(b.trend==='up'?'↑ Croissance':'↓ Perte', b.trend==='up'?'#22c55e':'#ef4444')}</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- LINK OPPORTUNITIES + VELOCITY -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🔗 Opportunités de liens détectées</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${linkOpps.map(l => \`
              <div style="display:flex;align-items:center;gap:10px;padding:10px;border-radius:8px;background:\${l.gained?'rgba(34,197,94,0.05)':'rgba(37,99,235,0.05)'};border:1px solid \${l.gained?'rgba(34,197,94,0.15)':'rgba(37,99,235,0.15)'}">
                <div style="flex:1">
                  <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(l.site)}</div>
                  <div style="font-size:10px;color:var(--fp-text-faint)">\${l.type} · DA \${l.da} · \${l.effort}</div>
                </div>
                \${l.gained
                  ? \`<span style="font-size:11px;color:#22c55e;font-weight:600">✓ Obtenu</span>\`
                  : \`<button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Demande de lien envoyée…')">Obtenir</button>\`
                }
              </div>
            \`).join('')}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📈 Vélocité d'acquisition (mois récents)</div>
          <div style="display:flex;gap:6px;align-items:flex-end;height:100px;padding-bottom:4px;margin-bottom:10px">
            \${[{m:'Jan',v:3},{m:'Fév',v:5},{m:'Mar',v:4},{m:'Avr',v:8},{m:'Mai',v:12}].map(m=>\`
              <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
                <div style="font-size:10px;font-weight:700;color:#2563EB">\${m.v}</div>
                <div style="width:100%;max-width:40px;height:\${Math.round(m.v/12*80)}px;background:linear-gradient(180deg,rgba(37,99,235,0.5),rgba(37,99,235,0.1));border-radius:4px 4px 0 0;border-top:2px solid #2563EB"></div>
                <div style="font-size:9px;color:var(--fp-text-faint)">\${m.m}</div>
              </div>
            \`).join('')}
          </div>
          <div style="padding:10px;background:rgba(37,99,235,0.06);border-radius:8px;font-size:12px;color:var(--fp-accent)">
            📈 Croissance +62% ce mois — meilleur mois depuis 6 mois
          </div>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: LOCAL — Carte de concurrence locale
  // ══════════════════════════════════════════════════════════
  if (sub === 'local') {
    const localComp = [
      { city: 'Paris Centre',    yours: 2,  comp1: 1,  comp2: 4,  gbp: 4.4, compGbp: 4.8, reviews: 47,  compReviews: 142, cov: 74 },
      { city: 'Lyon 1-4',        yours: 1,  comp1: 3,  comp2: 6,  gbp: 4.4, compGbp: 4.6, reviews: 47,  compReviews: 87,  cov: 88 },
      { city: 'Bordeaux Centre', yours: 6,  comp1: 2,  comp2: 5,  gbp: 4.4, compGbp: 4.9, reviews: 47,  compReviews: 201, cov: 42 },
      { city: 'Liège Centre',    yours: 4,  comp1: 7,  comp2: 9,  gbp: 4.4, compGbp: 4.2, reviews: 47,  compReviews: 63,  cov: 67 },
      { city: 'Marseille 1-6',   yours: 9,  comp1: 3,  comp2: 7,  gbp: 4.4, compGbp: 4.7, reviews: 47,  compReviews: 89,  cov: 31 },
    ];
    return \`
      \${aiBlock("Vous dominez la zone <strong>Paris Centre et Lyon 1-4</strong> mais restez faibles sur <strong>Bordeaux et Marseille</strong>. Vos concurrents gagnent de la visibilité via une <strong>activité d'avis plus forte</strong> (+3x vos avis sur Bordeaux). Opportunité : renforcer GBP sur 3 zones.",
        ['Plan domination locale', 'Renforcer GBP', 'Comparer les zones'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Zones où vous gagnez', localComp.filter(z => z.yours <= z.comp1).length + '/' + localComp.length, 'vs meilleur concurrent', 'up')}
        \${statCard('Note GBP moy.', '4.4★', 'vs 4.6 concurrents', 'neutral')}
        \${statCard('Avis total', '47', 'vs 116 moy. concurrents', 'down')}
        \${statCard('Avantage zones', localComp.filter(z => z.yours < z.comp1).length, 'territoires dominés', 'up')}
      </div>

      <!-- LOCAL MAP SVG -->
      <div class="fp-card fp-mb-20" style="padding:18px 20px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('map').replace('stroke="currentColor"','stroke="#2563EB"')}
            Carte de domination territoriale — Vous vs Concurrents
          </div>
        </div>
        <div style="position:relative;width:100%;height:220px;background:linear-gradient(135deg,#050810,#0a1628);border-radius:12px;overflow:hidden;border:1px solid var(--fp-border)">
          <svg width="100%" height="100%" style="position:absolute;inset:0;opacity:0.15">
            <defs><pattern id="cg" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M 28 0 L 0 0 0 28" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="0.5"/></pattern></defs>
            <rect width="100%" height="100%" fill="url(#cg)"/>
          </svg>
          <svg width="100%" height="100%" style="position:absolute;inset:0">
            <defs>
              <radialGradient id="cz1" cx="50%" cy="50%"><stop offset="0%" stop-color="#2563EB" stop-opacity="0.6"/><stop offset="100%" stop-color="#2563EB" stop-opacity="0"/></radialGradient>
              <radialGradient id="cz2" cx="50%" cy="50%"><stop offset="0%" stop-color="#22c55e" stop-opacity="0.55"/><stop offset="100%" stop-color="#22c55e" stop-opacity="0"/></radialGradient>
              <radialGradient id="cz3" cx="50%" cy="50%"><stop offset="0%" stop-color="#ef4444" stop-opacity="0.5"/><stop offset="100%" stop-color="#ef4444" stop-opacity="0"/></radialGradient>
              <radialGradient id="cz4" cx="50%" cy="50%"><stop offset="0%" stop-color="#f59e0b" stop-opacity="0.4"/><stop offset="100%" stop-color="#f59e0b" stop-opacity="0"/></radialGradient>
              <radialGradient id="cz5" cx="50%" cy="50%"><stop offset="0%" stop-color="#ef4444" stop-opacity="0.35"/><stop offset="100%" stop-color="#ef4444" stop-opacity="0"/></radialGradient>
            </defs>
            <!-- You dominate -->
            <ellipse cx="35%" cy="40%" rx="85" ry="65" fill="url(#cz1)"/>
            <ellipse cx="60%" cy="33%" rx="75" ry="55" fill="url(#cz2)"/>
            <!-- Competitor territory -->
            <ellipse cx="72%" cy="62%" rx="65" ry="50" fill="url(#cz3)"/>
            <ellipse cx="20%" cy="68%" rx="55" ry="42" fill="url(#cz4)"/>
            <ellipse cx="52%" cy="72%" rx="45" ry="35" fill="url(#cz5)"/>
            <!-- You marker -->
            <circle cx="35%" cy="40%" r="6" fill="#2563EB" opacity="0.9"/>
            <circle cx="35%" cy="40%" r="12" fill="none" stroke="#2563EB" stroke-width="1.5" opacity="0.5"/>
            <!-- Competitor markers -->
            <circle cx="72%" cy="62%" r="5" fill="#ef4444" opacity="0.9"/>
            <circle cx="20%" cy="68%" r="5" fill="#f59e0b" opacity="0.9"/>
            <circle cx="52%" cy="72%" r="4" fill="#ef4444" opacity="0.7"/>
            <circle cx="60%" cy="33%" r="5" fill="#22c55e" opacity="0.9"/>
          </svg>
          <div style="position:absolute;top:8px;left:12px;font-size:10px;color:var(--fp-text-faint)">Zones de domination locale</div>
          <div style="position:absolute;bottom:8px;left:12px;display:flex;gap:10px">
            <span style="font-size:10px;color:var(--fp-text-faint);display:flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:#2563EB;display:inline-block"></span>Vous</span>
            <span style="font-size:10px;color:var(--fp-text-faint);display:flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:#22c55e;display:inline-block"></span>Zones gagnées</span>
            <span style="font-size:10px;color:var(--fp-text-faint);display:flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block"></span>Zones perdues</span>
          </div>
        </div>
      </div>

      <!-- CITY BY CITY TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">Analyse ville par ville</div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Zone</th><th>Votre pos.</th><th>Meilleur concurrent</th><th>Note GBP</th><th>Avis (vous/eux)</th><th>Couverture</th><th>Statut</th></tr></thead>
            <tbody>
              \${localComp.map(z => {
                const winning = z.yours < z.comp1;
                return \`<tr>
                  <td style="font-weight:600">\${escHtml(z.city)}</td>
                  <td style="font-weight:700;color:\${z.yours<=3?'#22c55e':z.yours<=7?'#f59e0b':'#ef4444'}">#\${z.yours}</td>
                  <td style="color:var(--fp-text-muted)">#\${z.comp1} / #\${z.comp2}</td>
                  <td><span style="color:#f59e0b">\${z.gbp}★</span> <span style="color:var(--fp-text-faint);font-size:10px">vs \${z.compGbp}★</span></td>
                  <td style="font-size:11px">\${z.reviews} <span style="color:var(--fp-text-faint)">/ \${z.compReviews}</span></td>
                  <td><div class="fp-progress-track" style="height:5px;width:80px;display:inline-block"><div class="fp-progress-fill" style="width:\${z.cov}%;background:\${z.cov>=70?'#22c55e':z.cov>=40?'#f59e0b':'#ef4444'}"></div></div> <span style="font-size:10px;color:var(--fp-text-faint)">\${z.cov}%</span></td>
                  <td>\${badge(winning?'Vous gagnez':'Concurrent devant', winning?'#22c55e':'#ef4444')}</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ALERTS — Centre d'Alertes Concurrentielles
  // ══════════════════════════════════════════════════════════
  if (sub === 'alerts') {
    const alerts = [
      { type: 'threat',   severity: 'critical', icon: '🚨', comp: 'Boulangerie Dupont',   msg: "Gain de 3 positions sur 'boulangerie paris' — menace directe sur votre top 3",          date: '09/05', read: false },
      { type: 'backlink', severity: 'warning',  icon: '🔗', comp: 'Restaurant Panorama',   msg: "8 nouveaux backlinks depuis mairie-paris.fr — hausse autorité prévisible",               date: '08/05', read: false },
      { type: 'content',  severity: 'info',     icon: '📝', comp: 'Plomberie Express IDF', msg: "3 nouvelles pages locales créées — couverture Paris 13-15 initiée",                     date: '07/05', read: true  },
      { type: 'local',    severity: 'warning',  icon: '📍', comp: 'Boulangerie Dupont',    msg: "GBP renforcé — 14 nouvelles photos, catégorie secondaire traiteur ajoutée",             date: '06/05', read: true  },
      { type: 'ranking',  severity: 'info',     icon: '📈', comp: 'Restaurant Panorama',   msg: "Entrée en Local Pack sur 'restaurant panoramique paris' — visibilité +22%",             date: '05/05', read: true  },
      { type: 'threat',   severity: 'critical', icon: '⚡', comp: 'Nouveau concurrent',    msg: "Nouveau concurrent détecté : cuisine-bistronomique.fr — score 61 en 3 mois",            date: '03/05', read: true  },
    ];
    const sevColor = { critical: '#ef4444', warning: '#f59e0b', info: '#2563EB' };
    const sevLabel = { critical: 'Critique', warning: 'Attention', info: 'Info' };
    const typeIcon = { threat: 'alert-triangle', backlink: 'link', content: 'file-text', local: 'map-pin', ranking: 'trending-up' };
    return \`
      \${isUltra
        ? aiBlock("Détection IA de <strong>2 menaces critiques</strong> ce mois. <strong>Boulangerie Dupont</strong> accélère l'acquisition de backlinks locaux (+180% ce mois). Risque d'entrée en Local Pack sur vos mots-clés principaux dans <strong>4-6 semaines</strong> si aucune action.", ['Plan de défense IA', 'Contre-attaque contenu', 'Renforcer GBP'])
        : \`<div style="padding:14px 16px;background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">🤖</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Analyse IA des menaces — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Détection automatique des menaces, forecasting et recommandations stratégiques.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Alertes actives', alerts.filter(a => !a.read).length, 'non lues', 'down')}
        \${statCard('Menaces critiques', alerts.filter(a => a.severity === 'critical').length, 'ce mois', 'down')}
        \${statCard('Nouveaux concurrents', '1', 'détecté ce mois', 'neutral')}
        \${statCard('Mouvements détectés', alerts.length, '30 derniers jours', 'neutral')}
      </div>

      <!-- ALERT FEED -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('bell').replace('stroke="currentColor"','stroke="#ef4444"')}
            Fil d'alertes concurrentielles
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Toutes les alertes marquées comme lues')">Tout marquer lu</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${alerts.map(a => \`
            <div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:10px;background:\${!a.read?'rgba(255,255,255,0.04)':'rgba(255,255,255,0.01)'};border:1px solid \${!a.read?sevColor[a.severity]+'44':'var(--fp-border)'};border-left-width:\${!a.read?'3px':'1px'}">
              <span style="font-size:20px;flex-shrink:0">\${a.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                  \${badge(sevLabel[a.severity], sevColor[a.severity])}
                  <span style="font-size:11px;font-weight:700;color:var(--fp-text-soft)">\${escHtml(a.comp)}</span>
                  \${!a.read ? \`<span style="width:6px;height:6px;border-radius:50%;background:\${sevColor[a.severity]};display:inline-block"></span>\` : ''}
                </div>
                <div style="font-size:12px;color:var(--fp-text-muted);line-height:1.5">\${escHtml(a.msg)}</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0">
                <span style="font-size:10px;color:var(--fp-text-faint)">\${a.date}</span>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;padding:2px 6px" onclick="showToast('info','Plan de réponse IA généré…')">Répondre</button>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- THREAT SEVERITY SYSTEM -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">⚠️ Système de scoring des menaces</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
          \${comps.slice(0,4).map(c => {
            const threatScore = Math.round(c.score * 0.4 + c.delta * 10 + (c.local ? 15 : 0) + c.bl * 0.1);
            const tsc = threatScore > 50 ? '#ef4444' : threatScore > 35 ? '#f59e0b' : '#22c55e';
            const tsl = threatScore > 50 ? 'Menace forte' : threatScore > 35 ? 'À surveiller' : 'Faible';
            return \`<div style="padding:14px;border-radius:12px;border:1px solid \${tsc}33;background:\${tsc}08;text-align:center">
              <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft);margin-bottom:8px">\${escHtml(c.name.split(' ')[0] + ' ' + (c.name.split(' ')[1]||''))}</div>
              <div style="font-size:28px;font-weight:900;color:\${tsc}">\${threatScore}</div>
              <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:8px">/100</div>
              \${badge(tsl, tsc)}
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Command Center
  // ══════════════════════════════════════════════════════════
  const domScores = [
    { label: 'Domination SEO',    val: 68, color: '#2563EB',  icon: '🔍' },
    { label: 'Domination locale', val: 54, color: '#f59e0b',  icon: '📍' },
    { label: 'Autorité de marché',val: 42, color: '#8b5cf6',  icon: '🏆' },
  ];
  const circ52 = 2 * Math.PI * 46;

  const weaknesses = [
    { comp: 'Plomberie Express IDF', weak: 'Vitesse mobile : 68/100',        opp: '+8% ranking gain' },
    { comp: 'Pharmacie Saint-Michel',weak: 'Pas de GBP optimisé',             opp: '+15% visibilité locale' },
    { comp: 'Boulangerie Dupont',    weak: 'Aucune page locale Paris 13-15',   opp: '+340 rech/mois à capter' },
    { comp: 'Restaurant Panorama',   weak: '0 posts GBP cette semaine',        opp: 'Prendre leur Local Pack' },
  ];

  const oppHijack = [
    { title: 'Paris 13-15 non couvert',       gain: '+340 rech/mois', effort: '2h',    urgency: 'high'   },
    { title: 'Vitesse mobile : avantage +16', gain: 'Ranking supérieur', effort: 'Actif ✓', urgency: 'done' },
    { title: 'Q&A GBP vides chez 2 rivaux',  gain: '+12% engagement', effort: '1h',    urgency: 'medium' },
    { title: 'Schéma markup absent chez eux', gain: '+8% CTR Rich',    effort: '30 min', urgency: 'medium' },
  ];

  const recentMoves = [
    { date: '09/05', icon: '📈', comp: 'Boulangerie Dupont',   msg: "+3 positions sur 'boulangerie paris'",        severity: 'critical' },
    { date: '08/05', icon: '🔗', comp: 'Restaurant Panorama',  msg: "8 nouveaux backlinks — autorité en hausse",   severity: 'warning'  },
    { date: '06/05', icon: '📍', comp: 'Boulangerie Dupont',   msg: "GBP renforcé — 14 photos + catégorie ajoutée", severity: 'warning' },
    { date: '03/05', icon: '⚡', comp: 'Nouveau concurrent',   msg: "cuisine-bistronomique.fr détecté — score 61",  severity: 'info'    },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          War Room Concurrentiel
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);border-radius:20px;color:#ef4444">LIVE</span>
        </h1>
        <div class="fp-section-sub">Centre de commandement IA · Intelligence concurrentielle en temps réel</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Ajouter concurrent', 'fp-btn fp-btn-ghost fp-btn-sm', 'plus', "onclick=\\"showToast('info','Ajout concurrent…')\\"" )}
        \${btn('Rapport complet', 'fp-btn fp-btn-primary fp-btn-sm', 'download', "onclick=\\"showToast('info','Génération rapport…')\\"" )}
      </div>
    </div>

    <!-- AI STRATEGIST -->
    \${isUltra
      ? aiBlock("3 concurrents en <strong>accélération ce mois</strong>. <strong>Boulangerie Dupont</strong> gagne du terrain sur vos mots-clés principaux (+3 positions). Votre avantage défendable : <strong>vitesse mobile +16 pts</strong>. Action recommandée : créer 3 pages locales Paris 13-15 avant qu'un concurrent ne vous devance (délai estimé : 3-4 semaines).", ['Stratégie de défense IA', 'Pages locales prioritaires', 'Plan de contre-attaque'])
      : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
          <div style="font-size:24px">🤖</div>
          <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Stratège IA Concurrentiel — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Plans de bataille, forecasting, alertes menaces en temps réel et recommandations stratégiques personnalisées.</div></div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau vers Ultra…')">Passer Ultra</button>
        </div>\`
    }

    <!-- KPI ROW -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Concurrents suivis', comps.length, '+ 1 nouveau ce mois', 'up')}
      \${statCard('Votre rang marché', '#2/' + comps.length, 'sur l\'ensemble du secteur', 'up')}
      \${statCard('Menaces critiques', comps.filter(c => c.threat === 'high').length, 'à traiter cette semaine', 'down')}
      \${statCard('Opportunités détectées', oppHijack.filter(o => o.urgency !== 'done').length, 'à saisir maintenant', 'neutral')}
    </div>

    <!-- DOMINATION SCORES + RADAR -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- DOMINATION GAUGES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:16px">
          🏆 Scores de domination marché
        </div>
        <div style="display:flex;flex-direction:column;gap:16px">
          \${domScores.map(d => \`
            <div style="display:flex;align-items:center;gap:14px">
              <div style="flex-shrink:0">
                <svg width="64" height="64" viewBox="0 0 64 64">
                  <circle cx="32" cy="32" r="24" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="8"/>
                  <circle cx="32" cy="32" r="24" fill="none" stroke="\${d.color}" stroke-width="8"
                    stroke-dasharray="\${(circ52*d.val/100).toFixed(1)} \${(circ52*(1-d.val/100)).toFixed(1)}"
                    stroke-dashoffset="\${(circ52*0.25).toFixed(1)}"
                    stroke-linecap="round" transform="rotate(-90 32 32)"/>
                  <text x="32" y="37" text-anchor="middle" font-size="13" font-weight="800" fill="var(--fp-text)">\${d.val}</text>
                </svg>
              </div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${d.icon} \${d.label}</div>
                <div class="fp-progress-track" style="height:5px">
                  <div class="fp-progress-fill" style="width:\${d.val}%;background:\${d.color}"></div>
                </div>
                <div style="font-size:10px;color:var(--fp-text-faint);margin-top:4px">Objectif : 80/100 · \${80-d.val > 0 ? '+' + (80-d.val) + ' pts nécessaires' : 'Objectif atteint'}</div>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- RADAR CHART -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">Radar multidimensionnel</div>
        <div style="display:flex;align-items:center;gap:16px">
          <svg width="180" height="180" viewBox="0 0 180 180" style="flex-shrink:0">
            \${[0.2,0.4,0.6,0.8,1].map(s=>\`<polygon points="\${[[90,10],[157,55],[157,135],[90,170],[23,135],[23,55]].map(([x,y])=>[(x-90)*s+90,(y-90)*s+90].join(',')).join(' ')}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>\`).join('')}
            \${[[90,10],[157,55],[157,135],[90,170],[23,135],[23,55]].map(([x,y])=>\`<line x1="90" y1="90" x2="\${x}" y2="\${y}" stroke="rgba(255,255,255,0.05)" stroke-width="1"/>\`).join('')}
            <!-- Competitor avg -->
            <polygon points="90,28 141,62 141,124 90,152 40,124 40,62" fill="rgba(239,68,68,0.12)" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4,2"/>
            <!-- You -->
            <polygon points="90,30 136,66 143,128 90,155 38,128 38,62" fill="rgba(37,99,235,0.2)" stroke="#2563EB" stroke-width="2"/>
            <text x="90" y="5" text-anchor="middle" font-size="9" fill="var(--fp-text-muted)">SEO</text>
            <text x="164" y="57" font-size="9" fill="var(--fp-text-muted)">Backlinks</text>
            <text x="158" y="140" font-size="9" fill="var(--fp-text-muted)">Vitesse</text>
            <text x="90" y="180" text-anchor="middle" font-size="9" fill="var(--fp-text-muted)">Avis GBP</text>
            <text x="0" y="140" font-size="9" fill="var(--fp-text-muted)">Local</text>
            <text x="2" y="57" font-size="9" fill="var(--fp-text-muted)">Contenu</text>
          </svg>
          <div style="flex:1;display:flex;flex-direction:column;gap:8px">
            \${[
              { label: 'Score SEO',    you: 74, comp: 68 },
              { label: 'Backlinks',    you: 48, comp: 70 },
              { label: 'Vitesse mob.', you: 84, comp: 63 },
              { label: 'Note GBP',     you: 44, comp: 45 },
              { label: 'Local SEO',    you: 54, comp: 62 },
              { label: 'Contenu',      you: 62, comp: 56 },
            ].map(m=>\`
              <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:10px;color:var(--fp-text-muted);min-width:70px">\${m.label}</span>
                <div style="flex:1;display:flex;flex-direction:column;gap:2px">
                  <div class="fp-progress-track" style="height:3px"><div class="fp-progress-fill" style="width:\${m.you}%;background:#2563EB"></div></div>
                  <div class="fp-progress-track" style="height:3px"><div class="fp-progress-fill" style="width:\${m.comp}%;background:#ef444466"></div></div>
                </div>
                <span style="font-size:10px;font-weight:700;color:\${m.you>m.comp?'#22c55e':'#ef4444'};min-width:28px;text-align:right">\${m.you>m.comp?'+':''}\${m.you-m.comp}</span>
              </div>
            \`).join('')}
            <div style="display:flex;gap:12px;font-size:9px;color:var(--fp-text-faint);margin-top:4px">
              <span>▬ <span style="color:#2563EB">Vous</span></span>
              <span>▬ <span style="color:#ef4444">Moy. concurrents</span></span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- COMPETITOR CARDS -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('eye').replace('stroke="currentColor"','stroke="#ef4444"')}
          Surveillance temps réel — \${comps.length} concurrents
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('overview')">Leaderboard complet →</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        \${comps.map(c => {
          const dc = c.delta > 0 ? '#ef4444' : c.delta < 0 ? '#22c55e' : 'var(--fp-text-faint)';
          const ds = c.delta > 0 ? '↑ +' + c.delta + ' pts (menace)' : c.delta < 0 ? '↓ ' + Math.abs(c.delta) + ' pts (vous montez)' : '→ Stable';
          return \`<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border:1px solid var(--fp-border);border-radius:10px;background:rgba(255,255,255,0.02)">
            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
                <span style="font-size:13px;font-weight:600;color:var(--fp-text)">\${escHtml(c.name)}</span>
                \${badge(tl[c.threat], tc[c.threat])}
              </div>
              <div style="font-size:10px;color:var(--fp-text-faint);font-family:monospace">\${c.url}</div>
            </div>
            <div style="display:flex;gap:16px;align-items:center;flex-shrink:0">
              <div style="text-align:center">
                <div style="font-size:16px;font-weight:800;color:\${scoreColor(c.score)}">\${c.score}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">SEO</div>
              </div>
              <div style="text-align:center">
                <div style="font-size:16px;font-weight:800;color:\${c.speed>=80?'#22c55e':c.speed>=65?'#f59e0b':'#ef4444'}">\${c.speed}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">Speed</div>
              </div>
              <div style="text-align:center">
                <div style="font-size:16px;font-weight:800">\${c.reviews}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">Avis</div>
              </div>
              <div style="font-size:11px;font-weight:700;color:\${dc};min-width:130px;text-align:right">\${ds}</div>
            </div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Analyse de \${escHtml(c.name)}…')">Analyser</button>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- WEAKNESSES + OPPORTUNITIES -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- WEAKNESS DETECTION -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:12px">
          \${svgIcon('alert-triangle').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Failles détectées chez les concurrents
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${weaknesses.map(w => \`
            <div style="padding:10px 12px;background:rgba(34,197,94,0.05);border:1px solid rgba(34,197,94,0.15);border-radius:8px">
              <div style="font-size:11px;font-weight:700;color:var(--fp-text-soft);margin-bottom:2px">\${escHtml(w.comp)}</div>
              <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:4px">⚠ \${escHtml(w.weak)}</div>
              <div style="font-size:11px;font-weight:700;color:#22c55e">→ \${escHtml(w.opp)}</div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- OPPORTUNITY HIJACK + RECENT MOVES -->
      <div style="display:flex;flex-direction:column;gap:14px">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:12px">
            \${svgIcon('zap').replace('stroke="currentColor"','stroke="#22c55e"')}
            Moteur d'opportunités à saisir
          </div>
          <div style="display:flex;flex-direction:column;gap:6px">
            \${oppHijack.map(o => {
              const oc = o.urgency === 'high' ? '#ef4444' : o.urgency === 'medium' ? '#f59e0b' : '#22c55e';
              return \`<div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:\${o.urgency==='done'?'rgba(34,197,94,0.05)':'rgba(255,255,255,0.02)'}">
                <div style="width:6px;height:6px;border-radius:50%;background:\${oc};flex-shrink:0"></div>
                <div style="flex:1;font-size:12px;color:var(--fp-text-soft)">\${escHtml(o.title)}</div>
                <div style="text-align:right;flex-shrink:0">
                  <div style="font-size:11px;font-weight:700;color:#22c55e">\${escHtml(o.gain)}</div>
                  <div style="font-size:9px;color:var(--fp-text-faint)">\${escHtml(o.effort)}</div>
                </div>
              </div>\`;
            }).join('')}
          </div>
        </div>

        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:10px">
            \${svgIcon('activity').replace('stroke="currentColor"','stroke="#ef4444"')}
            Mouvements récents
          </div>
          \${recentMoves.map(m => \`
            <div style="display:flex;align-items:flex-start;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
              <span style="font-size:16px;flex-shrink:0">\${m.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${escHtml(m.comp)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.4">\${escHtml(m.msg)}</div>
              </div>
              <span style="font-size:10px;color:var(--fp-text-faint);flex-shrink:0">\${m.date}</span>
            </div>
          \`).join('')}
          <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:10px" onclick="navigateSub('alerts')">Voir toutes les alertes →</button>
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply replacement ──────────────────────────────────────────
src = replaceFunc(src, 'renderCompetitor', NEW_COMPETITOR);

writeFileSync(file, src, 'utf8');
console.log('\n✅ Competitor section fully replaced (7 sub-pages).');
