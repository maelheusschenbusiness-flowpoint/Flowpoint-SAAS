import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 3 → 8 sub-pages ───────────────────────
const OLD_SUBNAV = `'client-mode':   [{id:null,label:'Vue client'},{id:'presentations',label:'Présentations'},{id:'shares',label:'Partages'}],`;
const NEW_SUBNAV = `'client-mode':   [{id:null,label:'Command Center'},{id:'dashboards',label:'Dashboards'},{id:'reporting',label:'Reporting'},{id:'communication',label:'Communication'},{id:'onboarding',label:'Onboarding'},{id:'projects',label:'Projets'},{id:'analytics',label:'Analytics'},{id:'agency',label:'Agency Lab'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated client-mode sub-nav (3 \u2192 8)');
} else { console.error('SUB-NAV NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderClientMode() — full 8-sub-page AI client platform
// ══════════════════════════════════════════════════════════════
const NEW_CLIENT = `function renderClientMode() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';
  const avg = avgScore();
  const me  = STATE.me;

  // ── Shared client data ────────────────────────────────────
  const clients = [
    { id:'bm', name:"Boulangerie Martin",      avatar:"BM", color:"#22c55e", seoScore:82, uptime:99.98, engagement:92, satisfaction:96, lastActivity:"Il y a 2h",    health:'excellent', trend:'+4pts', risk:'Faible',   tags:['Local SEO','GBP','Rapports'] },
    { id:'rs', name:"Restaurant Le Soleil",     avatar:"RS", color:"#f59e0b", seoScore:67, uptime:98.72, engagement:61, satisfaction:74, lastActivity:"Il y a 3j",    health:'attention', trend:'-2pts', risk:'Moyen',    tags:['Monitor','Avis','Urgence']   },
    { id:'cl', name:"Coiffeur Lyon",            avatar:"CL", color:"#ef4444", seoScore:44, uptime:99.12, engagement:43, satisfaction:58, lastActivity:"Il y a 1sem.", health:'critique',  trend:'-8pts', risk:'Élevé',    tags:['Perf','SEO Critique']        },
    { id:'pp', name:"Plombier Paris",           avatar:"PP", color:"#2563EB", seoScore:71, uptime:99.91, engagement:78, satisfaction:82, lastActivity:"Il y a 1j",    health:'bon',       trend:'+6pts', risk:'Faible',   tags:['Croissance','Rankings']      },
  ];

  const healthColor = { excellent:'#22c55e', bon:'#2563EB', attention:'#f59e0b', critique:'#ef4444' };
  const healthLabel = { excellent:'Excellent', bon:'Bon', attention:'Attention', critique:'Critique' };

  // ══════════════════════════════════════════════════════════
  // SUB: DASHBOARDS CLIENT
  // ══════════════════════════════════════════════════════════
  if (sub === 'dashboards') {
    const circ46 = 2 * Math.PI * 46;
    const siteScores = STATE.audits.slice(0, 5).map(a => ({
      name: a.url.replace('https://',''),
      score: a.score,
      trend: [+4, -2, +1, +6, +3][STATE.audits.indexOf(a)] || 0,
    }));
    return \`
      \${aiBlock("Tableau de bord client simplifié. <strong>Score moyen : " + avg + "/100</strong> (+7 pts ce mois). Boulangerie Martin en tête à 82/100. Restaurant Le Soleil nécessite attention : monitor instable + 14 avis sans réponse.",
        ['Générer un rapport client', 'Envoyer une mise à jour', 'Planifier une réunion'])}

      <!-- EXECUTIVE KPI -->
      <div class="fp-stat-row fp-mb-20">
        \${statCard('Score SEO moyen', avg + '/100', '+7 pts ce mois', 'up')}
        \${statCard('Disponibilité', '99.1%', 'SLA tenu — 5 monitors', 'up')}
        \${statCard('Missions', STATE.missions.filter(m=>m.status==='done').length + '/' + STATE.missions.length, 'complétées ce mois', 'up')}
        \${statCard('Note Google', '4.4 ⭐', '+0.2 vs M-1', 'up')}
      </div>

      <!-- SITE SCORES + ACHIEVEMENTS -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📊 Performance par site — Mai 2026</div>
          \${siteScores.map(s => {
            const sc = scoreColor(s.score);
            const dc = s.trend > 0 ? '#22c55e' : s.trend < 0 ? '#ef4444' : 'var(--fp-text-faint)';
            return \`<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
                  <span style="font-size:11px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${escHtml(s.name)}</span>
                  <span style="font-size:10px;font-weight:700;color:\${dc};flex-shrink:0;margin-left:6px">\${s.trend > 0 ? '+' : ''}\${s.trend}pts</span>
                </div>
                <div class="fp-progress-track" style="height:6px"><div class="fp-progress-fill" style="width:\${s.score}%;background:\${sc}"></div></div>
              </div>
              <div style="font-size:14px;font-weight:800;color:\${sc};min-width:36px;text-align:right">\${s.score}</div>
            </div>\`;
          }).join('')}
        </div>

        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">✅ Réalisations du mois</div>
          \${[
            { ok:true,  warn:false, info:false, text:"3 audits SEO complets réalisés"           },
            { ok:true,  warn:false, info:false, text:"6 monitors configurés — uptime 99.1%"      },
            { ok:true,  warn:false, info:false, text:"2 rapports clients générés et partagés"    },
            { ok:true,  warn:false, info:false, text:"Score moyen augmenté de +7 pts"            },
            { ok:false, warn:true,  info:false, text:"14 avis Google en attente de réponse"      },
            { ok:false, warn:false, info:true,  text:"4 missions en cours de traitement"         },
          ].map(r => {
            const ic = r.warn ? '#f59e0b' : r.info ? '#2563EB' : '#22c55e';
            const path = r.warn
              ? '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'
              : r.info
                ? '<polyline points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>'
                : '<polyline points="20 6 9 17 4 12"/>';
            return \`<div style="font-size:12px;padding:8px 0;border-bottom:1px solid var(--fp-border);display:flex;align-items:center;gap:8px">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="\${ic}" stroke-width="2.5">\${path}</svg>
              \${escHtml(r.text)}
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- CLIENT HEALTH OVERVIEW -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🏥 Santé des clients — Vue d\'ensemble</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
          \${clients.map(c => {
            const hc = healthColor[c.health];
            return \`<div style="padding:14px;border-radius:12px;border:1px solid \${hc}28;background:\${hc}07">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
                <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,\${hc},\${hc}88);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff;flex-shrink:0">\${c.avatar}</div>
                <div style="flex:1;min-width:0">
                  <div style="font-size:12px;font-weight:700;color:var(--fp-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${escHtml(c.name)}</div>
                  \${badge(healthLabel[c.health], hc)}
                </div>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between">
                <div style="font-size:18px;font-weight:800;color:\${hc}">\${c.seoScore}<span style="font-size:10px;color:var(--fp-text-faint)">/100</span></div>
                <div style="font-size:11px;font-weight:700;color:\${c.trend.startsWith('+') ? '#22c55e' : '#ef4444'}">\${escHtml(c.trend)}</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: REPORTING CENTER
  // ══════════════════════════════════════════════════════════
  if (sub === 'reporting') {
    const reports = [
      { name:"Rapport Executive Mai 2026",        client:"Boulangerie Martin",   type:'PDF',  date:"09/05", views:4,  shared:true,  status:'Partagé',    color:'#22c55e' },
      { name:"Rapport SEO local — Plombier Paris",client:"Plombier Paris",       type:'PDF',  date:"07/05", views:2,  shared:true,  status:'Lu',         color:'#2563EB' },
      { name:"Rapport mensuel — Restaurant",      client:"Restaurant Le Soleil", type:'PDF',  date:"05/05", views:1,  shared:false, status:'Non lu',     color:'#f59e0b' },
      { name:"Export données — Coiffeur Lyon",    client:"Coiffeur Lyon",        type:'CSV',  date:"03/05", views:0,  shared:false, status:'Brouillon',  color:'#475569' },
      { name:"Rapport Q1-Q2 2026 — Global",       client:"Tous les clients",     type:'PDF',  date:"01/05", views:8,  shared:true,  status:'Partagé',    color:'#22c55e' },
    ];
    const shareLinks = [
      { name:"Boulangerie Martin",      url:"share.flowpoint.pro/bm-2026",  expires:"30/06/2026", views:12, active:true  },
      { name:"Restaurant Le Soleil",    url:"share.flowpoint.pro/rs-2026",  expires:"15/06/2026", views:3,  active:true  },
      { name:"Accès Dupont (expiré)",   url:"share.flowpoint.pro/cd-old",   expires:"01/05/2026", views:28, active:false },
    ];
    return \`
      \${isPro
        ? aiBlock("5 rapports générés ce mois — <strong>3 partagés, 1 non lu</strong> (Restaurant Le Soleil — risque satisfaction). Recommandation : envoyer une mise à jour proactive au Restaurant Le Soleil avec les améliorements du monitor. Activer le rapport automatique pour Coiffeur Lyon.",
            ['Générer un rapport', 'Envoyer mise à jour', 'Planifier envoi auto'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">📄</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Reporting avancé — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Rapports white-label, envois automatiques et tracking d\'engagement client.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Rapports ce mois', String(reports.length), 'dont 3 partagés', 'up')}
        \${statCard('Vues totales', String(reports.reduce((s,r) => s + r.views, 0)), 'par les clients', 'up')}
        \${statCard('Non lus', String(reports.filter(r => r.status === 'Non lu').length), 'action recommandée', 'down')}
        \${statCard('Liens de partage', String(shareLinks.filter(s => s.active).length), 'actifs ce mois', 'up')}
      </div>

      <!-- REPORT HISTORY -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('file-text').replace('stroke="currentColor"','stroke="#2563EB"')}
            Historique des rapports
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Génération…')">+ Nouveau rapport</button>
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Rapport</th><th>Client</th><th>Type</th><th>Date</th><th>Vues</th><th>Statut</th><th>Action</th></tr></thead>
            <tbody>
              \${reports.map(r => \`<tr>
                <td style="font-weight:600;font-size:11px">\${escHtml(r.name)}</td>
                <td style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(r.client)}</td>
                <td>\${badge(r.type, '#475569')}</td>
                <td style="color:var(--fp-text-faint);font-size:11px">\${escHtml(r.date)}</td>
                <td style="font-weight:700">\${r.views}</td>
                <td>\${badge(r.status, r.status === 'Partagé' ? '#22c55e' : r.status === 'Lu' ? '#2563EB' : r.status === 'Non lu' ? '#f59e0b' : '#475569')}</td>
                <td style="display:flex;gap:4px">
                  <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Lien copié !')">Partager</button>
                  <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','Téléchargement…')">PDF</button>
                </td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- SHARE LINKS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🔗 Liens de partage client</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${shareLinks.map(s => {
            const sc = s.active ? '#22c55e' : '#475569';
            return \`<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid \${sc}22">
              <div style="width:32px;height:32px;border-radius:8px;background:\${sc}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                \${svgIcon('link').replace('stroke="currentColor"',\`stroke="\${sc}"\`).replace('width="14"','width="13"').replace('height="14"','height="13"')}
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(s.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint);\${!s.active ? 'text-decoration:line-through' : ''}">\${escHtml(s.url)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${s.views} vues · Expire \${escHtml(s.expires)}</div>
              </div>
              \${badge(s.active ? 'Actif' : 'Expiré', sc)}
              \${s.active ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Lien copié !')">Copier</button>\` : ''}
            </div>\`;
          }).join('')}
          <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:4px" onclick="showToast('info','Nouveau lien…')">+ Créer un lien de partage</button>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: COMMUNICATION HUB
  // ══════════════════════════════════════════════════════════
  if (sub === 'communication') {
    const threads = [
      {
        id:'t1', client:"Boulangerie Martin", avatar:"BM", color:"#22c55e",
        subject:"Rapport Mai 2026 — Vos questions",
        messages: [
          { from:"Maël D. (Agence)", text:"Bonjour ! Votre rapport Mai 2026 est disponible. Score 82/100 — record ! Points clés : Local Pack #1 dans le 15e, +4pts SEO, uptime 100%.", time:"09/05 · 10h14", isClient:false },
          { from:"Boulangerie Martin", text:"Excellent ! On voit la progression sur Google Maps. Quand peut-on mettre à jour nos photos GBP ?", time:"09/05 · 11h42", isClient:true },
          { from:"Maël D. (Agence)", text:"Planifié pour cette semaine — notre IA va optimiser les 3 meilleures photos automatiquement.", time:"09/05 · 12h01", isClient:false },
        ],
        status:'actif', unread:0,
      },
      {
        id:'t2', client:"Restaurant Le Soleil", avatar:"RS", color:"#f59e0b",
        subject:"Incident monitor — Mise à jour",
        messages: [
          { from:"Système FlowPoint", text:"Alerte : restaurant-lesoleil.com était inaccessible 44 min. Incident résolu. Rapport disponible.", time:"09/05 · 15h16", isClient:false },
          { from:"Restaurant Le Soleil", text:"Merci pour l\'info rapide. C\'est grave pour notre référencement ?", time:"09/05 · 16h30", isClient:true },
        ],
        status:'en attente', unread:1,
      },
      {
        id:'t3', client:"Plombier Paris", avatar:"PP", color:"#2563EB",
        subject:"Progression ranking — Semaine 19",
        messages: [
          { from:"Maël D. (Agence)", text:"Bonne nouvelle : +6 positions sur vos mots-clés principaux ! Plombier urgence paris maintenant en position 12 (vs 18 il y a 2 mois).", time:"08/05 · 09h00", isClient:false },
        ],
        status:'actif', unread:0,
      },
    ];
    const approvals = [
      { title:"Stratégie contenu Q3 2026",  client:"Boulangerie Martin",   due:"12/05", status:'En attente', color:'#f59e0b' },
      { title:"Budget publicité locale",     client:"Restaurant Le Soleil", due:"15/05", status:'En attente', color:'#f59e0b' },
    ];
    return \`
      \${aiBlock("1 fil en attente de réponse urgente — <strong>Restaurant Le Soleil</strong> attend votre réponse depuis 22h sur l\'incident monitor. 2 approbations en attente. Suggestion : envoyer une mise à jour rassurante avec le rapport de résolution d\'incident.",
        ['Répondre au Restaurant', 'Gérer les approbations', 'Envoyer un résumé IA'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Fils actifs', String(threads.length), 'avec clients', 'up')}
        \${statCard('Non lus', String(threads.filter(t => t.unread > 0).length), 'réponse urgente', 'down')}
        \${statCard('Approbations', String(approvals.length), 'en attente', 'neutral')}
        \${statCard('Temps réponse moy.', '2h 14min', 'objectif < 4h', 'up')}
      </div>

      <!-- THREADS -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('message-circle').replace('stroke="currentColor"','stroke="#2563EB"')}
            Fils de discussion client
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Nouveau fil…')">+ Nouveau fil</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
          \${threads.map(t => \`
            <div style="border:1px solid \${t.unread ? t.color + '44' : 'var(--fp-border)'};border-radius:12px;overflow:hidden;background:\${t.unread ? t.color + '05' : 'transparent'}">
              <div style="padding:12px 14px;border-bottom:1px solid var(--fp-border);display:flex;align-items:center;gap:10px">
                <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,\${t.color},\${t.color}88);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#fff;flex-shrink:0">\${t.avatar}</div>
                <div style="flex:1;min-width:0">
                  <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(t.client)}</div>
                  <div style="font-size:11px;color:var(--fp-text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${escHtml(t.subject)}</div>
                </div>
                \${t.unread ? \`<span style="width:16px;height:16px;background:\${t.color};border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:#fff;flex-shrink:0">\${t.unread}</span>\` : ''}
                \${badge(t.status, t.status === 'en attente' ? '#f59e0b' : '#22c55e')}
              </div>
              <div style="padding:10px 14px;display:flex;flex-direction:column;gap:8px">
                \${t.messages.slice(-2).map(m => \`
                  <div style="display:flex;flex-direction:column;align-items:\${m.isClient ? 'flex-start' : 'flex-end'}">
                    <div style="max-width:85%;padding:8px 12px;border-radius:\${m.isClient ? '4px 12px 12px 12px' : '12px 4px 12px 12px'};background:\${m.isClient ? 'rgba(255,255,255,0.05)' : 'rgba(37,99,235,0.15)'};border:1px solid \${m.isClient ? 'rgba(255,255,255,0.08)' : 'rgba(37,99,235,0.25)'}">
                      <div style="font-size:10px;font-weight:600;color:\${m.isClient ? 'var(--fp-text-muted)' : 'var(--fp-accent)'};margin-bottom:3px">\${escHtml(m.from)}</div>
                      <div style="font-size:11px;color:var(--fp-text);line-height:1.5">\${escHtml(m.text)}</div>
                    </div>
                    <div style="font-size:9px;color:var(--fp-text-faint);margin-top:2px;padding:0 4px">\${escHtml(m.time)}</div>
                  </div>
                \`).join('')}
              </div>
              \${t.unread ? \`<div style="padding:8px 14px;border-top:1px solid var(--fp-border);display:flex;gap:6px">
                <input placeholder="Répondre à \${escHtml(t.client)}…" style="flex:1;background:rgba(255,255,255,0.04);border:1px solid var(--fp-border);border-radius:8px;padding:6px 10px;font-size:11px;color:var(--fp-text)" />
                <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Réponse envoyée !')">Envoyer</button>
              </div>\` : ''}
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- APPROVALS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">✅ Approbations en attente</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${approvals.map(a => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(245,158,11,0.07);border:1px solid rgba(245,158,11,0.25)">
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(a.title)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(a.client)} · Échéance : \${escHtml(a.due)}</div>
              </div>
              \${badge('En attente', '#f59e0b')}
              <div style="display:flex;gap:6px;flex-shrink:0">
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('info','Refus enregistré')">Refuser</button>
                <button class="fp-btn fp-btn-primary fp-btn-sm" style="font-size:10px" onclick="showToast('success','Approuvé !')">Approuver</button>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ONBOARDING CENTER
  // ══════════════════════════════════════════════════════════
  if (sub === 'onboarding') {
    const onboardings = [
      {
        client:"Boulangerie Martin", avatar:"BM", color:"#22c55e",
        progress:100, status:'Terminé', startDate:"15/03/2026",
        steps: [
          { label:"Fiche client créée",                done:true  },
          { label:"Audit initial lancé",               done:true  },
          { label:"Monitor configuré",                 done:true  },
          { label:"Fiche GBP connectée",               done:true  },
          { label:"Rapport de démarrage envoyé",       done:true  },
          { label:"Réunion kick-off réalisée",         done:true  },
        ],
      },
      {
        client:"Restaurant Le Soleil", avatar:"RS", color:"#f59e0b",
        progress:67, status:'En cours', startDate:"01/04/2026",
        steps: [
          { label:"Fiche client créée",                done:true  },
          { label:"Audit initial lancé",               done:true  },
          { label:"Monitor configuré",                 done:true  },
          { label:"Fiche GBP connectée",               done:false },
          { label:"Rapport de démarrage envoyé",       done:false },
          { label:"Réunion kick-off réalisée",         done:false },
        ],
      },
      {
        client:"Coiffeur Lyon", avatar:"CL", color:"#ef4444",
        progress:33, status:'En retard', startDate:"22/04/2026",
        steps: [
          { label:"Fiche client créée",                done:true  },
          { label:"Audit initial lancé",               done:true  },
          { label:"Monitor configuré",                 done:false },
          { label:"Fiche GBP connectée",               done:false },
          { label:"Rapport de démarrage envoyé",       done:false },
          { label:"Réunion kick-off réalisée",         done:false },
        ],
      },
    ];
    return \`
      \${aiBlock("Onboarding globalement en bonne voie. <strong>Boulangerie Martin : 100% complet ✅</strong>. Alerte : <strong>Coiffeur Lyon en retard</strong> — monitor et GBP non configurés depuis 17 jours. Action recommandée : relancer le client et planifier une session de configuration.",
        ['Relancer Coiffeur Lyon', 'Planifier config GBP', 'Rapport onboarding'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Clients onboardés', '1/3', 'Boulangerie Martin', 'up')}
        \${statCard('En cours', '1', 'Restaurant Le Soleil 67%', 'neutral')}
        \${statCard('En retard', '1', 'Coiffeur Lyon — action', 'down')}
        \${statCard('Durée moyenne', '24 jours', 'objectif : 21 jours', 'neutral')}
      </div>

      <!-- ONBOARDING CARDS -->
      <div style="display:flex;flex-direction:column;gap:12px">
        \${onboardings.map(o => {
          const sc = o.progress === 100 ? '#22c55e' : o.status === 'En retard' ? '#ef4444' : '#f59e0b';
          return \`<div class="fp-card">
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
              <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,\${o.color},\${o.color}88);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff;flex-shrink:0">\${o.avatar}</div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(o.client)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">Démarré le \${escHtml(o.startDate)}</div>
              </div>
              <div style="text-align:right">
                <div style="font-size:18px;font-weight:800;color:\${sc}">\${o.progress}%</div>
                \${badge(o.status, sc)}
              </div>
            </div>
            <div class="fp-progress-track" style="height:6px;margin-bottom:12px"><div class="fp-progress-fill" style="width:\${o.progress}%;background:\${sc}"></div></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              \${o.steps.map(s => \`<div style="display:flex;align-items:center;gap:6px;font-size:10px;color:\${s.done ? 'var(--fp-text-soft)' : 'var(--fp-text-faint)'}">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="\${s.done ? '#22c55e' : 'rgba(255,255,255,0.2)'}" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                \${escHtml(s.label)}
              </div>\`).join('')}
            </div>
            \${o.progress < 100 ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:12px;font-size:11px" onclick="showToast('info','Relance envoyée à \${escHtml(o.client)}…')">Relancer le client →</button>\` : ''}
          </div>\`;
        }).join('')}
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: GESTION DE PROJETS
  // ══════════════════════════════════════════════════════════
  if (sub === 'projects') {
    const missions = [
      { title:"Corriger balises title — plombier-paris.fr", cat:"SEO Technique", client:"Plombier Paris",      priority:'urgent',  status:'todo',       assign:"Maël D."   },
      { title:"Répondre aux 14 avis Google",                 cat:"Local SEO",     client:"Multi-clients",       priority:'urgent',  status:'todo',       assign:"Sophie M." },
      { title:"Optimiser vitesse mobile — coiffeur-lyon",    cat:"Performance",   client:"Coiffeur Lyon",       priority:'high',    status:'inprogress', assign:"Maël D."   },
      { title:"Connexion fiche GBP — Restaurant Le Soleil",  cat:"Onboarding",   client:"Restaurant Le Soleil",priority:'high',    status:'inprogress', assign:"Sophie M." },
      { title:"Score SEO boulangerie-martin 82/100 ✅",      cat:"SEO",           client:"Boulangerie Martin",  priority:'normal',  status:'done',       assign:"Maël D."   },
      { title:"Monitor configuré — 6 sites ✅",              cat:"Monitoring",    client:"Tous",                priority:'normal',  status:'done',       assign:"Système"   },
      { title:"Rapport Mai 2026 généré ✅",                   cat:"Reporting",     client:"Boulangerie Martin",  priority:'normal',  status:'done',       assign:"Lucas D."  },
    ];
    const roadmap = [
      { title:"Domination Local Pack 15e",    q:"Q2 2026",   done:true,  desc:"Local Pack #1 atteint sur 4 mots-clés"                },
      { title:"Score moyen portfolio 75/100", q:"Q3 2026",   done:false, desc:"Score actuel 71/100 — +4 pts nécessaires"             },
      { title:"Conversion mobile 2%",         q:"Q3 2026",   done:false, desc:"Corriger formulaire + CTA mobile — priorité urgente"  },
      { title:"10 clients actifs gérés",      q:"Q4 2026",   done:false, desc:"4 clients actifs — 6 à acquérir"                     },
    ];
    const cols = [
      { id:'todo',       label:'À faire',    color:'#f59e0b', emoji:'📋' },
      { id:'inprogress', label:'En cours',   color:'#2563EB', emoji:'⚡' },
      { id:'done',       label:'Terminé',    color:'#22c55e', emoji:'✅' },
    ];
    const prioColor = { urgent:'#ef4444', high:'#f59e0b', normal:'#22c55e' };
    return \`
      \${aiBlock("2 tâches urgentes actives. <strong>Priorité #1 : répondre aux 14 avis Google</strong> (impact note et Maps). Priorité #2 : vitesse mobile Coiffeur Lyon (impact conversion et rankings). Le roadmap Q3 2026 est en bonne voie — jalons Q2 atteints.",
        ['Plan IA des priorités', 'Assigner des tâches', 'Rapport projets'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Tâches urgentes', String(missions.filter(m => m.priority === 'urgent').length), 'action immédiate', 'down')}
        \${statCard('En cours', String(missions.filter(m => m.status === 'inprogress').length), 'assignées à équipe', 'neutral')}
        \${statCard('Terminées ce mois', String(missions.filter(m => m.status === 'done').length), 'jalons atteints', 'up')}
        \${statCard('Roadmap Q3 2026', '25%', '1 jalon sur 4 atteint', 'up')}
      </div>

      <!-- KANBAN -->
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px;overflow-x:auto">
        \${cols.map(col => {
          const colMissions = missions.filter(m => m.status === col.id);
          return \`<div style="background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);border-radius:12px;padding:12px">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px">
              <span style="font-size:14px">\${col.emoji}</span>
              <span style="font-size:12px;font-weight:700;color:\${col.color}">\${escHtml(col.label)}</span>
              <span style="font-size:10px;background:\${col.color}18;color:\${col.color};padding:1px 6px;border-radius:8px;font-weight:700;margin-left:auto">\${colMissions.length}</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px">
              \${colMissions.map(m => \`<div style="padding:10px 12px;background:\${prioColor[m.priority]}07;border:1px solid \${prioColor[m.priority]}25;border-radius:9px;border-left:3px solid \${prioColor[m.priority]}">
                <div style="font-size:10px;font-weight:600;color:var(--fp-text);line-height:1.4;margin-bottom:5px">\${escHtml(m.title)}</div>
                <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap">
                  \${badge(m.cat, '#475569')}
                  <span style="font-size:9px;color:var(--fp-text-faint)">\${escHtml(m.assign)}</span>
                </div>
              </div>\`).join('')}
              \${colMissions.length === 0 ? \`<div style="font-size:11px;color:var(--fp-text-faint);text-align:center;padding:12px">Aucune tâche</div>\` : ''}
            </div>
          </div>\`;
        }).join('')}
      </div>

      <!-- ROADMAP -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🗺️ Roadmap stratégique — 2026</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${roadmap.map((r, i) => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:\${r.done ? 'rgba(34,197,94,0.07)' : 'rgba(255,255,255,0.02)'};border:1px solid \${r.done ? 'rgba(34,197,94,0.25)' : 'var(--fp-border)'}">
              <div style="width:28px;height:28px;border-radius:50%;background:\${r.done ? '#22c55e' : 'rgba(255,255,255,0.06)'};display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:\${r.done ? '#fff' : 'var(--fp-text-faint)'};flex-shrink:0">\${r.done ? '✓' : i+1}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:\${r.done ? '#22c55e' : 'var(--fp-text)'}">\${escHtml(r.title)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(r.desc)}</div>
              </div>
              \${badge(r.q, r.done ? '#22c55e' : '#475569')}
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ANALYTICS & ENGAGEMENT
  // ══════════════════════════════════════════════════════════
  if (sub === 'analytics') {
    const engagementData = clients.map(c => ({
      ...c,
      reportViews:    [4, 1, 0, 2][clients.indexOf(c)],
      commFreq:       ['Hebdo', '2× semaine', 'Mensuelle', 'Hebdo'][clients.indexOf(c)],
      loginDays:      [14, 3, 1, 9][clients.indexOf(c)],
      churnRisk:      [8, 42, 71, 15][clients.indexOf(c)],
      engScore:       [c.engagement, c.engagement, c.engagement, c.engagement][0],
    }));
    return \`
      \${isUltra
        ? aiBlock("Analyse engagement client IA. <strong>Coiffeur Lyon — risque churn 71%</strong> : 1 connexion en 30 jours, 0 vue rapport, communication mensuelle uniquement. <strong>Action urgente : appel de rétention recommandé.</strong> Boulangerie Martin : engagement exemplaire 92%, client ambassadeur potentiel.",
            ['Plan rétention Coiffeur Lyon', 'Rapport engagement', 'Stratégie satisfaction'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px"><div style="font-size:24px">📊</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Analytics & Engagement — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Détection churn IA, scoring engagement client et analyse relationnelle avancée.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Score satisfaction moy.', '78/100', '4 clients', 'up')}
        \${statCard('Score engagement moy.', '72/100', 'en hausse +6', 'up')}
        \${statCard('Risque churn élevé', '1 client', 'Coiffeur Lyon — 71%', 'down')}
        \${statCard('Vues rapports total', String(engagementData.reduce((s,c) => s + c.reportViews, 0)), 'ce mois', 'up')}
      </div>

      <!-- ENGAGEMENT TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('bar-chart-2').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Engagement client — Analyse détaillée
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Client</th><th>Engagement</th><th>Satisfaction</th><th>Vues rapports</th><th>Connexions/30j</th><th>Comm.</th><th>Risque churn</th></tr></thead>
            <tbody>
              \${engagementData.map(c => {
                const hc = healthColor[c.health];
                const rc = c.churnRisk > 60 ? '#ef4444' : c.churnRisk > 30 ? '#f59e0b' : '#22c55e';
                return \`<tr>
                  <td>
                    <div style="display:flex;align-items:center;gap:8px">
                      <div style="width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,\${hc},\${hc}88);display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;color:#fff;flex-shrink:0">\${c.avatar}</div>
                      <span style="font-size:11px;font-weight:600">\${escHtml(c.name)}</span>
                    </div>
                  </td>
                  <td>
                    <div style="display:flex;align-items:center;gap:6px">
                      <div class="fp-progress-track" style="width:60px;height:5px"><div class="fp-progress-fill" style="width:\${c.engagement}%;background:\${hc}"></div></div>
                      <span style="font-size:11px;font-weight:700;color:\${hc}">\${c.engagement}%</span>
                    </div>
                  </td>
                  <td style="font-weight:700;color:\${c.satisfaction >= 80 ? '#22c55e' : c.satisfaction >= 60 ? '#f59e0b' : '#ef4444'}">\${c.satisfaction}/100</td>
                  <td style="font-weight:700">\${c.reportViews}</td>
                  <td style="font-weight:700;color:\${c.loginDays >= 10 ? '#22c55e' : c.loginDays >= 5 ? '#f59e0b' : '#ef4444'}">\${c.loginDays}j</td>
                  <td style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(c.commFreq)}</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:6px">
                      <span style="font-size:12px;font-weight:800;color:\${rc}">\${c.churnRisk}%</span>
                      \${c.churnRisk > 60 ? \`<span style="font-size:9px;padding:2px 6px;border-radius:6px;background:rgba(239,68,68,0.15);color:#ef4444;font-weight:700">⚠ Urgent</span>\` : ''}
                    </div>
                  </td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- CHURN RISK CARDS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🚨 Actions de rétention recommandées</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${[
            { client:"Coiffeur Lyon",        risk:71, action:"Appel de rétention urgent — 1 connexion en 30 jours",                   color:'#ef4444', btn:"Appeler" },
            { client:"Restaurant Le Soleil", risk:42, action:"Envoyer rapport de résolution incident + prochaines étapes GBP",          color:'#f59e0b', btn:"Envoyer email" },
          ].map(r => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:\${r.color}07;border:1px solid \${r.color}28">
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(r.client)} — Risque \${r.risk}%</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(r.action)}</div>
              </div>
              <button class="fp-btn fp-btn-primary fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('success','Action lancée…')">\${escHtml(r.btn)}</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: AGENCY LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'agency') {
    const templates = [
      { name:"Executive SEO",         pages:12, desc:"Rapport mensuel premium pour dirigeants",   uses:18 },
      { name:"Local SEO Performance", pages:8,  desc:"Focus Maps, GBP, visibilité locale",         uses:11 },
      { name:"Rapport de démarrage",  pages:6,  desc:"Bilan initial + plan 90 jours",              uses:4  },
      { name:"Bilan trimestriel",     pages:15, desc:"Q1/Q2/Q3/Q4 — Executive summary complet",   uses:7  },
    ];
    return \`
      \${isUltra
        ? aiBlock("Votre agence gère <strong>4 clients actifs</strong>. Branding white-label configuré. Recommandation : activer le domaine personnalisé pour une expérience client premium (1 seul clic). 4 templates disponibles — template Executive le plus utilisé (18×).",
            ['Configurer le domaine', 'Créer un template', 'Rapport agence complet'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.1),rgba(37,99,235,0.08));border:1px solid rgba(139,92,246,0.25);border-radius:var(--fp-radius-lg);padding:20px 24px;margin-bottom:20px">
            <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
              <div style="font-size:28px">🏢</div>
              <div>
                <div style="font-size:14px;font-weight:800;color:var(--fp-text);margin-bottom:3px">Agency Lab — Ultra requis</div>
                <div style="font-size:12px;color:var(--fp-text-muted)">White-label complet, domaines personnalisés, templates agence et portail client multi-marques.</div>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;margin-bottom:14px">
              \${['🎨 Branding white-label','🌐 Domaine personnalisé','📄 Templates agence','👥 Gestion multi-clients','🤖 IA relationnelle','📊 Analytics agence'].map(f => \`<div style="font-size:11px;padding:8px 12px;background:rgba(255,255,255,0.04);border-radius:8px;border:1px solid rgba(255,255,255,0.07);color:var(--fp-text-soft)">\${f}</div>\`).join('')}
            </div>
            <button class="fp-btn fp-btn-primary" onclick="showToast('info','Mise à niveau Ultra…')" style="width:100%">Débloquer Agency Lab — Passer Ultra →</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Clients actifs', String(clients.length), 'gérés ce mois', 'up')}
        \${statCard('Templates agence', String(templates.length), 'disponibles', 'up')}
        \${statCard('Rapports générés', '18', 'ce mois toute agence', 'up')}
        \${statCard('Domaine custom', isUltra ? 'Actif' : 'Non configuré', isUltra ? 'white-label actif' : 'Ultra requis', isUltra ? 'up' : 'neutral')}
      </div>

      <!-- BRANDING CONFIG -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">🎨 Configuration white-label</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
          \${[
            { label:"Logo agence",     val:"FlowPoint (défaut)",                  icon:"🖼️", locked:!isUltra },
            { label:"Couleur primaire",val:"#2563EB (Flowpoint Blue)",            icon:"🎨", locked:!isUltra },
            { label:"Nom de la marque",val:me?.org?.name || "Votre Agence",       icon:"✏️", locked:!isUltra },
            { label:"Domaine client",  val:isUltra ? "portal.votreagence.fr" : "Non configuré", icon:"🌐", locked:!isUltra },
            { label:"Pied de page",    val:"Propulsé par FlowPoint",              icon:"📝", locked:!isUltra },
            { label:"Palette couleurs",val:"Dark Blue Premium (défaut)",          icon:"🎭", locked:!isUltra },
          ].map(f => \`<div style="padding:14px;border-radius:10px;border:1px solid \${f.locked ? 'rgba(255,255,255,0.05)' : 'rgba(37,99,235,0.2)'};background:\${f.locked ? 'rgba(255,255,255,0.01)' : 'rgba(37,99,235,0.05)'};\${f.locked ? 'opacity:0.6' : ''}">
            <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:4px">\${f.icon} \${escHtml(f.label)}</div>
            <div style="font-size:12px;font-weight:600;color:var(--fp-text);margin-bottom:6px">\${escHtml(f.val)}</div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;width:100%" onclick="showToast('info','\${f.locked ? 'Ultra requis' : 'Modification…'}')">
              \${f.locked ? '🔒 Ultra' : 'Modifier'}
            </button>
          </div>\`).join('')}
        </div>
      </div>

      <!-- TEMPLATES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📄 Templates agence</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${templates.map(t => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <div style="width:36px;height:36px;border-radius:8px;background:rgba(37,99,235,0.15);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                \${svgIcon('file-text').replace('stroke="currentColor"','stroke="#2563EB"').replace('width="14"','width="14"')}
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(t.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(t.desc)} · \${t.pages} pages</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:11px;font-weight:700;color:var(--fp-text-soft)">\${t.uses}× utilisé</div>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;margin-top:4px" onclick="showToast('info','Génération…')">Utiliser</button>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Client Command Center
  // ══════════════════════════════════════════════════════════
  const cmdScores = [
    { label:'Satisfaction',  val:84, color:'#22c55e', icon:'😊' },
    { label:'Engagement',    val:72, color:'#2563EB', icon:'⚡' },
    { label:'Reporting',     val:88, color:'#22c55e', icon:'📄' },
    { label:'Collaboration', val:65, color:'#f59e0b', icon:'🤝' },
    { label:'Onboarding',    val:78, color:'#22c55e', icon:'🚀' },
    { label:'Momentum',      val:74, color:'#2563EB', icon:'📈' },
    { label:'Churn Risk',    val:18, color:'#22c55e', icon:'🛡️' },
  ];
  const circ36 = 2 * Math.PI * 36;

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Client Command Center
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.35);border-radius:20px;color:#2563EB">✦ PREMIUM</span>
        </h1>
        <div class="fp-section-sub">\${clients.length} clients actifs · Score satisfaction 84/100 · Mis à jour à l\'instant</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Partager', 'fp-btn fp-btn-ghost fp-btn-sm', 'link',    "onclick=\\"showToast('success','Lien de partage copié !')\\"" )}
        \${btn('Présenter','fp-btn fp-btn-primary fp-btn-sm','monitor', "onclick=\\"showToast('info','Mode présentation…')\\"" )}
      </div>
    </div>

    <!-- AI CLIENT INTELLIGENCE -->
    \${isUltra
      ? aiBlock("4 clients actifs gérés. Score satisfaction global <strong>84/100</strong>. Alerte : <strong>Coiffeur Lyon — risque churn 71%</strong> — 1 connexion en 30 jours. Action immédiate : appel de rétention. Restaurant Le Soleil non lu depuis 3 jours — envoyer rapport résolution incident.",
          ['Plan rétention clients', 'Rapport agence complet', 'Générer rapport executive'])
      : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">🤝</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Client Intelligence IA — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse satisfaction, détection churn IA et stratégie relationnelle automatique.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button></div>\`
    }

    <!-- KPI CARDS -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Clients actifs', String(clients.length), 'gérés ce mois', 'up')}
      \${statCard('Satisfaction moy.', '84/100', 'score global', 'up')}
      \${statCard('Rapports partagés', '3', 'ce mois · 7 vues', 'up')}
      \${statCard('Risque churn', '1 client', 'Coiffeur Lyon — urgent', 'down')}
    </div>

    <!-- 7 SCORE GAUGES -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('users').replace('stroke="currentColor"','stroke="#2563EB"')}
          Intelligence client — Scores clés
        </div>
        <span style="font-size:11px;color:var(--fp-text-faint)">Score global : <strong style="color:#22c55e">78/100</strong></span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(108px,1fr));gap:8px">
        \${cmdScores.map(k => {
          const filled = k.val / 100 * circ36;
          const dash   = circ36 - filled;
          return \`<div style="padding:12px;border-radius:11px;border:1px solid \${k.color}28;background:\${k.color}07;text-align:center">
            <svg width="52" height="52" viewBox="0 0 90 90" style="margin:0 auto 4px">
              <circle cx="45" cy="45" r="36" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="7"/>
              <circle cx="45" cy="45" r="36" fill="none" stroke="\${k.color}" stroke-width="7"
                stroke-dasharray="\${filled.toFixed(1)} \${dash.toFixed(1)}"
                stroke-dashoffset="\${(circ36*0.25).toFixed(1)}"
                stroke-linecap="round" transform="rotate(-90 45 45)"/>
              <text x="45" y="50" text-anchor="middle" font-size="18" font-weight="800" fill="\${k.color}" font-family="Outfit,sans-serif">\${k.val}</text>
            </svg>
            <div style="font-size:9px;font-weight:600;color:var(--fp-text-faint)">\${k.icon} \${escHtml(k.label)}</div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- CLIENT CARDS + QUICK NAV -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">👥 Portefeuille clients — Vue santé</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${clients.map(c => {
            const hc = healthColor[c.health];
            return \`<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;background:\${hc}07;border:1px solid \${hc}22">
              <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,\${hc},\${hc}88);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff;flex-shrink:0">\${c.avatar}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${escHtml(c.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(c.lastActivity)} · Engagement \${c.engagement}%</div>
                <div style="display:flex;gap:4px;margin-top:3px;flex-wrap:wrap">
                  \${c.tags.map(t => \`<span style="font-size:9px;padding:1px 5px;border-radius:4px;background:\${hc}18;color:\${hc}">\${t}</span>\`).join('')}
                </div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:16px;font-weight:800;color:\${hc}">\${c.seoScore}<span style="font-size:9px;color:var(--fp-text-faint)">/100</span></div>
                <div style="font-size:10px;font-weight:700;color:\${c.trend.startsWith('+') ? '#22c55e' : '#ef4444'}">\${escHtml(c.trend)}</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧭 Espaces client spécialisés</div>
        <div style="display:flex;flex-direction:column;gap:7px">
          \${[
            { label:'Dashboards client',   sub:'dashboards',    icon:'📊', desc:'Vue simplifiée executive pour clients' },
            { label:'Reporting Center',    sub:'reporting',     icon:'📄', desc:'3 rapports partagés · 1 non lu' },
            { label:'Communication Hub',   sub:'communication', icon:'💬', desc:'1 fil en attente · 2 approbations' },
            { label:'Onboarding Center',   sub:'onboarding',    icon:'🚀', desc:'1/3 terminé · 1 en retard' },
            { label:'Gestion de projets',  sub:'projects',      icon:'📋', desc:'2 tâches urgentes actives' },
            { label:'Analytics & Churn',   sub:'analytics',     icon:'📈', desc:'Churn Coiffeur Lyon 71% — urgent' },
            { label:'Agency Lab',          sub:'agency',        icon:'🏢', desc:isUltra ? 'White-label actif' : 'Ultra requis' },
          ].map(n => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${n.sub}')">
              <span style="font-size:16px">\${n.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(n.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(n.desc)}</div>
              </div>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--fp-text-faint)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply replacement ──────────────────────────────────────────
src = replaceFunc(src, 'renderClientMode', NEW_CLIENT);
writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Client Mode fully replaced (8 sub-pages).');
