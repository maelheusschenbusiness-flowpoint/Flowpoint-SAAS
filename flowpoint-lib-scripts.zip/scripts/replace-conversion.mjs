import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

// ── Helper: replace function by name ──────────────────────────
function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (chars: ${i - start})`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 5 → 6 sub-pages ────────────────────────
const OLD_SUBNAV = `'conversion': [{id:null,label:'Analyse UX'},{id:'funnel',label:'Funnel'},{id:'ab-tests',label:'Tests A/B'},{id:'recommendations',label:'Recommandations'},{id:'heatmap',label:'Heatmap'}],`;
const NEW_SUBNAV = `'conversion': [{id:null,label:'Command Center'},{id:'funnel',label:'Funnel Analytics'},{id:'ux-lab',label:'UX & Friction'},{id:'cta',label:'CTA Intelligence'},{id:'revenue-leak',label:'Revenue Leak'},{id:'cro',label:'CRO IA'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated conversion sub-nav (5 \u2192 6 sub-pages)');
} else {
  console.error('SUB-NAV NOT FOUND');
}

// ══════════════════════════════════════════════════════════════
// renderConversion() — 6-sub-page premium implementation
// ══════════════════════════════════════════════════════════════
const NEW_CONVERSION = `function renderConversion() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  // ── Shared data ────────────────────────────────────────────
  const funnelSteps = [
    { label: 'Impressions Google', val: '12 400', abs: 12400, pct: 100,  drop: null,  color: '#2563EB' },
    { label: 'Clics vers le site', val: '1 488',  abs: 1488,  pct: 12.0, drop: 88.0,  color: '#3b82f6' },
    { label: 'Pages vues',          val: '892',    abs: 892,   pct: 7.2,  drop: 40.1,  color: '#8b5cf6' },
    { label: 'Contacts initiés',    val: '134',    abs: 134,   pct: 1.1,  drop: 85.0,  color: '#f59e0b' },
    { label: 'Clients convertis',   val: '28',     abs: 28,    pct: 0.23, drop: 79.1,  color: '#22c55e' },
  ];

  const healthScores = [
    { label: 'Santé conv.',    val: 68, color: '#2563EB',  icon: '📊' },
    { label: 'Trust Score',    val: 52, color: '#ef4444',  icon: '🛡' },
    { label: 'Score UX',       val: 62, color: '#f59e0b',  icon: '🎨' },
    { label: 'Conv. Mobile',   val: 44, color: '#ef4444',  icon: '📱' },
    { label: 'Efficacité CTA', val: 58, color: '#f59e0b',  icon: '🎯' },
    { label: 'Stabilité Funnel',val:71, color: '#22c55e',  icon: '🔄' },
    { label: 'Optimis. Rev.',  val: 48, color: '#ef4444',  icon: '💰' },
  ];

  const circ46 = 2 * Math.PI * 46;

  // ══════════════════════════════════════════════════════════
  // SUB: FUNNEL ANALYTICS
  // ══════════════════════════════════════════════════════════
  if (sub === 'funnel') {
    const mobileSteps = [
      { label: 'Impressions', mob: 100, desk: 100 },
      { label: 'Clics',        mob: 9.8, desk: 14.2 },
      { label: 'Pages vues',   mob: 5.9, desk: 8.6 },
      { label: 'Contacts',     mob: 0.7, desk: 1.5 },
      { label: 'Clients',      mob: 0.12,desk: 0.34 },
    ];
    const friction = [
      { step: 'Page formulaire',   score: 42, issue: 'Trop de champs (8 champs requis)', impact: 'Critique' },
      { step: 'Page tarifs',       score: 58, issue: 'Pas de CTA visible above the fold', impact: "Élevé" },
      { step: 'Page contact',      score: 61, issue: 'Absence de numéro de téléphone', impact: "Élevé" },
      { step: 'Page accueil',      score: 67, issue: 'Vitesse chargement 3.2s mobile', impact: "Moyen" },
    ];
    return \`
      \${aiBlock("La plus grande perte de votre funnel : <strong>88% des visiteurs quittent sans explorer le site</strong> (clics Google non convertis). Sur mobile, le taux contact-client est <strong>3x inférieur</strong> au desktop. Priorité absolue : simplifier le formulaire et accélérer le mobile.",
        ["Optimiser le formulaire", "Comparer mobile vs desktop", "Plan CRO complet"])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard("Taux global", "0.23%", "+0.04% vs M-1", "up", "Secteur : 0.18%")}
        \${statCard("Pire chute", "Clics→Pages", "-88% des visiteurs perdus", "down")}
        \${statCard("Potentiel mobile", "×2.8", "vs taux desktop actuel", "neutral")}
        \${statCard("Clients potentiels", "+47/mois", "si taux atteint 0.41%", "up")}
      </div>

      <!-- FUNNEL VISUALIZATION -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon("filter").replace('stroke="currentColor"', 'stroke="#2563EB"')}
            Entonnoir de conversion · 30 derniers jours
          </div>
          <span style="font-size:11px;color:var(--fp-text-faint)">12 400 impressions initiales</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${funnelSteps.map((s, idx) => \`
            <div>
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
                <span style="font-size:11px;color:var(--fp-text-muted);min-width:140px">\${escHtml(s.label)}</span>
                <div style="flex:1;background:rgba(255,255,255,0.04);border-radius:6px;height:28px;overflow:hidden;position:relative">
                  <div style="width:\${Math.max(2,s.pct)}%;height:100%;background:linear-gradient(90deg,\${s.color}CC,\${s.color}66);border-radius:6px;display:flex;align-items:center;padding-left:10px;transition:width .6s ease">
                    \${s.pct >= 20 ? \`<span style="font-size:11px;font-weight:700;color:#fff">\${s.pct}%</span>\` : ""}
                  </div>
                </div>
                <div style="text-align:right;min-width:80px">
                  <div style="font-size:13px;font-weight:800;color:\${s.color}">\${escHtml(s.val)}</div>
                  \${s.drop !== null ? \`<div style="font-size:10px;color:#ef4444;font-weight:600">-\${s.drop}%</div>\` : ""}
                </div>
              </div>
              \${idx < funnelSteps.length - 1 ? \`<div style="margin-left:140px;font-size:10px;color:var(--fp-text-faint);padding-left:4px">▼ \${100 - Math.round(funnelSteps[idx+1].abs / s.abs * 100)}% de chute vers "\${escHtml(funnelSteps[idx+1].label)}"</div>\` : ""}
            </div>
          \`).join("")}
        </div>
      </div>

      <!-- MOBILE VS DESKTOP + FRICTION -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📱 Mobile vs 💻 Desktop</div>
          <table class="fp-data-table">
            <thead><tr><th>Étape</th><th style="color:#8b5cf6">Mobile</th><th style="color:#06b6d4">Desktop</th><th>Écart</th></tr></thead>
            <tbody>
              \${mobileSteps.map(m => {
                const gap = ((m.desk - m.mob) / m.mob * 100).toFixed(0);
                return \`<tr>
                  <td style="font-size:11px">\${escHtml(m.label)}</td>
                  <td style="font-weight:700;color:#8b5cf6">\${m.mob}%</td>
                  <td style="font-weight:700;color:#06b6d4">\${m.desk}%</td>
                  <td style="font-size:11px;font-weight:700;color:\${parseFloat(gap) > 30 ? "#ef4444" : "#f59e0b"}">Desktop +\${gap}%</td>
                </tr>\`;
              }).join("")}
            </tbody>
          </table>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">⚡ Points de friction détectés</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${friction.map(f => \`
              <div style="padding:10px 12px;border-radius:8px;border-left:3px solid \${f.score < 50 ? "#ef4444" : f.score < 65 ? "#f59e0b" : "#22c55e"};background:rgba(255,255,255,0.02)">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:3px">
                  <span style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(f.step)}</span>
                  \${badge(f.impact, f.impact === "Critique" ? "#ef4444" : f.impact === "Élevé" ? "#f59e0b" : "#64748b")}
                </div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(f.issue)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint);margin-top:3px">Score friction : <strong style="color:\${f.score < 50 ? "#ef4444" : "#f59e0b"}">\${f.score}/100</strong></div>
              </div>
            \`).join("")}
          </div>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: UX & FRICTION LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'ux-lab') {
    const scrollData = [
      { section: "Hero (0–25%)",        depth: 94, eng: 82 },
      { section: "Services (25–50%)",   depth: 71, eng: 65 },
      { section: "Tarifs (50–75%)",     depth: 48, eng: 38 },
      { section: "Contact (75–100%)",   depth: 22, eng: 14 },
    ];
    const clicks = [
      { type: "Rage click",  page: "Page formulaire",   count: 47,  zone: "Bouton Envoyer (inactif)", sev: "critical" },
      { type: "Rage click",  page: "Page contact",      count: 31,  zone: "Numéro de téléphone (non-cliquable)", sev: "critical" },
      { type: "Dead click",  page: "Page accueil",      count: 28,  zone: "Logo partenaires",          sev: "warning" },
      { type: "Dead click",  page: "Page services",     count: 19,  zone: "Titre H2 (zone inactive)",  sev: "warning" },
      { type: "Hesitation",  page: "Page tarifs",       count: 84,  zone: "Colonne prix Pro vs Ultra",  sev: "info" },
    ];
    const mobileChecks = [
      { item: "CTA visible sans scroll",      ok: false },
      { item: "Formulaire tactile (48px min)",ok: false },
      { item: "Vitesse < 2.5s",               ok: false },
      { item: "Texte lisible sans zoom",       ok: true  },
      { item: "Navigation thumb-friendly",    ok: true  },
      { item: "Numéro cliquable (tel:)",      ok: false },
    ];
    return \`
      \${isPro
        ? aiBlock("84 hésitations détectées sur la page Tarifs — les utilisateurs ne comprennent pas la différence entre vos offres. <strong>47 rage clicks sur le formulaire</strong> signalent un bouton Envoyer dysfonctionnel. Score UX mobile : <strong>44/100 — critique</strong>. Ces 3 problèmes peuvent réduire la conversion de -38%.",
            ["Corriger le formulaire", "Améliorer la page Tarifs", "Plan UX mobile"])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">🔬</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">UX & Friction Lab — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Rage clicks, dead clicks, heatmaps de friction et analyse comportementale avancée.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard("Score UX global", "62/100", "Opportunités majeures", "neutral")}
        \${statCard("Rage clicks", "78", "ce mois — critique", "down")}
        \${statCard("Profondeur scroll moy.", "48%", "abandon à mi-page", "neutral")}
        \${statCard("Score mobile UX", "44/100", "En dessous du seuil", "down")}
      </div>

      <!-- SCROLL DEPTH -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon("bar-chart-2").replace('stroke="currentColor"', 'stroke="#06b6d4"')}
          Analyse de profondeur de scroll
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${scrollData.map(s => \`
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:11px;color:var(--fp-text-muted);min-width:160px">\${escHtml(s.section)}</span>
              <div style="flex:1;display:flex;flex-direction:column;gap:3px">
                <div style="display:flex;align-items:center;gap:6px">
                  <div class="fp-progress-track" style="flex:1;height:6px;border-radius:3px">
                    <div class="fp-progress-fill" style="width:\${s.depth}%;background:#2563EB;border-radius:3px"></div>
                  </div>
                  <span style="font-size:11px;font-weight:700;color:#2563EB;min-width:32px">\${s.depth}%</span>
                  <span style="font-size:9px;color:var(--fp-text-faint)">atteint</span>
                </div>
                <div style="display:flex;align-items:center;gap:6px">
                  <div class="fp-progress-track" style="flex:1;height:4px;border-radius:3px">
                    <div class="fp-progress-fill" style="width:\${s.eng}%;background:\${s.eng > 60 ? "#22c55e" : s.eng > 35 ? "#f59e0b" : "#ef4444"};border-radius:3px"></div>
                  </div>
                  <span style="font-size:10px;font-weight:700;color:\${s.eng > 60 ? "#22c55e" : s.eng > 35 ? "#f59e0b" : "#ef4444"};min-width:32px">\${s.eng}%</span>
                  <span style="font-size:9px;color:var(--fp-text-faint)">engagement</span>
                </div>
              </div>
            </div>
          \`).join("")}
          <div style="font-size:11px;color:var(--fp-text-faint);margin-top:4px">📉 74% des utilisateurs n'atteignent pas la section Contact — une opportunité CTA majeure.</div>
        </div>
      </div>

      <!-- RAGE/DEAD CLICKS + MOBILE UX -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">
            \${svgIcon("zap").replace('stroke="currentColor"', 'stroke="#ef4444"')}
            Rage clicks & Dead clicks détectés
          </div>
          <div style="display:flex;flex-direction:column;gap:6px">
            \${clicks.map(c => {
              const sc = c.sev === "critical" ? "#ef4444" : c.sev === "warning" ? "#f59e0b" : "#2563EB";
              return \`<div style="padding:10px 12px;border-radius:8px;background:\${sc}09;border:1px solid \${sc}30;display:flex;align-items:flex-start;gap:10px">
                <div style="flex-shrink:0;margin-top:2px">\${badge(c.type, sc)}</div>
                <div style="flex:1;min-width:0">
                  <div style="font-size:11px;font-weight:600;color:var(--fp-text)">\${escHtml(c.page)}</div>
                  <div style="font-size:10px;color:var(--fp-text-muted);line-height:1.4">\${escHtml(c.zone)}</div>
                </div>
                <div style="font-size:13px;font-weight:800;color:\${sc};flex-shrink:0">\${c.count}×</div>
              </div>\`;
            }).join("")}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">
            \${svgIcon("smartphone").replace('stroke="currentColor"', 'stroke="#8b5cf6"')}
            Checklist UX Mobile
          </div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${mobileChecks.map(m => \`
              <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:\${m.ok ? "rgba(34,197,94,0.05)" : "rgba(239,68,68,0.05)"}">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="\${m.ok ? "#22c55e" : "#ef4444"}" stroke-width="2.5">
                  \${m.ok ? "<polyline points='20 6 9 17 4 12'/>" : "<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>"}
                </svg>
                <span style="font-size:12px;color:\${m.ok ? "var(--fp-text-soft)" : "var(--fp-text-muted)"}">\${escHtml(m.item)}</span>
              </div>
            \`).join("")}
          </div>
          <div style="margin-top:12px;padding:10px;background:rgba(239,68,68,0.06);border-radius:8px;font-size:11px;color:#ef4444">
            ⚠ 4 critères UX mobile échoués — Score : 44/100
          </div>
        </div>
      </div>

      <!-- FRICTION HEATMAP SVG -->
      \${isPro ? \`
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🔥 Heatmap de friction — Page d'accueil</div>
        <div style="position:relative;width:100%;height:200px;background:linear-gradient(180deg,#050810,#070d1c);border-radius:12px;overflow:hidden;border:1px solid var(--fp-border)">
          <svg width="100%" height="100%" style="position:absolute;inset:0">
            <defs>
              <radialGradient id="fh1" cx="50%" cy="50%"><stop offset="0%" stop-color="#ef4444" stop-opacity="0.8"/><stop offset="100%" stop-color="#ef4444" stop-opacity="0"/></radialGradient>
              <radialGradient id="fh2" cx="50%" cy="50%"><stop offset="0%" stop-color="#f59e0b" stop-opacity="0.6"/><stop offset="100%" stop-color="#f59e0b" stop-opacity="0"/></radialGradient>
              <radialGradient id="fh3" cx="50%" cy="50%"><stop offset="0%" stop-color="#ef4444" stop-opacity="0.7"/><stop offset="100%" stop-color="#ef4444" stop-opacity="0"/></radialGradient>
              <radialGradient id="fh4" cx="50%" cy="50%"><stop offset="0%" stop-color="#22c55e" stop-opacity="0.4"/><stop offset="100%" stop-color="#22c55e" stop-opacity="0"/></radialGradient>
            </defs>
            <!-- Rage click zones -->
            <ellipse cx="62%" cy="78%" rx="55" ry="40" fill="url(#fh1)"/>
            <ellipse cx="38%" cy="55%" rx="45" ry="35" fill="url(#fh2)"/>
            <ellipse cx="75%" cy="35%" rx="38" ry="30" fill="url(#fh3)"/>
            <ellipse cx="22%" cy="28%" rx="50" ry="38" fill="url(#fh4)"/>
            <!-- Labels -->
            <text x="62%" y="78%" text-anchor="middle" font-size="10" fill="white" dy="4">47 rage clicks</text>
            <text x="38%" y="55%" text-anchor="middle" font-size="10" fill="white" dy="4">31 rage clicks</text>
            <text x="75%" y="35%" text-anchor="middle" font-size="10" fill="white" dy="4">28 dead clicks</text>
          </svg>
          <div style="position:absolute;top:8px;left:12px;font-size:10px;color:var(--fp-text-faint)">Zones de friction — Page formulaire</div>
          <div style="position:absolute;bottom:8px;right:12px;display:flex;gap:10px">
            <span style="font-size:10px;color:var(--fp-text-faint);display:flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block"></span>Rage clicks</span>
            <span style="font-size:10px;color:var(--fp-text-faint);display:flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:#f59e0b;display:inline-block"></span>Hésitation</span>
            <span style="font-size:10px;color:var(--fp-text-faint);display:flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:#22c55e;display:inline-block"></span>Zone OK</span>
          </div>
        </div>
      </div>
      \` : ""}
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CTA INTELLIGENCE
  // ══════════════════════════════════════════════════════════
  if (sub === 'cta') {
    const ctas = [
      { name: "Appeler maintenant",       page: "Accueil",    ctr: 2.1, mob: 1.2, pos: "Above fold", vis: 82, impact: "Critique" },
      { name: "Demander un devis",        page: "Services",   ctr: 1.4, mob: 0.8, pos: "Below fold", vis: 54, impact: "Élevé"    },
      { name: "Nous contacter",           page: "Contact",    ctr: 3.2, mob: 2.6, pos: "Header",     vis: 91, impact: "Moyen"    },
      { name: "En savoir plus",           page: "Services",   ctr: 0.8, mob: 0.5, pos: "Mid-page",   vis: 62, impact: "Faible"   },
      { name: "Voir nos offres",          page: "Accueil",    ctr: 1.9, mob: 1.1, pos: "Hero",       vis: 78, impact: "Moyen"    },
      { name: "Réserver un appel",        page: "Tarifs",     ctr: 0.4, mob: 0.2, pos: "Bottom",     vis: 31, impact: "Critique" },
    ];
    const abIdeas = [
      { cta: "Appeler maintenant", varB: "Appel gratuit — 24h/24", estGain: "+34%", effort: "30 min" },
      { cta: "Demander un devis",  varB: "Devis gratuit en 2 min",  estGain: "+22%", effort: "20 min" },
      { cta: "Réserver un appel",  varB: "Parler à un expert",       estGain: "+18%", effort: "15 min" },
    ];
    return \`
      \${isPro
        ? aiBlock("Le CTA <strong>Réserver un appel</strong> est quasi-invisible (31/100) et génère 0.4% de CTR — <strong>coût : environ 23 clients perdus par mois</strong>. Sur mobile, tous vos CTAs principaux perdent en moyenne -48% de CTR. Simple action : déplacer le CTA principal au-dessus de la ligne de flottaison.",
            ["Optimiser le CTA principal", "Tests A/B CTAs", "Rapport CTAs complet"])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">🎯</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">CTA Intelligence — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse de visibilité, CTR par CTA, performance mobile et suggestions IA.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard("CTAs analysés", String(ctas.length), "sur toutes vos pages", "neutral")}
        \${statCard("CTAs critiques", String(ctas.filter(c => c.impact === "Critique").length), "visibilité < 50 ou CTR < 0.5%", "down")}
        \${statCard("Meilleur CTR", "3.2%", "Nous contacter — Header", "up")}
        \${statCard("CTR mobile moyen", "1.07%", "vs 1.63% desktop", "neutral")}
      </div>

      <!-- CTA TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon("target").replace('stroke="currentColor"', 'stroke="#f59e0b"')}
          Performance de chaque CTA
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>CTA</th><th>Page</th><th>Visibilité</th><th>CTR Global</th><th>CTR Mobile</th><th>Position</th><th>Impact</th><th>Action</th></tr></thead>
            <tbody>
              \${ctas.map(c => {
                const vc = c.vis >= 80 ? "#22c55e" : c.vis >= 60 ? "#f59e0b" : "#ef4444";
                const ic = c.impact === "Critique" ? "#ef4444" : c.impact === "Élevé" ? "#f59e0b" : c.impact === "Moyen" ? "#2563EB" : "#64748b";
                return \`<tr>
                  <td style="font-weight:700">\${escHtml(c.name)}</td>
                  <td style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(c.page)}</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:6px">
                      <div class="fp-progress-track" style="width:60px;height:5px"><div class="fp-progress-fill" style="width:\${c.vis}%;background:\${vc}"></div></div>
                      <span style="font-size:11px;font-weight:700;color:\${vc}">\${c.vis}</span>
                    </div>
                  </td>
                  <td style="font-weight:700;color:\${c.ctr >= 2 ? "#22c55e" : c.ctr >= 1 ? "#f59e0b" : "#ef4444"}">\${c.ctr}%</td>
                  <td style="font-weight:700;color:\${c.mob >= 1.5 ? "#22c55e" : c.mob >= 0.8 ? "#f59e0b" : "#ef4444"}">\${c.mob}%</td>
                  <td style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(c.pos)}</td>
                  <td>\${badge(c.impact, ic)}</td>
                  <td><button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Optimisation \${escHtml(c.name)}…')">Optimiser</button></td>
                </tr>\`;
              }).join("")}
            </tbody>
          </table>
        </div>
      </div>

      <!-- A/B TEST IDEAS FOR CTAs -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧪 Suggestions de tests A/B pour vos CTAs</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${abIdeas.map(ab => \`
            <div style="padding:12px 14px;border-radius:10px;background:rgba(37,99,235,0.05);border:1px solid rgba(37,99,235,0.2)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
                <span style="font-size:12px;font-weight:700;color:var(--fp-text)">CTA actuel : "\${escHtml(ab.cta)}"</span>
                <span style="font-size:11px;font-weight:700;color:#22c55e">\${escHtml(ab.estGain)} estimé</span>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
                <div style="padding:8px;border-radius:6px;border:1px solid var(--fp-border)"><div style="font-size:9px;color:var(--fp-text-faint)">Variant A (actuel)</div><div style="font-size:12px;font-weight:600;margin-top:3px">"\${escHtml(ab.cta)}"</div></div>
                <div style="padding:8px;border-radius:6px;border:1px solid rgba(34,197,94,0.3);background:rgba(34,197,94,0.05)"><div style="font-size:9px;color:#22c55e">Variant B (IA)</div><div style="font-size:12px;font-weight:600;margin-top:3px">"\${escHtml(ab.varB)}"</div></div>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between">
                <span style="font-size:10px;color:var(--fp-text-faint)">Effort : \${escHtml(ab.effort)}</span>
                <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Test A/B créé !')">Lancer le test</button>
              </div>
            </div>
          \`).join("")}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: REVENUE LEAK DETECTOR
  // ══════════════════════════════════════════════════════════
  if (sub === 'revenue-leak') {
    const leaks = [
      { page: "Page formulaire",    issue: "8 champs obligatoires — abandon 85%",    loss: "1 890€/mois",  score: 18, type: "form",    urg: "critical" },
      { page: "Page tarifs",        issue: "Pas de CTA visible — hésitation prolongée", loss: "1 240€/mois",  score: 31, type: "cta",     urg: "critical" },
      { page: "Vitesse mobile",     issue: "3.2s de chargement — perte ranking mobile", loss: "820€/mois",   score: 44, type: "speed",   urg: "high"     },
      { page: "Preuves sociales",   issue: "Aucun avis affiché sur le site web",       loss: "630€/mois",   score: 52, type: "trust",   urg: "high"     },
      { page: "Chat / disponibilité",issue: "Aucun chat live ou bot de qualification", loss: "490€/mois",   score: 60, type: "channel", urg: "medium"   },
    ];
    const trustIssues = [
      { issue: "Pas de badge certifié visible",     fix: "Ajouter logo RGE / assurance", effort: "30 min" },
      { issue: "Aucune mention légale en footer",   fix: "Ajouter mentions légales",    effort: "15 min" },
      { issue: "Pas de politique de confidentialité",fix: "Ajouter RGPD notice",        effort: "45 min" },
      { issue: "Photos équipe absentes",            fix: "Section équipe avec photos",  effort: "2h"     },
    ];
    const totalLoss = leaks.reduce((s, l) => s + parseInt(l.loss), 0);
    return \`
      \${aiBlock("Perte de revenus estimée : <strong>\${totalLoss.toLocaleString("fr-FR")}€/mois</strong> à cause de 5 fuites de conversion majeures. Le formulaire trop long seul vous coûte <strong>1 890€/mois</strong> en clients perdus. Ces problèmes se règlent en moins de 8h au total.",
        ["Créer le plan de correction", "Prioriser les actions", "Rapport de pertes"])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard("Perte estimée totale", totalLoss.toLocaleString("fr-FR") + "€/mois", "si fuites corrigées", "down")}
        \${statCard("Fuites critiques", String(leaks.filter(l => l.urg === "critical").length), "à corriger en urgence", "down")}
        \${statCard("Gain potentiel", "+47 clients/mois", "si taux 0.23% → 0.41%", "up")}
        \${statCard("Effort total correctif", "< 8h", "pour corriger toutes les fuites", "up")}
      </div>

      <!-- REVENUE LEAK LIST -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon("alert-triangle").replace('stroke="currentColor"', 'stroke="#ef4444"')}
          Fuites de conversion détectées — Impact financier
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${leaks.map((l, i) => {
            const sc = l.urg === "critical" ? "#ef4444" : l.urg === "high" ? "#f59e0b" : "#2563EB";
            return \`<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:10px;border-left:3px solid \${sc};background:\${sc}08">
              <div style="flex-shrink:0;width:28px;height:28px;border-radius:50%;background:\${sc}20;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:\${sc}">\${i + 1}</div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">\${escHtml(l.page)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(l.issue)}</div>
                <div style="margin-top:6px">
                  <div class="fp-progress-track" style="height:4px;max-width:200px">
                    <div class="fp-progress-fill" style="width:\${l.score}%;background:\${sc}"></div>
                  </div>
                  <div style="font-size:9px;color:var(--fp-text-faint);margin-top:2px">Score conversion : \${l.score}/100</div>
                </div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:15px;font-weight:800;color:\${sc}">-\${escHtml(l.loss)}</div>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="margin-top:4px" onclick="showToast('success','Mission créée !')">Corriger</button>
              </div>
            </div>\`;
          }).join("")}
        </div>
      </div>

      <!-- TRUST ISSUES + PRIORITY MATRIX -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🛡 Problèmes de confiance détectés</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${trustIssues.map(t => \`
              <div style="padding:10px 12px;border-radius:8px;background:rgba(239,68,68,0.05);border:1px solid rgba(239,68,68,0.15)">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text);margin-bottom:3px">⚠ \${escHtml(t.issue)}</div>
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div style="font-size:11px;color:#22c55e">→ \${escHtml(t.fix)}</div>
                  <span style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(t.effort)}</span>
                </div>
              </div>
            \`).join("")}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:10px">⚡ Matrice impact / effort</div>
          <div style="position:relative;width:100%;height:200px;background:rgba(255,255,255,0.02);border-radius:10px;border:1px solid var(--fp-border)">
            <div style="position:absolute;top:8px;left:50%;transform:translateX(-50%);font-size:9px;color:var(--fp-text-faint)">IMPACT ÉLEVÉ</div>
            <div style="position:absolute;bottom:8px;left:50%;transform:translateX(-50%);font-size:9px;color:var(--fp-text-faint)">IMPACT FAIBLE</div>
            <div style="position:absolute;top:50%;left:8px;transform:translateY(-50%);font-size:9px;color:var(--fp-text-faint)">EFFORT FAIBLE</div>
            <div style="position:absolute;top:50%;right:8px;transform:translateY(-50%);font-size:9px;color:var(--fp-text-faint)">EFFORT ÉLEVÉ</div>
            <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:rgba(255,255,255,0.06)"></div>
            <div style="position:absolute;left:50%;top:0;bottom:0;width:1px;background:rgba(255,255,255,0.06)"></div>
            <!-- Items plotted -->
            <div style="position:absolute;top:20%;left:18%;font-size:9px;padding:4px 7px;background:#22c55e20;border:1px solid #22c55e40;border-radius:5px;color:#22c55e">Preuves sociales</div>
            <div style="position:absolute;top:25%;left:22%;font-size:9px;padding:4px 7px;background:#22c55e20;border:1px solid #22c55e40;border-radius:5px;color:#22c55e">CTA tarifs</div>
            <div style="position:absolute;top:18%;right:18%;font-size:9px;padding:4px 7px;background:#f59e0b20;border:1px solid #f59e0b40;border-radius:5px;color:#f59e0b">Formulaire</div>
            <div style="position:absolute;bottom:25%;right:25%;font-size:9px;padding:4px 7px;background:#ef444420;border:1px solid #ef444440;border-radius:5px;color:#ef4444">Chat live</div>
            <div style="position:absolute;bottom:30%;left:20%;font-size:9px;padding:4px 7px;background:#2563EB20;border:1px solid #2563EB40;border-radius:5px;color:#2563EB">Vitesse mobile</div>
          </div>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: AI CRO STRATEGIST
  // ══════════════════════════════════════════════════════════
  if (sub === 'cro') {
    const roadmap = [
      { week: "Semaine 1", action: "Simplifier le formulaire (3 champs max)", impact: "+18%", done: false, priority: "🔴" },
      { week: "Semaine 1", action: "Ajouter CTA urgence above the fold",      impact: "+34%", done: false, priority: "🔴" },
      { week: "Semaine 2", action: "Afficher avis Google sur la page",         impact: "+15%", done: false, priority: "🟡" },
      { week: "Semaine 2", action: "Optimiser vitesse mobile (< 2.5s)",        impact: "+22%", done: false, priority: "🟡" },
      { week: "Semaine 3", action: "Lancer A/B test CTA bouton principal",     impact: "+34%", done: false, priority: "🟢" },
      { week: "Semaine 4", action: "Installer chat live ou bot qualification",  impact: "+28%", done: false, priority: "🟢" },
    ];
    const experiments = [
      { name: "CTA couleur rouge vs bleu",        hypo: "Rouge augmente urgence et clics",       est: "+12-28%", dur: "2 sem" },
      { name: "Formulaire 3 vs 8 champs",          hypo: "Friction réduite = conversion doublée", est: "+40-60%", dur: "3 sem" },
      { name: "Hero avec vidéo vs image statique", hypo: "Vidéo capte mieux sur mobile",          est: "+15-22%", dur: "2 sem" },
    ];
    const badges = [
      { name: "Premier audit",         done: true,  icon: "🎯" },
      { name: "Funnel analysé",         done: true,  icon: "🔍" },
      { name: "Premier test A/B lancé", done: false, icon: "🧪" },
      { name: "Taux > 0.3%",            done: false, icon: "📈" },
      { name: "Score UX > 80",          done: false, icon: "🎨" },
      { name: "Zéro fuite détectée",    done: false, icon: "🛡" },
    ];
    const forecast = [
      { month: "Actuel", rate: 0.23, clients: 28 },
      { month: "M+1",    rate: 0.29, clients: 36 },
      { month: "M+2",    rate: 0.35, clients: 43 },
      { month: "M+3",    rate: 0.41, clients: 51 },
    ];
    return \`
      \${isUltra
        ? aiBlock("Avec le plan CRO IA complet sur 4 semaines, votre taux peut passer de <strong>0.23% à 0.41%</strong> (+78%). Gain estimé : <strong>+23 clients/mois</strong> soit <strong>+2 300€/mois</strong>. Priorité absolue cette semaine : formulaire simplifié + CTA urgence. Ces 2 actions seules = +52% de conversion.",
            ["Lancer le plan CRO", "Créer toutes les missions", "Rapport stratégique"])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
            <div style="font-size:24px">🤖</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Stratège CRO IA — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Plans de bataille CRO personnalisés, forecasting, expériences intelligentes et recommandations stratégiques.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard("Taux actuel", "0.23%", "Secteur : 0.18%", "up")}
        \${statCard("Taux cible M+3", "0.41%", "+78% avec le plan CRO", "up")}
        \${statCard("Gain clients estimé", "+23/mois", "en 3 mois avec plan", "up")}
        \${statCard("ROI estimé plan CRO", "+2 300€/mois", "à 100€ client moyen", "up")}
      </div>

      <!-- ROADMAP -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon("map").replace('stroke="currentColor"', 'stroke="#2563EB"')}
          Plan d'optimisation CRO — 4 semaines
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${roadmap.map((r, i) => \`
            <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
              <span style="font-size:16px">\${r.priority}</span>
              <div style="flex:1">
                <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:2px">\${escHtml(r.week)}</div>
                <div style="font-size:13px;font-weight:600;color:var(--fp-text)">\${escHtml(r.action)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:12px;font-weight:800;color:#22c55e">\${escHtml(r.impact)}</div>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="margin-top:3px" onclick="showToast('success','Mission créée !')">Mission</button>
              </div>
            </div>
          \`).join("")}
        </div>
      </div>

      <!-- EXPERIMENTS + FORECAST -->
      <div class="fp-grid-2 fp-mb-20">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">🧪 Expériences intelligentes</div>
          <div style="display:flex;flex-direction:column;gap:10px">
            \${experiments.map(ex => \`
              <div style="padding:12px 14px;border-radius:10px;background:rgba(37,99,235,0.05);border:1px solid rgba(37,99,235,0.2)">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(ex.name)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:6px">"\${escHtml(ex.hypo)}"</div>
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div>
                    <span style="font-size:11px;font-weight:700;color:#22c55e">\${escHtml(ex.est)}</span>
                    <span style="font-size:10px;color:var(--fp-text-faint)"> · Durée : \${escHtml(ex.dur)}</span>
                  </div>
                  <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('success','Test lancé !')">Lancer</button>
                </div>
              </div>
            \`).join("")}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📈 Prévision de conversion</div>
          <div style="display:flex;gap:8px;align-items:flex-end;height:120px;margin-bottom:12px">
            \${forecast.map((f, i) => \`
              <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
                <div style="font-size:11px;font-weight:700;color:\${i === 0 ? "var(--fp-text-muted)" : "#22c55e"}">\${f.rate}%</div>
                <div style="width:100%;max-width:50px;height:\${Math.round(f.rate / 0.41 * 100)}px;background:\${i === 0 ? "rgba(37,99,235,0.3)" : "linear-gradient(180deg,rgba(34,197,94,0.6),rgba(34,197,94,0.1))"};border-radius:6px 6px 0 0;border-top:2px solid \${i === 0 ? "#2563EB" : "#22c55e"}"></div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(f.month)}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">\${f.clients} clients</div>
              </div>
            \`).join("")}
          </div>
          <div style="padding:10px;background:rgba(34,197,94,0.06);border-radius:8px;font-size:12px;color:#22c55e;text-align:center">
            🎯 Objectif M+3 : <strong>0.41%</strong> — +\${forecast[3].clients - forecast[0].clients} clients/mois
          </div>
        </div>
      </div>

      <!-- GAMIFICATION BADGES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🏆 CRO Milestones</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">
          \${badges.map(b => \`
            <div style="padding:14px;border-radius:12px;text-align:center;border:1px solid \${b.done ? "rgba(34,197,94,0.3)" : "var(--fp-border)"};background:\${b.done ? "rgba(34,197,94,0.06)" : "rgba(255,255,255,0.02)"}">
              <div style="font-size:28px;margin-bottom:6px;opacity:\${b.done ? 1 : 0.3}">\${b.icon}</div>
              <div style="font-size:11px;font-weight:600;color:\${b.done ? "var(--fp-text)" : "var(--fp-text-faint)"}">\${escHtml(b.name)}</div>
              <div style="margin-top:6px">\${badge(b.done ? "Débloqué" : "Verrouillé", b.done ? "#22c55e" : "#64748b")}</div>
            </div>
          \`).join("")}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Conversion Command Center
  // ══════════════════════════════════════════════════════════
  const leakTotal = 5070;
  const sessions = [
    { label: "Taux de scroll > 50%",   val: "48%",  delta: "-12%", bad: true  },
    { label: "Rage clicks détectés",   val: "78",   delta: "ce mois", bad: true  },
    { label: "Dead clicks",             val: "47",   delta: "en baisse", bad: false },
    { label: "Sessions avec abandon",   val: "67%",  delta: "formulaire", bad: true  },
  ];
  const mobIssues = [
    { issue: "CTA non visible sans scroll",     impact: "+34% conv. potentiel" },
    { issue: "Formulaire non adapté tactile",   impact: "85% abandon sur mobile" },
    { issue: "Vitesse 3.2s (seuil : 2.5s)",     impact: "-22% ranking mobile" },
  ];

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Conversion Command Center
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(37,99,235,0.12);border:1px solid rgba(37,99,235,0.3);border-radius:20px;color:#2563EB">AI-POWERED</span>
        </h1>
        <div class="fp-section-sub">Plateforme de CRO, intelligence comportementale et optimisation revenue</div>
      </div>
      <div class="fp-section-actions">
        \${btn("Lancer analyse", "fp-btn fp-btn-primary fp-btn-sm", "search", "onclick=\\"showToast('info','Analyse en cours…')\\"" )}
        \${btn("Rapport CRO", "fp-btn fp-btn-ghost fp-btn-sm", "download", "onclick=\\"showToast('info','Génération rapport…')\\"" )}
      </div>
    </div>

    <!-- AI INTELLIGENCE -->
    \${isUltra
      ? aiBlock("Taux de conversion actuel : <strong>0.23%</strong>. Avec les optimisations prioritaires, vous pouvez atteindre <strong>0.41% en 4 semaines</strong> (+78%). 3 fuites critiques : formulaire 8 champs, CTA invisible sur mobile, absence de preuves sociales. Gain estimé : <strong>+2 300€/mois</strong>.",
          ["Plan CRO complet", "Corriger les fuites", "Tester les CTAs"])
      : \`<div style="background:linear-gradient(135deg,rgba(37,99,235,0.08),rgba(139,92,246,0.06));border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
          <div style="font-size:24px">🤖</div>
          <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">Stratège CRO IA — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Plans de conversion personnalisés, forecasting et recommandations business chaque semaine.</div></div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
        </div>\`
    }

    <!-- KPI ROW -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard("Taux de conversion", "0.23%", "+0.04% vs M-1", "up", "Secteur : 0.18%")}
      \${statCard("Clients/mois", "28", "+4 vs M-1", "up")}
      \${statCard("Revenu estimé", "2 800€/mois", "+400€ vs M-1", "up")}
      \${statCard("Perte rev. détectée", leakTotal.toLocaleString("fr-FR") + "€/mois", "5 fuites actives", "down")}
    </div>

    <!-- 7 HEALTH SCORES -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon("activity").replace('stroke="currentColor"', 'stroke="#2563EB"')}
          Système de santé conversion — 7 indicateurs
        </div>
        <span style="font-size:11px;color:var(--fp-text-faint)">Score moyen : <strong style="color:#f59e0b">57/100</strong></span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
        \${healthScores.map(h => {
          const circ = circ46;
          const filled = h.val / 100 * circ;
          return \`<div style="padding:14px;border-radius:12px;border:1px solid \${h.color}28;background:\${h.color}07;text-align:center">
            <svg width="64" height="64" viewBox="0 0 64 64" style="margin:0 auto 6px">
              <circle cx="32" cy="32" r="24" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="7"/>
              <circle cx="32" cy="32" r="24" fill="none" stroke="\${h.color}" stroke-width="7"
                stroke-dasharray="\${(filled).toFixed(1)} \${(circ - filled).toFixed(1)}"
                stroke-dashoffset="\${(circ * 0.25).toFixed(1)}"
                stroke-linecap="round" transform="rotate(-90 32 32)"/>
              <text x="32" y="36" text-anchor="middle" font-size="13" font-weight="800" fill="\${h.color}">\${h.val}</text>
            </svg>
            <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${h.icon} \${escHtml(h.label)}</div>
            <div style="margin-top:6px">\${badge(h.val >= 70 ? "Bon" : h.val >= 50 ? "Moyen" : "Critique", h.color)}</div>
          </div>\`;
        }).join("")}
      </div>
    </div>

    <!-- FUNNEL SNAPSHOT + SESSION INTEL -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon("filter").replace('stroke="currentColor"', 'stroke="#8b5cf6"')}
            Funnel — Ce mois
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('funnel')">Analyse complète →</button>
        </div>
        \${funnelSteps.map((s, idx) => \`
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:\${idx < funnelSteps.length - 1 ? "4px" : "0"}">
            <span style="font-size:10px;color:var(--fp-text-faint);min-width:120px">\${escHtml(s.label)}</span>
            <div class="fp-progress-track" style="flex:1;height:8px;border-radius:4px">
              <div class="fp-progress-fill" style="width:\${Math.max(2, s.pct)}%;background:\${s.color};border-radius:4px"></div>
            </div>
            <span style="font-size:11px;font-weight:700;color:\${s.color};min-width:48px;text-align:right">\${escHtml(s.val)}</span>
          </div>
        \`).join("")}
        <div style="margin-top:12px;padding:10px;background:rgba(239,68,68,0.06);border-radius:8px;font-size:11px;color:#ef4444;text-align:center">
          ⚠ 88% des visiteurs quittent sans explorer le site
        </div>
      </div>

      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon("eye").replace('stroke="currentColor"', 'stroke="#06b6d4"')}
            Intelligence comportementale
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('ux-lab')">Détails →</button>
        </div>
        \${sessions.map(s => \`
          <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
            <span style="font-size:12px;color:var(--fp-text-muted)">\${escHtml(s.label)}</span>
            <div style="text-align:right">
              <div style="font-size:13px;font-weight:800;color:\${s.bad ? "#ef4444" : "#22c55e"}">\${escHtml(s.val)}</div>
              <div style="font-size:9px;color:var(--fp-text-faint)">\${escHtml(s.delta)}</div>
            </div>
          </div>
        \`).join("")}
      </div>
    </div>

    <!-- MOBILE ISSUES + REVENUE LEAK PREVIEW -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon("smartphone").replace('stroke="currentColor"', 'stroke="#ef4444"')}
            Alertes conversion mobile
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('ux-lab')">UX Lab →</button>
        </div>
        <div style="font-size:12px;font-weight:700;color:#ef4444;padding:10px 12px;background:rgba(239,68,68,0.08);border-radius:8px;margin-bottom:10px">
          ⚠ Score UX Mobile : 44/100 — En dessous du seuil critique
        </div>
        \${mobIssues.map(m => \`
          <div style="display:flex;align-items:flex-start;gap:8px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" style="flex-shrink:0;margin-top:2px"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            <div style="flex:1">
              <div style="font-size:12px;color:var(--fp-text-soft)">\${escHtml(m.issue)}</div>
              <div style="font-size:10px;color:#22c55e;font-weight:600">\${escHtml(m.impact)}</div>
            </div>
          </div>
        \`).join("")}
        <button class="fp-btn fp-btn-primary fp-btn-sm" style="width:100%;margin-top:12px" onclick="navigateSub('ux-lab')">Analyser UX mobile</button>
      </div>

      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon("alert-triangle").replace('stroke="currentColor"', 'stroke="#ef4444"')}
            Revenue Leak — Top fuites
          </div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('revenue-leak')">Toutes les fuites →</button>
        </div>
        \${[
          { page: "Formulaire (8 champs)",  loss: "1 890€/mois", urg: "critical" },
          { page: "CTA tarifs invisible",   loss: "1 240€/mois", urg: "critical" },
          { page: "Vitesse mobile 3.2s",    loss: "820€/mois",   urg: "high"     },
          { page: "Pas de preuves sociales",loss: "630€/mois",   urg: "high"     },
        ].map(l => {
          const lc = l.urg === "critical" ? "#ef4444" : "#f59e0b";
          return \`<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:6px;height:6px;border-radius:50%;background:\${lc};flex-shrink:0"></div>
              <span style="font-size:12px;color:var(--fp-text-soft)">\${escHtml(l.page)}</span>
            </div>
            <span style="font-size:12px;font-weight:800;color:\${lc}">-\${escHtml(l.loss)}</span>
          </div>\`;
        }).join("")}
        <div style="margin-top:12px;padding:10px;background:rgba(239,68,68,0.08);border-radius:8px;text-align:center">
          <div style="font-size:15px;font-weight:800;color:#ef4444">-\${leakTotal.toLocaleString("fr-FR")}€/mois</div>
          <div style="font-size:10px;color:var(--fp-text-faint)">Perte totale estimée à corriger</div>
        </div>
      </div>
    </div>

    <!-- CRO QUICK WINS -->
    <div class="fp-card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon("zap").replace('stroke="currentColor"', 'stroke="#22c55e"')}
          Quick Wins CRO — Actions à fort impact immédiat
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigateSub('cro')">Plan complet →</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        \${[
          { t: "Ajouter CTA urgence above the fold",        impact: "+34%", effort: "30 min", priority: "Critique" },
          { t: "Simplifier formulaire (3 champs max)",      impact: "+18%", effort: "1h",     priority: "Critique" },
          { t: "Afficher les avis Google sur le site",      impact: "+15%", effort: "45 min", priority: "Élevé"    },
          { t: "Badge disponibilité 24h/24 visible",        impact: "+12%", effort: "15 min", priority: "Moyen"    },
        ].map(r => {
          const pc = r.priority === "Critique" ? "#ef4444" : r.priority === "Élevé" ? "#f59e0b" : "#2563EB";
          return \`<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border)">
            <div style="flex:1">
              <span style="font-size:13px;font-weight:600;color:var(--fp-text)">\${escHtml(r.t)}</span>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-size:12px;font-weight:800;color:#22c55e">\${escHtml(r.impact)}</div>
              <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(r.effort)}</div>
            </div>
            \${badge(r.priority, pc)}
            <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('success','Mission créée !')">Créer</button>
          </div>\`;
        }).join("")}
      </div>
    </div>
  \`;
}`;

// ── Apply replacement ──────────────────────────────────────────
src = replaceFunc(src, 'renderConversion', NEW_CONVERSION);

writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Conversion section fully replaced (6 sub-pages).');
