import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (chars: ${i - start})`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Add billing to SUB_NAVS ────────────────────────────────
const OLD_SUBNAV_SETTINGS = `  'settings': [{id:null,label:'Général'},{id:'alerts',label:'Alertes'},{id:'api',label:'API & Webhooks'}],`;
const NEW_SUBNAV_SETTINGS  = `  'billing':       [{id:null,label:'Command Center'},{id:'plans',label:'Plans'},{id:'addons',label:'Add-ons'},{id:'invoices',label:'Factures'},{id:'usage',label:'Usage'},{id:'ai-strategist',label:'IA Stratégiste'},{id:'enterprise',label:'Enterprise'}],
  'settings': [{id:null,label:'Général'},{id:'alerts',label:'Alertes'},{id:'api',label:'API & Webhooks'}],`;

if (src.includes(OLD_SUBNAV_SETTINGS)) {
  src = src.replace(OLD_SUBNAV_SETTINGS, NEW_SUBNAV_SETTINGS);
  console.log('\u2713 Added billing sub-nav (7 sub-pages)');
} else { console.error('SUB-NAV ANCHOR NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderBilling() — full 7-sub-page AI Billing platform
// ══════════════════════════════════════════════════════════════
const NEW_BILLING = `function renderBilling() {
  const sub  = STATE.subRoute;
  const me   = STATE.me;
  const plan = me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  // ── Shared plan data ─────────────────────────────────────
  const PLANS = [
    {
      id:'standard', name:'Standard', price:29, annual:23, color:'#475569',
      badge:'Démarrage', tagline:'Idéal pour les indépendants et PME',
      features:[
        'Jusqu\'à 50 audits/mois','10 monitors','5 rapports PDF','1 utilisateur',
        'Local SEO basique','Support email 48h','Rétention 30 jours','Export CSV',
      ],
      locked:['White-label','IA Insights','Multi-sièges','API Access','Custom domain'],
    },
    {
      id:'pro', name:'Pro', price:79, annual:63, color:'#2563EB', current:true,
      badge:'Recommandé', tagline:'Pour les agences et équipes growth',
      features:[
        '250 audits/mois','50 monitors','Rapports illimités','5 utilisateurs',
        'IA Insights Pro','Local SEO avancé','White-label rapports','API Access',
        'Support prioritaire 4h','Rétention 90 jours','Analytics concurrents',
      ],
      locked:['Multi-workspace','SSO Enterprise','Dedicated onboarding','SLA garanti 99.9%'],
    },
    {
      id:'ultra', name:'Ultra', price:199, annual:159, color:'#8b5cf6',
      badge:'Enterprise', tagline:'Pour les grandes agences et entreprises',
      features:[
        'Audits illimités','Monitors illimités','Multi-workspace','Sièges illimités',
        'IA Stratégiste complet','White-label portail','SSO Enterprise','API illimitée',
        'Custom domain','SLA 99.9% garanti','Support dédié < 1h','Rétention 365 jours',
        'Onboarding dédié','Agency Lab complet','Facturation client',
      ],
      locked:[],
    },
  ];

  const usages = [
    { l:'Audits',      icon:'search',     v:me.usage.audit.used,   max:me.usage.audit.limit,   color:'#2563EB', forecast:92 },
    { l:'PDF',         icon:'file-text',  v:me.usage.pdf.used,     max:me.usage.pdf.limit,     color:'#8b5cf6', forecast:61 },
    { l:'Exports',     icon:'download',   v:me.usage.exports.used, max:me.usage.exports.limit, color:'#22c55e', forecast:40 },
    { l:'Monitors',    icon:'activity',   v:me.usage.monitor.used, max:me.usage.monitor.limit, color:'#f59e0b', forecast:78 },
    { l:'Sièges',      icon:'users',      v:1,                     max:5,                      color:'#06b6d4', forecast:20 },
    { l:'AI Crédits',  icon:'bot',        v:412,                   max:1000,                   color:'#ef4444', forecast:55 },
    { l:'Storage',     icon:'database',   v:2.4,                   max:10,                     color:'#22c55e', forecast:32, unit:'GB' },
    { l:'API Appels',  icon:'code',       v:3280,                  max:10000,                  color:'#f59e0b', forecast:44, unit:'' },
    { l:'Bandwidth',   icon:'wifi',       v:18.2,                  max:50,                     color:'#06b6d4', forecast:48, unit:'GB' },
  ];

  const healthScore = 78;
  const upgradeScore = isUltra ? 0 : 62;

  // ══════════════════════════════════════════════════════════
  // SUB: PLANS & ABONNEMENTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'plans') {
    return \`
      \${aiBlock(
        isPro
          ? "Plan <strong>Pro</strong> actif — parfaitement adapté à votre usage actuel. Prévision : si votre équipe dépasse 5 sièges ou vos audits approchent 250/mois, l\'Ultra s\'imposera. ROI estimé du passage Ultra : <strong>+34% efficacité agence</strong>."
          : "Plan <strong>Standard</strong> actif. Votre utilisation des audits est à 76% — passage Pro recommandé dans 3 semaines. ROI estimé passage Pro : économie de 4h/semaine sur les rapports manuels.",
        ['Simuler le passage Pro', 'Estimer le ROI', 'Voir les fonctionnalités']
      )}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Plan actuel', plan, 'actif · renouvellement 1er juin', 'up')}
        \${statCard('Coût mensuel', isStd ? '29€' : isPro && !isUltra ? '79€' : '199€', 'HT · facturation mensuelle', 'neutral')}
        \${statCard('Économie annuel', isStd ? '72€' : isPro && !isUltra ? '192€' : '480€', 'avec facturation annuelle', 'up')}
        \${statCard('Prochain renouvellement', '01/06/2026', 'dans 23 jours', 'neutral')}
      </div>

      <!-- PLAN CARDS -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;margin-bottom:20px">
        \${PLANS.map(p => {
          const isCurrent = p.id === plan.toLowerCase() || (p.id === 'ultra' && isUltra);
          return \`<div style="border-radius:16px;border:2px solid \${isCurrent ? p.color : 'rgba(255,255,255,0.06)'};background:\${isCurrent ? p.color + '08' : 'rgba(255,255,255,0.02)'};padding:22px;position:relative;overflow:hidden;transition:border-color 0.2s">
            \${isCurrent ? \`<div style="position:absolute;top:14px;right:14px;font-size:10px;font-weight:700;background:\${p.color};color:#fff;padding:3px 10px;border-radius:20px">Plan actuel</div>\` : ''}
            <div style="margin-bottom:16px">
              <div style="font-size:11px;font-weight:600;color:\${p.color};margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em">\${escHtml(p.badge)}</div>
              <div style="font-size:22px;font-weight:900;color:var(--fp-text);margin-bottom:2px;font-family:var(--fp-font-head)">\${escHtml(p.name)}</div>
              <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(p.tagline)}</div>
            </div>
            <div style="margin-bottom:16px">
              <span style="font-size:36px;font-weight:900;color:\${p.color};font-family:var(--fp-font-head)">\${p.price}€</span>
              <span style="font-size:12px;color:var(--fp-text-faint)">/mois · ou \${p.annual}€/mois annuel</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:18px">
              \${p.features.map(f => \`<div style="display:flex;align-items:flex-start;gap:7px;font-size:11px;color:var(--fp-text-soft)">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="\${p.color}" stroke-width="2.5" style="flex-shrink:0;margin-top:1px"><polyline points="20 6 9 17 4 12"/></svg>
                \${escHtml(f)}
              </div>\`).join('')}
              \${p.locked.map(f => \`<div style="display:flex;align-items:flex-start;gap:7px;font-size:11px;color:var(--fp-text-faint)">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="2.5" style="flex-shrink:0;margin-top:1px"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                \${escHtml(f)}
              </div>\`).join('')}
            </div>
            <button class="fp-btn \${isCurrent ? 'fp-btn-ghost' : 'fp-btn-primary'} fp-btn-sm" style="width:100%;\${isCurrent ? 'opacity:0.5;cursor:default' : \`background:\${p.color};border-color:\${p.color}\`}" \${isCurrent ? '' : \`onclick="showToast('info','Passage \${p.name}…')"\`}>
              \${isCurrent ? 'Plan actuel' : \`Passer \${p.name} →\`}
            </button>
          </div>\`;
        }).join('')}
      </div>

      <!-- COMPARISON TABLE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📊 Comparaison détaillée des plans</div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead>
              <tr>
                <th style="text-align:left">Fonctionnalité</th>
                \${PLANS.map(p => \`<th style="color:\${p.color};text-align:center">\${p.name}</th>\`).join('')}
              </tr>
            </thead>
            <tbody>
              \${[
                ['Audits / mois', '50', '250', 'Illimités'],
                ['Monitors', '10', '50', 'Illimités'],
                ['Utilisateurs', '1', '5', 'Illimités'],
                ['Rapports PDF', '5', 'Illimités', 'Illimités'],
                ['IA Insights', '—', '✓ Pro', '✓ Complet'],
                ['White-label', '—', '✓', '✓'],
                ['API Access', '—', '✓', '✓ Illimitée'],
                ['Multi-workspace', '—', '—', '✓'],
                ['SSO Enterprise', '—', '—', '✓'],
                ['SLA garanti', '—', '—', '99.9%'],
                ['Support', 'Email 48h', 'Prioritaire 4h', 'Dédié <1h'],
                ['Rétention', '30 jours', '90 jours', '365 jours'],
              ].map(([feat, ...vals]) => \`<tr>
                <td style="font-weight:600;font-size:11px">\${escHtml(feat)}</td>
                \${vals.map((v, i) => \`<td style="text-align:center;font-size:11px;color:\${v === '—' ? 'var(--fp-text-faint)' : PLANS[i].color};font-weight:\${v !== '—' ? 700 : 400}">\${v}</td>\`).join('')}
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ADD-ONS MARKETPLACE
  // ══════════════════════════════════════════════════════════
  if (sub === 'addons') {
    const allAddons = [
      // ── Monitoring ──
      { cat:'Monitoring', name:'+10 Monitors',             price:'9€/mois',  icon:'📡', color:'#f59e0b', active:false, tag:'Populaire',   roi:'99.9% uptime garanti',       desc:'Surveillez 10 sites supplémentaires en temps réel avec alertes SMS/email instantanées.' },
      { cat:'Monitoring', name:'+50 Monitors',             price:'29€/mois', icon:'📡', color:'#f59e0b', active:true,  tag:'Best value',   roi:'50 sites couverts',           desc:'Pack monitoring massif pour agences. Alertes avancées, SLA, et rapport disponibilité.' },
      { cat:'Monitoring', name:'Global Monitoring',        price:'49€/mois', icon:'🌍', color:'#f59e0b', active:false, tag:'Enterprise',   roi:'Monitoring 15 régions',       desc:'Surveillez depuis 15 régions mondiales. Latence, CDN, et géo-disponibilité.' },
      { cat:'Monitoring', name:'SLA Monitoring Avancé',    price:'19€/mois', icon:'🛡️', color:'#f59e0b', active:false, tag:'Pro',          roi:'SLA 99.9% garanti',           desc:'Rapports SLA automatiques, incidents, et analytics disponibilité avancés.' },
      // ── SEO ──
      { cat:'SEO',        name:'Advanced SEO Lab',         price:'29€/mois', icon:'🔬', color:'#2563EB', active:false, tag:'IA Powered',   roi:'+40% couverture sémantique',  desc:'Lab SEO IA complet : analyse sémantique, gap analysis, et topical authority.' },
      { cat:'SEO',        name:'Keyword Domination Engine',price:'39€/mois', icon:'🚀', color:'#2563EB', active:false, tag:'Ultra',        roi:'10× volume keywords trackés', desc:'Trackez 10 000+ mots-clés. IA de clustering, SERP features, et cannibalization.' },
      { cat:'SEO',        name:'Backlink Intelligence',    price:'24€/mois', icon:'🔗', color:'#2563EB', active:false, tag:'Croissance',   roi:'Analyse profil de liens',     desc:'Analysez les backlinks de vos concurrents. Opportunités, toxiques, et outreach IA.' },
      { cat:'SEO',        name:'AI Content Strategist',   price:'34€/mois', icon:'✍️', color:'#2563EB', active:false, tag:'IA',           roi:'+65% efficacité contenu',     desc:'Stratégie de contenu IA. Briefs automatiques, SERP gap, et calendrier éditorial.' },
      // ── Local SEO ──
      { cat:'Local SEO',  name:'+10 Emplacements GBP',    price:'19€/mois', icon:'📍', color:'#22c55e', active:false, tag:'Local',        roi:'10 fiches GBP optimisées',    desc:'Gérez 10 fiches Google Business Profile supplémentaires avec automatisation IA.' },
      { cat:'Local SEO',  name:'AI GBP Posting',          price:'29€/mois', icon:'🤖', color:'#22c55e', active:false, tag:'IA Auto',      roi:'+42% engagement GBP',         desc:'Posts GBP générés automatiquement par IA. Photos optimisées, horaires, et offres.' },
      { cat:'Local SEO',  name:'Review Intelligence',     price:'19€/mois', icon:'⭐', color:'#22c55e', active:false, tag:'Sentiment IA', roi:'+38% note moyenne',           desc:'IA de sentiment sur vos avis Google. Réponses automatiques et alertes critiques.' },
      { cat:'Local SEO',  name:'Local Domination Maps',   price:'24€/mois', icon:'🗺️', color:'#22c55e', active:false, tag:'Heatmap',      roi:'Visibilité Maps 360°',        desc:'Heatmaps de visibilité locale. Analysez votre présence dans le Local Pack par zone.' },
      // ── Conversion ──
      { cat:'Conversion', name:'AI CRO Strategist',       price:'34€/mois', icon:'📈', color:'#ef4444', active:false, tag:'IA',           roi:'+28% taux conversion',        desc:'Stratégiste CRO IA. Recommandations de tests A/B, friction analysis, et UX scoring.' },
      { cat:'Conversion', name:'Behavioral AI',           price:'44€/mois', icon:'🧠', color:'#ef4444', active:false, tag:'Ultra',        roi:'Analyse comportement IA',     desc:'Heatmaps IA, session replay, et analyse comportementale prédictive en temps réel.' },
      { cat:'Conversion', name:'Revenue Leak AI',         price:'29€/mois', icon:'💸', color:'#ef4444', active:false, tag:'ROI',          roi:'Détecte fuites de revenus',   desc:'IA de détection des pertes de conversion. Prioritise les quick wins revenue.' },
      // ── Reporting ──
      { cat:'Reporting',  name:'White-Label Exports',     price:'Inclus',   icon:'🎨', color:'#06b6d4', active:me.addons?.whiteLabel, tag:'Pro inclus', roi:'Rapports à votre marque', desc:'Rapports PDF 100% white-label. Logo, couleurs, et domaine personnalisés.' },
      { cat:'Reporting',  name:'Agency Reporting Packs',  price:'49€/mois', icon:'📦', color:'#06b6d4', active:false, tag:'Agence',       roi:'12 templates pro inclus',     desc:'Bibliothèque de 12 templates agence premium. Rapports Executive, KPI, et Local SEO.' },
      { cat:'Reporting',  name:'AI Executive Reporting',  price:'24€/mois', icon:'📊', color:'#06b6d4', active:false, tag:'IA Auto',      roi:'Rapports auto hebdo/mensuel', desc:'Résumés IA automatiques envoyés à vos clients. Format executive, multi-canal.' },
      // ── IA ──
      { cat:'IA',         name:'AI Forecasting Engine',   price:'39€/mois', icon:'🔮', color:'#8b5cf6', active:false, tag:'Prédictif',    roi:'Prévisions 6 mois',           desc:'Modèle prédictif IA. Prévisions de trafic, rankings, et croissance sur 6 mois.' },
      { cat:'IA',         name:'AI Market Intelligence',  price:'49€/mois', icon:'🌐', color:'#8b5cf6', active:false, tag:'Intelligence',  roi:'Veille marché automatique',   desc:'Veille concurrentielle IA. Tendances marché, opportunités, et alertes sectorielles.' },
      { cat:'IA',         name:'AI Automation Workflows', price:'34€/mois', icon:'⚡', color:'#8b5cf6', active:false, tag:'Automation',   roi:'Économise 6h/semaine',        desc:'Workflows d\'automatisation IA. Audits, rapports, et alertes entièrement automatisés.' },
      // ── Team ──
      { cat:'Équipe',     name:'+5 Sièges',               price:'35€/mois', icon:'👥', color:'#06b6d4', active:me.addons?.extraSeats > 0, tag:'Collaboration', roi:'5 utilisateurs suppl.', desc:'Ajoutez 5 membres d\'équipe avec rôles et permissions granulaires.' },
      { cat:'Équipe',     name:'Enterprise Permissions',  price:'19€/mois', icon:'🔐', color:'#06b6d4', active:false, tag:'Sécurité',     roi:'RBAC complet',                desc:'Contrôle d\'accès granulaire. Rôles custom, audit log, et permissions par workspace.' },
      // ── Storage ──
      { cat:'Storage',    name:'Rétention 90 jours',      price:'9€/mois',  icon:'🗄️', color:'#475569', active:false, tag:'Standard+',    roi:'3 mois d\'historique',        desc:'Conservez 90 jours d\'historique pour tous vos audits, monitors, et rapports.' },
      { cat:'Storage',    name:'Rétention 365 jours',     price:'19€/mois', icon:'🗄️', color:'#475569', active:false, tag:'Pro+',         roi:'1 an d\'historique complet',  desc:'365 jours d\'historique. Analyses long-terme et tendances annuelles.' },
      // ── API ──
      { cat:'API',        name:'Webhooks Avancés',        price:'14€/mois', icon:'🔔', color:'#f59e0b', active:false, tag:'Dev',          roi:'Alertes temps réel',          desc:'Webhooks personnalisables pour Slack, Discord, et systèmes tiers. Templates inclus.' },
      { cat:'API',        name:'Zapier/Make Integration', price:'19€/mois', icon:'⚙️', color:'#f59e0b', active:false, tag:'No-code',      roi:'1000+ intégrations',          desc:'Connectez FlowPoint à 1000+ applications. CRM, Slack, Notion, HubSpot, et plus.' },
      { cat:'API',        name:'CRM Intégrations',        price:'29€/mois', icon:'🏢', color:'#f59e0b', active:false, tag:'Enterprise',   roi:'HubSpot, Salesforce, Pipedrive', desc:'Synchronisez vos données SEO avec votre CRM. Leads, opportunités, et reporting.' },
      // ── Enterprise ──
      { cat:'Enterprise', name:'Custom Domain',           price:'9€/mois',  icon:'🌐', color:'#8b5cf6', active:me.addons?.customDomain, tag:'Branding', roi:'portal.votreagence.fr', desc:'Portail client sur votre propre domaine. HTTPS automatique et personnalisation.' },
      { cat:'Enterprise', name:'SSO Enterprise',          price:'49€/mois', icon:'🔑', color:'#8b5cf6', active:false, tag:'Ultra',        roi:'SAML 2.0 / OIDC',            desc:'Single Sign-On enterprise. Compatible SAML 2.0, OIDC, Azure AD, et Okta.' },
      { cat:'Enterprise', name:'Dedicated Onboarding',   price:'Inclus Ultra', icon:'🚀', color:'#8b5cf6', active:isUltra, tag:'Ultra inclus', roi:'Setup en 48h garanti',  desc:'Onboarding dédié avec expert FlowPoint. Configuration complète et formation équipe.' },
    ];

    const cats = ['Tous', 'Monitoring', 'SEO', 'Local SEO', 'Conversion', 'Reporting', 'IA', 'Équipe', 'Storage', 'API', 'Enterprise'];
    const activeCat = 'Tous'; // default; filter by query in real app
    const displayAddons = allAddons; // show all; real impl would filter

    const activeCount = allAddons.filter(a => a.active).length;
    const monthlyCost = [29, 19, 9, 19, 35].reduce((a, b) => a + b, 0); // sample

    return \`
      \${aiBlock(
        "Vous utilisez <strong>\${activeCount} add-ons actifs</strong>. Recommandation IA : <strong>AI Forecasting Engine</strong> (39€/mois) pourrait améliorer votre planification growth de +34%. <strong>Review Intelligence</strong> est prioritaire pour le compte Restaurant Le Soleil (14 avis sans réponse = risque note).",
        ['Ajouter AI Forecasting', 'Activer Review Intelligence', 'Voir ROI des add-ons']
      )}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Add-ons actifs', String(activeCount), 'sur ' + allAddons.length + ' disponibles', 'up')}
        \${statCard('Coût add-ons', '111€/mois', 'en plus du plan', 'neutral')}
        \${statCard('Modules IA dispo', String(allAddons.filter(a => a.cat === 'IA').length), 'modules d\'intelligence', 'up')}
        \${statCard('ROI estimé', '+42%', 'efficacité agence', 'up')}
      </div>

      <!-- CATEGORY FILTER -->
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">
        \${cats.map(c => \`<button onclick="showToast('info','Filtre: \${c}')" style="font-size:11px;font-weight:600;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.04);color:var(--fp-text-muted);cursor:pointer">\${escHtml(c)}</button>\`).join('')}
      </div>

      <!-- ADD-ONS GRID -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px">
        \${displayAddons.map(a => \`
          <div style="border-radius:14px;border:1px solid \${a.active ? a.color + '44' : 'rgba(255,255,255,0.06)'};background:\${a.active ? a.color + '07' : 'rgba(255,255,255,0.02)'};padding:16px;position:relative;overflow:hidden">
            \${a.active ? \`<div style="position:absolute;top:0;right:0;width:3px;height:100%;background:linear-gradient(to bottom,\${a.color},\${a.color}44)"></div>\` : ''}
            <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px">
              <div style="font-size:20px;flex-shrink:0">\${a.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);line-height:1.3">\${escHtml(a.name)}</div>
                <div style="display:flex;align-items:center;gap:4px;margin-top:3px;flex-wrap:wrap">
                  \${badge(a.cat, '#475569')}
                  \${badge(a.tag, a.color)}
                </div>
              </div>
              \${a.active ? \`<div style="width:8px;height:8px;border-radius:50%;background:#22c55e;flex-shrink:0;margin-top:4px;box-shadow:0 0 8px rgba(34,197,94,0.5)"></div>\` : ''}
            </div>
            <div style="font-size:10px;color:var(--fp-text-muted);line-height:1.5;margin-bottom:10px">\${escHtml(a.desc)}</div>
            <div style="font-size:10px;color:\${a.color};font-weight:600;margin-bottom:10px">✦ \${escHtml(a.roi)}</div>
            <div style="display:flex;align-items:center;justify-content:space-between">
              <span style="font-size:13px;font-weight:800;color:\${a.active ? '#22c55e' : 'var(--fp-text)'}">\${escHtml(a.price)}</span>
              <button class="fp-btn \${a.active ? 'fp-btn-ghost' : 'fp-btn-primary'} fp-btn-sm" style="font-size:10px;\${a.active ? 'border-color:rgba(239,68,68,0.3);color:#ef4444' : \`background:\${a.color};border-color:\${a.color}\`}" onclick="showToast('\${a.active ? 'info' : 'success'}','\${a.active ? 'Désactivation…' : 'Activation de ' + escHtml(a.name) + '…'}')">
                \${a.active ? 'Désactiver' : 'Activer →'}
              </button>
            </div>
          </div>
        \`).join('')}
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: FACTURES & PAIEMENTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'invoices') {
    const invoices = [
      { id:'FP-2026-051', date:'01/05/2026', amount:'79.00', plan:'Pro', addons:'29€ Priority Support + 19€ Monitors Pack', status:'Payée',   color:'#22c55e' },
      { id:'FP-2026-041', date:'01/04/2026', amount:'79.00', plan:'Pro', addons:'29€ Priority Support + 19€ Monitors Pack', status:'Payée',   color:'#22c55e' },
      { id:'FP-2026-031', date:'01/03/2026', amount:'79.00', plan:'Pro', addons:'29€ Priority Support + 9€ Custom Domain',   status:'Payée',   color:'#22c55e' },
      { id:'FP-2026-021', date:'01/02/2026', amount:'49.00', plan:'Standard', addons:'Aucun',                                status:'Payée',   color:'#22c55e' },
      { id:'FP-2026-011', date:'01/01/2026', amount:'49.00', plan:'Standard', addons:'Aucun',                                status:'Payée',   color:'#22c55e' },
      { id:'FP-2025-121', date:'01/12/2025', amount:'49.00', plan:'Standard', addons:'Aucun',                                status:'Payée',   color:'#22c55e' },
    ];
    const paymentMethods = [
      { type:'Visa',       last4:'4242', expires:'09/2027', default:true,  color:'#1a1f71' },
      { type:'Mastercard', last4:'5555', expires:'03/2026', default:false, color:'#eb001b' },
    ];
    return \`
      \${aiBlock(
        "Toutes vos factures sont à jour ✅. Prochain débit : <strong>79€ le 1er juin 2026</strong> (Plan Pro). Votre carte Visa ****4242 est valide jusqu\'en sept. 2027. Aucun paiement échoué détecté ce semestre.",
        ['Télécharger factures', 'Mettre à jour carte', 'Activer facture annuelle']
      )}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Total payé 2026', '286€', '5 factures · HT', 'up')}
        \${statCard('Prochain débit', '79€', '01/06/2026 — dans 23 jours', 'neutral')}
        \${statCard('Méthodes de paiement', String(paymentMethods.length), 'actives — Visa par défaut', 'up')}
        \${statCard('Paiements échoués', '0', 'aucun incident 2026', 'up')}
      </div>

      <!-- PAYMENT METHODS -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">💳 Méthodes de paiement</div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Ajout de carte…')">+ Ajouter une carte</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${paymentMethods.map(pm => \`
            <div style="display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:12px;background:rgba(255,255,255,0.03);border:1px solid \${pm.default ? 'rgba(37,99,235,0.3)' : 'rgba(255,255,255,0.07)'}">
              <div style="width:44px;height:30px;border-radius:6px;background:\${pm.color};display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <span style="font-size:9px;font-weight:900;color:#fff;letter-spacing:.04em">\${pm.type.toUpperCase()}</span>
              </div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${pm.type} •••• \${pm.last4}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">Expire \${pm.expires}</div>
              </div>
              \${pm.default ? badge('Par défaut', '#22c55e') : ''}
              <div style="display:flex;gap:6px">
                \${!pm.default ? \`<button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Carte par défaut mise à jour')">Définir par défaut</button>\` : ''}
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;border-color:rgba(239,68,68,0.3);color:#ef4444" onclick="showToast('info','Suppression…')">Supprimer</button>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- INVOICE TABLE -->
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">🧾 Historique des factures</div>
          <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Export CSV…')">Exporter tout</button>
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Numéro</th><th>Date</th><th>Plan</th><th>Modules</th><th>Total HT</th><th>Statut</th><th>Actions</th></tr></thead>
            <tbody>
              \${invoices.map(inv => \`<tr>
                <td style="font-family:var(--fp-font-mono);font-size:10px;font-weight:700;color:var(--fp-accent)">\${escHtml(inv.id)}</td>
                <td style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(inv.date)}</td>
                <td>\${badge(inv.plan, '#2563EB')}</td>
                <td style="font-size:10px;color:var(--fp-text-faint);max-width:180px">\${escHtml(inv.addons)}</td>
                <td style="font-weight:800;font-family:var(--fp-font-mono)">\${escHtml(inv.amount)}€</td>
                <td>\${badge(inv.status, inv.status === 'Payée' ? '#22c55e' : '#ef4444')}</td>
                <td style="display:flex;gap:4px">
                  <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','Téléchargement PDF…')">PDF</button>
                  <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('success','Envoi email…')">Email</button>
                </td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: USAGE ANALYTICS
  // ══════════════════════════════════════════════════════════
  if (sub === 'usage') {
    return \`
      \${isPro
        ? aiBlock(
            "Analyse usage Mai 2026. <strong>Audits à 76% — seuil d\'alerte atteint dans ~8 jours</strong> au rythme actuel. AI Crédits 41% — consommation stable. Storage très faible (24%) — aucune action nécessaire. Recommandation : activer +200 Audits (9€/mois) ou passer Ultra pour audits illimités.",
            ['Ajouter +200 Audits', 'Voir prévisions 30j', 'Rapport usage complet']
          )
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">📊</div><div style="flex:1"><div style="font-size:13px;font-weight:700;margin-bottom:2px">Usage Analytics avancé — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Prévisions, alertes de seuil et analytics d\'utilisation détaillés.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Usage moyen', '58%', 'des ressources utilisées', 'up')}
        \${statCard('Ressources critiques', String(usages.filter(u => u.forecast > 80).length), 'seuil d\'alerte 80%', 'down')}
        \${statCard('Prévision 30j', '82%', 'usage moyen prévu', 'neutral')}
        \${statCard('Plan capacity', plan, 'adapté à votre usage actuel', 'up')}
      </div>

      <!-- USAGE GRID -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;margin-bottom:20px">
        \${usages.map(u => {
          const pct  = Math.round(u.v / u.max * 100);
          const fc   = u.forecast;
          const pc   = pct > 80 ? '#ef4444' : pct > 60 ? '#f59e0b' : u.color;
          const fcc  = fc  > 80 ? '#ef4444' : fc  > 60 ? '#f59e0b' : '#22c55e';
          const vDisp = u.unit ? u.v + u.unit : String(u.v);
          const mDisp = u.unit ? u.max + u.unit : String(u.max);
          return \`<div class="fp-card" style="border-left:3px solid \${pc};position:relative;overflow:hidden">
            \${pct > 80 ? \`<div style="position:absolute;top:10px;right:10px;font-size:9px;font-weight:700;background:rgba(239,68,68,0.15);color:#ef4444;padding:2px 7px;border-radius:10px">⚠ Critique</div>\` : fc > 80 ? \`<div style="position:absolute;top:10px;right:10px;font-size:9px;font-weight:700;background:rgba(245,158,11,0.15);color:#f59e0b;padding:2px 7px;border-radius:10px">⟶ Alerte prévue</div>\` : ''}
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
              <div style="width:30px;height:30px;border-radius:8px;background:\${pc}18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                \${svgIcon(u.icon).replace('stroke="currentColor"',\`stroke="\${pc}"\`).replace('width="14"','width="13"').replace('height="14"','height="13"')}
              </div>
              <span style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(u.l)}</span>
            </div>
            <div style="display:flex;align-items:baseline;gap:4px;margin-bottom:8px">
              <span style="font-size:24px;font-weight:900;color:\${pc};font-family:var(--fp-font-head)">\${vDisp}</span>
              <span style="font-size:12px;color:var(--fp-text-faint)">/ \${mDisp}</span>
              <span style="font-size:11px;font-weight:700;color:\${pc};margin-left:auto">\${pct}%</span>
            </div>
            <div class="fp-progress-track" style="height:6px;margin-bottom:10px">
              <div class="fp-progress-fill" style="width:\${pct}%;background:\${pc};transition:width 0.6s ease"></div>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between">
              <div style="font-size:10px;color:var(--fp-text-faint)">Prévision 30j :</div>
              <div style="font-size:11px;font-weight:700;color:\${fcc}">\${fc}%</div>
            </div>
            <div class="fp-progress-track" style="height:3px;margin-top:4px;background:rgba(255,255,255,0.04)">
              <div style="height:100%;width:\${fc}%;background:\${fcc};border-radius:99px;transition:width 0.6s ease"></div>
            </div>
          </div>\`;
        }).join('')}
      </div>

      <!-- ADOPTION TRACKING -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📈 Adoption des fonctionnalités — Ce mois</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
          \${[
            { feat:'Audits SEO',         rate:94, trend:'+8%'  },
            { feat:'Monitors',           rate:88, trend:'+3%'  },
            { feat:'Rapports PDF',       rate:72, trend:'+12%' },
            { feat:'Local SEO',          rate:67, trend:'+5%'  },
            { feat:'IA Insights',        rate:61, trend:'+18%' },
            { feat:'Concurrents',        rate:54, trend:'+7%'  },
            { feat:'Conversion',         rate:41, trend:'+4%'  },
            { feat:'Data Explorer',      rate:38, trend:'+9%'  },
          ].map(f => {
            const c = f.rate > 75 ? '#22c55e' : f.rate > 50 ? '#f59e0b' : '#ef4444';
            return \`<div style="padding:12px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <span style="font-size:11px;font-weight:600;color:var(--fp-text)">\${escHtml(f.feat)}</span>
                <span style="font-size:10px;font-weight:700;color:#22c55e">\${escHtml(f.trend)}</span>
              </div>
              <div class="fp-progress-track" style="height:5px;margin-bottom:4px"><div class="fp-progress-fill" style="width:\${f.rate}%;background:\${c}"></div></div>
              <div style="font-size:10px;font-weight:700;color:\${c}">\${f.rate}%</div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: IA STRATÉGISTE
  // ══════════════════════════════════════════════════════════
  if (sub === 'ai-strategist') {
    const strategies = [
      {
        title:'Passage Ultra recommandé dans 6 semaines',
        body:'Au rythme actuel, vos audits dépasseront 250/mois le 22 juin. Le passage Ultra (199€/mois) coûte +120€ mais génère 4h/semaine d\'économie d\'automatisation = 200€ de valeur temps. ROI positif en 1 mois.',
        priority:'Haute', color:'#f59e0b', action:'Simuler Ultra',
        metrics:['Audits 76% de capacité', 'Seuil prévu J+8', 'ROI : +200€/mois'],
      },
      {
        title:'Review Intelligence — Quick Win immédiat',
        body:'14 avis Google sans réponse détectés. Review Intelligence (19€/mois) automatise les réponses IA et améliore la note moyenne de +0.4 points — impact direct sur le Local Pack.',
        priority:'Urgente', color:'#ef4444', action:'Activer Review Intelligence',
        metrics:['14 avis sans réponse', '+0.4 note Google estimée', 'ROI < 1 semaine'],
      },
      {
        title:'AI CRO Strategist — Conversion non exploitée',
        body:'Votre taux de conversion mobile est à 0.8% (benchmark secteur : 2.1%). AI CRO Strategist (34€/mois) détecterait les frictions et prioriserait les tests. Gain estimé : +1.3% conversion = +€€€.',
        priority:'Moyenne', color:'#2563EB', action:'Essayer AI CRO',
        metrics:['Conversion mobile 0.8%', 'Benchmark : 2.1%', 'Gain potentiel : +62%'],
      },
      {
        title:'Facturation annuelle — Économie immédiate',
        body:'Passer en facturation annuelle génère une économie de 192€/an sur le plan Pro. Aucun changement de fonctionnalités — simplement votre cycle de paiement adapté.',
        priority:'Faible', color:'#22c55e', action:'Activer annuel',
        metrics:['Économie : 192€/an', 'Équivaut à 2.4 mois offerts', 'Prélèvement unique'],
      },
    ];
    const churnRisks = [
      { risk:'Usage en baisse — Rapports PDF', score:12, desc:'Usage PDF réduit de 40% vs M-1 — possible désengagement feature', color:'#f59e0b' },
      { risk:'Pas de connexion Manager 7 jours', score:8, desc:'L\'utilisateur secondaire n\'a pas ouvert la session depuis 7 jours', color:'#f59e0b' },
    ];
    return \`
      \${isUltra
        ? aiBlock("IA Stratégiste activé — analyse complète du compte. <strong>3 opportunités d\'optimisation détectées</strong>. Priorité : activer Review Intelligence (ROI < 1 semaine). Prévision : dépassement plan dans 8 jours. Économie annuelle disponible : 192€.",
            ['Appliquer toutes les recommandations', 'Rapport ROI complet', 'Prévision 6 mois'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px"><div style="font-size:24px">🧠</div><div style="flex:1"><div style="font-size:13px;font-weight:700;margin-bottom:2px">IA Stratégiste complet — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse ROI, prévision d\'upgrade, et optimisation des coûts SaaS automatisée.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Score optimisation', '62/100', '+15 pts ce mois', 'up')}
        \${statCard('Économies identifiées', '192€/an', 'facturation annuelle', 'up')}
        \${statCard('ROI add-ons estimé', '+42%', 'efficacité agence', 'up')}
        \${statCard('Alertes churn', String(churnRisks.length), 'signaux faibles détectés', 'neutral')}
      </div>

      <!-- STRATEGIES -->
      <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:20px">
        \${strategies.map((s, i) => \`
          <div style="border-radius:14px;border:1px solid \${s.color}28;background:\${s.color}06;padding:18px">
            <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px">
              <div style="width:28px;height:28px;border-radius:50%;background:\${s.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:12px;font-weight:900;color:\${s.color}">\${i+1}</div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(s.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.6;margin-bottom:10px">\${escHtml(s.body)}</div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
                  \${s.metrics.map(m => \`<span style="font-size:10px;font-weight:600;padding:3px 9px;border-radius:10px;background:\${s.color}18;color:\${s.color}">\${escHtml(m)}</span>\`).join('')}
                </div>
                <div style="display:flex;align-items:center;gap:10px">
                  \${badge('Priorité ' + s.priority, s.color)}
                  <button class="fp-btn fp-btn-primary fp-btn-sm" style="font-size:10px;background:\${s.color};border-color:\${s.color}" onclick="showToast('success','Action lancée…')">\${escHtml(s.action)} →</button>
                </div>
              </div>
            </div>
          </div>
        \`).join('')}
      </div>

      <!-- CHURN PREVENTION -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🛡️ Prévention churn — Signaux faibles</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${churnRisks.map(r => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:\${r.color}07;border:1px solid \${r.color}28">
              <div style="flex:1">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(r.risk)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(r.desc)}</div>
              </div>
              <div style="font-size:11px;font-weight:700;color:\${r.color};min-width:40px;text-align:center">Risque \${r.score}%</div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Analyse…')">Analyser</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: ENTERPRISE LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'enterprise') {
    const workspaces = [
      { name:'Agence Principale',  clients:4, seats:3, plan:'Pro',   mrr:'316€', status:'Actif',   color:'#2563EB' },
      { name:'Client Boulangerie', clients:1, seats:1, plan:'Shared','mrr':'—',  status:'Géré',    color:'#22c55e' },
      { name:'Client Plombier',    clients:1, seats:1, plan:'Shared', mrr:'—',   status:'Géré',    color:'#22c55e' },
    ];
    const features = [
      { name:'Multi-workspace',         active:isUltra, desc:'Gérez plusieurs workspaces séparés dans une seule interface',        icon:'🏢', color:'#2563EB' },
      { name:'SSO Enterprise',          active:false,    desc:'Azure AD, Okta, SAML 2.0 — connexion unifiée pour votre équipe',    icon:'🔑', color:'#8b5cf6', locked:true },
      { name:'Custom Domain',           active:me.addons?.customDomain, desc:'Portail client sur votre propre domaine personnalisé',icon:'🌐', color:'#06b6d4' },
      { name:'White-Label Portail',     active:isUltra, desc:'Interface complète à votre marque pour vos clients',                  icon:'🎨', color:'#f59e0b' },
      { name:'Facturation client',      active:isUltra, desc:'Générez des factures au nom de votre agence pour vos clients',       icon:'🧾', color:'#22c55e' },
      { name:'Audit Log Avancé',        active:false,    desc:'Historique complet de toutes les actions — conformité RGPD',         icon:'📋', color:'#ef4444', locked:true },
      { name:'Dedicated Onboarding',    active:isUltra, desc:'Expert dédié pour la configuration et formation de votre équipe',    icon:'🚀', color:'#8b5cf6' },
      { name:'SLA 99.9% garanti',       active:isUltra, desc:'Garantie de disponibilité avec crédits automatiques si non atteint', icon:'🛡️', color:'#22c55e' },
    ];
    return \`
      \${isUltra
        ? aiBlock("Enterprise Lab actif. <strong>3 workspaces gérés</strong> pour 4 clients. MRR agence : 316€/mois. White-label et custom domain disponibles — activez le portail client personnalisé pour une expérience premium maximale.",
            ['Configurer portail client', 'Ajouter un workspace', 'Générer rapport agence'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.1),rgba(37,99,235,0.08));border:1px solid rgba(139,92,246,0.25);border-radius:var(--fp-radius-lg);padding:20px 24px;margin-bottom:20px">
            <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
              <div style="font-size:28px">🏢</div>
              <div>
                <div style="font-size:14px;font-weight:800;margin-bottom:3px">Enterprise Lab — Ultra requis</div>
                <div style="font-size:12px;color:var(--fp-text-muted)">Multi-workspace, SSO, white-label portail, facturation client et analytics agence avancés.</div>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;margin-bottom:14px">
              \${['🏢 Multi-workspace','🔑 SSO Enterprise','🌐 Custom domain','🎨 Portail white-label','🧾 Facturation client','📋 Audit log RGPD','🚀 Onboarding dédié','🛡️ SLA 99.9% garanti'].map(f => \`<div style="font-size:11px;padding:8px 12px;background:rgba(255,255,255,0.04);border-radius:8px;border:1px solid rgba(255,255,255,0.07);color:var(--fp-text-soft)">\${f}</div>\`).join('')}
            </div>
            <button class="fp-btn fp-btn-primary" onclick="showToast('info','Passage Ultra…')" style="width:100%">Débloquer Enterprise Lab → Passer Ultra (199€/mois)</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Workspaces', String(workspaces.length), 'agence + clients', 'up')}
        \${statCard('MRR Agence', '316€', 'revenus récurrents', 'up')}
        \${statCard('Fonctions actives', String(features.filter(f => f.active).length) + '/' + features.length, 'Enterprise actives', 'up')}
        \${statCard('Conformité RGPD', 'En cours', 'audit log à activer', 'neutral')}
      </div>

      <!-- WORKSPACES -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">🏢 Gestion des workspaces</div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Nouveau workspace…')">+ Workspace</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${workspaces.map(ws => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid \${ws.color}22">
              <div style="width:36px;height:36px;border-radius:10px;background:\${ws.color}18;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">🏢</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(ws.name)}</div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${ws.clients} client(s) · \${ws.seats} siège(s) · Plan \${ws.plan}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${ws.mrr}</div>
                \${badge(ws.status, ws.status === 'Actif' ? '#22c55e' : '#2563EB')}
              </div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;flex-shrink:0" onclick="showToast('info','Gestion workspace…')">Gérer</button>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- FEATURE STATUS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">⚡ Fonctionnalités Enterprise</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:8px">
          \${features.map(f => \`
            <div style="padding:14px;border-radius:10px;border:1px solid \${f.active ? f.color + '33' : 'rgba(255,255,255,0.05)'};background:\${f.active ? f.color + '07' : 'rgba(255,255,255,0.01)'};\${f.locked ? 'opacity:0.55' : ''}">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
                <span style="font-size:16px">\${f.icon}</span>
                <span style="font-size:12px;font-weight:700;color:var(--fp-text);flex:1">\${escHtml(f.name)}</span>
                <div style="width:8px;height:8px;border-radius:50%;flex-shrink:0;background:\${f.active ? '#22c55e' : 'rgba(255,255,255,0.12)'};\${f.active ? 'box-shadow:0 0 6px rgba(34,197,94,0.4)' : ''}"></div>
              </div>
              <div style="font-size:10px;color:var(--fp-text-muted);line-height:1.4;margin-bottom:8px">\${escHtml(f.desc)}</div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;width:100%" onclick="showToast('info','\${f.locked ? 'Ultra requis' : f.active ? 'Configuré' : 'Activation…'}')">
                \${f.locked ? '🔒 Ultra requis' : f.active ? '✓ Configurer' : 'Activer →'}
              </button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Billing Command Center
  // ══════════════════════════════════════════════════════════
  const usageHealth = healthScore;
  const circ42 = 2 * Math.PI * 42;
  const criticalUsages = usages.filter(u => Math.round(u.v / u.max * 100) > 75);

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Billing Command Center
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.35);border-radius:20px;color:#2563EB">✦ SMART</span>
        </h1>
        <div class="fp-section-sub">Plan \${plan} actif · Prochain débit 01/06/2026 · Usage health \${usageHealth}/100</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Télécharger facture','fp-btn fp-btn-ghost fp-btn-sm','download',"onclick=\\"showToast('info','Téléchargement…')\\"" )}
        \${btn('Gérer le plan','fp-btn fp-btn-primary fp-btn-sm','zap',     "onclick=\\"navigateSub('plans')\\"" )}
      </div>
    </div>

    <!-- AI BILLING INTELLIGENCE -->
    \${isPro
      ? aiBlock(
          criticalUsages.length > 0
            ? "⚠ <strong>" + criticalUsages.map(u => u.l).join(' et ') + " approchent de la limite du plan</strong>. Recommandation : ajouter un pack ou passer Ultra avant d\'atteindre le seuil. Économie disponible : <strong>192€/an</strong> avec facturation annuelle."
            : "Usage sain — toutes les ressources sont sous contrôle. <strong>Facturation annuelle disponible : économisez 192€/an</strong>. 3 add-ons IA recommandés pour maximiser l\'efficacité de votre agence.",
          ['Optimiser mon plan', 'Voir les add-ons IA', 'Facturation annuelle']
        )
      : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">💡</div><div style="flex:1"><div style="font-size:13px;font-weight:700;margin-bottom:2px">IA Billing Insights — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Recommandations IA, prévisions d\'usage et optimisation de coûts automatisée.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
    }

    <!-- HERO KPI ROW -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Plan actuel', plan, 'actif · 79€/mois', 'up')}
      \${statCard('Usage Health', usageHealth + '/100', usageHealth > 70 ? 'Sain — sous contrôle' : 'Attention requise', usageHealth > 70 ? 'up' : 'down')}
      \${statCard('Potentiel upgrade', upgradeScore + '%', isUltra ? 'Plan optimal atteint' : 'Score upgrade détecté', isUltra ? 'up' : 'neutral')}
      \${statCard('Prochain débit', '79€', '01/06/2026 · dans 23j', 'neutral')}
    </div>

    <!-- PLAN + GAUGES -->
    <div class="fp-grid-2 fp-mb-20">
      <!-- PLAN HERO CARD -->
      <div class="fp-card" style="background:linear-gradient(135deg,rgba(37,99,235,0.08),rgba(139,92,246,0.05));border:1px solid rgba(37,99,235,0.2);position:relative;overflow:hidden">
        <div style="position:absolute;top:-20px;right:-20px;width:120px;height:120px;border-radius:50%;background:radial-gradient(circle,rgba(37,99,235,0.12),transparent 70%)"></div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;position:relative">
          <div style="width:52px;height:52px;border-radius:14px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.25);display:flex;align-items:center;justify-content:center;flex-shrink:0">
            \${svgIcon('zap').replace('width="14"','width="22"').replace('height="14"','height="22"').replace('stroke="currentColor"','stroke="#2563EB"')}
          </div>
          <div>
            <div style="font-size:22px;font-weight:900;color:var(--fp-text);font-family:var(--fp-font-head)">Plan \${plan}</div>
            <div style="font-size:12px;color:#22c55e;display:flex;align-items:center;gap:5px;margin-top:2px">
              \${svgIcon('check').replace('stroke="currentColor"','stroke="#22c55e"').replace('width="14"','width="12"').replace('height="14"','height="12"')}
              Actif · Renouvellement 01/06/2026
            </div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
          \${[
            { label:'Coût mensuel',       val:'\${isStd ? "29€" : isPro && !isUltra ? "79€" : "199€"}' },
            { label:'Économie annuelle',  val:'\${isStd ? "72€" : isPro && !isUltra ? "192€" : "480€"}' },
            { label:'Add-ons actifs',     val:'3 modules' },
            { label:'Prochaine facture',  val:'01/06/2026' },
          ].map(m => \`<div style="padding:10px 12px;border-radius:9px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.06)">
            <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:3px">\${escHtml(m.label)}</div>
            <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${m.val}</div>
          </div>\`).join('')}
        </div>
        <div style="display:flex;gap:8px">
          \${btn('Changer de plan','fp-btn fp-btn-primary fp-btn-sm','','onclick="navigateSub(\'plans\')"')}
          \${btn('Add-ons','fp-btn fp-btn-ghost fp-btn-sm','','onclick="navigateSub(\'addons\')"')}
        </div>
      </div>

      <!-- USAGE HEALTH GAUGE + TOP USAGES -->
      <div class="fp-card">
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px">
          <svg width="80" height="80" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="8"/>
            <circle cx="50" cy="50" r="42" fill="none" stroke="\${usageHealth > 70 ? '#22c55e' : '#f59e0b'}" stroke-width="8"
              stroke-dasharray="\${(usageHealth/100*circ42).toFixed(1)} \${(circ42*(1-usageHealth/100)).toFixed(1)}"
              stroke-linecap="round" transform="rotate(-90 50 50)"/>
            <text x="50" y="55" text-anchor="middle" font-size="22" font-weight="900" fill="\${usageHealth > 70 ? '#22c55e' : '#f59e0b'}" font-family="Outfit,sans-serif">\${usageHealth}</text>
          </svg>
          <div>
            <div style="font-size:14px;font-weight:700;color:var(--fp-text)">Usage Health Score</div>
            <div style="font-size:11px;color:\${usageHealth > 70 ? '#22c55e' : '#f59e0b'};font-weight:600;margin-bottom:4px">\${usageHealth > 70 ? '✓ Sain — toutes ressources sous contrôle' : '⚠ Quelques ressources à surveiller'}</div>
            <div style="font-size:10px;color:var(--fp-text-faint)">Score composite 9 ressources</div>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px">
          \${usages.slice(0, 4).map(u => {
            const pct = Math.round(u.v / u.max * 100);
            const pc  = pct > 80 ? '#ef4444' : pct > 60 ? '#f59e0b' : u.color;
            const vd  = u.unit ? u.v + u.unit : String(u.v);
            const md  = u.unit ? u.max + u.unit : String(u.max);
            return \`<div>
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:3px">
                <span style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(u.l)}</span>
                <span style="font-size:11px;font-weight:700;color:\${pc}">\${vd}/\${md} (\${pct}%)</span>
              </div>
              <div class="fp-progress-track" style="height:5px"><div class="fp-progress-fill" style="width:\${pct}%;background:\${pc}"></div></div>
            </div>\`;
          }).join('')}
          <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:4px;font-size:11px" onclick="navigateSub('usage')">Voir tous les usages →</button>
        </div>
      </div>
    </div>

    <!-- BILLING TIMELINE -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('clock').replace('stroke="currentColor"','stroke="#2563EB"')}
          Timeline facturation — Événements récents
        </div>
        <div style="position:relative;padding-left:20px">
          <div style="position:absolute;left:6px;top:0;bottom:0;width:1px;background:linear-gradient(to bottom,#2563EB,transparent)"></div>
          \${[
            { d:'01/05/2026', ev:'Facture payée — 79€',                     c:'#22c55e', ic:'check-circle' },
            { d:'28/04/2026', ev:'Usage AI Crédits > 40% — seuil atteint',  c:'#f59e0b', ic:'alert-triangle' },
            { d:'15/04/2026', ev:'Add-on Monitors +50 — activé',            c:'#2563EB', ic:'plus-circle' },
            { d:'01/04/2026', ev:'Facture payée — 79€',                     c:'#22c55e', ic:'check-circle' },
            { d:'01/03/2026', ev:'Passage Plan Pro — upgrade',              c:'#8b5cf6', ic:'zap' },
            { d:'01/02/2026', ev:'Facture payée — 49€ (Standard)',          c:'#22c55e', ic:'check-circle' },
          ].map(ev => \`<div style="position:relative;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,0.04)">
            <div style="position:absolute;left:-17px;top:2px;width:8px;height:8px;border-radius:50%;background:\${ev.c};box-shadow:0 0 6px \${ev.c}44"></div>
            <div style="font-size:9px;color:var(--fp-text-faint);margin-bottom:2px">\${escHtml(ev.d)}</div>
            <div style="font-size:11px;font-weight:600;color:var(--fp-text)">\${escHtml(ev.ev)}</div>
          </div>\`).join('')}
        </div>
      </div>

      <!-- QUICK NAV -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧭 Espaces de facturation</div>
        <div style="display:flex;flex-direction:column;gap:7px">
          \${[
            { label:'Plans & Abonnements',  sub:'plans',          icon:'💎', desc:'Comparer les plans · Upgrade · ROI' },
            { label:'Add-ons Marketplace',  sub:'addons',         icon:'🛒', desc:allAddons.filter(a => a.active).length + ' actifs sur ' + allAddons.length + ' disponibles' },
            { label:'Factures & Paiements', sub:'invoices',       icon:'🧾', desc:'6 factures · 286€ payés 2026' },
            { label:'Usage Analytics',      sub:'usage',          icon:'📊', desc:criticalUsages.length > 0 ? criticalUsages.length + ' ressource(s) à surveiller' : 'Toutes ressources saines' },
            { label:'IA Stratégiste',       sub:'ai-strategist',  icon:'🧠', desc:'4 recommandations · 192€ économies' },
            { label:'Enterprise Lab',       sub:'enterprise',     icon:'🏢', desc:isUltra ? '3 workspaces actifs' : 'Ultra requis — portail agence complet' },
          ].map(n => \`
            <div style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${n.sub}')">
              <span style="font-size:16px">\${n.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(n.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(n.desc)}</div>
              </div>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--fp-text-faint)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply ──────────────────────────────────────────────────────
src = replaceFunc(src, 'renderBilling', NEW_BILLING);
writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Billing fully replaced (7 sub-pages + sub-nav added).');
