import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

// Find renderOverview start
const START_MARKER = '\nfunction renderOverview() {';
const NEXT_MARKER  = '\n/* ── AUDITS ── */';

const si = src.indexOf(START_MARKER);
const ei = src.indexOf(NEXT_MARKER);
if (si === -1 || ei === -1) { console.error('MARKER NOT FOUND', si, ei); process.exit(1); }

const NEW_FN = `
function renderOverview() {
  const me = STATE.me;
  const avg = avgScore();
  const down = monitorsDown();
  const isPro  = me.plan === 'Pro' || me.plan === 'Ultra';
  const isUltra = me.plan === 'Ultra';
  const isStd  = !isPro && !isUltra;

  const activeMonitors = STATE.monitors.filter(m => m.status !== 'down').length;
  const totalMonitors  = STATE.monitors.length;
  const pingOk = totalMonitors > 0 ? Math.round(activeMonitors / totalMonitors * 100) : 100;
  const conversionScore = 61;
  const localScore = 74;
  const competitorPressure = 42;
  const revenueOpp = 2400;
  const growthMomentum = 78;
  const globalScore = Math.round((avg + localScore + conversionScore + growthMomentum) / 4);

  const healthMetrics = [
    { label:'SEO Health',         val:avg,                 max:100, color:'#2563EB',  icon:'🔍', trend:'+5',  unit:'/100', route:'audits' },
    { label:'Conversion',         val:conversionScore,     max:100, color:'#22c55e',  icon:'⚡', trend:'+3',  unit:'/100', route:'conversion' },
    { label:'Monitoring',         val:pingOk,              max:100, color:pingOk===100?'#22c55e':'#ef4444', icon:'📡', trend:down>0?'-'+down:'OK', unit:'%', route:'monitors' },
    { label:'Local Visibility',   val:localScore,          max:100, color:'#f59e0b',  icon:'📍', trend:'+8%', unit:'%',   route:'local-seo' },
    { label:'Competitor Pressure',val:competitorPressure,  max:100, color:'#ef4444',  icon:'⚔️', trend:'▲1',  unit:'/100', route:'competitors' },
    { label:'Growth Momentum',    val:growthMomentum,      max:100, color:'#8b5cf6',  icon:'🚀', trend:'+7',  unit:'/100', route:'overview' },
    { label:'Revenue Opportunity',val:Math.round(revenueOpp/50), max:100, color:'#06b6d4', icon:'💰', trend:'+12%', unit:'k€', route:'overview' },
    { label:'Workspace Stability',val:Math.round((activeMonitors/Math.max(totalMonitors,1))*100), max:100, color:'#22c55e', icon:'🏢', trend:'Stable', unit:'%', route:'overview' },
  ];

  const circ30 = 2 * Math.PI * 30;
  const circ22 = 2 * Math.PI * 22;

  const scoreGauge = (val, max, color, size=70, r=28) => {
    const c = 2*Math.PI*r;
    const fill = (val/max*c).toFixed(1);
    const empty = (c*(1-val/max)).toFixed(1);
    return \`<svg width="\${size}" height="\${size}" viewBox="0 0 \${size} \${size}">
      <circle cx="\${size/2}" cy="\${size/2}" r="\${r}" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="5"/>
      <circle cx="\${size/2}" cy="\${size/2}" r="\${r}" fill="none" stroke="\${color}" stroke-width="5"
        stroke-dasharray="\${fill} \${empty}" stroke-linecap="round"
        transform="rotate(-90 \${size/2} \${size/2})"/>
      <text x="\${size/2}" y="\${size/2+5}" text-anchor="middle" font-size="12" font-weight="900" fill="\${color}" font-family="Outfit,sans-serif">\${val}</text>
    </svg>\`;
  };

  const priorities = [
    { title:'Répondre aux 14 avis Google', impact:'Élevé', roi:'+12% visibilité locale', time:'30 min', urgency:'Urgent', color:'#ef4444', icon:'⭐', route:'local-seo' },
    { title:'Corriger CLS mobile sur 3 sites', impact:'Élevé', roi:'+8 pts Core Web Vitals', time:'2h', urgency:'Haute', color:'#f59e0b', icon:'📱', route:'audits' },
    { title:'Créer pages locales (arr. 13, 14)', impact:'Très élevé', roi:'+40% trafic local', time:'3h', urgency:'Haute', color:'#2563EB', icon:'📍', route:'local-seo' },
    { title:'Corriger balises meta (3 sites)', impact:'Moyen', roi:'+6 pts SEO moyen', time:'45 min', urgency:'Normale', color:'#8b5cf6', icon:'🏷️', route:'audits' },
    { title:'Lancer audit Plombier Paris', impact:'Élevé', roi:'Gain 15 pts estimé', time:'5 min', urgency:'Urgente', color:'#ef4444', icon:'🔍', route:'audits' },
  ];

  const opportunities = [
    { title:'Pages locales Paris 13-15', score:94, roi:'2 400€/mois estimé', type:'Local SEO', color:'#22c55e', icon:'📍', desc:'3 zones sans pages dédiées — fort potentiel de capture' },
    { title:'Mots-clés "urgence nuit"', score:87, roi:'+28% trafic nocturne', type:'SEO', color:'#2563EB', icon:'🔑', desc:'Volume: 890/mois · Difficulté: 32 · Vous pouvez dominer' },
    { title:'CTA mobile non visible', score:82, roi:'+18% taux conversion', type:'CRO', color:'#8b5cf6', icon:'📱', desc:'45% du trafic est mobile — bouton hors viewport' },
    { title:'Avis sans réponse (14)', score:79, roi:'+0.4 note Google', type:'Réputation', color:'#f59e0b', icon:'⭐', desc:'Impact direct Local Pack · Réponse en < 24h recommandée' },
    { title:'Duplicate content (5 pages)', score:71, roi:'+10 pts potentiel', type:'Technique', color:'#06b6d4', icon:'🔄', desc:'Canonicals manquants — Google indexe en double' },
  ];

  const wsModules = [
    { name:'Audits SEO',      score:avg,    status:avg>70?'ok':'warn', icon:'🔍', issues:avg<70?3:0, color:'#2563EB',  route:'audits' },
    { name:'Monitors',        score:pingOk, status:down===0?'ok':'down', icon:'📡', issues:down, color:'#22c55e', route:'monitors' },
    { name:'Local SEO',       score:74,     status:'ok',    icon:'📍', issues:2, color:'#f59e0b', route:'local-seo' },
    { name:'Concurrents',     score:58,     status:'warn',  icon:'⚔️', issues:1, color:'#ef4444', route:'competitors' },
    { name:'Conversion',      score:61,     status:'warn',  icon:'⚡', issues:3, color:'#8b5cf6', route:'conversion' },
    { name:'Data Explorer',   score:90,     status:'ok',    icon:'📊', issues:0, color:'#06b6d4', route:'data-explorer' },
    { name:'Rapports',        score:85,     status:'ok',    icon:'📄', issues:0, color:'#2563EB', route:'reports' },
    { name:'Alertes',         score:72,     status:'ok',    icon:'🔔', issues:2, color:'#f59e0b', route:'alerts' },
    { name:'IA Copilot',      score:95,     status:'ok',    icon:'🧠', issues:0, color:'#8b5cf6', route:'ai' },
  ];

  const liveEvents = [
    { time:'Il y a 2 min', type:'success', msg:'Monitor plombier-paris.fr — UP · Latence 187ms', icon:'📡' },
    { time:'Il y a 8 min', type:'warning', msg:'Avis Google reçu — 3 étoiles · Sans réponse', icon:'⭐' },
    { time:'Il y a 14 min', type:'info',   msg:'Audit SEO terminé — boulangerie-martin.fr · 71/100', icon:'🔍' },
    { time:'Il y a 31 min', type:'success', msg:'Mission "Schema markup" complétée par Lucas', icon:'✅' },
    { time:'Il y a 1h',     type:'warning', msg:'Concurrent Boulangerie Dupont : +4 pts détectés', icon:'⚔️' },
    { time:'Il y a 2h',     type:'error',  msg:'Alert déclenchée : CLS > 0.1 sur restaurant-lesoleil.com', icon:'⚠️' },
    { time:'Il y a 3h',     type:'info',   msg:'Rapport mensuel généré — 4 clients · PDF prêt', icon:'📄' },
  ];

  const forecasts = [
    { label:'Score SEO', current:avg,    forecast:avg+9,  unit:'/100', color:'#2563EB', data:[avg-6,avg-4,avg-2,avg,avg+2,avg+5,avg+9] },
    { label:'Trafic',    current:'+18%', forecast:'+31%', unit:'',     color:'#22c55e', data:[8,11,14,18,22,26,31] },
    { label:'Conversion',current:'2.4%', forecast:'3.1%', unit:'',     color:'#8b5cf6', data:[2.1,2.2,2.3,2.4,2.6,2.8,3.1] },
    { label:'Local Pack',current:'74%',  forecast:'88%',  unit:'',     color:'#f59e0b', data:[65,67,70,74,77,82,88] },
  ];

  const achievements = [
    { icon:'🏆', title:'26 missions complétées', desc:'Record personnel — Mai 2026', color:'#f59e0b', unlocked:true },
    { icon:'🔥', title:'Streak 14 jours',        desc:'Optimisation quotidienne active', color:'#ef4444', unlocked:true },
    { icon:'⭐', title:'Score 70+ atteint',       desc:'Benchmark professionnel franchi', color:'#22c55e', unlocked:true },
    { icon:'🚀', title:'Premier Ultra Client',    desc:'Prochain objectif : 80/100', color:'#8b5cf6', unlocked:false },
    { icon:'💎', title:'100% Uptime — 30 jours', desc:'Stabilité monitoring exemplaire', color:'#06b6d4', unlocked:false },
  ];

  const quickActions = [
    { label:'Audit SEO',         icon:'🔍', color:'#2563EB', action:"navigate('audits')" },
    { label:'Rapport Exécutif',  icon:'📄', color:'#22c55e', action:"showToast('info','Génération rapport…')" },
    { label:'Analyser Concurrents', icon:'⚔️', color:'#ef4444', action:"navigate('competitors')" },
    { label:'Nouveau Monitor',   icon:'📡', color:'#f59e0b', action:"showToast('info','Nouveau monitor…')" },
    { label:'Créer Mission',     icon:'🎯', color:'#8b5cf6', action:"navigate('missions')" },
    { label:'Conversion IA',     icon:'⚡', color:'#06b6d4', action:"navigate('conversion')" },
    { label:'Local SEO',         icon:'📍', color:'#22c55e', action:"navigate('local-seo')" },
    { label:'Voir les Alertes',  icon:'🔔', color:'#f59e0b', action:"navigate('alerts')" },
  ];

  const digestItems = [
    { type:'success', msg:'+7 pts de score SEO moyen ce mois — meilleure progression de l\'année' },
    { type:'warning', msg:'14 avis Google en attente de réponse sur 3 fiches GBP' },
    { type:'info',    msg:'3 opportunités locales haute valeur détectées par l\'IA ce matin' },
    { type:'error',   msg:'Concurrent Dupont : +4 pts · Surveillance prioritaire activée' },
    { type:'success', msg:'26 missions complétées en mai — record personnel' },
  ];

  const typeColor = { success:'#22c55e', warning:'#f59e0b', info:'#2563EB', error:'#ef4444' };
  const typeIcon  = { success:'✅', warning:'⚠️', info:'💡', error:'🚨' };

  return \`
    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- EXECUTIVE HERO HEADER -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div style="position:relative;overflow:hidden;border-radius:var(--fp-radius-xl);margin-bottom:24px;background:linear-gradient(135deg,rgba(5,8,16,0.98),rgba(17,24,60,0.95));border:1px solid rgba(37,99,235,0.2);padding:28px 28px 24px">
      <!-- Background glow orbs -->
      <div style="position:absolute;top:-60px;right:-60px;width:280px;height:280px;border-radius:50%;background:radial-gradient(circle,rgba(37,99,235,0.12),transparent 70%);pointer-events:none"></div>
      <div style="position:absolute;bottom:-40px;left:-40px;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(139,92,246,0.1),transparent 70%);pointer-events:none"></div>

      <!-- Header row -->
      <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:24px;position:relative;flex-wrap:wrap;gap:16px">
        <div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
            <div style="width:10px;height:10px;border-radius:50%;background:#22c55e;box-shadow:0 0 10px rgba(34,197,94,0.6);animation:fp-pulse-dot 2s ease-in-out infinite"></div>
            <span style="font-size:11px;font-weight:700;color:#22c55e;letter-spacing:0.1em;text-transform:uppercase">LIVE · Command Center</span>
          </div>
          <h1 style="font-size:26px;font-weight:900;color:var(--fp-text);margin:0 0 4px;font-family:var(--fp-font-head);line-height:1.1">Bonjour, \${escHtml(me.firstName)} 👋</h1>
          <div style="font-size:13px;color:var(--fp-text-muted)">Plateforme IA · Plan <strong style="color:#2563EB">\${escHtml(me.plan)}</strong> · Score global <strong style="color:\${scoreColor(globalScore)}">\${globalScore}/100</strong></div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <div class="fp-view-toggle" id="chart-range-toggle">
            <button class="fp-view-toggle-btn" data-range="1">Auj.</button>
            <button class="fp-view-toggle-btn" data-range="3">3j</button>
            <button class="fp-view-toggle-btn active" data-range="7">7j</button>
            <button class="fp-view-toggle-btn" data-range="30">30j</button>
          </div>
          \${btn('Actualiser','fp-btn fp-btn-ghost fp-btn-sm','refresh','id="refresh-btn"')}
          \${btn('Exporter','fp-btn fp-btn-ghost fp-btn-sm','download','id="export-btn"')}
        </div>
      </div>

      <!-- 8 Health Gauge Grid -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;position:relative">
        \${healthMetrics.map(h => {
          const col = h.val >= 70 ? '#22c55e' : h.val >= 50 ? '#f59e0b' : '#ef4444';
          const isUp = h.trend.startsWith('+');
          const isNeg = h.trend.startsWith('▲') || h.trend.startsWith('-');
          return \`<div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:14px 12px;cursor:pointer;transition:all 0.18s" onclick="navigate('\${h.route}')">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:10px">
              <div>
                <div style="font-size:14px;margin-bottom:2px">\${h.icon}</div>
                <div style="font-size:10px;font-weight:700;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:0.06em;line-height:1.2">\${h.label}</div>
              </div>
              <div style="font-size:10px;font-weight:700;color:\${isNeg?'#ef4444':isUp?'#22c55e':'#94a3b8'};flex-shrink:0">\${h.trend}</div>
            </div>
            \${scoreGauge(h.val, h.max, h.color, 62, 24)}
            <div style="margin-top:6px">
              <div class="fp-progress-track" style="height:3px;border-radius:99px"><div class="fp-progress-fill" style="width:\${Math.round(h.val/h.max*100)}%;background:\${h.color};border-radius:99px"></div></div>
            </div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- AI EXECUTIVE SUMMARY -->
    <!-- ═══════════════════════════════════════════════════════ -->
    \${isPro
      ? aiBlock(
          'Votre portefeuille affiche un score global de <strong>' + globalScore + '/100</strong> — en hausse de +7 pts ce mois. ' +
          (down > 0 ? '<span style="color:#ef4444">⚠ ' + down + ' monitor(s) DOWN — intervention requise.</span> ' : 'Monitoring optimal. ') +
          'IA recommande 3 actions haute priorité : <strong>répondre aux avis Google</strong> (+12% visibilité locale), ' +
          '<strong>créer les pages locales Paris 13-15</strong> (+40% trafic), et <strong>corriger le CLS mobile</strong> (+18% conversion). ' +
          'Potentiel de revenus supplémentaires estimé : <strong>2 400€/mois</strong>.',
          ['Voir le plan d\'action', 'Créer les missions', 'Analyser les concurrents', 'Générer rapport exécutif']
        )
      : \`<div style="padding:18px 20px;background:linear-gradient(135deg,rgba(37,99,235,0.08),rgba(139,92,246,0.05));border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;gap:14px;align-items:center">
          <div style="font-size:28px">🧠</div>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:700;margin-bottom:3px">IA Executive Summary — Pro requis</div>
            <div style="font-size:12px;color:var(--fp-text-muted)">Obtenez des analyses stratégiques IA, des prévisions d\'usage et des recommandations personnalisées.</div>
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="navigate('billing')">Passer Pro</button>
        </div>\`
    }

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- KPI STAT ROW -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Score SEO', avg + '/100', '+5 pts ce mois', 'up')}
      \${statCard('Monitors actifs', activeMonitors + '/' + totalMonitors, down > 0 ? down + ' DOWN' : 'Tous UP', down > 0 ? 'down' : 'up')}
      \${statCard('Opportunités IA', '5 détectées', '2 400€/mois potentiel', 'up')}
      \${statCard('Missions complétées', '26', 'record · +8 vs M-1', 'up')}
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- LIVE COMMAND CENTER + WORKSPACE MAP -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- LIVE COMMAND CENTER -->
      <div class="fp-card" style="border:1px solid rgba(37,99,235,0.15)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div style="display:flex;align-items:center;gap:8px">
            <div style="width:8px;height:8px;border-radius:50%;background:#22c55e;animation:fp-pulse-dot 2s infinite"></div>
            <span class="fp-card-title" style="margin-bottom:0">Live Command Center</span>
          </div>
          <span style="font-size:10px;color:var(--fp-text-faint)">Mise à jour en temps réel</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:1px">
          \${liveEvents.map(ev => {
            const c = typeColor[ev.type] || '#2563EB';
            return \`<div style="display:flex;align-items:flex-start;gap:10px;padding:9px 10px;border-radius:9px;background:rgba(255,255,255,0.015);margin-bottom:2px;border-left:2px solid \${c}22">
              <div style="font-size:14px;flex-shrink:0;margin-top:1px">\${ev.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:11px;color:var(--fp-text);line-height:1.4">\${ev.msg}</div>
                <div style="font-size:10px;color:var(--fp-text-faint);margin-top:2px">\${ev.time}</div>
              </div>
              <div style="width:6px;height:6px;border-radius:50%;background:\${c};flex-shrink:0;margin-top:4px"></div>
            </div>\`;
          }).join('')}
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:10px;font-size:11px" onclick="navigate('activity')">Voir toute l\'activité →</button>
      </div>

      <!-- WORKSPACE MAP -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🗺️ Workspace Intelligence Map</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
          \${wsModules.map(m => {
            const sc = m.score >= 70 ? '#22c55e' : m.score >= 50 ? '#f59e0b' : '#ef4444';
            const bg = m.status === 'ok' ? 'rgba(34,197,94,0.04)' : m.status === 'down' ? 'rgba(239,68,68,0.07)' : 'rgba(245,158,11,0.05)';
            const br = m.status === 'ok' ? 'rgba(34,197,94,0.15)' : m.status === 'down' ? 'rgba(239,68,68,0.2)' : 'rgba(245,158,11,0.15)';
            return \`<div style="padding:10px;border-radius:10px;background:\${bg};border:1px solid \${br};cursor:pointer;transition:all 0.15s" onclick="navigate('\${m.route}')">
              <div style="font-size:16px;margin-bottom:4px">\${m.icon}</div>
              <div style="font-size:10px;font-weight:700;color:var(--fp-text);margin-bottom:4px;line-height:1.2">\${m.name}</div>
              <div style="font-size:12px;font-weight:800;color:\${sc}">\${m.score}</div>
              \${m.issues > 0 ? \`<div style="font-size:9px;color:#ef4444;margin-top:2px">\${m.issues} issue\${m.issues>1?'s':''}</div>\` : \`<div style="font-size:9px;color:#22c55e;margin-top:2px">✓ OK</div>\`}
            </div>\`;
          }).join('')}
        </div>
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- BUSINESS OPPORTUNITIES + AI PRIORITIES -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- OPPORTUNITIES HUB -->
      <div class="fp-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">💎 Business Opportunities</div>
          <span style="font-size:10px;font-weight:700;color:#22c55e;background:rgba(34,197,94,0.1);padding:2px 8px;border-radius:20px">IA Scoring</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${opportunities.map(o => \`
            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);cursor:pointer;transition:all 0.15s" onclick="showToast('info','Analyse : \${o.title}…')">
              <div style="font-size:18px;flex-shrink:0">\${o.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:2px">\${escHtml(o.title)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(o.desc)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:11px;font-weight:800;color:\${o.color}">\${o.score}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">\${o.roi}</div>
              </div>
              <div style="width:36px;flex-shrink:0">
                <div class="fp-progress-track" style="height:4px"><div class="fp-progress-fill" style="width:\${o.score}%;background:\${o.color}"></div></div>
              </div>
            </div>
          \`).join('')}
        </div>
        <div style="margin-top:12px;padding:10px 12px;background:rgba(37,99,235,0.05);border:1px solid rgba(37,99,235,0.15);border-radius:9px;display:flex;align-items:center;justify-content:space-between">
          <span style="font-size:11px;color:var(--fp-text-muted)">Potentiel total identifié</span>
          <span style="font-size:14px;font-weight:800;color:#22c55e">~2 400€/mois</span>
        </div>
      </div>

      <!-- AI PRIORITY ENGINE -->
      <div class="fp-card" style="background:linear-gradient(135deg,rgba(139,92,246,0.05),rgba(5,8,16,0.8));border:1px solid rgba(139,92,246,0.15)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">🧠 AI Priority Engine</div>
          \${badge('IA Powered','#8b5cf6')}
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${priorities.map((p,i) => \`
            <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:10px;border:1px solid \${p.color}22;background:\${p.color}06;cursor:pointer" onclick="navigate('\${p.route}')">
              <div style="width:22px;height:22px;border-radius:7px;background:\${p.color}20;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:12px">\${p.icon}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(p.title)}</div>
                <div style="display:flex;gap:6px;flex-wrap:wrap">
                  \${badge(p.urgency,p.color)}
                  <span style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(p.roi)}</span>
                  <span style="font-size:10px;color:var(--fp-text-faint)">· \${escHtml(p.time)}</span>
                </div>
              </div>
              <div style="font-size:18px;font-weight:900;color:\${p.color};opacity:0.3;font-family:var(--fp-font-head);flex-shrink:0">\${i+1}</div>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- EXECUTIVE FORECASTING -->
    <!-- ═══════════════════════════════════════════════════════ -->
    \${isPro ? \`
    <div class="fp-card fp-mb-20" style="border:1px solid rgba(6,182,212,0.15)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <div style="display:flex;align-items:center;gap:8px">
          <div style="font-size:18px">🔮</div>
          <div class="fp-card-title" style="margin-bottom:0">Executive Forecasting — 30 jours</div>
        </div>
        \${badge('IA Prédictif','#06b6d4')}
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
        \${forecasts.map(f => \`
          <div style="padding:14px;border-radius:12px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06)">
            <div style="font-size:11px;font-weight:600;color:var(--fp-text-muted);margin-bottom:8px">\${f.label}</div>
            \${sparklineSVG(f.data, f.color, 200, 36)}
            <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-top:8px">
              <div>
                <div style="font-size:10px;color:var(--fp-text-faint)">Actuel</div>
                <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${f.current}</div>
              </div>
              <div style="text-align:right">
                <div style="font-size:10px;color:var(--fp-text-faint)">J+30</div>
                <div style="font-size:13px;font-weight:700;color:\${f.color}">\${f.forecast}</div>
              </div>
            </div>
          </div>
        \`).join('')}
      </div>
    </div>
    \` : \`
    <div style="padding:16px 20px;background:rgba(6,182,212,0.05);border:1px solid rgba(6,182,212,0.15);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;gap:14px;align-items:center">
      <div style="font-size:26px">🔮</div>
      <div style="flex:1">
        <div style="font-size:13px;font-weight:700;margin-bottom:3px">Executive Forecasting — Pro requis</div>
        <div style="font-size:12px;color:var(--fp-text-muted)">Prévisions IA trafic, conversion, Local SEO et revenus sur 30 jours.</div>
      </div>
      <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="navigate('billing')">Activer →</button>
    </div>
    \`}

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- MOMENTUM ENGINE + DAILY DIGEST -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="fp-grid-2 fp-mb-20">

      <!-- MOMENTUM & ACHIEVEMENTS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🏆 Workspace Momentum</div>

        <!-- Streak -->
        <div style="padding:12px 14px;border-radius:10px;background:linear-gradient(135deg,rgba(239,68,68,0.08),rgba(245,158,11,0.05));border:1px solid rgba(239,68,68,0.15);display:flex;align-items:center;gap:12px;margin-bottom:12px">
          <div style="font-size:28px">🔥</div>
          <div style="flex:1">
            <div style="font-size:14px;font-weight:800;color:var(--fp-text)">Streak 14 jours</div>
            <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:6px">Optimisation quotidienne active — record à 21j</div>
            <div style="display:flex;gap:3px">
              \${Array.from({length:21}).map((_,i) => \`<div style="width:10px;height:10px;border-radius:3px;background:\${i<14?'#ef4444':'rgba(255,255,255,0.07)'}"></div>\`).join('')}
            </div>
          </div>
        </div>

        <!-- Score progression -->
        <div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span style="font-size:11px;color:var(--fp-text-muted)">Progression score SEO — Objectif 80/100</span>
            <span style="font-size:11px;font-weight:700;color:#2563EB">\${avg}/100</span>
          </div>
          <div class="fp-progress-track" style="height:6px;border-radius:99px">
            <div class="fp-progress-fill" style="width:\${Math.round(avg/80*100)}%;background:linear-gradient(90deg,#2563EB,#8b5cf6);border-radius:99px"></div>
          </div>
          <div style="font-size:10px;color:var(--fp-text-faint);margin-top:3px">Encore \${80-avg} pts pour atteindre l\'objectif Elite</div>
        </div>

        <!-- Achievements -->
        <div style="display:flex;flex-direction:column;gap:6px">
          \${achievements.map(a => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:\${a.unlocked?a.color+'08':'rgba(255,255,255,0.02)'};border:1px solid \${a.unlocked?a.color+'22':'rgba(255,255,255,0.05)'};opacity:\${a.unlocked?1:0.5}">
              <div style="font-size:18px">\${a.icon}</div>
              <div style="flex:1">
                <div style="font-size:11px;font-weight:700;color:var(--fp-text)">\${escHtml(a.title)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(a.desc)}</div>
              </div>
              \${a.unlocked ? \`<div style="font-size:10px;font-weight:700;color:\${a.color}">✓</div>\` : \`<div style="font-size:10px;color:var(--fp-text-faint)">🔒</div>\`}
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- DAILY DIGEST -->
      <div class="fp-card" style="background:linear-gradient(135deg,rgba(37,99,235,0.06),rgba(5,8,16,0.9));border:1px solid rgba(37,99,235,0.15)">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
          <div style="font-size:18px">📋</div>
          <div class="fp-card-title" style="margin-bottom:0">Daily Digest — \${new Date().toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'})}</div>
        </div>

        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px">
          \${digestItems.map(d => \`
            <div style="display:flex;align-items:flex-start;gap:10px;padding:9px 11px;border-radius:9px;background:\${typeColor[d.type]}08;border-left:3px solid \${typeColor[d.type]}">
              <span style="font-size:13px;flex-shrink:0">\${typeIcon[d.type]}</span>
              <span style="font-size:11px;color:var(--fp-text);line-height:1.45">\${d.msg}</span>
            </div>
          \`).join('')}
        </div>

        <!-- Quick stat summary -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding-top:14px;border-top:1px solid var(--fp-border)">
          \${[
            { label:'Audits lancés', val:'4', color:'#2563EB' },
            { label:'Missions actives', val:'8', color:'#8b5cf6' },
            { label:'Alertes', val:'2', color:'#f59e0b' },
          ].map(s => \`<div style="text-align:center">
            <div style="font-size:20px;font-weight:800;color:\${s.color};font-family:var(--fp-font-head)">\${s.val}</div>
            <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(s.label)}</div>
          </div>\`).join('')}
        </div>
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- QUICK ACTIONS HUB -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
        <div style="font-size:18px">⚡</div>
        <div class="fp-card-title" style="margin-bottom:0">Quick Actions Hub</div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
        \${quickActions.map(q => \`
          <button style="padding:14px 10px;border-radius:12px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.07);cursor:pointer;transition:all 0.18s;display:flex;flex-direction:column;align-items:center;gap:8px;width:100%;outline:none" onclick="\${q.action}" onmouseover="this.style.background='\${q.color}12';this.style.borderColor='\${q.color}30'" onmouseout="this.style.background='rgba(255,255,255,0.02)';this.style.borderColor='rgba(255,255,255,0.07)'">
            <div style="font-size:22px">\${q.icon}</div>
            <div style="font-size:11px;font-weight:700;color:var(--fp-text);text-align:center;line-height:1.2">\${escHtml(q.label)}</div>
          </button>
        \`).join('')}
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- ACTIVITY + TOP SITES -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="fp-grid-2">
      <div class="fp-card">
        <div class="fp-flex-between" style="margin-bottom:12px">
          <span class="fp-card-title" style="margin-bottom:0">Activité récente</span>
          <button class="fp-link-btn" id="activity-see-all">Voir tout →</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${ACTIVITY_FEED.slice(0,6).map(item => {
            const colors = {success:'#22c55e',error:'#ef4444',info:'#2563EB',warning:'#f59e0b',purple:'#8b5cf6'};
            const c = colors[item.type] || '#2563EB';
            return \`<div class="fp-activity-item">
              <div class="fp-activity-icon" style="background:\${c}18">\${svgIcon(item.icon).replace('stroke="currentColor"',\`stroke="\${c}"\`)}</div>
              <div>
                <div class="fp-activity-title">\${item.title}</div>
                <div class="fp-activity-desc">\${item.desc}</div>
                <div class="fp-activity-time">Il y a \${item.time}</div>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <div class="fp-card">
        <div class="fp-flex-between" style="margin-bottom:12px">
          <span class="fp-card-title" style="margin-bottom:0">Top sites — Performance</span>
          <button class="fp-link-btn" onclick="navigate('audits')">Tous les audits →</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${[
            {url:'coiffure-lyon.fr',       score:84, trend:'up',      delta:'+2', audits:1},
            {url:'boulangerie-martin.fr',  score:71, trend:'up',      delta:'+5', audits:4},
            {url:'restaurant-lesoleil.com',score:61, trend:'up',      delta:'+3', audits:2},
            {url:'pharmacie-centre.fr',    score:55, trend:'neutral',  delta:'—',  audits:1},
            {url:'plombier-paris.fr',      score:38, trend:'down',    delta:'-2', audits:5},
          ].map(s => \`
            <div style="display:flex;align-items:center;gap:8px;padding:9px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);cursor:pointer" onclick="navigate('audits')">
              <div style="width:8px;height:8px;border-radius:50%;flex-shrink:0;background:\${s.score>=70?'#22c55e':s.score>=50?'#f59e0b':'#ef4444'}"></div>
              <div style="flex:1;font-size:11px;font-weight:600;color:var(--fp-text-soft);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${s.url}</div>
              <div style="font-size:12px;font-weight:800;color:\${scoreColor(s.score)}">\${s.score}/100</div>
              <div style="font-size:11px;font-weight:700;color:\${s.trend==='up'?'#22c55e':s.trend==='down'?'#ef4444':'var(--fp-text-faint)'}">\${s.trend==='up'?'↑':s.trend==='down'?'↓':'—'} \${s.delta}</div>
              \${sparklineSVG([s.score-8,s.score-5,s.score-3,s.score], scoreColor(s.score), 50, 20)}
            </div>
          \`).join('')}
        </div>
        <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--fp-border);display:flex;align-items:center;justify-content:space-between">
          <span style="font-size:11px;color:var(--fp-text-faint)">Score moyen portefeuille</span>
          <span style="font-size:14px;font-weight:800;color:\${scoreColor(avg)}">\${avg}/100</span>
        </div>
      </div>
    </div>
  \`;
}

`;

src = src.slice(0, si) + NEW_FN + src.slice(ei);
writeFileSync(file, src, 'utf8');
console.log('renderOverview replaced — ' + NEW_FN.length + ' chars');
