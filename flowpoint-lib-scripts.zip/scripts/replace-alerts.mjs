import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

function replaceFunc(src, name, newBody) {
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  console.log(`\u2713 Replaced ${name} (${i - start} chars)`);
  return src.slice(0, start) + newBody + src.slice(i + 1);
}

// ── 1. Update sub-nav: 4 → 8 sub-pages ───────────────────────
const OLD_SUBNAV = `'alerts-center': [{id:null,label:'Toutes'},{id:'critical',label:'Critiques'},{id:'warnings',label:'Avertissements'},{id:'info',label:'Info'}],`;
const NEW_SUBNAV = `'alerts-center': [{id:null,label:'Command Center'},{id:'incidents',label:'Incidents'},{id:'seo',label:'SEO'},{id:'performance',label:'Performance'},{id:'conversion',label:'Conversion'},{id:'local',label:'Local SEO'},{id:'competitor',label:'Concurrents'},{id:'ai',label:'IA Threat Lab'}],`;

if (src.includes(OLD_SUBNAV)) {
  src = src.replace(OLD_SUBNAV, NEW_SUBNAV);
  console.log('\u2713 Updated alerts-center sub-nav (4 \u2192 8)');
} else { console.error('SUB-NAV NOT FOUND'); }

// ══════════════════════════════════════════════════════════════
// renderAlertsCenter() — full 8-sub-page AI threat platform
// ══════════════════════════════════════════════════════════════
const NEW_ALERTS = `function renderAlertsCenter() {
  const sub = STATE.subRoute;
  const plan = STATE.me?.plan || 'Pro';
  const isStd   = plan === 'Standard';
  const isPro   = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  // ── Rule-based alerts from STATE ────────────────────────────
  const ruleAlerts = (STATE.alertEvents || []).map(ev => ({
    id: ev.id,
    sev: ev.severity === 'critical' ? 'critical' : 'warning',
    cat: 'Règle',
    icon: ev.ruleType === 'seo_score' ? 'trending-up' : ev.ruleType === 'latency' ? 'activity' : 'wifi',
    title: "Règle déclenchée : " + escHtml(ev.ruleName),
    desc: escHtml(ev.message),
    time: new Date(ev.time).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    color: ev.severity === 'critical' ? '#ef4444' : '#f59e0b',
    ruleSource: ev.ruleName,
    impact: "Surveillance automatique active",
  }));

  // ── Static enriched alert feed ───────────────────────────────
  const staticAlerts = [
    { id:'al1',  sev:'critical',  cat:'Monitor',    icon:'wifi-off',     title:"Monitor DOWN — restaurant-lesoleil.com",      desc:"Inaccessible depuis 44 min — impact client direct estimé -180€",             time:"44 min",  color:'#ef4444', impact:"Élevé — 18% trafic affecté"   },
    { id:'al2',  sev:'critical',  cat:'SEO',        icon:'trending-down', title:"Score SEO critique — plombier-paris.fr",       desc:"38/100 avec 22 problèmes non résolus — perte position Google estimée",        time:"2h",      color:'#ef4444', impact:"Critique — risque ranking"    },
    { id:'al3',  sev:'critical',  cat:'Performance',icon:'activity',      title:"Latence élevée — coiffeur-lyon.com",           desc:"Répond en 890ms (seuil 500ms) — Core Web Vitals dégradés",                   time:"3h",      color:'#ef4444', impact:"Moyen — UX mobile impactée"   },
    { id:'al4',  sev:'critical',  cat:'Local SEO',  icon:'message-circle',title:"14 avis Google sans réponse",                  desc:"3 fiches GBP concernées — impact note moyenne et confiance client",          time:"1j",      color:'#ef4444', impact:"Élevé — note en baisse"       },
    { id:'al5',  sev:'warning',   cat:'Quota',      icon:'alert-circle',  title:"Quota audits à 80% — 240/300 utilisés",        desc:"60 audits restants ce mois — penser à optimiser les planifications",         time:"2j",      color:'#f59e0b', impact:"Faible — risque dépassement"  },
    { id:'al6',  sev:'warning',   cat:'Concurrent', icon:'users',         title:"Boulangerie Dupont +12 positions ce mois",      desc:"Concurrent en accélération locale — risque perte Local Pack",                time:"2j",      color:'#f59e0b', impact:"Moyen — pression concurrence" },
    { id:'al7',  sev:'warning',   cat:'Conversion', icon:'trending-down', title:"Conversion weekend à 0%",                      desc:"Sam 3 et dim 4 mai — 0 client malgré 1200 sessions",                         time:"3j",      color:'#f59e0b', impact:"Critique — -800€ estimé"      },
    { id:'al8',  sev:'info',      cat:'Monitor',    icon:'check-circle',  title:"Monitor de retour — restaurant-lesoleil.com",  desc:"Disponibilité retrouvée après 44 min — incident clos",                       time:"Hier",    color:'#22c55e', impact:"Résolu"                        },
    { id:'al9',  sev:'info',      cat:'Rapport',    icon:'file-text',     title:"Rapport mensuel prêt",                          desc:"Rapport SEO Executive Mai 2026 — 14 pages disponibles",                      time:"Hier",    color:'#2563EB', impact:"Info — aucun risque"           },
    { id:'al10', sev:'info',      cat:'SEO',        icon:'trending-up',   title:"Score amélioré — boulangerie-martin.fr",       desc:"82/100 (+4 pts) — audit complet terminé avec succès",                        time:"2j",      color:'#22c55e', impact:"Positif"                       },
  ];

  const allAlerts = [...ruleAlerts, ...staticAlerts];
  const criticals = allAlerts.filter(a => a.sev === 'critical');
  const warnings  = allAlerts.filter(a => a.sev === 'warning');

  // ══════════════════════════════════════════════════════════
  // SUB: INCIDENT RESPONSE CENTER
  // ══════════════════════════════════════════════════════════
  if (sub === 'incidents') {
    const incidents = [
      {
        id: 'inc1', sev: 'critical', status: 'Actif',
        title: "Monitor DOWN — restaurant-lesoleil.com",
        systems: ['Monitor', 'Uptime', 'Trafic'],
        impact: "Perte estimée 180€ revenue — 18% trafic affecté",
        cause: "Timeout serveur — probable surcharge backend",
        since: "09/05/2026 · 14h32", duration: "44 min",
        steps: ["Vérifier le serveur hébergeur", "Redémarrer le service web", "Activer le mode maintenance"],
        color: '#ef4444',
      },
      {
        id: 'inc2', sev: 'critical', status: 'Analyse',
        title: "Conversion weekend à 0% — sam-dim 3-4 mai",
        systems: ['Conversion', 'UX', 'Mobile'],
        impact: "800€ revenue manqués — 1200 sessions sans conversion",
        cause: "Probable formulaire contact non fonctionnel en mobile",
        since: "03/05/2026 · 00h00", duration: "48h",
        steps: ["Tester le formulaire mobile", "Vérifier les erreurs JS", "Analyser les sessions abandonnées"],
        color: '#ef4444',
      },
      {
        id: 'inc3', sev: 'warning', status: 'Surveillé',
        title: "Latence élevée — coiffeur-lyon.com",
        systems: ['Performance', 'Core Web Vitals'],
        impact: "UX dégradée — conversion mobile à risque",
        cause: "Images non compressées — absence de CDN",
        since: "09/05/2026 · 11h14", duration: "3h",
        steps: ["Optimiser les images (WebP)", "Activer le cache navigateur", "Analyser les ressources bloquantes"],
        color: '#f59e0b',
      },
      {
        id: 'inc4', sev: 'warning', status: 'Surveillé',
        title: "Score SEO critique — plombier-paris.fr",
        systems: ['SEO', 'Audit', 'Rankings'],
        impact: "Risque perte positions Google — 22 problèmes non résolus",
        cause: "Balises title manquantes, vitesse mobile 42/100, maillage interne insuffisant",
        since: "07/05/2026 · 09h00", duration: "2j",
        steps: ["Corriger les balises title (3 pages)", "Optimiser vitesse mobile", "Ajouter maillage interne"],
        color: '#f59e0b',
      },
    ];
    const rootCauses = [
      { icon: '🖥️', title: "Surcharge hébergeur",          prob: 78, color: '#ef4444', desc: "Le pic de trafic Maps (+21% ce mois) dépasse la capacité configurée" },
      { icon: '📱', title: "Régression mobile non détectée", prob: 64, color: '#f59e0b', desc: "Mise à jour CSS semaine 18 a cassé le formulaire sur iOS Safari" },
      { icon: '⚡', title: "Images non optimisées",          prob: 91, color: '#ef4444', desc: "6 images > 500KB chargées sans lazy loading ni compression WebP" },
    ];
    return \`
      \${isUltra
        ? aiBlock("2 incidents actifs — impact business estimé <strong>-980€</strong>. Priorité absolue : le formulaire mobile cassé (weekend 0% conversion). Corrélation détectée : la latence coiffeur-lyon.com est directement liée aux images non compressées (+430ms).",
            ['Plan de résolution IA', 'Rapport incident PDF', 'Alerter équipe'])
        : \`<div style="padding:14px 16px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">🚨</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Incident Response — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse IA des incidents, root cause analysis et plans de résolution automatiques.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Incidents actifs', String(incidents.filter(i => i.status === 'Actif').length), 'action immédiate', 'down')}
        \${statCard('Sous surveillance', String(incidents.filter(i => i.status === 'Surveillé').length), 'monitoring en cours', 'neutral')}
        \${statCard('Impact business', '-980€', 'estimé ce mois', 'down')}
        \${statCard('MTTR moyen', '2h 18min', 'Mean Time To Resolve', 'neutral')}
      </div>

      <!-- INCIDENT CARDS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('alert-triangle').replace('stroke="currentColor"','stroke="#ef4444"')}
          Incidents actifs — Priorisation IA
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${incidents.map(inc => \`
            <div style="padding:16px;border-radius:12px;border:1px solid \${inc.color}28;background:\${inc.color}06;border-left-width:4px">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px">
                <div>
                  <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                    \${badge(inc.sev === 'critical' ? 'Critique' : 'Alerte', inc.color)}
                    \${badge(inc.status, inc.status === 'Actif' ? '#ef4444' : '#f59e0b')}
                    \${inc.systems.map(s => \`<span style="font-size:9px;padding:2px 6px;border-radius:6px;background:rgba(255,255,255,0.06);color:var(--fp-text-faint)">\${s}</span>\`).join('')}
                  </div>
                  <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(inc.title)}</div>
                </div>
                <div style="text-align:right;flex-shrink:0">
                  <div style="font-size:11px;color:var(--fp-text-faint)">\${escHtml(inc.since)}</div>
                  <div style="font-size:11px;font-weight:700;color:\${inc.color}">⏱ \${escHtml(inc.duration)}</div>
                </div>
              </div>
              <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:8px">⚠️ <strong>Impact :</strong> \${escHtml(inc.impact)}</div>
              <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:10px">🔎 <strong>Cause probable :</strong> \${escHtml(inc.cause)}</div>
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                \${inc.steps.map((s, idx) => \`<span style="font-size:10px;padding:3px 8px;border-radius:6px;background:\${inc.color}14;color:\${inc.color};font-weight:600">\${idx+1}. \${escHtml(s)}</span>\`).join('')}
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;margin-left:auto" onclick="showToast('info','Résolution en cours…')">Résoudre →</button>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- ROOT CAUSES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🔬 Analyse Root Cause — IA</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${rootCauses.map(r => \`
            <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid \${r.color}22">
              <span style="font-size:22px;flex-shrink:0">\${r.icon}</span>
              <div style="flex:1">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(r.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(r.desc)}</div>
              </div>
              <div style="text-align:center;flex-shrink:0;min-width:60px">
                <div style="font-size:16px;font-weight:800;color:\${r.color}">\${r.prob}%</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">probabilité</div>
                <div class="fp-progress-track" style="height:4px;margin-top:4px"><div class="fp-progress-fill" style="width:\${r.prob}%;background:\${r.color}"></div></div>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: SEO ALERTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'seo') {
    const rankDrops = [
      { kw: "boulangerie paris 15",            before: 2,  after: 4,  delta: -2, vol: 320, cause: "Concurrent renforcé son contenu",         risk: 'Élevé',  color: '#ef4444' },
      { kw: "plombier urgence paris",           before: 7,  after: 12, delta: -5, vol: 580, cause: "Mise à jour algo Google détectée",         risk: 'Critique',color: '#ef4444' },
      { kw: "restaurant gastronomique 75018",   before: 14, after: 18, delta: -4, vol: 210, cause: "Page non optimisée pour intent local",      risk: 'Moyen',  color: '#f59e0b' },
      { kw: "serrurier 75011",                  before: 1,  after: 1,  delta: 0,  vol: 440, cause: "Position stable — surveiller",              risk: 'Faible', color: '#22c55e' },
      { kw: "fleuriste mariage paris",          before: 29, after: 22, delta: +7, vol: 190, cause: "Optimisation de page réussie",              risk: 'Positif',color: '#22c55e' },
    ];
    const trafficAnomalies = [
      { title: "Pic trafic anormal +340 sessions",    time: "06/05 · 14h", type: 'info',    desc: "Partage viral Facebook local — rebond 89% — pas de conversion" },
      { title: "Chute organique -23% lundi 5 mai",    time: "05/05 · 08h", type: 'warning', desc: "Probable filtre Google — 3 pages dé-indexées temporairement" },
      { title: "Trafic mobile réduit -18% semaine 18",time: "01/05 · 00h", type: 'warning', desc: "Corrélation avec dégradation Core Web Vitals mobile détectée" },
    ];
    return \`
      \${aiBlock("3 mots-clés ont perdu des positions cette semaine. Alerte critique : <strong>plombier urgence paris</strong> a chuté de #7 à #12 (-5 places) — probable mise à jour algo Google. Opportunité : <strong>fleuriste mariage paris</strong> progresse fortement (+7 positions).",
        ['Plan récupération rankings', 'Analyser les concurrents', 'Rapport SEO PDF'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Alertes SEO actives', '4', 'dont 2 critiques', 'down')}
        \${statCard('Mots-clés en baisse', '3', 'cette semaine', 'down')}
        \${statCard('Mots-clés en hausse', '1', 'optimisation réussie', 'up')}
        \${statCard('Trafic organique', '-23% lundi', 'récupéré mardi', 'neutral')}
      </div>

      <!-- RANKING DROPS TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('trending-down').replace('stroke="currentColor"','stroke="#ef4444"')}
          Alertes positions — Mai 2026
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Mot-clé</th><th>Avant</th><th>Après</th><th>Delta</th><th>Volume</th><th>Cause probable</th><th>Risque</th></tr></thead>
            <tbody>
              \${rankDrops.map(k => {
                const dc = k.delta < -3 ? '#ef4444' : k.delta < 0 ? '#f59e0b' : k.delta > 0 ? '#22c55e' : 'var(--fp-text-faint)';
                return \`<tr>
                  <td style="font-weight:600;font-size:11px">\${escHtml(k.kw)}</td>
                  <td style="font-weight:700;color:var(--fp-text-soft)">#\${k.before}</td>
                  <td style="font-weight:700;color:\${k.color}">#\${k.after}</td>
                  <td style="font-weight:800;color:\${dc}">\${k.delta > 0 ? '+' : ''}\${k.delta}</td>
                  <td style="color:var(--fp-text-faint)">\${k.vol}</td>
                  <td style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(k.cause)}</td>
                  <td>\${badge(k.risk, k.color)}</td>
                </tr>\`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- TRAFFIC ANOMALIES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📊 Anomalies de trafic détectées</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${trafficAnomalies.map(a => {
            const ac = a.type === 'warning' ? '#f59e0b' : '#2563EB';
            return \`<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:10px;background:\${ac}08;border-left:3px solid \${ac}">
              <div style="flex:1">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:3px">\${escHtml(a.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${escHtml(a.desc)}</div>
              </div>
              <div style="flex-shrink:0;text-align:right">
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(a.time)}</div>
                \${badge(a.type === 'warning' ? 'Alerte' : 'Info', ac)}
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: PERFORMANCE & UPTIME ALERTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'performance') {
    const monPerf = STATE.monitors.slice(0, 6).map((m, i) => ({
      ...m,
      lat:    [142, 890, 89, 621, 318, 203][i] || 250,
      uptime: [99.98, 98.72, 100, 99.12, 99.91, 99.44][i] || 99.5,
      status: [true, false, true, true, true, true][i],
      lcp:    [2.1, 4.8, 1.4, 3.9, 2.6, 2.2][i] || 2.5,
      cwv:    ['OK', 'NOK', 'OK', 'NOK', 'OK', 'OK'][i],
    }));
    const maxLat = Math.max(...monPerf.map(m => m.lat));
    return \`
      \${isPro
        ? aiBlock("2 sites avec problèmes de performance critiques. <strong>coiffeur-lyon.com : 890ms</strong> (seuil 500ms) — LCP 4.8s critique. <strong>restaurant-lesoleil.com DOWN</strong> 44 min — uptime 98.72% (SLA non respecté). Corrélation : les 2 sites sous-performants ont un taux de conversion mobile 0%.",
            ['Diagnostiquer les performances', 'Optimiser Core Web Vitals', 'Rapport SLA'])
        : \`<div style="padding:14px 16px;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">⚡</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Performance Alerts — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse IA des performances, alertes Core Web Vitals et monitoring SLA avancé.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Sites à risque', String(monPerf.filter(m => !m.status || m.lat > 500).length), 'action requise', 'down')}
        \${statCard('Latence critique', '890ms', 'coiffeur-lyon.com', 'down')}
        \${statCard('Core Web Vitals NOK', String(monPerf.filter(m => m.cwv === 'NOK').length), 'sites concernés', 'down')}
        \${statCard('Uptime global moy.', '99.5%', 'SLA cible : 99.9%', 'neutral')}
      </div>

      <!-- LATENCY BARS -->
      <div class="fp-card fp-mb-20">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            \${svgIcon('activity').replace('stroke="currentColor"','stroke="#2563EB"')}
            Latence par site — Alerte seuil 500ms
          </div>
          <span style="font-size:11px;color:var(--fp-text-faint)">Seuil : <strong style="color:#f59e0b">500ms</strong></span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${monPerf.map(m => {
            const lc = m.lat > 600 ? '#ef4444' : m.lat > 400 ? '#f59e0b' : '#22c55e';
            const pct = Math.round(m.lat / maxLat * 100);
            return \`<div style="display:flex;align-items:center;gap:10px">
              <div style="width:140px;font-size:11px;color:var(--fp-text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex-shrink:0">\${escHtml(m.url?.replace('https://','') || m.name || 'Monitor')}</div>
              <div style="flex:1;background:rgba(255,255,255,0.03);border-radius:5px;height:22px;overflow:hidden;position:relative">
                <div style="height:100%;width:\${pct}%;background:linear-gradient(90deg,\${lc}99,\${lc}44);border-radius:5px;transition:width 0.5s ease"></div>
                \${m.lat > 500 ? \`<div style="position:absolute;top:0;left:\${Math.round(500/maxLat*100)}%;width:2px;height:100%;background:#f59e0b;opacity:0.6"></div>\` : ''}
              </div>
              <div style="min-width:60px;text-align:right;flex-shrink:0">
                <span style="font-size:12px;font-weight:800;color:\${lc}">\${m.lat}ms</span>
              </div>
              \${badge(m.status ? (m.lat > 500 ? 'Lent' : 'OK') : 'DOWN', m.status ? (m.lat > 500 ? '#f59e0b' : '#22c55e') : '#ef4444')}
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- CWV TABLE -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🌐 Core Web Vitals — Alertes</div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Site</th><th>LCP</th><th>Uptime</th><th>CWV</th><th>Statut</th></tr></thead>
            <tbody>
              \${monPerf.map(m => \`<tr>
                <td style="font-size:11px;font-weight:600">\${escHtml(m.url?.replace('https://','') || m.name || 'Monitor')}</td>
                <td style="font-weight:700;color:\${m.lcp > 4 ? '#ef4444' : m.lcp > 2.5 ? '#f59e0b' : '#22c55e'}">\${m.lcp}s</td>
                <td style="font-weight:700;color:\${m.uptime >= 99.9 ? '#22c55e' : m.uptime >= 99 ? '#f59e0b' : '#ef4444'}">\${m.uptime}%</td>
                <td>\${badge(m.cwv, m.cwv === 'OK' ? '#22c55e' : '#ef4444')}</td>
                <td>\${badge(m.status ? 'En ligne' : 'DOWN', m.status ? '#22c55e' : '#ef4444')}</td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: CONVERSION & UX ALERTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'conversion') {
    const convAlerts = [
      { sev:'critical', icon:'📉', title:"Conversion weekend à 0%",         desc:"Samedi 3 et dimanche 4 mai — 0 client sur 1200 sessions. Formulaire contact probable hors service sur mobile iOS.",  impact:"-800€ estimé",  action:"Vérifier formulaire" },
      { sev:'critical', icon:'📱', title:"Taux conversion mobile 0.12%",      desc:"58% du trafic — converti 14× moins que le desktop. Page Tarifs : 61% d\'abandons avec seulement 39% de scroll.",      impact:"-2 840€/mois",  action:"Plan UX mobile"      },
      { sev:'warning',  icon:'🎯', title:"CTA Hero — CTR chute à 2.8%",       desc:"Le CTA principal Devis a perdu 1.4 points vs M-1. Visibilité réduite sur mobile (bouton trop bas dans la page).",    impact:"-480€/mois",    action:"Optimiser le CTA"   },
      { sev:'warning',  icon:'😤', title:"Rage clicks x47 sur formulaire",    desc:"47 rage clicks détectés sur le champ email du formulaire principal — probable bug de validation ou UX confuse.",        impact:"UX dégradée",    action:"Corriger formulaire" },
      { sev:'info',     icon:'✅', title:"CTA Appeler +4.1% — en hausse",     desc:"Le bouton Appeler maintenant performe mieux que prévu sur mobile. CTR mobile 6.2% vs 4.1% desktop.",                   impact:"Positif",        action:"Amplifier"          },
    ];
    const frictions = [
      { page: "Formulaire contact",  score: 28, issues: 3, sev: 'critical', color: '#ef4444' },
      { page: "Page Tarifs",         score: 44, issues: 2, sev: 'high',     color: '#f59e0b' },
      { page: "Page Services",       score: 62, issues: 1, sev: 'medium',   color: '#f59e0b' },
      { page: "Accueil mobile",      score: 51, issues: 2, sev: 'high',     color: '#f59e0b' },
      { page: "Blog",                score: 84, issues: 0, sev: 'ok',       color: '#22c55e' },
    ];
    return \`
      \${aiBlock("2 alertes critiques conversion actives. <strong>Perte estimée : -3 640€/mois</strong>. Priorité #1 : formulaire mobile cassé (weekend 0%). Priorité #2 : UX mobile Tarifs — 61% d\'abandons avec seulement 39% de scroll.",
        ['Plan CRO mobile', 'Corriger le formulaire', 'Rapport conversion'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Alertes conversion', String(convAlerts.length), 'dont 2 critiques', 'down')}
        \${statCard('Perte estimée', '-3 640€', 'ce mois — récupérable', 'down')}
        \${statCard('Score UX moyen', '54/100', 'Page critique : 28/100', 'down')}
        \${statCard('Rage clicks', '47×', 'formulaire principal', 'down')}
      </div>

      <!-- CONVERSION ALERTS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('trending-down').replace('stroke="currentColor"','stroke="#ef4444"')}
          Alertes conversion actives
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${convAlerts.map(a => {
            const ac = a.sev === 'critical' ? '#ef4444' : a.sev === 'warning' ? '#f59e0b' : '#22c55e';
            return \`<div style="display:flex;align-items:flex-start;gap:12px;padding:14px;border-radius:10px;border:1px solid \${ac}28;background:\${ac}07;border-left-width:3px">
              <span style="font-size:20px;flex-shrink:0">\${a.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                  \${badge(a.sev === 'critical' ? 'Critique' : a.sev === 'warning' ? 'Alerte' : 'Positif', ac)}
                  <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(a.title)}</span>
                </div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.5">\${escHtml(a.desc)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0;min-width:80px">
                <div style="font-size:12px;font-weight:800;color:\${ac}">\${escHtml(a.impact)}</div>
                <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;margin-top:6px" onclick="showToast('info','\${escHtml(a.action)}…')">\${escHtml(a.action)}</button>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- UX FRICTION SCORES -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">😤 Score de friction UX par page</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${frictions.map(f => \`
            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid \${f.color}22">
              <div style="flex:1">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text);margin-bottom:4px">\${escHtml(f.page)}</div>
                <div class="fp-progress-track" style="height:5px"><div class="fp-progress-fill" style="width:\${f.score}%;background:\${f.color}"></div></div>
              </div>
              <div style="min-width:40px;text-align:center">
                <div style="font-size:14px;font-weight:800;color:\${f.color}">\${f.score}</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">/100</div>
              </div>
              <div style="font-size:11px;color:\${f.issues ? '#ef4444' : '#22c55e'};font-weight:600;min-width:60px;text-align:right">
                \${f.issues ? f.issues + ' problème' + (f.issues > 1 ? 's' : '') : 'OK ✓'}
              </div>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: LOCAL SEO & GBP ALERTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'local') {
    const gbpAlerts = [
      { icon:'💬', sev:'critical', title:"14 avis Google sans réponse",       desc:"Avis récents non traités sur 3 fiches — impact négatif sur la note et la confiance client. Risque baisse ranking Maps.",  time:"1j",    color:'#ef4444' },
      { icon:'📍', sev:'warning',  title:"Visibilité Maps -8% — Marais",       desc:"Le 4e arrondissement a perdu 8 points de visibilité locale cette semaine — concurrent renforcé sa fiche GBP.",           time:"3j",    color:'#f59e0b' },
      { icon:'📷', sev:'warning',  title:"Photos GBP obsolètes — 3 fiches",    desc:"Aucune photo ajoutée depuis > 60 jours sur 3 fiches. Google favorise les fiches actives avec contenu visuel récent.",     time:"5j",    color:'#f59e0b' },
      { icon:'🏆', sev:'info',     title:"Position #1 Local Pack — 15e arr.",  desc:"boulangerie-martin.fr domine le Local Pack sur 4 mots-clés dans le 15e. Performance GBP en amélioration.",               time:"2j",    color:'#22c55e' },
    ];
    const localDrops = [
      { zone: "Marais (4e)",          vis: 31, delta: -8,  cause: "Concurrent renforcé GBP + 3 nouveaux avis",    risk: 'Élevé'   },
      { zone: "Montmartre (18e)",     vis: 44, delta: -2,  cause: "Baisse de régularité des publications GBP",     risk: 'Moyen'   },
      { zone: "République (11e)",     vis: 28, delta: -5,  cause: "Manque de mots-clés locaux dans description",   risk: 'Élevé'   },
    ];
    const reviewStats = [
      { label: "Avis sans réponse",     val: 14,  alert: true,  color: '#ef4444' },
      { label: "Avis récents (30j)",    val: 23,  alert: false, color: '#22c55e' },
      { label: "Note moyenne",          val: 4.4, alert: false, color: '#f59e0b', unit: '★' },
      { label: "Sentiment négatif",     val: 3,   alert: true,  color: '#ef4444' },
    ];
    return \`
      \${aiBlock("2 alertes locales critiques. <strong>14 avis sans réponse</strong> menacent votre note et votre ranking Maps. La zone Marais recule de -8 pts suite au renforcement GBP d\'un concurrent. Action immédiate : répondre aux avis + publier 3 nouvelles photos GBP.",
        ['Répondre aux avis', 'Renforcer les fiches GBP', 'Rapport local complet'])}

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Alertes locales', String(gbpAlerts.length), 'dont 1 critique', 'down')}
        \${statCard('Avis sans réponse', '14', 'risque note Google', 'down')}
        \${statCard('Zones en recul', String(localDrops.length), 'cette semaine', 'down')}
        \${statCard('Zone dominée', '15e arr.', 'Local Pack #1', 'up')}
      </div>

      <!-- GBP ALERTS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('map-pin').replace('stroke="currentColor"','stroke="#f59e0b"')}
          Alertes Google Business Profile
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${gbpAlerts.map(a => {
            return \`<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:10px;background:\${a.color}08;border-left:3px solid \${a.color}">
              <span style="font-size:20px;flex-shrink:0">\${a.icon}</span>
              <div style="flex:1">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                  \${badge(a.sev === 'critical' ? 'Critique' : a.sev === 'warning' ? 'Alerte' : 'Positif', a.color)}
                  <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(a.title)}</span>
                </div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.5">\${escHtml(a.desc)}</div>
              </div>
              <span style="font-size:10px;color:var(--fp-text-faint);flex-shrink:0">\${escHtml(a.time)}</span>
            </div>\`;
          }).join('')}
        </div>
      </div>

      <!-- VISIBILITY DROPS + REVIEW STATS -->
      <div class="fp-grid-2">
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">📉 Zones en recul — Alertes</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            \${localDrops.map(d => \`
              <div style="padding:12px 14px;border-radius:9px;background:rgba(239,68,68,0.05);border:1px solid rgba(239,68,68,0.2)">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
                  <span style="font-size:12px;font-weight:700;color:var(--fp-text)">\${escHtml(d.zone)}</span>
                  <div style="display:flex;align-items:center;gap:8px">
                    <span style="font-size:13px;font-weight:800;color:#ef4444">\${d.delta}pts</span>
                    <span style="font-size:11px;font-weight:600;color:var(--fp-text-faint)">\${d.vis}%</span>
                  </div>
                </div>
                <div style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(d.cause)}</div>
                <div style="margin-top:6px">\${badge(d.risk, d.risk === 'Élevé' ? '#ef4444' : '#f59e0b')}</div>
              </div>
            \`).join('')}
          </div>
        </div>
        <div class="fp-card">
          <div class="fp-card-title" style="margin-bottom:14px">⭐ Statistiques avis Google</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            \${reviewStats.map(r => \`
              <div style="padding:14px;border-radius:10px;border:1px solid \${r.color}28;background:\${r.color}07;text-align:center">
                <div style="font-size:22px;font-weight:800;color:\${r.color}">\${r.val}\${r.unit || ''}</div>
                <div style="font-size:10px;color:var(--fp-text-muted);margin-top:4px">\${escHtml(r.label)}</div>
                \${r.alert ? \`<div style="font-size:9px;color:\${r.color};margin-top:6px;font-weight:700">⚠ Action requise</div>\` : ''}
              </div>
            \`).join('')}
          </div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" style="width:100%;margin-top:14px" onclick="showToast('info','Gestion des avis…')">Répondre aux 14 avis →</button>
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: COMPETITOR MOVEMENT ALERTS
  // ══════════════════════════════════════════════════════════
  if (sub === 'competitor') {
    const compMovements = [
      { name:"Boulangerie Dupont",    gain:+12, kw:"boulangerie paris 15", type:"Ranking",   sev:'critical', delta:"#2→#4 défavorable",  color:'#ef4444' },
      { name:"Plomberie Express 75",  gain:+8,  kw:"plombier urgence 75",  type:"Backlinks", sev:'warning',  delta:"+180% backlinks mois",color:'#f59e0b' },
      { name:"Café Montmartre",       gain:+5,  kw:"café brunch paris 18", type:"Contenu",   sev:'warning',  delta:"3 articles publiés",  color:'#f59e0b' },
      { name:"Fleurs du Marais",      gain:+6,  kw:"fleuriste mariage",    type:"Local SEO", sev:'warning',  delta:"GBP renforcé +6 avis",color:'#f59e0b' },
      { name:"Coiffure Chic Lyon",    gain:-3,  kw:"coiffeur lyon centre", type:"Ranking",   sev:'info',     delta:"Recul concurrent",    color:'#22c55e' },
    ];
    const threats = [
      { title:"Boulangerie Dupont — menace critique", desc:"Accélération backlinks (+180%) + renforcement GBP = risque perte Local Pack 15e dans 4-6 semaines.", urg: true  },
      { title:"Contenu local concurrent — Montmartre",  desc:"3 articles optimisés publiés cette semaine ciblant vos mots-clés stratégiques dans le 18e.",        urg: false },
    ];
    return \`
      \${isPro
        ? aiBlock("Alerte concurrentielle critique : <strong>Boulangerie Dupont accélère fortement</strong> (+12 positions + 180% backlinks). Risque perte Local Pack 15e dans <strong>4-6 semaines</strong> sans contre-mesures. Action recommandée : renforcer GBP + publier contenu local immédiatement.",
            ['Plan contre-offensive IA', 'Analyser Boulangerie Dupont', 'Renforcer GBP'])
        : \`<div style="padding:14px 16px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px"><div style="font-size:22px">🎯</div><div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">Intelligence concurrentielle — Pro requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Alertes IA sur les mouvements concurrents, backlinks, contenu et local SEO.</div></div><button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Pro</button></div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Mouvements détectés', String(compMovements.filter(c => c.sev !== 'info').length), 'dont 1 critique', 'down')}
        \${statCard('Menace critique', 'Boulangerie Dupont', '+12 positions ce mois', 'down')}
        \${statCard('Concurrent en recul', '1', 'opportunité à saisir', 'up')}
        \${statCard('Alerte backlinks', '+180%', 'activité anormale', 'down')}
      </div>

      <!-- MOVEMENTS TABLE -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('users').replace('stroke="currentColor"','stroke="#ef4444"')}
          Mouvements concurrents — Radar IA
        </div>
        <div style="overflow-x:auto">
          <table class="fp-data-table">
            <thead><tr><th>Concurrent</th><th>Mouvement</th><th>Type</th><th>Mot-clé cible</th><th>Menace</th><th>Action</th></tr></thead>
            <tbody>
              \${compMovements.map(c => \`<tr>
                <td style="font-weight:700">\${escHtml(c.name)}</td>
                <td style="font-weight:800;color:\${c.color}">\${c.gain >= 0 ? '+' : ''}\${c.gain}</td>
                <td>\${badge(c.type, '#475569')}</td>
                <td style="font-size:10px;color:var(--fp-text-muted)">\${escHtml(c.kw)}</td>
                <td>\${badge(c.sev === 'critical' ? 'Critique' : c.sev === 'warning' ? 'Alerte' : 'Recul', c.color)}</td>
                <td><button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px" onclick="showToast('info','Analyse…')">Analyser</button></td>
              </tr>\`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- THREAT CARDS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🚨 Menaces prioritaires</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${threats.map(t => \`
            <div style="padding:14px 16px;border-radius:10px;background:\${t.urg ? 'rgba(239,68,68,0.07)' : 'rgba(245,158,11,0.07)'};border:1px solid \${t.urg ? 'rgba(239,68,68,0.25)' : 'rgba(245,158,11,0.25)'}">
              <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:5px">\${escHtml(t.title)}</div>
              <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.55">\${escHtml(t.desc)}</div>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" style="font-size:10px;margin-top:10px" onclick="showToast('info','Plan contre-offensive…')">Plan contre-offensive →</button>
            </div>
          \`).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // SUB: AI THREAT ANALYSIS LAB
  // ══════════════════════════════════════════════════════════
  if (sub === 'ai') {
    const riskPreds = [
      { icon:'🌐', title:"Risque perte Local Pack 15e",   prob:68, horizon:"4-6 sem.", sev:'critical', desc:"Si Boulangerie Dupont maintient son rythme (+12 pos/mois), perte probable du Local Pack 15e. Fenêtre d'action : 3 semaines.", color:'#ef4444' },
      { icon:'📱', title:"Chute conversion mobile M+1",    prob:74, horizon:"30 jours", sev:'critical', desc:"Sans correction du formulaire mobile, le taux conversion mobile restera < 0.2% — perte estimée 2 800€/mois supplémentaire.", color:'#ef4444' },
      { icon:'⚡', title:"Surcharge serveur pic juillet",  prob:52, horizon:"60 jours", sev:'warning',  desc:"Avec la croissance trafic Maps (+21%/mois), risque de timeout serveur lors des pics de juillet-août similaire à l\'incident du 4/05.", color:'#f59e0b' },
      { icon:'🔗', title:"Pénalité backlinks spam",        prob:31, horizon:"90 jours", sev:'medium',   desc:"3 backlinks de faible qualité détectés ce mois. Si le volume augmente, risque de filtre Google Penguin sur plombier-paris.fr.", color:'#2563EB' },
      { icon:'📉', title:"Déclin SEO coiffeur-lyon.com",  prob:61, horizon:"45 jours", sev:'warning',  desc:"Sans correction vitesse mobile (890ms LCP 4.8s) et Core Web Vitals, Google peut désclasser les pages principales.",             color:'#f59e0b' },
    ];
    const vulns = [
      { cat: 'Conversion', score: 28, risk: 'Critique', items: ['Formulaire mobile cassé', 'CTA Hero invisible mobile', 'Page Tarifs sans ancrage'] },
      { cat: 'Infrastructure', score: 44, risk: 'Élevé', items: ['2 sites vitesse < 500ms', 'CDN non configuré', 'Cache navigateur absent'] },
      { cat: 'Local SEO', score: 61, risk: 'Moyen', items: ['14 avis sans réponse', 'Photos GBP obsolètes', 'Zones Marais en recul'] },
      { cat: 'SEO Technique', score: 74, risk: 'Faible', items: ['2 sites mots-clés en baisse', 'Schema markup partiel'] },
    ];
    return \`
      \${isUltra
        ? aiBlock("5 risques prédictifs détectés. 2 critiques à traiter dans les 3 semaines. <strong>Risque prioritaire : perte Local Pack 15e</strong> (prob. 68%) si Boulangerie Dupont maintient son rythme. Revenue à risque M+3 : <strong>-8 400€</strong> si aucune action.",
            ['Rapport risques complet', 'Plan défensif IA', 'Alerter équipe'])
        : \`<div style="background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(37,99,235,0.06));border:1px solid rgba(139,92,246,0.2);border-radius:var(--fp-radius-lg);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
            <div style="font-size:24px">🔮</div>
            <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:3px">IA Threat Lab — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Prédictions de risques, analyse de vulnérabilités business et alertes anticipées par IA.</div></div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
          </div>\`
      }

      <div class="fp-stat-row fp-mb-20">
        \${statCard('Risques prédits', String(riskPreds.length), 'horizon 90 jours', 'down')}
        \${statCard('Risques critiques', String(riskPreds.filter(r => r.sev === 'critical').length), 'action < 3 semaines', 'down')}
        \${statCard('Revenue à risque', '-8 400€', 'si aucune action M+3', 'down')}
        \${statCard('Vulnérabilités', String(vulns.filter(v => v.risk !== 'Faible').length), 'domaines critiques', 'neutral')}
      </div>

      <!-- RISK PREDICTIONS -->
      <div class="fp-card fp-mb-20">
        <div class="fp-card-title" style="margin-bottom:14px">
          \${svgIcon('cpu').replace('stroke="currentColor"','stroke="#8b5cf6"')}
          Prédictions IA — Risques futurs
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${riskPreds.map(r => \`
            <div style="display:flex;align-items:flex-start;gap:12px;padding:14px;border-radius:10px;border:1px solid \${r.color}28;background:\${r.color}06">
              <span style="font-size:22px;flex-shrink:0">\${r.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
                  \${badge(r.sev === 'critical' ? 'Critique' : r.sev === 'warning' ? 'Alerte' : 'Moyen', r.color)}
                  <span style="font-size:10px;color:var(--fp-text-faint)">Horizon : \${escHtml(r.horizon)}</span>
                </div>
                <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:4px">\${escHtml(r.title)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.5">\${escHtml(r.desc)}</div>
              </div>
              <div style="text-align:center;flex-shrink:0;min-width:64px">
                <div style="font-size:20px;font-weight:900;color:\${r.color}">\${r.prob}%</div>
                <div style="font-size:9px;color:var(--fp-text-faint)">probabilité</div>
                <div class="fp-progress-track" style="height:4px;margin-top:4px"><div class="fp-progress-fill" style="width:\${r.prob}%;background:\${r.color}"></div></div>
              </div>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- VULNERABILITY ANALYSIS -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🛡️ Analyse de vulnérabilités business</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
          \${vulns.map(v => {
            const vc = v.risk === 'Critique' ? '#ef4444' : v.risk === 'Élevé' ? '#f59e0b' : v.risk === 'Moyen' ? '#2563EB' : '#22c55e';
            const circ = 2 * Math.PI * 28;
            const fill = v.score / 100 * circ;
            return \`<div style="padding:14px;border-radius:12px;border:1px solid \${vc}28;background:\${vc}07">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
                <svg width="56" height="56" viewBox="0 0 64 64" style="flex-shrink:0">
                  <circle cx="32" cy="32" r="28" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="6"/>
                  <circle cx="32" cy="32" r="28" fill="none" stroke="\${vc}" stroke-width="6"
                    stroke-dasharray="\${fill.toFixed(1)} \${(circ-fill).toFixed(1)}"
                    stroke-dashoffset="\${(circ*0.25).toFixed(1)}" stroke-linecap="round"
                    transform="rotate(-90 32 32)"/>
                  <text x="32" y="37" text-anchor="middle" font-size="13" font-weight="800" fill="\${vc}">\${v.score}</text>
                </svg>
                <div>
                  <div style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(v.cat)}</div>
                  \${badge(v.risk, vc)}
                </div>
              </div>
              \${v.items.map(item => \`<div style="font-size:10px;color:var(--fp-text-muted);padding:3px 0;border-bottom:1px solid rgba(255,255,255,0.03)">• \${escHtml(item)}</div>\`).join('')}
            </div>\`;
          }).join('')}
        </div>
      </div>
    \`;
  }

  // ══════════════════════════════════════════════════════════
  // DEFAULT (null) — Alert Command Center
  // ══════════════════════════════════════════════════════════
  const alertScores = [
    { label:'Stabilité',         val: 76, color:'#22c55e', icon:'🛡️' },
    { label:'Score menace',      val: 42, color:'#ef4444', icon:'🚨' },
    { label:'Résolution',        val: 68, color:'#2563EB', icon:'✅' },
    { label:'Risque business',   val: 58, color:'#f59e0b', icon:'💼' },
    { label:'Sévérité incidents',val: 34, color:'#22c55e', icon:'⚡' },
    { label:'Santé système',     val: 82, color:'#22c55e', icon:'🖥️' },
  ];
  const circ46 = 2 * Math.PI * 46;

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Alert Command Center
          <span style="font-size:11px;font-weight:600;padding:3px 10px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);border-radius:20px;color:#ef4444;animation:pulse 2s infinite">● LIVE</span>
        </h1>
        <div class="fp-section-sub">Surveillance temps réel · \${criticals.length} critiques · \${warnings.length} alertes · Mis à jour à l\'instant</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Tout marquer lu', 'fp-btn fp-btn-ghost fp-btn-sm', 'check', "onclick=\\"showToast('success','Alertes marquées lues')\\"" )}
        \${btn('Config alertes',  'fp-btn fp-btn-ghost fp-btn-sm', 'settings', "onclick=\\"navigate('settings');setTimeout(()=>navigateSub('alerts'),50)\\"" )}
      </div>
    </div>

    <!-- AI INTELLIGENCE -->
    \${isUltra
      ? aiBlock("Surveillance active. <strong>" + criticals.length + " menaces critiques</strong> détectées. Priorité #1 : formulaire mobile cassé (-800€ weekend). Priorité #2 : monitor DOWN restaurant-lesoleil.com (-180€). Risque concurrent : Boulangerie Dupont accélère fortement — <strong>fenêtre d\'action 3 semaines</strong>.",
          ['Plan résolution immédiat', 'Rapport incident', 'Alerter équipe'])
      : \`<div style="padding:14px 16px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);border-radius:var(--fp-radius-lg);margin-bottom:20px;display:flex;align-items:center;gap:12px">
          <div style="font-size:22px">🛡️</div>
          <div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-bottom:2px">IA Alert Intelligence — Ultra requis</div><div style="font-size:12px;color:var(--fp-text-muted)">Analyse IA des menaces, prédictions d\'incidents et plans de résolution automatiques.</div></div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="showToast('info','Mise à niveau…')">Passer Ultra</button>
        </div>\`
    }

    <!-- KPI CARDS -->
    <div class="fp-stat-row fp-mb-20">
      \${statCard('Alertes actives', String(allAlerts.length), 'toutes catégories', 'neutral')}
      \${statCard('Critiques', String(criticals.length), 'action immédiate requise', 'down')}
      \${statCard('Avertissements', String(warnings.length), 'à surveiller', 'neutral')}
      \${statCard('Impact estimé', '-980€', 'ce mois — récupérable', 'down')}
    </div>

    <!-- 6 SCORE GAUGES -->
    <div class="fp-card fp-mb-20">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="fp-card-title" style="margin-bottom:0">
          \${svgIcon('shield').replace('stroke="currentColor"','stroke="#ef4444"')}
          Tableau de bord threat intelligence — 6 scores clés
        </div>
        <span style="font-size:11px;color:var(--fp-text-faint)">Score global : <strong style="color:#f59e0b">60/100</strong></span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
        \${alertScores.map(k => {
          const filled = k.val / 100 * circ46;
          const dash   = circ46 - filled;
          return \`<div style="padding:14px;border-radius:12px;border:1px solid \${k.color}28;background:\${k.color}07;text-align:center">
            <svg width="64" height="64" viewBox="0 0 120 120" style="margin:0 auto 6px">
              <circle cx="60" cy="60" r="46" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="8"/>
              <circle cx="60" cy="60" r="46" fill="none" stroke="\${k.color}" stroke-width="8"
                stroke-dasharray="\${filled.toFixed(1)} \${dash.toFixed(1)}"
                stroke-dashoffset="\${(circ46*0.25).toFixed(1)}"
                stroke-linecap="round" transform="rotate(-90 60 60)"/>
              <text x="60" y="65" text-anchor="middle" font-size="22" font-weight="800" fill="\${k.color}" font-family="Outfit,sans-serif">\${k.val}</text>
            </svg>
            <div style="font-size:11px;font-weight:600;color:var(--fp-text-soft)">\${k.icon} \${escHtml(k.label)}</div>
            <div style="margin-top:6px">\${badge(k.val>=70?'Bon':k.val>=45?'Moyen':'Critique', k.color)}</div>
          </div>\`;
        }).join('')}
      </div>
    </div>

    <!-- LIVE ALERT FEED + QUICK NAV -->
    <div class="fp-grid-2 fp-mb-20">
      <div class="fp-card" style="grid-column:span 1">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="fp-card-title" style="margin-bottom:0">
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#ef4444;margin-right:6px;animation:pulse 1.5s infinite"></span>
            Flux d\'alertes en temps réel
          </div>
          <span style="font-size:10px;color:var(--fp-text-faint)">Mis à jour à l\'instant</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${allAlerts.slice(0, 8).map(a => {
            const bg = a.sev === 'critical' ? '#ef4444' : a.sev === 'warning' ? '#f59e0b' : '#22c55e';
            return \`<div class="fp-alert-item \${a.sev === 'critical' ? 'critical' : a.sev === 'warning' ? 'warning' : 'success'}" style="padding:10px 12px;gap:10px">
              <div class="fp-alert-icon" style="width:28px;height:28px;min-width:28px;background:\${bg}15;border-radius:7px;display:flex;align-items:center;justify-content:center">
                \${svgIcon(a.icon || 'alert').replace('stroke="currentColor"',\`stroke="\${bg}"\`).replace('width="14"','width="12"').replace('height="14"','height="12"')}
              </div>
              <div class="fp-alert-body" style="flex:1;min-width:0">
                <div class="fp-alert-title" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${escHtml(a.title)}</div>
                <div class="fp-alert-time" style="font-size:9px">Il y a \${escHtml(a.time)}\${a.cat ? ' · ' + escHtml(a.cat) : ''}</div>
              </div>
              \${badge(a.sev === 'critical' ? 'Critique' : a.sev === 'warning' ? 'Alerte' : 'Info', bg)}
            </div>\`;
          }).join('')}
        </div>
      </div>

      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🧭 Centres d\'alerte spécialisés</div>
        <div style="display:flex;flex-direction:column;gap:7px">
          \${[
            { label:'Incidents actifs',     sub:'incidents',  icon:'🚨', count:2,  sev:'critical', desc:'2 incidents en cours' },
            { label:'Alertes SEO',          sub:'seo',        icon:'🔍', count:4,  sev:'warning',  desc:'3 positions perdues' },
            { label:'Performance & Uptime', sub:'performance',icon:'⚡', count:3,  sev:'critical', desc:'1 site DOWN · 2 lents' },
            { label:'Conversion & UX',      sub:'conversion', icon:'🎯', count:5,  sev:'critical', desc:'Perte -3640€ ce mois' },
            { label:'Local SEO & GBP',      sub:'local',      icon:'📍', count:4,  sev:'warning',  desc:'14 avis sans réponse' },
            { label:'Concurrents',          sub:'competitor', icon:'🏴', count:4,  sev:'warning',  desc:'Boulangerie Dupont +12' },
            { label:'IA Threat Lab',        sub:'ai',         icon:'🔮', count:5,  sev:'critical', desc:'5 risques prédits' },
          ].map(n => {
            const nc = n.sev === 'critical' ? '#ef4444' : '#f59e0b';
            return \`<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:9px;background:rgba(255,255,255,0.02);border:1px solid var(--fp-border);cursor:pointer" onclick="navigateSub('\${n.sub}')">
              <span style="font-size:16px">\${n.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${escHtml(n.label)}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${escHtml(n.desc)}</div>
              </div>
              <div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
                <span style="font-size:11px;font-weight:800;color:\${nc}">\${n.count}</span>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--fp-text-faint)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
              </div>
            </div>\`;
          }).join('')}
        </div>
      </div>
    </div>
  \`;
}`;

// ── Apply replacement ──────────────────────────────────────────
src = replaceFunc(src, 'renderAlertsCenter', NEW_ALERTS);
writeFileSync(file, src, 'utf8');
console.log('\n\u2705 Alert Center fully replaced (8 sub-pages).');
