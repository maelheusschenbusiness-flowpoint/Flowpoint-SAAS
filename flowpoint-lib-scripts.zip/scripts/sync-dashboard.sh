#!/bin/bash
set -e

# Sync dashboard assets from the canonical source (flowpoint-export) to mockup-sandbox.
# The mockup-sandbox/public/dashboard/ directory is gitignored because it is not the
# source of truth — this script materialises the files from artifacts/flowpoint-export/.
# Run automatically via: pnpm install (postinstall), post-merge, and predev in mockup-sandbox.

SRC="$(dirname "$0")/../artifacts/flowpoint-export"
DEST="$(dirname "$0")/../artifacts/mockup-sandbox/public/dashboard"

mkdir -p "$DEST"

for file in dashboard.js dashboard.css dashboard.html fp-config.js fp-backend.js; do
  if [ -f "$SRC/$file" ]; then
    cp "$SRC/$file" "$DEST/$file"
    echo "sync-dashboard: $file -> mockup-sandbox/public/dashboard/"
  fi
done
