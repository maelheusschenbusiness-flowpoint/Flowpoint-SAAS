import { readFileSync, writeFileSync } from 'fs';

const file = 'artifacts/flowpoint-export/dashboard.js';
let src = readFileSync(file, 'utf8');

// Helper: replace a named function entirely
function replaceFunc(src, name, newBody) {
  // Find "function <name>(" then find its matching closing brace
  const start = src.indexOf(`function ${name}(`);
  if (start === -1) { console.error(`NOT FOUND: ${name}`); return src; }
  let depth = 0, i = start, found = false;
  while (i < src.length) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { found = true; break; } }
    i++;
  }
  if (!found) { console.error(`NO CLOSING BRACE: ${name}`); return src; }
  const before = src.slice(0, start);
  const after  = src.slice(i + 1);
  console.log(`✓ Replaced ${name} (${i - start} chars)`);
  return before + newBody + after;
}

// ══════════════════════════════════════════════════════════════
// 1. renderMonitors() — Status page
// ══════════════════════════════════════════════════════════════
const NEW_MONITORS = `function renderMonitors() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';
  const monitors = STATE.monitors;
  const nUp   = monitors.filter(m => m.status === 'up').length;
  const nDown = monitors.filter(m => m.status === 'down').length;
  const nWarn = monitors.filter(m => m.status === 'warn').length;
  const avgLatency = Math.round(
    monitors.filter(m => m.status !== 'down').reduce((s, m) => s + m.latency, 0) /
    Math.max(1, monitors.filter(m => m.status !== 'down').length)
  );
  const avgUptime = (
    monitors.reduce((s, m) => s + parseFloat(computeRealUptime(m)), 0) /
    Math.max(1, monitors.length)
  ).toFixed(1);

  const timeline = [
    { time: '13:58', type: 'up',     site: 'plombier-paris.fr',        msg: 'Retour en ligne · Durée: 0 min' },
    { time: '13:12', type: 'down',   site: 'restaurant-lesoleil.com',  msg: 'Site DOWN — timeout connexion TCP' },
    { time: '11:45', type: 'alert',  site: 'coiffeur-lyon.com',        msg: 'Latence élevée détectée : 890ms' },
    { time: '09:30', type: 'config', site: 'Flowpoint',                msg: 'Interval réduit à 1 min · boulangerie-martin.fr' },
    { time: '08:00', type: 'up',     site: 'auto-moto-services.fr',    msg: 'Check quotidien · Statut OK' },
    { time: 'Hier 22:12', type: 'up',site: 'restaurant-lesoleil.com',  msg: 'Retour en ligne · Durée: 12 min' },
  ];
  const deps = [
    { name: 'Stripe',       status: 'operational', latency: '142ms', icon: '💳', desc: 'Paiements' },
    { name: 'Cloudflare',   status: 'operational', latency: '12ms',  icon: '🛡', desc: 'CDN & DNS' },
    { name: 'Supabase',     status: 'operational', latency: '89ms',  icon: '🗄', desc: 'Base de données' },
    { name: 'Google APIs',  status: 'operational', latency: '201ms', icon: '🔍', desc: 'Maps & SEO' },
    { name: 'SendGrid',     status: 'degraded',    latency: '480ms', icon: '📧', desc: 'Email marketing' },
    { name: 'OVH / O2Switch',status:'operational', latency: '55ms',  icon: '🖥', desc: 'Hébergement' },
  ];
  const depColor = s => s === 'operational' ? '#22c55e' : s === 'degraded' ? '#f59e0b' : '#ef4444';
  const tlColor  = t => t === 'down' ? '#ef4444' : t === 'up' ? '#22c55e' : t === 'alert' ? '#f59e0b' : '#94a3b8';
  const tlIcon   = t => t === 'down' ? '⬇' : t === 'up' ? '⬆' : t === 'alert' ? '⚡' : '⚙';

  return \`
    <div class="fp-section-header">
      <div>
        <h1 style="display:flex;align-items:center;gap:10px">
          Monitors
          <span style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:500;color:#22c55e;background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.25);border-radius:20px;padding:3px 10px">
            <span style="width:6px;height:6px;border-radius:50%;background:#22c55e;animation:fp-pulse-dot 2s infinite;display:inline-block"></span>
            Live · Check toutes les 5 min
          </span>
        </h1>
        <div class="fp-section-sub">Protection enterprise 24/7 · \${monitors.length} sites surveillés · Alertes instantanées</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Vérifier tout', 'fp-btn fp-btn-ghost fp-btn-sm', 'refresh', 'id="monitor-check-all"')}
        \${btn('+ Nouveau', 'fp-btn fp-btn-primary fp-btn-sm', 'plus', 'id="monitor-new-btn"')}
      </div>
    </div>

    \${aiBlock(
      nDown > 0
        ? \`🚨 <strong>\${nDown} site(s) DOWN</strong> actuellement. Impact estimé : <strong>~\${nDown * 8}–\${nDown * 15}€/min</strong>.\${nWarn > 0 ? ' ' + nWarn + ' site(s) en dégradation.' : ''} Latence moy. : <strong>\${avgLatency}ms</strong>.\`
        : \`Tous les sites opérationnels. Uptime moy. : <strong>\${avgUptime}%</strong> · Latence moy. : <strong>\${avgLatency}ms</strong>.\${nWarn > 0 ? ' <strong>' + nWarn + ' alerte(s)</strong> latence à surveiller.' : ' Performance nominale.'}\`,
      nDown > 0
        ? ['Diagnostiquer les pannes', 'Notifier les clients', 'Créer un incident']
        : ['Rapport uptime complet', 'Optimiser la latence', 'Configurer SLA']
    )}

    <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:20px">
      \${[
        { l: 'En ligne',       v: \`\${nUp}/\${monitors.length}\`, c: '#22c55e',                                        sub: nWarn + ' en alerte' },
        { l: 'DOWN',           v: String(nDown),                  c: nDown > 0 ? '#ef4444' : '#22c55e',             sub: nDown > 0 ? 'Action requise' : 'Tout OK' },
        { l: 'Latence moy.',   v: \`\${avgLatency}ms\`,           c: avgLatency > 400 ? '#ef4444' : avgLatency > 200 ? '#f59e0b' : '#22c55e', sub: '-42ms vs hier' },
        { l: 'Uptime global',  v: \`\${avgUptime}%\`,             c: parseFloat(avgUptime) >= 99 ? '#22c55e' : '#f59e0b', sub: 'SLA 99.0% cible' },
        { l: 'Incidents/mois', v: '3',                            c: '#f59e0b',                                     sub: 'vs 2 mois dernier' },
      ].map(s => \`
        <div class="fp-card fp-card-sm">
          <div style="font-size:10px;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px">\${s.l}</div>
          <div style="font-size:22px;font-weight:800;color:\${s.c};font-family:var(--fp-font-head);line-height:1;margin-bottom:4px">\${s.v}</div>
          <div style="font-size:10px;color:var(--fp-text-faint)">\${s.sub}</div>
        </div>
      \`).join('')}
    </div>

    <div class="fp-grid-auto fp-mb-24">
      \${monitors.map(m => \`
        <div class="fp-monitor-card fp-hover-toolbar-wrap\${m.status === 'down' ? ' down' : ''}\${STATE.selectedMonitors.has(m.id) ? ' fp-card-sel' : ''}" data-monitor-id="\${m.id}">
          <label class="fp-monitor-cb-wrap" title="Sélectionner">
            <input type="checkbox" class="fp-monitor-cb" data-id="\${m.id}"\${STATE.selectedMonitors.has(m.id) ? ' checked' : ''}/>
          </label>
          <div class="fp-monitor-status-row">
            <div class="fp-monitor-name-wrap">
              <div class="fp-monitor-pulse \${m.status}"></div>
              <span class="fp-monitor-name">\${escHtml(m.name)}</span>
            </div>
            \${badge(statusLabel(m.status), statusBadgeColor(m.status))}
          </div>
          <div class="fp-monitor-url">\${escHtml(m.url)}</div>
          <div class="fp-monitor-stats">
            <div><div class="fp-monitor-stat-label">Uptime</div><div class="fp-monitor-stat-value" style="color:#22c55e">\${computeRealUptime(m)}%</div></div>
            <div><div class="fp-monitor-stat-label">Latence</div><div class="fp-monitor-stat-value" style="color:\${m.latency > 500 ? '#ef4444' : m.latency > 200 ? '#f59e0b' : 'var(--fp-text)'}">\${m.status === 'down' ? 'DOWN' : m.latency + 'ms'}</div></div>
            <div><div class="fp-monitor-stat-label">Check</div><div style="font-size:11px;color:var(--fp-text-muted)">Il y a \${m.lastCheck}</div></div>
          </div>
          <div class="fp-uptime-bars">\${uptimeBars(m)}</div>
          <div class="fp-monitor-uptime30">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:3px">
              <span style="font-size:9px;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.07em">Uptime 30j</span>
              \${(() => {
                const s = STATE.monitorsSummary[m.id];
                if (!s || !s.length) return '';
                const tot = s.reduce((a, d) => a + d.total, 0), ok = s.reduce((a, d) => a + d.ok, 0);
                return tot ? \`<span style="font-size:9px;font-weight:700;color:\${ok/tot >= .99 ? '#22c55e' : ok/tot >= .90 ? '#f59e0b' : '#ef4444'}">\${(ok/tot*100).toFixed(1)}%</span>\` : '';
              })()}
            </div>
            \${uptime30SparklineSVG(m.id)}
          </div>
          <div class="fp-monitor-latency-spark">
            \${monitorSparklineSVG(monitorLatencyData(m), m.status === 'down' ? '#ef4444' : m.status === 'warn' ? '#f59e0b' : '#2563EB', 120, 22)}
            <span style="font-size:9px;color:var(--fp-text-faint)">latence 7 checks</span>
          </div>
          <div class="fp-hover-toolbar">
            <button class="fp-hover-toolbar-btn monitor-view" data-id="\${m.id}" title="Voir détails">\${svgIcon('eye')}</button>
            <button class="fp-hover-toolbar-btn monitor-ping" data-id="\${m.id}" title="Tester">\${svgIcon('refresh')}</button>
            <button class="fp-hover-toolbar-btn monitor-del"  data-id="\${m.id}" title="Supprimer">\${svgIcon('trash')}</button>
          </div>
        </div>
      \`).join('')}
    </div>

    <div class="fp-grid-2 fp-mb-16">
      <!-- Activity Timeline -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">⏱ Timeline d'activité</div>
        <div style="display:flex;flex-direction:column;gap:0">
          \${timeline.map((ev, i) => \`
            <div style="display:flex;gap:10px;align-items:flex-start;padding:9px 0;\${i < timeline.length - 1 ? 'border-bottom:1px solid rgba(255,255,255,0.04)' : ''}">
              <div style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:\${tlColor(ev.type)}18;border:1.5px solid \${tlColor(ev.type)}40;display:flex;align-items:center;justify-content:center;font-size:9px;margin-top:1px">\${tlIcon(ev.type)}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:11.5px;font-weight:600;color:var(--fp-text-soft)">\${escHtml(ev.site)}</div>
                <div style="font-size:11px;color:var(--fp-text-muted)">\${ev.msg}</div>
              </div>
              <span style="font-size:10px;color:var(--fp-text-faint);flex-shrink:0;white-space:nowrap">\${ev.time}</span>
            </div>
          \`).join('')}
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:10px" onclick="navigateSub('incidents')">Voir tous les incidents →</button>
      </div>

      <!-- Dependency Monitoring -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:4px">🔗 Dépendances externes</div>
        <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:14px">Services tiers critiques surveillés en temps réel</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          \${deps.map(d => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:rgba(255,255,255,0.03);border:1px solid \${depColor(d.status)}20;border-radius:8px">
              <span style="font-size:18px;flex-shrink:0">\${d.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${d.name}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${d.desc}</div>
              </div>
              <span style="font-size:11px;font-weight:600;color:var(--fp-text-muted)">\${d.latency}</span>
              <div style="width:8px;height:8px;border-radius:50%;background:\${depColor(d.status)};flex-shrink:0;\${d.status === 'operational' ? 'box-shadow:0 0 6px ' + depColor(d.status) + '60' : ''}"></div>
            </div>
          \`).join('')}
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:12px;padding-top:12px;border-top:1px solid var(--fp-border);font-size:11px;color:var(--fp-text-faint)">
          <span>\${deps.filter(d => d.status === 'operational').length}/\${deps.length} opérationnels</span>
          \${deps.filter(d => d.status !== 'operational').length > 0
            ? \`<span style="color:#f59e0b">⚠ \${deps.filter(d => d.status !== 'operational').length} dégradé(s)</span>\`
            : '<span style="color:#22c55e">✅ Tous opérationnels</span>'}
        </div>
      </div>
    </div>

    <div class="fp-grid-3 fp-mb-16">
      <!-- SSL -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:12px">🔒 Certificats SSL</div>
        <div style="display:flex;flex-direction:column;gap:6px">
          \${monitors.slice(0, 5).map((m, idx) => {
            const days = [312, 87, 42, 198, 156][idx % 5];
            const c = days < 30 ? '#ef4444' : days < 60 ? '#f59e0b' : '#22c55e';
            return \`<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
              <div style="width:6px;height:6px;border-radius:50%;background:\${c};flex-shrink:0"></div>
              <span style="flex:1;font-size:11px;color:var(--fp-text-soft);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${m.name}</span>
              <span style="font-size:11px;font-weight:700;color:\${c}">\${days}j</span>
            </div>\`;
          }).join('')}
        </div>
        <div style="font-size:10px;color:var(--fp-text-faint);margin-top:8px">Auto-renouvellement Let's Encrypt actif</div>
      </div>

      <!-- Alert channels summary -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:12px">🔔 Canaux d'alerte actifs</div>
        <div style="display:flex;flex-direction:column;gap:9px">
          \${[
            { icon: '📧', name: 'Email',   detail: \`\${monitors.filter(m => m.alertEmail).length} monitors\`, color: '#22c55e',  active: true },
            { icon: '💬', name: 'Slack',   detail: isPro ? '#flowpoint-alerts' : 'Pro requis →',              color: isPro ? '#22c55e' : '#64748b', active: isPro },
            { icon: '🎮', name: 'Discord', detail: isPro ? 'Webhook configuré' : 'Pro requis →',              color: isPro ? '#8b5cf6' : '#64748b', active: isPro },
            { icon: '📱', name: 'SMS',     detail: isUltra ? '+33 6 12 34 56 78' : 'Ultra requis →',         color: isUltra ? '#22c55e' : '#64748b', active: isUltra },
          ].map(ch => \`
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:16px">\${ch.icon}</span>
              <div style="flex:1">
                <div style="font-size:11.5px;font-weight:600;color:\${ch.active ? 'var(--fp-text)' : 'var(--fp-text-muted)'}">\${ch.name}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${ch.detail}</div>
              </div>
              <div style="width:8px;height:8px;border-radius:50%;background:\${ch.color}"></div>
            </div>
          \`).join('')}
        </div>
        <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;margin-top:12px" onclick="navigateSub('config')">Configurer →</button>
      </div>

      <!-- Predictive monitoring -->
      <div class="fp-card" style="\${isUltra ? '' : 'opacity:0.8'}">
        <div class="fp-card-title" style="margin-bottom:4px">🤖 Monitoring Prédictif\${isUltra ? '' : ' <span style="font-size:10px;color:#8b5cf6;background:rgba(139,92,246,0.1);padding:1px 6px;border-radius:4px;font-weight:600">Ultra</span>'}</div>
        <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:12px">Détection d'anomalies par IA avant incidents</div>
        \${isUltra ? \`
          <div style="display:flex;flex-direction:column;gap:8px">
            \${[
              { icon: '⚡', lvl: 'warning', site: 'restaurant-lesoleil.com', msg: 'Pic de latence probable vendredi 18h–20h' },
              { icon: '🔮', lvl: 'info',    site: 'coiffeur-lyon.com',       msg: 'Pattern d\'instabilité — 3 incidents similaires' },
              { icon: '✅', lvl: 'ok',      site: 'plombier-paris.fr',       msg: 'Performance stable · aucun risque' },
            ].map(p => \`
              <div style="padding:8px 10px;background:rgba(255,255,255,0.03);border-left:2px solid \${p.lvl === 'warning' ? '#f59e0b' : p.lvl === 'info' ? '#2563EB' : '#22c55e'};border-radius:0 6px 6px 0;font-size:11px">
                <div style="font-weight:600;color:var(--fp-text-soft);margin-bottom:2px">\${p.icon} \${p.site}</div>
                <div style="color:var(--fp-text-muted)">\${p.msg}</div>
              </div>
            \`).join('')}
          </div>
        \` : \`
          <div style="text-align:center;padding:16px 0">
            <div style="font-size:28px;margin-bottom:8px">🔮</div>
            <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:12px">Anticipez les pannes avant qu'elles arrivent</div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="navigate('billing')">Passer Ultra →</button>
          </div>
        \`}
      </div>
    </div>

    <!-- API Endpoint Monitoring -->
    <div class="fp-card">
      <div class="fp-flex-between" style="margin-bottom:14px">
        <div>
          <div class="fp-card-title" style="margin-bottom:0">🔌 API & Endpoints</div>
          <div style="font-size:11px;color:var(--fp-text-faint);margin-top:2px">Surveillance des endpoints critiques et webhooks</div>
        </div>
        \${btn('Ajouter endpoint', 'fp-btn fp-btn-ghost fp-btn-sm', 'plus', 'onclick="showToast(\'info\',\'Ajouter un endpoint API…\')"')}
      </div>
      <div style="overflow-x:auto">
        <table class="fp-data-table">
          <thead><tr><th>Endpoint</th><th>Méthode</th><th>Statut</th><th>Latence</th><th>Uptime</th><th>Check</th><th>Action</th></tr></thead>
          <tbody>
            \${[
              { name: 'API Contact Form',  url: '/api/contact',  method: 'POST', status: 'UP',   latency: '142ms',   rate: '99.8%', last: '2 min' },
              { name: 'Webhook GBP Sync',  url: '/webhooks/gbp', method: 'POST', status: 'UP',   latency: '89ms',    rate: '100%',  last: '5 min' },
              { name: 'API Avis Google',   url: '/api/reviews',  method: 'GET',  status: 'UP',   latency: '312ms',   rate: '99.1%', last: '1 min' },
              { name: 'Sitemap Generator', url: '/sitemap.xml',  method: 'GET',  status: 'SLOW', latency: '1 240ms', rate: '97.4%', last: '3 min' },
            ].map(ep => {
              const sc = ep.status === 'UP' ? '#22c55e' : ep.status === 'SLOW' ? '#f59e0b' : '#ef4444';
              const mc = ep.method === 'GET' ? '#2563EB' : '#8b5cf6';
              return \`<tr>
                <td>
                  <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${ep.name}</div>
                  <div style="font-size:10px;color:var(--fp-text-faint);font-family:var(--fp-font-mono)">\${ep.url}</div>
                </td>
                <td><span style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;background:\${mc}18;color:\${mc}">\${ep.method}</span></td>
                <td>\${badge(ep.status, sc)}</td>
                <td><span style="font-weight:700;color:\${parseInt(ep.latency) > 500 ? '#f59e0b' : 'var(--fp-text)'}">\${ep.latency}</span></td>
                <td><span style="color:\${parseFloat(ep.rate) >= 99 ? '#22c55e' : '#f59e0b'};font-weight:600">\${ep.rate}</span></td>
                <td><span style="font-size:11px;color:var(--fp-text-muted)">Il y a \${ep.last}</span></td>
                <td><button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Ping envoyé…')">Ping</button></td>
              </tr>\`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 2. renderMonitorsPerformance()
// ══════════════════════════════════════════════════════════════
const NEW_PERF = `function renderMonitorsPerformance() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const cwv = [
    { site: 'plombier-paris.fr',       lcp: 1.8, cls: 0.04, inp: 45,  ttfb: 180, score: 91 },
    { site: 'restaurant-lesoleil.com', lcp: 3.2, cls: 0.12, inp: 120, ttfb: 480, score: 58 },
    { site: 'boulangerie-martin.fr',   lcp: 2.4, cls: 0.08, inp: 78,  ttfb: 290, score: 74 },
    { site: 'coiffeur-lyon.com',       lcp: 4.1, cls: 0.21, inp: 210, ttfb: 890, score: 42 },
    { site: 'auto-moto-services.fr',   lcp: 2.0, cls: 0.05, inp: 55,  ttfb: 200, score: 88 },
  ];
  const lcpC  = v => v <= 2.5 ? '#22c55e' : v <= 4 ? '#f59e0b' : '#ef4444';
  const clsC  = v => v <= 0.1 ? '#22c55e' : v <= 0.25 ? '#f59e0b' : '#ef4444';
  const inpC  = v => v <= 200 ? '#22c55e' : v <= 500 ? '#f59e0b' : '#ef4444';
  const ttfbC = v => v <= 600 ? '#22c55e' : v <= 1800 ? '#f59e0b' : '#ef4444';

  const regions = [
    { name: '🇫🇷 France (Paris)',   latency: 142, ok: true },
    { name: '🇩🇪 Allemagne',        latency: 198, ok: true },
    { name: '🇬🇧 Royaume-Uni',      latency: 220, ok: true },
    { name: '🇳🇱 Pays-Bas',         latency: 167, ok: true },
    { name: '🇺🇸 USA (East)',       latency: 380, ok: false },
    { name: '🌏 Asie-Pacifique',    latency: 520, ok: false },
  ];

  return \`
    \${aiBlock(
      'Latence globale stable à <strong>319ms</strong>. ⚠ <strong>coiffeur-lyon.com</strong> : LCP 4.1s + TTFB 890ms — probable hébergement non optimisé + absence de CDN. Corriger peut gagner <strong>+18 pts CWV</strong> et réduire le taux de rebond de 12%.',
      ['Diagnostiquer coiffeur-lyon.com', 'Rapport CWV complet', 'Recommandations CDN']
    )}

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
      \${[
        { l: 'Latence moy.',     v: '319ms',  c: '#22c55e', sub: '-42ms vs hier' },
        { l: 'Score CWV moy.',   v: '71/100', c: '#f59e0b', sub: '+3 pts ce mois' },
        { l: 'LCP moyen',        v: '2.7s',   c: '#f59e0b', sub: 'Cible : ≤2.5s' },
        { l: 'Sites "Good" CWV', v: '2/5',    c: '#2563EB', sub: 'plombier + auto-moto' },
      ].map(s => \`
        <div class="fp-card fp-card-sm">
          <div style="font-size:10px;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px">\${s.l}</div>
          <div style="font-size:20px;font-weight:800;color:\${s.c};font-family:var(--fp-font-head);margin-bottom:3px">\${s.v}</div>
          <div style="font-size:10px;color:var(--fp-text-faint)">\${s.sub}</div>
        </div>
      \`).join('')}
    </div>

    <!-- AI Performance Insights -->
    <div class="fp-card fp-mb-16" style="background:linear-gradient(135deg,rgba(37,99,235,0.06) 0%,rgba(139,92,246,0.04) 100%);border-color:rgba(37,99,235,0.18)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
        <span style="font-size:16px">✦</span>
        <span style="font-size:13px;font-weight:700;color:#2563EB">IA Performance Intelligence</span>
        \${isUltra ? '' : '<span style="font-size:10px;color:#8b5cf6;background:rgba(139,92,246,0.12);padding:1px 7px;border-radius:4px;font-weight:600">Ultra</span>'}
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
        \${[
          { icon: '📱', title: 'Mobile Europe', msg: 'La latence mobile augmente en Europe (+18% cette semaine). Probablement lié à un pic de trafic sur coiffeur-lyon.com.', color: '#f59e0b' },
          { icon: '⚡', title: 'Pics serveur', msg: 'Les temps de réponse serveur spikent 08h–09h et 19h–20h. Pattern de charge cyclique — cache à activer.', color: '#ef4444' },
          { icon: '🔮', title: 'Prévision', msg: 'Dégradation probable vendredi 18h sur restaurant-lesoleil.com basée sur 4 semaines d\'historique.', color: '#2563EB' },
        ].map(ins => \`
          <div style="padding:10px;background:rgba(255,255,255,0.03);border-radius:8px;border-left:2px solid \${ins.color}">
            <div style="font-size:12px;font-weight:600;color:var(--fp-text);margin-bottom:4px">\${ins.icon} \${ins.title}</div>
            <div style="font-size:11px;color:var(--fp-text-muted);line-height:1.5">\${isUltra ? ins.msg : ins.msg.slice(0, 40) + '… <span style=\\"color:#8b5cf6;font-weight:600\\">Ultra requis</span>'}</div>
          </div>
        \`).join('')}
      </div>
    </div>

    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:14px">⚡ Latence temps réel par site</div>
      <div class="fp-funnel">
        \${STATE.monitors.map(m => \`
          <div class="fp-funnel-step">
            <div class="fp-funnel-label">\${escHtml(m.name)}</div>
            <div class="fp-funnel-bar-wrap">
              <div class="fp-funnel-bar-fill" style="width:\${Math.min(100, (m.latency / 1000) * 100)}%;background:\${m.latency > 500 ? '#ef4444' : m.latency > 200 ? '#f59e0b' : '#22c55e'}">
                \${m.status !== 'down' ? m.latency + 'ms' : 'DOWN'}
              </div>
            </div>
            <div class="fp-funnel-val">\${computeRealUptime(m)}%</div>
          </div>
        \`).join('')}
      </div>
    </div>

    <!-- Core Web Vitals table -->
    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:14px">📊 Core Web Vitals — LCP · CLS · INP · TTFB</div>
      <div style="overflow-x:auto">
        <table class="fp-data-table">
          <thead>
            <tr>
              <th>Site</th>
              <th style="text-align:center">LCP<div style="font-size:9px;color:var(--fp-text-faint);font-weight:400">≤2.5s</div></th>
              <th style="text-align:center">CLS<div style="font-size:9px;color:var(--fp-text-faint);font-weight:400">≤0.1</div></th>
              <th style="text-align:center">INP<div style="font-size:9px;color:var(--fp-text-faint);font-weight:400">≤200ms</div></th>
              <th style="text-align:center">TTFB<div style="font-size:9px;color:var(--fp-text-faint);font-weight:400">≤600ms</div></th>
              <th style="text-align:center">Score</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            \${cwv.map(c => \`
              <tr>
                <td><span style="font-family:var(--fp-font-mono);font-size:11px;color:var(--fp-text-soft)">\${c.site}</span></td>
                <td style="text-align:center">
                  <span style="font-weight:700;color:\${lcpC(c.lcp)}">\${c.lcp}s</span>
                  <div style="height:2px;background:rgba(255,255,255,0.07);border-radius:1px;width:44px;margin:3px auto 0"><div style="height:100%;width:\${Math.min(100,c.lcp/6*100)}%;background:\${lcpC(c.lcp)};border-radius:1px"></div></div>
                </td>
                <td style="text-align:center">
                  <span style="font-weight:700;color:\${clsC(c.cls)}">\${c.cls}</span>
                  <div style="height:2px;background:rgba(255,255,255,0.07);border-radius:1px;width:44px;margin:3px auto 0"><div style="height:100%;width:\${Math.min(100,c.cls/0.5*100)}%;background:\${clsC(c.cls)};border-radius:1px"></div></div>
                </td>
                <td style="text-align:center">
                  <span style="font-weight:700;color:\${inpC(c.inp)}">\${c.inp}ms</span>
                  <div style="height:2px;background:rgba(255,255,255,0.07);border-radius:1px;width:44px;margin:3px auto 0"><div style="height:100%;width:\${Math.min(100,c.inp/600*100)}%;background:\${inpC(c.inp)};border-radius:1px"></div></div>
                </td>
                <td style="text-align:center">
                  <span style="font-weight:700;color:\${ttfbC(c.ttfb)}">\${c.ttfb}ms</span>
                  <div style="height:2px;background:rgba(255,255,255,0.07);border-radius:1px;width:44px;margin:3px auto 0"><div style="height:100%;width:\${Math.min(100,c.ttfb/2000*100)}%;background:\${ttfbC(c.ttfb)};border-radius:1px"></div></div>
                </td>
                <td style="text-align:center">
                  <span style="font-size:16px;font-weight:800;color:\${c.score >= 80 ? '#22c55e' : c.score >= 50 ? '#f59e0b' : '#ef4444'}">\${c.score}</span>
                </td>
                <td><button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Analyse CWV lancée…')">Optimiser</button></td>
              </tr>
            \`).join('')}
          </tbody>
        </table>
      </div>
      <div style="display:flex;gap:16px;margin-top:10px;font-size:10.5px;color:var(--fp-text-faint)">
        <span><span style="color:#22c55e">●</span> Bon</span>
        <span><span style="color:#f59e0b">●</span> À améliorer</span>
        <span><span style="color:#ef4444">●</span> Mauvais</span>
      </div>
    </div>

    <div class="fp-grid-2">
      <!-- Regional perf -->
      <div class="fp-card" style="\${isPro ? '' : 'opacity:0.75'}">
        <div class="fp-card-title" style="margin-bottom:4px">🌍 Performance Géographique\${isPro ? '' : ' <span style="font-size:10px;color:#8b5cf6;background:rgba(139,92,246,0.1);padding:1px 6px;border-radius:4px;font-weight:600">Pro+</span>'}</div>
        <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:14px">Latence depuis 6 régions mondiales</div>
        \${isPro ? \`
          <div style="display:flex;flex-direction:column;gap:8px">
            \${regions.map(r => \`
              <div style="display:flex;align-items:center;gap:10px">
                <span style="font-size:11.5px;color:var(--fp-text-soft);min-width:175px">\${r.name}</span>
                <div style="flex:1;height:5px;background:rgba(255,255,255,0.07);border-radius:3px;overflow:hidden">
                  <div style="height:100%;width:\${Math.min(100, r.latency / 600 * 100)}%;background:\${r.ok ? '#22c55e' : r.latency < 450 ? '#f59e0b' : '#ef4444'};border-radius:3px;transition:width .6s"></div>
                </div>
                <span style="font-size:11.5px;font-weight:700;color:\${r.ok ? '#22c55e' : r.latency < 450 ? '#f59e0b' : '#ef4444'};min-width:52px;text-align:right">\${r.latency}ms</span>
              </div>
            \`).join('')}
          </div>
          <div style="margin-top:14px;padding:10px;background:rgba(37,99,235,0.06);border-radius:8px;font-size:11px;color:var(--fp-text-muted)">
            ⚠ Latence critique en Asie-Pacifique (520ms). Envisagez un CDN avec PoP Asie (Cloudflare / Fastly).
          </div>
        \` : \`
          <div style="text-align:center;padding:20px">
            <div style="font-size:32px;margin-bottom:10px">🌍</div>
            <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:12px">Monitoring depuis 6 régions mondiales</div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="navigate('billing')">Activer Pro →</button>
          </div>
        \`}
      </div>

      <!-- Mobile vs Desktop -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📱 Mobile vs Desktop</div>
        <div style="display:flex;flex-direction:column;gap:12px">
          \${cwv.slice(0, 4).map(c => {
            const mob = Math.max(20, c.score - Math.floor(Math.random() * 18 + 7));
            const delta = c.score - mob;
            return \`
              <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                  <span style="font-size:11px;color:var(--fp-text-soft)">\${c.site}</span>
                  <span style="font-size:10px;color:#ef4444">Mobile −\${delta} pts</span>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
                  <div>
                    <div style="font-size:9px;color:var(--fp-text-faint);margin-bottom:2px">🖥 Desktop</div>
                    <div style="height:5px;background:rgba(255,255,255,0.07);border-radius:3px;overflow:hidden"><div style="height:100%;width:\${c.score}%;background:\${c.score>=80?'#22c55e':c.score>=50?'#f59e0b':'#ef4444'};border-radius:3px"></div></div>
                    <div style="font-size:10px;font-weight:700;color:\${c.score>=80?'#22c55e':c.score>=50?'#f59e0b':'#ef4444'};margin-top:2px">\${c.score}/100</div>
                  </div>
                  <div>
                    <div style="font-size:9px;color:var(--fp-text-faint);margin-bottom:2px">📱 Mobile</div>
                    <div style="height:5px;background:rgba(255,255,255,0.07);border-radius:3px;overflow:hidden"><div style="height:100%;width:\${mob}%;background:\${mob>=80?'#22c55e':mob>=50?'#f59e0b':'#ef4444'};border-radius:3px"></div></div>
                    <div style="font-size:10px;font-weight:700;color:\${mob>=80?'#22c55e':mob>=50?'#f59e0b':'#ef4444'};margin-top:2px">\${mob}/100</div>
                  </div>
                </div>
              </div>
            \`;
          }).join('')}
        </div>
        <div style="margin-top:14px;padding:8px 10px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);border-radius:8px;font-size:11px;color:var(--fp-text-soft)">
          ⚠ Tous les sites ont un score mobile inférieur au desktop. Le mobile représente 63% du trafic Google.
        </div>
      </div>
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 3. renderMonitorsIncidents()
// ══════════════════════════════════════════════════════════════
const NEW_INCIDENTS = `function renderMonitorsIncidents() {
  const incidents = [
    {
      id: 'inc-1', site: 'restaurant-lesoleil.com',
      start: '08:14', end: '08:58', detected: '08:14', notified: '08:15', date: '03/05/2026',
      duration: '44 min', type: 'DOWN', severity: 'critical',
      rootCause: 'Saturation CPU hébergeur OVH — timeout connexion TCP après 30s',
      aiAnalysis: 'Cet incident correspond au pattern "saturation serveur mutualisé" identifié 2× ce trimestre. Les pics de CPU surviennent entre 08h–09h. Recommandation : migrer vers un VPS ou activer un CDN avec cache agressif.',
      impact: '~6–8 réservations perdues · ~180–240€ estimé · 847 visiteurs potentiels impactés',
      services: ['Site web', 'Formulaire contact', 'Réservation en ligne'],
      ttd: '47s', ttr: '44 min', notifiedBool: true,
    },
    {
      id: 'inc-2', site: 'coiffeur-lyon.com',
      start: '22:00', end: '22:12', detected: '22:01', notified: null, date: '28/04/2026',
      duration: '12 min', type: 'DÉGRADATION (>500ms)', severity: 'warning',
      rootCause: 'Pic de charge nocturne — plugin cache WP3TC désactivé lors d\'une mise à jour automatique',
      aiAnalysis: 'Dégradation nocturne récurrente après mise à jour WordPress. Pattern identifié : chaque mise à jour de plugin peut désactiver le cache. Solution préventive : mettre à jour via staging uniquement.',
      impact: 'Dégradation UX · Perte estimée <20€ · Aucune réservation perdue (heure creuse)',
      services: ['Site web', 'Galerie photos'],
      ttd: '1 min', ttr: '12 min', notifiedBool: false,
    },
    {
      id: 'inc-3', site: 'boulangerie-martin.fr',
      start: '14:30', end: '14:33', detected: '14:30', notified: null, date: '20/04/2026',
      duration: '3 min', type: 'DOWN', severity: 'info',
      rootCause: 'Redéploiement WordPress planifié — coupure de service intentionnelle',
      aiAnalysis: 'Coupure propre lors d\'un déploiement. Aucun risque identifié. Recommandation : activer le mode maintenance avant les déploiements pour éviter les erreurs 503.',
      impact: 'Négligeable (3 min, heure creuse) · Aucune perte estimée',
      services: ['Site web'],
      ttd: '<1 min', ttr: '3 min', notifiedBool: false,
    },
  ];
  const sevColor = s => s === 'critical' ? '#ef4444' : s === 'warning' ? '#f59e0b' : '#94a3b8';
  const sevLabel = s => s === 'critical' ? 'Critique' : s === 'warning' ? 'Important' : 'Informatif';
  const sevEmoji = s => s === 'critical' ? '🔴' : s === 'warning' ? '🟡' : 'ℹ️';

  return \`
    \${aiBlock(
      '3 incidents ce mois · Downtime total : <strong>59 min</strong> · Impact financier estimé : <strong>~200–260€</strong>. Pattern récurrent détecté : <strong>saturation hébergeur mutualisé</strong> sur restaurant-lesoleil.com. Migration VPS recommandée.',
      ['Plan de résolution IA', 'Rapport incidents PDF', 'Activer alertes SMS']
    )}

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
      \${[
        { l: 'Incidents ce mois', v: '3',    c: '#f59e0b', sub: 'vs 2 mois dernier' },
        { l: 'Downtime total',    v: '59min', c: '#ef4444', sub: '0.14% du mois' },
        { l: 'MTTR moyen',       v: '20min', c: '#22c55e', sub: 'Mean time to resolve' },
        { l: 'TTD moyen',        v: '54s',   c: '#22c55e', sub: 'Time to detect' },
      ].map(s => \`
        <div class="fp-card fp-card-sm">
          <div style="font-size:10px;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px">\${s.l}</div>
          <div style="font-size:20px;font-weight:800;color:\${s.c};font-family:var(--fp-font-head);margin-bottom:3px">\${s.v}</div>
          <div style="font-size:10px;color:var(--fp-text-faint)">\${s.sub}</div>
        </div>
      \`).join('')}
    </div>

    <!-- Timeline visual -->
    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:18px">📅 Timeline des incidents — Mai 2026</div>
      <div style="position:relative;padding:0 10px">
        <div style="position:absolute;top:10px;left:10px;right:10px;height:2px;background:rgba(255,255,255,0.07);border-radius:1px"></div>
        <div style="display:flex;justify-content:space-between;position:relative;z-index:1">
          \${[
            { day: '20/04', label: 'boulangerie 3min', type: 'info' },
            { day: '28/04', label: 'coiffeur dégradé 12min', type: 'warning' },
            { day: '01/05', label: 'Calme', type: 'ok' },
            { day: '03/05', label: 'restaurant DOWN 44min', type: 'critical' },
            { day: '07/05', label: 'Calme', type: 'ok' },
            { day: '09/05', label: 'Aujourd\'hui', type: 'today' },
          ].map(ev => \`
            <div style="display:flex;flex-direction:column;align-items:center;gap:6px;max-width:80px">
              <div style="width:14px;height:14px;border-radius:50%;background:\${ev.type==='critical'?'#ef4444':ev.type==='warning'?'#f59e0b':ev.type==='today'?'#2563EB':ev.type==='info'?'#94a3b8':'#22c55e'};border:2px solid var(--fp-bg);box-shadow:0 0 0 2px \${ev.type==='critical'?'#ef4444':ev.type==='warning'?'#f59e0b':ev.type==='today'?'#2563EB':ev.type==='info'?'#94a3b8':'#22c55e'}40"></div>
              <div style="font-size:10px;font-weight:700;color:var(--fp-text-faint)">\${ev.day}</div>
              <div style="font-size:9px;color:\${ev.type==='critical'?'#ef4444':ev.type==='warning'?'#f59e0b':ev.type==='today'?'#2563EB':'var(--fp-text-faint)'};text-align:center;line-height:1.3">\${ev.label}</div>
            </div>
          \`).join('')}
        </div>
      </div>
    </div>

    <!-- Incident cards -->
    <div style="display:flex;flex-direction:column;gap:14px">
      \${incidents.map(inc => \`
        <div class="fp-card" style="border-left:3px solid \${sevColor(inc.severity)}">
          <!-- Header -->
          <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:14px;flex-wrap:wrap">
            <div style="width:38px;height:38px;border-radius:10px;background:\${sevColor(inc.severity)}15;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:18px">\${sevEmoji(inc.severity)}</div>
            <div style="flex:1;min-width:160px">
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
                <span style="font-size:13px;font-weight:700;color:var(--fp-text)">\${escHtml(inc.site)}</span>
                \${badge(sevLabel(inc.severity), sevColor(inc.severity))}
                \${badge(inc.type, '#94a3b8')}
                \${badge('Résolu', '#22c55e')}
                \${inc.notifiedBool ? badge('Notifié ✓', '#2563EB') : '<span style="font-size:10px;color:var(--fp-text-faint)">⚠ Non notifié</span>'}
              </div>
              <div style="font-size:11px;color:var(--fp-text-faint);font-family:var(--fp-font-mono)">\${inc.date} · \${inc.start} → \${inc.end} · <strong>\${inc.duration}</strong></div>
            </div>
            <div style="display:flex;gap:16px;flex-shrink:0;text-align:center">
              <div><div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${inc.ttd}</div><div style="font-size:9px;color:var(--fp-text-faint);text-transform:uppercase">TTD</div></div>
              <div><div style="font-size:12px;font-weight:700;color:var(--fp-text)">\${inc.ttr}</div><div style="font-size:9px;color:var(--fp-text-faint);text-transform:uppercase">TTR</div></div>
            </div>
          </div>

          <!-- Mini timeline -->
          <div style="display:flex;align-items:flex-start;gap:2px;margin-bottom:14px;padding:10px;background:rgba(255,255,255,0.02);border-radius:8px;overflow-x:auto">
            \${[
              { label: 'Début',   time: inc.start,             color: '#ef4444' },
              { label: 'Détecté', time: inc.detected,          color: '#f59e0b' },
              { label: 'Notifié', time: inc.notified || '—',   color: inc.notified ? '#8b5cf6' : '#64748b' },
              { label: 'Résolu',  time: inc.end,               color: '#22c55e' },
            ].map((step, i, arr) => \`
              <div style="display:flex;align-items:center;flex-shrink:0">
                <div style="text-align:center;min-width:55px">
                  <div style="width:10px;height:10px;border-radius:50%;background:\${step.color};margin:0 auto 4px;box-shadow:0 0 6px \${step.color}60"></div>
                  <div style="font-size:11px;font-weight:700;color:\${step.color}">\${step.time}</div>
                  <div style="font-size:9px;color:var(--fp-text-faint)">\${step.label}</div>
                </div>
                \${i < arr.length - 1 ? '<div style="flex:1;height:1px;background:rgba(255,255,255,0.1);min-width:20px;margin:0 4px;margin-top:-18px"></div>' : ''}
              </div>
            \`).join('')}
          </div>

          <!-- Details -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
            <div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:10px">
              <div style="font-size:10px;font-weight:700;color:var(--fp-text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">🔍 Cause identifiée</div>
              <div style="font-size:11.5px;color:var(--fp-text-soft);line-height:1.5">\${escHtml(inc.rootCause)}</div>
            </div>
            <div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:10px">
              <div style="font-size:10px;font-weight:700;color:var(--fp-text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">💥 Impact business</div>
              <div style="font-size:11.5px;color:\${inc.severity==='critical'?'#ef4444':'var(--fp-text-soft)'};line-height:1.5">\${escHtml(inc.impact)}</div>
            </div>
          </div>

          <!-- AI root cause -->
          <div style="background:rgba(37,99,235,0.07);border-left:2px solid #2563EB;padding:10px 12px;border-radius:0 8px 8px 0;margin-bottom:12px">
            <div style="font-size:10px;font-weight:700;color:#2563EB;margin-bottom:4px">✦ Analyse IA · Root Cause Detection</div>
            <div style="font-size:11.5px;color:var(--fp-text-soft);line-height:1.6">\${escHtml(inc.aiAnalysis)}</div>
          </div>

          <!-- Services + actions -->
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
            <div>
              <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:5px">Services impactés :</div>
              <div style="display:flex;gap:5px;flex-wrap:wrap">
                \${inc.services.map(s => \`<span style="font-size:10px;background:rgba(239,68,68,0.1);color:#ef4444;border-radius:4px;padding:2px 7px">\${s}</span>\`).join('')}
              </div>
            </div>
            <div style="display:flex;gap:6px;flex-shrink:0">
              \${btn('Plan d\'action', 'fp-btn fp-btn-ghost fp-btn-sm', '', 'onclick="showToast(\'info\',\'Plan d\\\'action généré…\')"')}
              \${btn('Rapport PDF', 'fp-btn fp-btn-ghost fp-btn-sm', 'download', 'onclick="showToast(\'success\',\'Rapport généré…\')"')}
            </div>
          </div>
        </div>
      \`).join('')}
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 4. renderMonitorsConfig()
// ══════════════════════════════════════════════════════════════
const NEW_CONFIG = `function renderMonitorsConfig() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';

  const presets = [
    { icon: '🛒', name: 'E-commerce',  desc: 'Vérif. panier + paiement · LCP <2s · SSL', checks: ['Uptime', 'Checkout', 'Stripe', 'SSL', 'CWV'], color: '#22c55e', pro: false },
    { icon: '⚡', name: 'API / SaaS',  desc: 'Endpoints + webhooks + latence <200ms',      checks: ['Endpoints', 'Webhooks', 'Auth', 'Rate limits'], color: '#2563EB', pro: false },
    { icon: '📍', name: 'Local Biz',   desc: 'GBP + avis + présence locale + speed mobile', checks: ['Uptime', 'Mobile', 'GBP', 'DNS'], color: '#f59e0b', pro: false },
    { icon: '🏢', name: 'Corporate',   desc: 'Multi-régions + SLA 99.9% + alertes équipe',  checks: ['Uptime', 'Régions', 'SLA', 'SSL', 'Incidents'], color: '#8b5cf6', pro: true },
  ];
  const channels = [
    { icon: '📧', name: 'Email',    active: true,    detail: \`\${STATE.monitors.filter(m => m.alertEmail).length} monitors configurés\`, color: '#22c55e', gate: null },
    { icon: '💬', name: 'Slack',    active: isPro,   detail: isPro ? '#flowpoint-alerts actif' : 'Disponible Pro+', color: isPro ? '#22c55e' : '#64748b', gate: 'Pro' },
    { icon: '🎮', name: 'Discord',  active: isPro,   detail: isPro ? 'Bot Flowpoint connecté' : 'Disponible Pro+', color: isPro ? '#8b5cf6' : '#64748b', gate: 'Pro' },
    { icon: '📱', name: 'SMS',      active: isUltra, detail: isUltra ? '+33 6 12 34 56 78' : 'Disponible Ultra', color: isUltra ? '#22c55e' : '#64748b', gate: 'Ultra' },
    { icon: '🔗', name: 'Webhook',  active: isPro,   detail: isPro ? 'api.monagence.fr/alerts' : 'Disponible Pro+', color: isPro ? '#2563EB' : '#64748b', gate: 'Pro' },
    { icon: '📢', name: 'PagerDuty',active: isUltra, detail: isUltra ? 'Intégration active' : 'Disponible Ultra', color: isUltra ? '#f59e0b' : '#64748b', gate: 'Ultra' },
  ];
  const windows = [
    { name: 'Déploiement hebdo',  schedule: 'Dimanche 02:00–04:00', sites: 'Tous les sites',         next: '11 mai 02:00' },
    { name: 'Maintenance OVH',    schedule: 'Lundi 23:00–01:00',    sites: 'restaurant-lesoleil.com', next: '13 mai 23:00' },
  ];

  return \`
    \${aiBlock('Configuration optimale détectée. Recommandation : activer <strong>Slack alerts</strong> pour notifications équipe instantanées, et créer une <strong>fenêtre de maintenance</strong> pour les déploiements du dimanche.', [])}

    <!-- Presets -->
    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:4px">⚙ Presets de monitoring</div>
      <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:16px">Templates préconfigurés selon votre type de site — déploiement en 1 clic</div>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px">
        \${presets.map(p => \`
          <div style="padding:14px;background:rgba(255,255,255,0.03);border:1px solid \${p.color}22;border-radius:10px;\${p.pro && !isPro ? 'opacity:0.65' : ''}">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
              <span style="font-size:22px">\${p.icon}</span>
              <div>
                <div style="font-size:12.5px;font-weight:700;color:var(--fp-text)">\${p.name}\${p.pro && !isPro ? ' <span style="font-size:9px;color:#8b5cf6;background:rgba(139,92,246,0.1);padding:1px 5px;border-radius:3px">Pro</span>' : ''}</div>
                <div style="font-size:10.5px;color:var(--fp-text-muted);margin-top:1px">\${p.desc}</div>
              </div>
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px">
              \${p.checks.map(c => \`<span style="font-size:9.5px;background:\${p.color}15;color:\${p.color};border-radius:4px;padding:1px 6px">\${c}</span>\`).join('')}
            </div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;\${p.pro && !isPro ? 'opacity:0.5;cursor:not-allowed' : ''}" onclick="\${p.pro && !isPro ? "navigate('billing')" : \`showToast('success','Preset «\${p.name}» appliqué !')\`}">
              \${p.pro && !isPro ? '🔒 Activer Pro' : 'Appliquer →'}
            </button>
          </div>
        \`).join('')}
      </div>
    </div>

    <!-- Alert Channels -->
    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:4px">🔔 Canaux d'alerte multi-canal</div>
      <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:16px">Escalade intelligente · Groupage d'alertes · Réduction du bruit IA</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
        \${channels.map(ch => \`
          <div style="padding:12px;background:rgba(255,255,255,0.03);border:1px solid \${ch.active ? ch.color + '35' : 'var(--fp-border)'};border-radius:10px;\${!ch.active ? 'opacity:0.65' : ''}">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <div style="display:flex;align-items:center;gap:7px">
                <span style="font-size:20px">\${ch.icon}</span>
                <span style="font-size:12.5px;font-weight:700;color:var(--fp-text)">\${ch.name}</span>
              </div>
              <div style="width:8px;height:8px;border-radius:50%;background:\${ch.active ? ch.color : '#64748b'};\${ch.active ? 'box-shadow:0 0 6px ' + ch.color + '60' : ''}"></div>
            </div>
            <div style="font-size:10.5px;color:var(--fp-text-muted);margin-bottom:10px">\${ch.detail}</div>
            <button class="fp-btn fp-btn-ghost fp-btn-sm" style="width:100%;font-size:10px" onclick="\${!ch.active ? "navigate('billing')" : \`showToast('info','Configuration \${ch.name}…')\`}">
              \${!ch.active ? \`🔒 \${ch.gate} requis\` : 'Configurer'}
            </button>
          </div>
        \`).join('')}
      </div>

      <!-- Global settings -->
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;padding-top:14px;border-top:1px solid var(--fp-border)">
        <div>
          <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:7px">Intervalle de check</div>
          <select class="fp-select" style="width:100%">
            <option>Toutes les 30s (Ultra)</option>
            <option>Toutes les 1 min (Pro+)</option>
            <option selected>Toutes les 5 min</option>
            <option>Toutes les 10 min</option>
          </select>
        </div>
        <div>
          <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:7px">Seuil alerte latence</div>
          <select class="fp-select" style="width:100%">
            <option>200ms</option>
            <option selected>500ms</option>
            <option>1 000ms</option>
          </select>
        </div>
        <div>
          <div style="font-size:11px;color:var(--fp-text-muted);margin-bottom:7px">Groupage d'alertes IA</div>
          <select class="fp-select" style="width:100%">
            <option selected>Activé (réduction bruit)</option>
            <option>Désactivé</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Maintenance Windows -->
    <div class="fp-card fp-mb-16">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div>
          <div class="fp-card-title" style="margin-bottom:0">🛠 Fenêtres de maintenance</div>
          <div style="font-size:11px;color:var(--fp-text-faint);margin-top:2px">Silencez les alertes pendant les déploiements planifiés</div>
        </div>
        \${btn('+ Nouvelle fenêtre', 'fp-btn fp-btn-ghost fp-btn-sm', '', 'onclick="showToast(\'info\',\'Configurer une fenêtre de maintenance…\')"')}
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px">
        \${windows.map(w => \`
          <div style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:rgba(255,255,255,0.03);border:1px solid var(--fp-border);border-radius:9px;flex-wrap:wrap">
            <div style="flex:1;min-width:120px">
              <div style="font-size:12px;font-weight:600;color:var(--fp-text)">\${w.name}</div>
              <div style="font-size:11px;color:var(--fp-text-muted)">\${w.schedule} · \${w.sites}</div>
            </div>
            <div>
              <div style="font-size:10px;color:var(--fp-text-faint)">Prochaine</div>
              <div style="font-size:11px;font-weight:600;color:var(--fp-accent)">\${w.next}</div>
            </div>
            \${badge('Actif', '#22c55e')}
            <button class="fp-btn fp-btn-ghost fp-btn-sm" onclick="showToast('info','Fenêtre modifiée…')">Modifier</button>
          </div>
        \`).join('')}
      </div>
    </div>

    <!-- Per-monitor config -->
    <div class="fp-card">
      <div class="fp-card-title" style="margin-bottom:14px">📋 Configuration par monitor</div>
      \${STATE.monitors.map(m => \`
        <div style="padding:12px 0;border-bottom:1px solid var(--fp-border)">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap">
            <div class="fp-monitor-pulse \${m.status}" style="flex-shrink:0"></div>
            <div style="flex:1">
              <div style="font-size:13px;font-weight:600;color:var(--fp-text)">\${escHtml(m.name)}</div>
              <div style="font-size:10px;color:var(--fp-text-faint);font-family:var(--fp-font-mono)">\${escHtml(m.url)}</div>
            </div>
            \${badge(statusLabel(m.status), statusBadgeColor(m.status))}
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding-left:20px">
            <div style="display:flex;gap:8px;align-items:center">
              <span style="font-size:10px;color:var(--fp-text-muted);width:65px">📧 Email :</span>
              <input class="fp-input monitor-cfg-email" data-monitor-id="\${m.id}" placeholder="alerte@email.com" value="\${escHtml(m.alertEmail || '')}" style="flex:1;height:30px;font-size:11px"/>
              <button class="fp-btn fp-btn-primary fp-btn-sm monitor-cfg-save" data-monitor-id="\${m.id}">✓</button>
            </div>
            <div style="display:flex;gap:8px;align-items:center;\${isUltra ? '' : 'opacity:0.5'}">
              <span style="font-size:10px;color:#8b5cf6;width:65px">📱 SMS :</span>
              <input class="fp-input" placeholder="+33 6…" value="\${escHtml(m.alertPhone || '')}" style="flex:1;height:30px;font-size:11px" \${isUltra ? '' : 'disabled'}/>
              <button class="fp-btn fp-btn-ghost fp-btn-sm" \${isUltra ? '' : 'disabled'}>✓</button>
            </div>
          </div>
        </div>
      \`).join('')}
    </div>
  \`;
}`;

// ══════════════════════════════════════════════════════════════
// 5. renderMonitorsSLA()
// ══════════════════════════════════════════════════════════════
const NEW_SLA = `function renderMonitorsSLA() {
  const plan = STATE.me?.plan || 'Pro';
  const isPro = plan === 'Pro' || plan === 'Agency';
  const isUltra = plan === 'Agency';
  const monitors = STATE.monitors;
  const globalUptime = (monitors.reduce((s, m) => s + parseFloat(computeRealUptime(m)), 0) / Math.max(1, monitors.length)).toFixed(2);
  const slaOK = parseFloat(globalUptime) >= 99.0;

  const slaData = monitors.map(m => {
    const up = parseFloat(computeRealUptime(m));
    const ok = up >= 99.0;
    const downMin = ok ? 0 : Math.round((100 - up) / 100 * 30 * 24 * 60);
    const risk = !ok ? 'Hors SLA' : up < 99.5 ? 'À risque' : 'Conforme';
    return { m, up, ok, downMin, risk };
  });

  const months = ['Nov', 'Déc', 'Jan', 'Fév', 'Mar', 'Avr', 'Mai'];
  const uptimes = [97.4, 98.1, 98.8, 99.2, 99.4, 99.1, parseFloat(globalUptime)];

  return \`
    <div class="fp-section-header">
      <div>
        <h1>SLA Intelligence Center</h1>
        <div class="fp-section-sub">Service Level Agreements · Engagement uptime · Prévision breach · Mai 2026</div>
      </div>
      <div class="fp-section-actions">
        \${btn('Rapport SLA PDF', 'fp-btn fp-btn-ghost fp-btn-sm', 'download', 'onclick="showToast(\'success\',\'Rapport SLA PDF en cours…\')"')}
        \${btn('Page statut', 'fp-btn fp-btn-primary fp-btn-sm', 'globe', 'onclick="showToast(\'success\',\'Lien copié : status.monagence.fr\')"')}
      </div>
    </div>

    \${aiBlock(
      slaOK
        ? \`SLA global respecté : <strong>\${globalUptime}%</strong> uptime (cible 99,0%). Aucune violation ce mois. <strong>\${slaData.filter(s => s.risk === 'Conforme').length}/\${monitors.length}</strong> sites conformes. Attention : restaurant-lesoleil.com atteindra 97.8% si un nouvel incident survient.\`
        : \`⚠ <strong>Violation SLA détectée.</strong> Uptime global : <strong>\${globalUptime}%</strong> (cible 99,0%). \${slaData.filter(s => !s.ok).length} site(s) hors SLA — plan correctif requis.\`,
      ['Rapport SLA complet', 'Envoyer rapport client', 'Plan correctif']
    )}

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
      \${[
        { l: 'SLA Global',       v: globalUptime + '%', c: slaOK ? '#22c55e' : '#ef4444', sub: 'Cible : 99.0%' },
        { l: 'Sites conformes',  v: slaData.filter(s => s.ok).length + '/' + monitors.length, c: '#22c55e', sub: 'Au-dessus du seuil' },
        { l: 'Downtime total',   v: '44 min',   c: '#f59e0b', sub: '0.10% du mois' },
        { l: 'Page statut',      v: 'Active',   c: '#22c55e', sub: 'status.monagence.fr' },
      ].map(s => \`
        <div class="fp-card fp-card-sm">
          <div style="font-size:10px;color:var(--fp-text-faint);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px">\${s.l}</div>
          <div style="font-size:22px;font-weight:800;color:\${s.c};font-family:var(--fp-font-head);margin-bottom:3px">\${s.v}</div>
          <div style="font-size:10px;color:var(--fp-text-faint)">\${s.sub}</div>
        </div>
      \`).join('')}
    </div>

    <div class="fp-grid-2 fp-mb-16">
      <!-- Uptime chart -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">📊 Uptime historique — 7 mois</div>
        <div style="display:flex;align-items:flex-end;gap:8px;height:90px;margin-bottom:8px">
          \${uptimes.map((v, i) => \`
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%">
              <div style="font-size:9px;color:var(--fp-text-faint)">\${v.toFixed(1)}%</div>
              <div style="flex:1;width:100%;display:flex;align-items:flex-end">
                <div style="width:100%;height:\${Math.max(6, (v - 96) / 4 * 100)}%;background:\${v >= 99.5 ? '#22c55e' : v >= 99 ? '#f59e0b' : '#ef4444'};border-radius:4px 4px 0 0;transition:height .5s ease;\${i === uptimes.length - 1 ? 'box-shadow:0 0 8px ' + (v >= 99 ? '#22c55e' : '#f59e0b') + '60' : ''}"></div>
              </div>
            </div>
          \`).join('')}
        </div>
        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--fp-text-faint)">
          \${months.map(m => \`<span>\${m}</span>\`).join('')}
        </div>
        <div style="display:flex;gap:12px;margin-top:10px;font-size:10.5px;color:var(--fp-text-faint)">
          <span><span style="color:#22c55e">●</span> ≥99.5%</span>
          <span><span style="color:#f59e0b">●</span> 99.0–99.5%</span>
          <span><span style="color:#ef4444">●</span> <99.0%</span>
        </div>
      </div>

      <!-- SLA Risk Detection -->
      <div class="fp-card" style="\${isUltra ? '' : 'opacity:0.8'}">
        <div class="fp-card-title" style="margin-bottom:4px">⚠ SLA Risk Detection\${isUltra ? '' : ' <span style="font-size:10px;color:#8b5cf6;background:rgba(139,92,246,0.1);padding:1px 6px;border-radius:4px;font-weight:600">Ultra</span>'}</div>
        <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:14px">Détection proactive des violations SLA à venir</div>
        \${isUltra ? \`
          <div style="display:flex;flex-direction:column;gap:12px">
            \${[
              { site: 'restaurant-lesoleil.com', risk: 82, msg: '2 incidents ce mois → SLA breach à 97.8% si 1 incident de plus', color: '#ef4444' },
              { site: 'coiffeur-lyon.com',       risk: 45, msg: 'Latence élevée récurrente — risque dégradation SLA sous 30j',    color: '#f59e0b' },
              { site: 'boulangerie-martin.fr',   risk: 12, msg: 'Uptime stable · Aucun risque de violation SLA détecté',           color: '#22c55e' },
            ].map(r => \`
              <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                  <span style="font-size:11.5px;color:var(--fp-text-soft)">\${r.site}</span>
                  <span style="font-size:12px;font-weight:800;color:\${r.color}">Risque \${r.risk}%</span>
                </div>
                <div style="height:5px;background:rgba(255,255,255,0.07);border-radius:3px;overflow:hidden;margin-bottom:4px">
                  <div style="height:100%;width:\${r.risk}%;background:\${r.color};border-radius:3px;transition:width .6s"></div>
                </div>
                <div style="font-size:10.5px;color:var(--fp-text-muted)">\${r.msg}</div>
              </div>
            \`).join('')}
          </div>
          <div style="margin-top:14px;padding:10px;background:rgba(37,99,235,0.06);border-radius:8px;font-size:11px;color:var(--fp-text-muted)">
            ✦ Prévision IA : uptime global stable à 99.1% les 30 prochains jours si aucun nouveau incident critique.
          </div>
        \` : \`
          <div style="text-align:center;padding:20px">
            <div style="font-size:32px;margin-bottom:10px">🔮</div>
            <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:12px">Anticipez les violations SLA avant qu'elles surviennent</div>
            <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="navigate('billing')">Passer Ultra →</button>
          </div>
        \`}
      </div>
    </div>

    <!-- SLA table per site -->
    <div class="fp-card fp-mb-16">
      <div class="fp-card-title" style="margin-bottom:14px">📋 SLA par site — Mai 2026</div>
      <div style="overflow-x:auto">
        <table class="fp-data-table">
          <thead>
            <tr><th>Site</th><th>Cible</th><th>Uptime réel</th><th>Downtime</th><th>Incidents</th><th>Risque</th><th>Statut</th></tr>
          </thead>
          <tbody>
            \${slaData.map(({ m, up, ok, downMin, risk }) => \`
              <tr>
                <td>
                  <strong style="font-size:12px">\${escHtml(m.name)}</strong>
                  <div style="font-size:10px;color:var(--fp-text-faint);font-family:var(--fp-font-mono)">\${escHtml(m.url)}</div>
                </td>
                <td style="color:var(--fp-text-muted)">99.0%</td>
                <td>
                  <span style="font-weight:800;color:\${ok ? '#22c55e' : up >= 98 ? '#f59e0b' : '#ef4444'}">\${up}%</span>
                  <div style="height:3px;background:rgba(255,255,255,0.06);border-radius:2px;width:60px;margin-top:3px">
                    <div style="height:100%;width:\${Math.min(100, up)}%;background:\${ok ? '#22c55e' : '#ef4444'};border-radius:2px"></div>
                  </div>
                </td>
                <td>\${downMin > 0 ? '<span style="color:#f59e0b">' + downMin + ' min</span>' : '<span style="color:#22c55e">0 min</span>'}</td>
                <td>\${m.status === 'down' ? '<span style="color:#ef4444">1</span>' : '<span style="color:#22c55e">0</span>'}</td>
                <td>\${badge(risk, risk === 'Conforme' ? '#22c55e' : risk === 'À risque' ? '#f59e0b' : '#ef4444')}</td>
                <td>\${badge(ok ? 'SLA OK' : 'Hors SLA', ok ? '#22c55e' : '#ef4444')}</td>
              </tr>
            \`).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Business Impact Engine + Public status + Synthetic journeys -->
    <div class="fp-grid-2 fp-mb-16">
      <!-- Business Impact -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:4px">💼 Business Impact Engine</div>
        <div style="font-size:11px;color:var(--fp-text-faint);margin-bottom:14px">Impact des incidents sur vos KPI business</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          \${[
            { icon: '💰', title: 'Perte revenue estimée', val: '~220€', sub: 'Mai 2026 · restaurant-lesoleil.com', color: '#ef4444' },
            { icon: '📉', title: 'Taux de rebond impact', val: '+8%',  sub: 'Corrélé aux incidents de latence',   color: '#f59e0b' },
            { icon: '🛒', title: 'Conversions perdues',   val: '~6',   sub: 'Réservations non abouties',          color: '#f59e0b' },
            { icon: '⭐', title: 'Impact satisfaction',   val: '-0.2★', sub: 'Projection note Google estimée',    color: '#94a3b8' },
          ].map(kpi => \`
            <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:rgba(255,255,255,0.03);border-radius:8px">
              <span style="font-size:20px">\${kpi.icon}</span>
              <div style="flex:1">
                <div style="font-size:11.5px;font-weight:600;color:var(--fp-text)">\${kpi.title}</div>
                <div style="font-size:10px;color:var(--fp-text-faint)">\${kpi.sub}</div>
              </div>
              <span style="font-size:14px;font-weight:800;color:\${kpi.color}">\${kpi.val}</span>
            </div>
          \`).join('')}
        </div>
      </div>

      <!-- Public status page -->
      <div class="fp-card">
        <div class="fp-card-title" style="margin-bottom:14px">🌐 Page statut publique</div>
        <div style="background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:10px;padding:12px;margin-bottom:14px">
          <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:4px">URL de votre page statut</div>
          <div style="font-family:var(--fp-font-mono);font-size:12px;color:var(--fp-accent)">status.monagence.fr</div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
          \${[
            { l: 'Monitors affichés', v: 'Actif' }, { l: 'White Label', v: 'Actif' },
            { l: 'Abonnés email', v: '3' },         { l: 'Mise à jour', v: 'Temps réel' },
          ].map(s => \`
            <div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:8px 10px;text-align:center">
              <div style="font-size:10px;color:var(--fp-text-faint)">\${s.l}</div>
              <div style="font-size:13px;font-weight:700;color:var(--fp-text);margin-top:3px">\${s.v}</div>
            </div>
          \`).join('')}
        </div>
        <div style="display:flex;gap:8px">
          \${btn('Copier lien', 'fp-btn fp-btn-ghost fp-btn-sm', '', 'onclick="showToast(\'success\',\'Lien copié !\')"')}
          \${btn('Voir la page', 'fp-btn fp-btn-primary fp-btn-sm', 'globe', 'onclick="showToast(\'info\',\'Ouverture de la page statut…\')"')}
        </div>
      </div>
    </div>

    <!-- Synthetic Journeys -->
    <div class="fp-card" style="\${isUltra ? '' : 'opacity:0.8'}">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:10px">
        <div>
          <div class="fp-card-title" style="margin-bottom:0">🤖 Journeys Synthétiques\${isUltra ? '' : ' <span style="font-size:10px;color:#8b5cf6;background:rgba(139,92,246,0.1);padding:1px 6px;border-radius:4px;font-weight:600">Ultra</span>'}</div>
          <div style="font-size:11px;color:var(--fp-text-faint);margin-top:2px">Simulation automatique des parcours utilisateurs critiques</div>
        </div>
        \${isUltra ? btn('Relancer tous les tests', 'fp-btn fp-btn-ghost fp-btn-sm', '', 'onclick="showToast(\'info\',\'Journeys lancés…\')"') : ''}
      </div>
      \${isUltra ? \`
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
          \${[
            { icon: '🔐', name: 'Simulation login',      status: 'OK',   time: '1.2s', site: 'boulangerie-martin.fr',   steps: 3 },
            { icon: '🛒', name: 'Simulation checkout',   status: 'OK',   time: '2.4s', site: 'restaurant-lesoleil.com', steps: 5 },
            { icon: '📋', name: 'Simulation formulaire', status: 'FAIL', time: '—',    site: 'coiffeur-lyon.com',       steps: 2 },
          ].map(j => \`
            <div style="padding:12px;background:rgba(255,255,255,0.03);border:1px solid \${j.status === 'OK' ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)'};border-radius:9px">
              <div style="font-size:22px;margin-bottom:8px">\${j.icon}</div>
              <div style="font-size:12px;font-weight:700;color:var(--fp-text);margin-bottom:2px">\${j.name}</div>
              <div style="font-size:10px;color:var(--fp-text-faint);margin-bottom:8px">\${j.site} · \${j.steps} étapes</div>
              <div style="display:flex;align-items:center;justify-content:space-between">
                \${badge(j.status, j.status === 'OK' ? '#22c55e' : '#ef4444')}
                <span style="font-size:11px;font-weight:600;color:var(--fp-text-muted)">\${j.time}</span>
              </div>
            </div>
          \`).join('')}
        </div>
      \` : \`
        <div style="text-align:center;padding:20px">
          <div style="font-size:32px;margin-bottom:10px">🤖</div>
          <div style="font-size:12px;color:var(--fp-text-muted);margin-bottom:12px">Testez automatiquement login, checkout, formulaires — 24/7</div>
          <button class="fp-btn fp-btn-primary fp-btn-sm" onclick="navigate('billing')">Activer Ultra →</button>
        </div>
      \`}
    </div>
  \`;
}`;

// Apply all replacements
src = replaceFunc(src, 'renderMonitors',             NEW_MONITORS);
src = replaceFunc(src, 'renderMonitorsPerformance',   NEW_PERF);
src = replaceFunc(src, 'renderMonitorsIncidents',     NEW_INCIDENTS);
src = replaceFunc(src, 'renderMonitorsConfig',        NEW_CONFIG);
src = replaceFunc(src, 'renderMonitorsSLA',           NEW_SLA);

writeFileSync(file, src, 'utf8');
console.log('✅ All 5 monitor functions replaced.');
