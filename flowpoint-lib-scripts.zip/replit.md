# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM (schema defined; in-memory store used for dashboard data)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (ESM bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Artifacts

### API Server (`artifacts/api-server`)
Express 5 API server with the following endpoints:
- `GET /api/healthz` — health check
- `GET /api/me` — current user + plan info
- `GET /api/overview` — dashboard overview stats
- `GET /api/audits`, `POST /api/audits`, `DELETE /api/audits/:id`
- `GET /api/monitors`, `POST /api/monitors`, `PATCH /api/monitors/:id`, `DELETE /api/monitors/:id`
- `GET /api/reports`, `POST /api/reports`, `GET /api/reports/:id/download` (PDF), `DELETE /api/reports/:id`
- `GET /api/team`, `POST /api/team/invite`, `DELETE /api/team/:id`
- `POST /api/ai/chat` — AI assistant (uses OpenAI if OPENAI_API_KEY set, mock otherwise)
- `POST /api/billing/portal` — Stripe customer portal (uses Stripe if STRIPE_SECRET_KEY set, mock URL otherwise)
- `GET /api/billing/events` — Server-Sent Events for real-time plan updates
- `POST /api/webhooks/stripe` — Stripe webhook handler (subscription.updated, subscription.deleted, invoice.payment_succeeded)

### Dashboard (`artifacts/flowpoint-export/dashboard.js`)
Vanilla JS IIFE dashboard. Features:
- **Stripe portal**: "Gérer" button on billing page calls `POST /api/billing/portal` and opens the returned URL in a new tab
- **PDF download**: FAB "Générer rapport PDF" creates a report via `POST /api/reports` then triggers browser download from `GET /api/reports/:id/download`
- **Real-time plan updates**: Subscribes to `GET /api/billing/events` SSE on init, updates `STATE.me.plan` and re-renders billing section when plan changes
- **Monitor auto-refresh**: Polls `/api/monitors` every 60s
- **Browser push notifications**: Bell toggle in the activity panel header and in Settings > Alertes & Notifications. When enabled, fires a native `Notification` for each `activity:new` SSE event when `document.hidden === true`. Clicking the notification focuses the window and opens the activity panel. State persisted in `localStorage['fp-push-notif']`.

Note: `artifacts/mockup-sandbox/public/dashboard/` is a synced copy of `artifacts/flowpoint-export/` — keep both in sync when editing dashboard files.

### Mockup Sandbox (`artifacts/mockup-sandbox`)
React/Vite component preview server. Serves `public/dashboard/` as static files (includes the Flowpoint dashboard).

## Services (`artifacts/api-server/src/services/`)

- **`store.ts`** — in-memory data store (monitors, audits, reports, team, user). Resets on server restart.
- **`mock-data.ts`** — default seed data for the store
- **`email.ts`** — nodemailer-based email service. Requires `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`. Logs email content when SMTP not configured.
- **`pdf.ts`** — PDFKit-based PDF report generation. Streams directly to response.
- **`monitor-cron.ts`** — node-cron job (every 5 minutes) that checks monitor URLs, sends DOWN/UP email alerts to `monitor.alertEmail` and/or `ALERT_EMAIL` env var.

## Environment Variables

- `PORT` — required for API server and mockup-sandbox
- `STRIPE_SECRET_KEY` — Stripe API key (optional; uses mock URLs without it)
- `STRIPE_WEBHOOK_SECRET` — Stripe webhook signing secret (optional; skips verification without it)
- `STRIPE_CUSTOMER_ID` — pre-existing Stripe customer ID (optional)
- `STRIPE_RETURN_URL` — URL to return to after Stripe portal (optional)
- `PUBLIC_URL` — public URL of the app (optional, used for Stripe return URL)
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` — SMTP email credentials (optional)
- `SMTP_FROM` — from address for emails (optional, defaults to SMTP_USER)
- `ALERT_EMAIL` — global email for monitor DOWN alerts (optional)
- `OPENAI_API_KEY` — OpenAI API key for AI chat (optional; uses mock replies without it)
