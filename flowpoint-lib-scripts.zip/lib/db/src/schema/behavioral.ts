import { pgTable, text, integer, real, boolean, timestamp, jsonb, uniqueIndex } from "drizzle-orm/pg-core";

export const behaviorEventsTable = pgTable("behavior_events", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  siteUrl: text("site_url").notNull(),
  page: text("page").notNull(),
  eventType: text("event_type").notNull(),
  element: text("element"),
  xPos: integer("x_pos"),
  yPos: integer("y_pos"),
  scrollDepth: integer("scroll_depth"),
  timeOnPage: integer("time_on_page"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const behaviorSessionsTable = pgTable("behavior_sessions", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  userAgent: text("user_agent"),
  deviceType: text("device_type").notNull().default("desktop"),
  country: text("country"),
  pageViews: integer("page_views").notNull().default(1),
  bounce: boolean("bounce").notNull().default(false),
  engagementScore: integer("engagement_score").notNull().default(0),
  rageClicks: integer("rage_clicks").notNull().default(0),
  exitPage: text("exit_page"),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
});

export const behaviorInsightsTable = pgTable("behavior_insights", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  insightType: text("insight_type").notNull(),
  severity: text("severity").notNull().default("medium"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  affectedPages: jsonb("affected_pages"),
  estimatedImpact: text("estimated_impact"),
  aiSuggestion: text("ai_suggestion"),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

// Per-site ingestion tokens — hash stored server-side, bound to org for ownership checks
export const behaviorSiteTokensTable = pgTable("behavior_site_tokens", {
  tokenHash:  text("token_hash").primaryKey(),
  siteUrl:    text("site_url").notNull(),
  orgId:      text("org_id").notNull().default("default"),
  createdAt:  timestamp("created_at").defaultNow().notNull(),
  lastUsedAt: timestamp("last_used_at"),
}, (t) => [
  uniqueIndex("behavior_site_tokens_site_url_idx").on(t.siteUrl),
]);

export type BehaviorEvent = typeof behaviorEventsTable.$inferSelect;
export type BehaviorSession = typeof behaviorSessionsTable.$inferSelect;
export type BehaviorInsight = typeof behaviorInsightsTable.$inferSelect;
export type BehaviorSiteToken = typeof behaviorSiteTokensTable.$inferSelect;
