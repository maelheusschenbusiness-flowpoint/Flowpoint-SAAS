import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const connectorsTable = pgTable("connectors", {
  id: text("id").primaryKey(),
  provider: text("provider").notNull().unique(),
  status: text("status").notNull().default("disconnected"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  workspaceId: text("workspace_id"),
  config: text("config").default("{}"),
  syncStatus: text("sync_status").default("idle"),
  lastSync: text("last_sync"),
  webhookSecret: text("webhook_secret"),
  connected: boolean("connected").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type Connector = typeof connectorsTable.$inferSelect;
