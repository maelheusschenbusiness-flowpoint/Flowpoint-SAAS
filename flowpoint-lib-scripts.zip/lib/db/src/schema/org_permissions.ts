import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const orgPermissionsTable = pgTable("org_permissions", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  role: text("role").notNull(),
  module: text("module").notNull(),
  canRead: boolean("can_read").notNull().default(true),
  canWrite: boolean("can_write").notNull().default(false),
  canAdmin: boolean("can_admin").notNull().default(false),
  canExport: boolean("can_export").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type OrgPermission = typeof orgPermissionsTable.$inferSelect;
