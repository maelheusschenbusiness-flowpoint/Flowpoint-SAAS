import { pgTable, text, integer, real, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const auditsTable = pgTable("audits", {
  id:        text("id").primaryKey(),
  orgId:     text("org_id").notNull().default("default"),
  url:       text("url").notNull(),
  score:     real("score").notNull().default(0),
  status:    text("status").notNull().default("ok"),
  speed:     real("speed").notNull().default(0),
  date:      text("date").notNull(),
  issues:    integer("issues").notNull().default(0),
  origin:    text("origin").notNull().default("manual"),
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => [
  index("audits_org_id_idx").on(t.orgId),
  index("audits_url_idx").on(t.url),
  index("audits_status_idx").on(t.status),
  index("audits_created_at_idx").on(t.createdAt),
  index("audits_org_created_idx").on(t.orgId, t.createdAt),
]);

export const insertAuditSchema = createInsertSchema(auditsTable).omit({ createdAt: true });
export type InsertAudit = z.infer<typeof insertAuditSchema>;
export type Audit = typeof auditsTable.$inferSelect;
