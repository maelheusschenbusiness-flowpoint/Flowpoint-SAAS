import { pgTable, text, real, bigint, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const monitorsTable = pgTable("monitors", {
  id:            text("id").primaryKey(),
  orgId:         text("org_id").notNull().default("default"),
  name:          text("name").notNull(),
  url:           text("url").notNull(),
  status:        text("status").notNull().default("up"),
  uptime:        real("uptime").notNull().default(100),
  latency:       real("latency").notNull().default(0),
  lastCheck:     text("last_check").notNull().default("never"),
  alertEmail:    text("alert_email").default(""),
  alertPhone:    text("alert_phone").default(""),
  isCritical:    boolean("is_critical").default(false),
  frequency:     text("frequency").default("5min"),
  lastAlertSent: bigint("last_alert_sent", { mode: "number" }),
  createdAt:     timestamp("created_at").defaultNow(),
}, (t) => [
  index("monitors_org_id_idx").on(t.orgId),
  index("monitors_status_idx").on(t.status),
  index("monitors_url_idx").on(t.url),
  index("monitors_org_status_idx").on(t.orgId, t.status),
]);

export const insertMonitorSchema = createInsertSchema(monitorsTable).omit({ createdAt: true });
export type InsertMonitor = z.infer<typeof insertMonitorSchema>;
export type Monitor = typeof monitorsTable.$inferSelect;
