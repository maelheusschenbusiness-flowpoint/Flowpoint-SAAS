import { pgTable, text, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const automationWorkflowsTable = pgTable("automation_workflows", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  name: text("name").notNull(),
  icon: text("icon").notNull().default("⚡"),
  description: text("description"),
  triggerType: text("trigger_type").notNull(),
  triggerConfig: jsonb("trigger_config"),
  actions: jsonb("actions").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  runsCount: integer("runs_count").notNull().default(0),
  lastRunAt: timestamp("last_run_at"),
  nextRunAt: timestamp("next_run_at"),
  category: text("category").notNull().default("general"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const workflowRunsTable = pgTable("workflow_runs", {
  id: text("id").primaryKey(),
  workflowId: text("workflow_id").notNull(),
  status: text("status").notNull().default("running"),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
  durationMs: integer("duration_ms"),
  stepsCompleted: integer("steps_completed").notNull().default(0),
  stepsFailed: integer("steps_failed").notNull().default(0),
  error: text("error"),
  output: jsonb("output"),
  metadata: jsonb("metadata"),
});

export type AutomationWorkflow = typeof automationWorkflowsTable.$inferSelect;
export type WorkflowRun = typeof workflowRunsTable.$inferSelect;
