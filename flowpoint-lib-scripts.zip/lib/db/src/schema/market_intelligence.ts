import { pgTable, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const marketInsightsTable = pgTable("market_insights", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  insightType: text("insight_type").notNull(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  impact: text("impact").notNull().default("medium"),
  score: integer("score").notNull().default(50),
  sources: jsonb("sources"),
  aiGenerated: text("ai_generated").notNull().default("true"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
});

export const marketTrendsTable = pgTable("market_trends", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  keyword: text("keyword").notNull(),
  trendDirection: text("trend_direction").notNull().default("stable"),
  momentum: real("momentum").notNull().default(0),
  volumeEstimate: integer("volume_estimate").notNull().default(0),
  competitorCount: integer("competitor_count").notNull().default(0),
  opportunity: text("opportunity"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type MarketInsight = typeof marketInsightsTable.$inferSelect;
export type MarketTrend = typeof marketTrendsTable.$inferSelect;
