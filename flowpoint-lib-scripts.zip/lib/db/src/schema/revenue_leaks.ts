import { pgTable, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const revenueLeaksTable = pgTable("revenue_leaks", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  leakType: text("leak_type").notNull(),
  page: text("page").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  estimatedMonthlyLoss: real("estimated_monthly_loss").notNull().default(0),
  impactScore: integer("impact_score").notNull().default(0),
  fixDifficultyMin: integer("fix_difficulty_min").notNull().default(30),
  quickFix: text("quick_fix"),
  status: text("status").notNull().default("open"),
  metadata: jsonb("metadata"),
  detectedAt: timestamp("detected_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

export const trafficLossesTable = pgTable("traffic_losses", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  reason: text("reason").notNull(),
  pagesAffected: jsonb("pages_affected"),
  estimatedSessionsLost: integer("estimated_sessions_lost").notNull().default(0),
  estimatedRevenueLoss: real("estimated_revenue_loss").notNull().default(0),
  severity: text("severity").notNull().default("medium"),
  detectedAt: timestamp("detected_at").defaultNow().notNull(),
});

export const conversionFailuresTable = pgTable("conversion_failures", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  funnelStep: text("funnel_step").notNull(),
  failureRate: real("failure_rate").notNull().default(0),
  sessionsImpacted: integer("sessions_impacted").notNull().default(0),
  estimatedLossEur: real("estimated_loss_eur").notNull().default(0),
  rootCause: text("root_cause"),
  recommendation: text("recommendation"),
  detectedAt: timestamp("detected_at").defaultNow().notNull(),
});

export type RevenueLeak = typeof revenueLeaksTable.$inferSelect;
export type TrafficLoss = typeof trafficLossesTable.$inferSelect;
export type ConversionFailure = typeof conversionFailuresTable.$inferSelect;
