import { pgTable, text, integer, timestamp, index } from "drizzle-orm/pg-core";

export const competitorsTable = pgTable("competitors", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  name: text("name").notNull(),
  url: text("url").notNull(),
  domainRating: integer("domain_rating").notNull().default(0),
  keywords: integer("keywords").notNull().default(0),
  traffic: integer("traffic").notNull().default(0),
  threatLevel: text("threat_level").notNull().default("low"),
  delta: integer("delta").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => [
  index("competitors_org_id_idx").on(t.orgId),
  index("competitors_url_idx").on(t.url),
  index("competitors_threat_idx").on(t.threatLevel),
]);

export type Competitor = typeof competitorsTable.$inferSelect;
