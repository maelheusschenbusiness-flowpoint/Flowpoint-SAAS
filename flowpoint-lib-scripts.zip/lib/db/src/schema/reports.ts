import { pgTable, text, integer, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const reportsTable = pgTable("reports", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  name: text("name").notNull(),
  type: text("type").notNull().default("PDF"),
  date: text("date").notNull(),
  pages: integer("pages").notNull().default(0),
  shared: boolean("shared").notNull().default(false),
  auditId: text("audit_id").default(""),
  whiteLabel: boolean("white_label").notNull().default(false),
  pdfReady: boolean("pdf_ready").notNull().default(false),
  meetingNotesJson: text("meeting_notes_json").default("[]"),
  dateStart: text("date_start").default(""),
  dateEnd: text("date_end").default(""),
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => [
  index("reports_org_id_idx").on(t.orgId),
  index("reports_created_at_idx").on(t.createdAt),
  index("reports_type_idx").on(t.type),
]);

export const insertReportSchema = createInsertSchema(reportsTable).omit({ createdAt: true });
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;
