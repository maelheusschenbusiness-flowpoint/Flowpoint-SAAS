import { pgTable, text, varchar, bigint, index, uniqueIndex } from "drizzle-orm/pg-core";

export const sessionsTable = pgTable("sessions", {
  id:          varchar("id", { length: 64 }).primaryKey(),
  tokenHash:   varchar("token_hash", { length: 64 }).notNull(),
  userId:      text("user_id").notNull(),
  email:       text("email").notNull(),
  orgId:       text("org_id").notNull().default("default"),
  role:        text("role").notNull().default("viewer"),
  expiresAt:   bigint("expires_at", { mode: "number" }).notNull(),
  createdAt:   bigint("created_at", { mode: "number" }).notNull(),
  lastSeenAt:  bigint("last_seen_at", { mode: "number" }).notNull(),
  userAgent:   text("user_agent"),
  ipHash:      varchar("ip_hash", { length: 64 }),
}, (t) => [
  uniqueIndex("sessions_token_hash_idx").on(t.tokenHash),
  index("sessions_user_id_idx").on(t.userId),
  index("sessions_expires_at_idx").on(t.expiresAt),
]);

export type Session = typeof sessionsTable.$inferSelect;
