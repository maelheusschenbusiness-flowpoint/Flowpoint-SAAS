import { pgTable, text, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const orgAddonsTable = pgTable("org_addons", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  addonKey: text("addon_key").notNull(),
  active: boolean("active").notNull().default(false),
  activatedAt: timestamp("activated_at"),
  expiresAt: timestamp("expires_at"),
  stripeItemId: text("stripe_item_id"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type OrgAddon = typeof orgAddonsTable.$inferSelect;
