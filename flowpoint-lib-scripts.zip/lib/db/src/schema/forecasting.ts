import { pgTable, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const forecastModelsTable = pgTable("forecast_models", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  modelType: text("model_type").notNull(),
  params: jsonb("params"),
  lastTrainedAt: timestamp("last_trained_at"),
  accuracy: real("accuracy"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const forecastSnapshotsTable = pgTable("forecast_snapshots", {
  id: text("id").primaryKey(),
  modelId: text("model_id").notNull(),
  date: text("date").notNull(),
  value: real("value").notNull(),
  metricType: text("metric_type").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const forecastPredictionsTable = pgTable("forecast_predictions", {
  id: text("id").primaryKey(),
  modelId: text("model_id").notNull(),
  date: text("date").notNull(),
  predictedValue: real("predicted_value").notNull(),
  confidenceLow: real("confidence_low").notNull(),
  confidenceHigh: real("confidence_high").notNull(),
  scenario: text("scenario").notNull().default("base"),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
});

export type ForecastModel = typeof forecastModelsTable.$inferSelect;
export type ForecastSnapshot = typeof forecastSnapshotsTable.$inferSelect;
export type ForecastPrediction = typeof forecastPredictionsTable.$inferSelect;
