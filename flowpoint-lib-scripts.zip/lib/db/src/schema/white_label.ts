import { pgTable, text, boolean, integer, timestamp, jsonb } from "drizzle-orm/pg-core";

export const customDomainsTable = pgTable("custom_domains", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  domain: text("domain").notNull(),
  status: text("status").notNull().default("pending"),
  sslActive: boolean("ssl_active").notNull().default(false),
  verificationToken: text("verification_token"),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const reportTemplatesTable = pgTable("report_templates", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  name: text("name").notNull(),
  logoUrl: text("logo_url"),
  primaryColor: text("primary_color").notNull().default("#2563EB"),
  secondaryColor: text("secondary_color").notNull().default("#22c55e"),
  font: text("font").notNull().default("Inter"),
  footerText: text("footer_text"),
  headerText: text("header_text"),
  hideFlowpointBranding: boolean("hide_flowpoint_branding").notNull().default(false),
  customCss: text("custom_css"),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const reportExportsTable = pgTable("report_exports", {
  id: text("id").primaryKey(),
  reportId: text("report_id").notNull(),
  templateId: text("template_id"),
  format: text("format").notNull().default("pdf"),
  filePath: text("file_path"),
  sizeBytes: integer("size_bytes"),
  status: text("status").notNull().default("pending"),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
  downloadedAt: timestamp("downloaded_at"),
  downloadCount: integer("download_count").notNull().default(0),
  metadata: jsonb("metadata"),
});

export type CustomDomain = typeof customDomainsTable.$inferSelect;
export type ReportTemplate = typeof reportTemplatesTable.$inferSelect;
export type ReportExport = typeof reportExportsTable.$inferSelect;
