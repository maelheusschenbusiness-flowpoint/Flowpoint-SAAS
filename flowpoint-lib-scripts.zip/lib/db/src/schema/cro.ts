import { pgTable, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const croRecommendationsTable = pgTable("cro_recommendations", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  page: text("page").notNull(),
  type: text("type").notNull(),
  priority: text("priority").notNull().default("medium"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  implementation: text("implementation"),
  estimatedUplift: real("estimated_uplift").notNull().default(0),
  status: text("status").notNull().default("pending"),
  aiGenerated: text("ai_generated").notNull().default("true"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const croExperimentsTable = pgTable("cro_experiments", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  page: text("page").notNull(),
  name: text("name").notNull(),
  hypothesis: text("hypothesis").notNull(),
  variantA: jsonb("variant_a"),
  variantB: jsonb("variant_b"),
  status: text("status").notNull().default("draft"),
  winner: text("winner"),
  conversionA: real("conversion_a"),
  conversionB: real("conversion_b"),
  confidence: real("confidence"),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const croScoresTable = pgTable("cro_scores", {
  id: text("id").primaryKey(),
  siteUrl: text("site_url").notNull(),
  page: text("page").notNull(),
  overallScore: integer("overall_score").notNull().default(50),
  frictionScore: integer("friction_score").notNull().default(50),
  ctaScore: integer("cta_score").notNull().default(50),
  formScore: integer("form_score").notNull().default(50),
  mobileScore: integer("mobile_score").notNull().default(50),
  copyScore: integer("copy_score").notNull().default(50),
  issues: jsonb("issues"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type CroRecommendation = typeof croRecommendationsTable.$inferSelect;
export type CroExperiment = typeof croExperimentsTable.$inferSelect;
export type CroScore = typeof croScoresTable.$inferSelect;
