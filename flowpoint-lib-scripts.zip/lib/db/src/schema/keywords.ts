import { pgTable, text, integer, timestamp, index } from "drizzle-orm/pg-core";

export const keywordsTable = pgTable("keywords", {
  id:           text("id").primaryKey(),
  orgId:        text("org_id").notNull().default("default"),
  keyword:      text("keyword").notNull(),
  position:     integer("position").notNull().default(0),
  prevPosition: integer("prev_position").notNull().default(0),
  volume:       integer("volume").notNull().default(0),
  difficulty:   integer("difficulty").notNull().default(50),
  trend:        text("trend").notNull().default("stable"),
  intent:       text("intent"),
  url:          text("url"),
  tag:          text("tag"),
  createdAt:    timestamp("created_at").defaultNow(),
  updatedAt:    timestamp("updated_at").defaultNow(),
}, (t) => [
  index("keywords_org_id_idx").on(t.orgId),
  index("keywords_keyword_idx").on(t.keyword),
  index("keywords_position_idx").on(t.position),
  index("keywords_tag_idx").on(t.tag),
  index("keywords_org_keyword_idx").on(t.orgId, t.keyword),
]);

export type Keyword = typeof keywordsTable.$inferSelect;
