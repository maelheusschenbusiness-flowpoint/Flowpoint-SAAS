import { pgTable, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const aiUsageLogsTable = pgTable("ai_usage_logs", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  userId: text("user_id").notNull().default("mael"),
  model: text("model").notNull(),
  feature: text("feature").notNull(),
  creditsUsed: integer("credits_used").notNull().default(0),
  tokensIn: integer("tokens_in").notNull().default(0),
  tokensOut: integer("tokens_out").notNull().default(0),
  costEur: real("cost_eur").notNull().default(0),
  latencyMs: integer("latency_ms").notNull().default(0),
  success: text("success").notNull().default("true"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiMonthlyUsageTable = pgTable("ai_monthly_usage", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  month: text("month").notNull(),
  creditsUsed: integer("credits_used").notNull().default(0),
  creditsLimit: integer("credits_limit").notNull().default(100000),
  creditsExtra: integer("credits_extra").notNull().default(0),
  costEur: real("cost_eur").notNull().default(0),
  requestCount: integer("request_count").notNull().default(0),
  tokensUsed: integer("tokens_used").notNull().default(0),
  resetAt: timestamp("reset_at"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const aiAlertsTable = pgTable("ai_alerts", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull().default("default"),
  alertType: text("alert_type").notNull(),
  message: text("message").notNull(),
  threshold: integer("threshold"),
  currentValue: integer("current_value"),
  triggeredAt: timestamp("triggered_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
  metadata: jsonb("metadata"),
});

export type AiUsageLog = typeof aiUsageLogsTable.$inferSelect;
export type AiMonthlyUsage = typeof aiMonthlyUsageTable.$inferSelect;
export type AiAlert = typeof aiAlertsTable.$inferSelect;
